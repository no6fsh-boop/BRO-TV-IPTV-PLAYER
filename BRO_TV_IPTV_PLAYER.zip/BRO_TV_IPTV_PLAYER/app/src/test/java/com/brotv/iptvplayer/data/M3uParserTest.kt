package com.brotv.iptvplayer.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M3uParserTest {
    @Test
    fun parsesLiveMovieSeriesAndEpg() {
        val text = """#EXTM3U x-tvg-url="epg.xml"
#EXTINF:-1 tvg-id="news" group-title="Live",News FHD
/live/news.m3u8
#EXTINF:-1 group-title="Movies",Desert Film
/movie/1.mp4
#EXTINF:-1 group-title="Series",Saga S02E03
/series/3.mp4
""".trimIndent()
        val c = M3uParser().parse(text, "https://example.com/list.m3u", "Demo")
        assertEquals(1, c.channels.size)
        assertEquals(1, c.movies.size)
        assertEquals(1, c.series.size)
        assertEquals(2, c.series.single().episodes.single().season)
        assertEquals(3, c.series.single().episodes.single().episode)
        assertEquals("https://example.com/epg.xml", c.m3uEpgUrl)
        assertTrue(c.channels.single().streamUrl.startsWith("https://example.com/"))
    }
    @Test
    fun acceptsBomAndUsesFirstEpgUrl() {
        val text = "\uFEFF#EXTM3U x-tvg-url=\"epg-a.xml,epg-b.xml\"\n" +
            "#EXTINF:-1 tvg-id=\"one\",One\n/live/one.m3u8\n"
        val c = M3uParser().parse(text, "https://example.com/list.m3u", "Demo")
        assertEquals("https://example.com/epg-a.xml", c.m3uEpgUrl)
        assertEquals(1, c.channels.size)
    }

}
