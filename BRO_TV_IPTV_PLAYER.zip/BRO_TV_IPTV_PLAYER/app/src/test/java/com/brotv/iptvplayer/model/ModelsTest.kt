package com.brotv.iptvplayer.model

import org.junit.Assert.assertEquals
import org.junit.Test

class ModelsTest {
    @Test fun normalizesVariantNames() {
        assertEquals(normalizeVariantKey("News 4K HEVC"), normalizeVariantKey("News FHD h264"))
    }
}
