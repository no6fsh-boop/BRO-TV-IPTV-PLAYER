package com.brotv.iptvplayer.player

import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.PlaybackPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamSelectorTest {
    @Test
    fun healthDropsAfterErrorsAndRebuffers() {
        val book = StreamHealthBook()
        val initial = book.health("a").score
        book.started("a", 1_200)
        val started = book.health("a").score
        book.error("a")
        book.rebuffer("a")
        book.dropped("a", 50)
        val damaged = book.health("a").score

        assertTrue(started >= initial)
        assertTrue(damaged < started)
    }

    @Test
    fun conservativeCapPenalizesExplicitHighFps4kVariant() {
        val book = StreamHealthBook()
        val prefs = PlaybackPreferences(autoBestStream = true, conservative4k60Cap = true)
        val channels = listOf(
            Channel(id = "a", title = "News 4K 120fps", streamUrl = "https://x/a.m3u8"),
            Channel(id = "b", title = "News FHD", streamUrl = "https://x/b.m3u8"),
        )
        val ranked = StreamSelector.rank(channels, prefs, book)
        assertEquals("b", ranked.first().id)
    }
}
