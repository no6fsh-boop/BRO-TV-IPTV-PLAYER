package com.brotv.iptvplayer.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class UrlToolsTest {
    @Test
    fun normalizesHost() {
        assertEquals("https://example.com:8080", UrlTools.normalizeHost("example.com:8080/"))
        assertEquals(
            "https://example.com:8080",
            UrlTools.normalizeHost("https://example.com:8080/player_api.php?username=a&password=b"),
        )
        assertEquals(
            "http://example.com/iptv",
            UrlTools.normalizeHost("http://example.com/iptv/get.php?username=a&password=b"),
        )
    }

    @Test
    fun redactsCredentials() {
        val redacted = UrlTools.redact("https://x/player_api.php?username=alice&password=secret https://x/live/alice/secret/1.ts")
        assertFalse(redacted.contains("alice"))
        assertFalse(redacted.contains("secret"))
    }
}
