package com.brotv.iptvplayer

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.brotv.iptvplayer.data.AppPreferencesStore
import com.brotv.iptvplayer.data.CredentialStore
import com.brotv.iptvplayer.data.ProviderRepository
import com.brotv.iptvplayer.model.Catalog
import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.ContinueItem
import com.brotv.iptvplayer.model.EpgNowNext
import com.brotv.iptvplayer.model.MediaKind
import com.brotv.iptvplayer.model.Movie
import com.brotv.iptvplayer.model.PlaybackPreferences
import com.brotv.iptvplayer.model.PlaybackRequest
import com.brotv.iptvplayer.model.ProviderProfile
import com.brotv.iptvplayer.model.ProviderType
import com.brotv.iptvplayer.model.Series
import com.brotv.iptvplayer.model.SkipSegment
import com.brotv.iptvplayer.player.IntroMarkerProvider
import com.brotv.iptvplayer.player.NoOpIntroMarkerProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface BroScreen {
    data object Login : BroScreen
    data object Home : BroScreen
    data object Live : BroScreen
    data object Movies : BroScreen
    data object SeriesList : BroScreen
    data object Favorites : BroScreen
    data object Settings : BroScreen
    data class MovieDetail(val movieId: String) : BroScreen
    data class SeriesDetail(val seriesId: String) : BroScreen
    data object Player : BroScreen
}

data class AppUiState(
    val screen: BroScreen = BroScreen.Login,
    val loading: Boolean = true,
    val loadingMessage: String = "جاري التحميل…",
    val error: String? = null,
    val profile: ProviderProfile? = null,
    val catalog: Catalog = Catalog(),
    val favorites: Set<String> = emptySet(),
    val continueWatching: List<ContinueItem> = emptyList(),
    val playbackPreferences: PlaybackPreferences = PlaybackPreferences(),
    val selectedSeries: Series? = null,
    val activePlayback: PlaybackRequest? = null,
    val activeEpg: EpgNowNext = EpgNowNext(),
    val introMarkers: List<SkipSegment> = emptyList(),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val credentials = CredentialStore(application)
    private val prefs = AppPreferencesStore(application)
    private val repository = ProviderRepository()
    // Replace this provider with a metadata-backed implementation without changing PlayerScreen.
    private val introMarkerProvider: IntroMarkerProvider = NoOpIntroMarkerProvider
    private val loadedSeries = mutableMapOf<String, Series>()

    private val _ui = MutableStateFlow(
        AppUiState(
            favorites = prefs.favorites(),
            continueWatching = prefs.history(),
            playbackPreferences = prefs.loadPlaybackPreferences(),
        )
    )
    val ui: StateFlow<AppUiState> = _ui.asStateFlow()

    init {
        val saved = credentials.load()
        if (saved == null) {
            _ui.update { it.copy(loading = false, screen = BroScreen.Login) }
        } else {
            connect(saved, saveOnSuccess = false)
        }
    }

    fun loginM3u(name: String, url: String) {
        connect(
            ProviderProfile(
                name = name.ifBlank { "M3U" },
                type = ProviderType.M3U,
                m3uUrl = url.trim(),
            )
        )
    }

    fun loginXtream(name: String, host: String, username: String, password: String) {
        connect(
            ProviderProfile(
                name = name.ifBlank { "Xtream" },
                type = ProviderType.XTREAM,
                host = host.trim(),
                username = username.trim(),
                password = password,
            )
        )
    }

    private fun connect(profile: ProviderProfile, saveOnSuccess: Boolean = true) {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, loadingMessage = "جاري الاتصال بالمزوّد…", error = null) }
            runCatching { repository.connect(profile) }
                .onSuccess { catalog ->
                    if (saveOnSuccess) credentials.save(profile)
                    _ui.update {
                        it.copy(
                            loading = false,
                            screen = BroScreen.Home,
                            profile = profile,
                            catalog = catalog,
                            favorites = prefs.favorites(),
                            continueWatching = prefs.history(),
                            error = null,
                        )
                    }
                }
                .onFailure { e ->
                    _ui.update {
                        it.copy(
                            loading = false,
                            screen = BroScreen.Login,
                            error = e.message?.take(240) ?: "تعذر الاتصال بالمزوّد",
                        )
                    }
                }
        }
    }

    fun logout() {
        credentials.clear()
        loadedSeries.clear()
        _ui.update {
            AppUiState(
                screen = BroScreen.Login,
                loading = false,
                favorites = prefs.favorites(),
                continueWatching = prefs.history(),
                playbackPreferences = prefs.loadPlaybackPreferences(),
            )
        }
    }

    fun refreshCatalog() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, loadingMessage = "جاري تحديث القائمة…", error = null) }
            runCatching { repository.refresh() }
                .onSuccess { catalog -> _ui.update { it.copy(loading = false, catalog = catalog) } }
                .onFailure { e -> _ui.update { it.copy(loading = false, error = e.message ?: "فشل التحديث") } }
        }
    }

    fun navigate(screen: BroScreen) {
        _ui.update { it.copy(screen = screen, error = null) }
    }

    fun openMovie(movie: Movie) = navigate(BroScreen.MovieDetail(movie.id))

    fun openSeries(series: Series) {
        _ui.update { it.copy(screen = BroScreen.SeriesDetail(series.id), selectedSeries = loadedSeries[series.id] ?: series, error = null) }
        if (series.episodes.isEmpty() && loadedSeries[series.id] == null) {
            viewModelScope.launch {
                _ui.update { it.copy(loading = true, loadingMessage = "جاري تحميل الحلقات…") }
                runCatching { repository.loadSeries(series) }
                    .onSuccess { loaded ->
                        loadedSeries[series.id] = loaded
                        _ui.update { it.copy(loading = false, selectedSeries = loaded) }
                    }
                    .onFailure { e -> _ui.update { it.copy(loading = false, error = e.message ?: "تعذر تحميل الحلقات") } }
            }
        }
    }

    fun playChannel(channel: Channel) {
        val alternatives = repository.alternativesFor(channel)
        val request = PlaybackRequest(
            id = channel.id,
            title = channel.title,
            kind = MediaKind.LIVE,
            streamUrl = channel.streamUrl,
            channelAlternatives = alternatives,
        )
        _ui.update {
            it.copy(
                screen = BroScreen.Player,
                activePlayback = request,
                activeEpg = EpgNowNext(),
                introMarkers = emptyList(),
            )
        }
        loadEpg(channel)
    }

    fun stepLive(delta: Int) {
        val state = _ui.value
        val currentId = state.activePlayback?.id ?: return
        val list = state.catalog.channels
        if (list.isEmpty()) return
        val index = list.indexOfFirst { it.id == currentId }.let { if (it < 0) 0 else it }
        val newIndex = (index + delta).floorMod(list.size)
        playChannel(list[newIndex])
    }

    fun tuneLive(channelNumber: Int) {
        val list = _ui.value.catalog.channels
        if (channelNumber !in 1..list.size) {
            showMessage("رقم القناة غير موجود")
            return
        }
        playChannel(list[channelNumber - 1])
    }

    fun playMovie(movie: Movie) {
        val resume = prefs.history().firstOrNull { it.mediaId == movie.id && it.kind == MediaKind.MOVIE }?.positionMs ?: 0L
        val request = PlaybackRequest(
            id = movie.id,
            title = movie.title,
            kind = MediaKind.MOVIE,
            streamUrl = movie.streamUrl,
            resumePositionMs = resume,
        )
        _ui.update {
            it.copy(
                screen = BroScreen.Player,
                activePlayback = request,
                introMarkers = emptyList(),
            )
        }
        loadIntroMarkers(request)
    }

    fun playEpisode(series: Series, episodeIndex: Int) {
        if (series.episodes.isEmpty()) return
        val idx = episodeIndex.coerceIn(0, series.episodes.lastIndex)
        val ep = series.episodes[idx]
        val resume = prefs.history().firstOrNull { it.mediaId == ep.id && it.kind == MediaKind.EPISODE }?.positionMs ?: 0L
        val request = PlaybackRequest(
            id = ep.id,
            title = "${series.title} · ${ep.title}",
            kind = MediaKind.EPISODE,
            streamUrl = ep.streamUrl,
            episodeQueue = series.episodes,
            episodeIndex = idx,
            resumePositionMs = resume,
        )
        _ui.update {
            it.copy(
                screen = BroScreen.Player,
                selectedSeries = series,
                activePlayback = request,
                introMarkers = emptyList(),
            )
        }
        loadIntroMarkers(request)
    }

    fun playNextEpisode() {
        val state = _ui.value
        val request = state.activePlayback ?: return
        if (request.kind != MediaKind.EPISODE) return
        val series = state.selectedSeries ?: return
        val next = request.episodeIndex + 1
        if (next in series.episodes.indices) playEpisode(series, next)
    }

    fun onPlaybackEnded() {
        val state = _ui.value
        val request = state.activePlayback ?: return
        if (request.kind == MediaKind.EPISODE && state.playbackPreferences.autoNextEpisode) {
            val next = request.episodeIndex + 1
            val series = state.selectedSeries
            if (series != null && next in series.episodes.indices) {
                playEpisode(series, next)
                return
            }
        }
        if (request.kind != MediaKind.LIVE) {
            prefs.removeHistory(request.id, request.kind)
            _ui.update { it.copy(continueWatching = prefs.history()) }
        }
    }

    fun onPlaybackProgress(positionMs: Long, durationMs: Long) {
        val request = _ui.value.activePlayback ?: return
        if (request.kind == MediaKind.LIVE || durationMs <= 0) return
        prefs.upsertHistory(
            ContinueItem(
                mediaId = request.id,
                kind = request.kind,
                title = request.title,
                positionMs = positionMs,
                durationMs = durationMs,
                updatedAtMs = System.currentTimeMillis(),
                seriesId = if (request.kind == MediaKind.EPISODE) _ui.value.selectedSeries?.id else null,
                episodeIndex = if (request.kind == MediaKind.EPISODE) request.episodeIndex else -1,
            )
        )
        _ui.update { it.copy(continueWatching = prefs.history()) }
    }

    fun resume(item: ContinueItem) {
        when (item.kind) {
            MediaKind.MOVIE -> _ui.value.catalog.movies.firstOrNull { it.id == item.mediaId }?.let(::playMovie)
                ?: showMessage("العنصر لم يعد موجودًا في القائمة الحالية")
            MediaKind.EPISODE -> resumeEpisode(item)
            else -> Unit
        }
    }

    private fun resumeEpisode(item: ContinueItem) {
        val loadedPair = loadedSeries.values.firstNotNullOfOrNull { series ->
            series.episodes.indexOfFirst { it.id == item.mediaId }
                .takeIf { it >= 0 }
                ?.let { series to it }
        }
        if (loadedPair != null) {
            playEpisode(loadedPair.first, loadedPair.second)
            return
        }

        val seriesId = item.seriesId
        val baseSeries = seriesId?.let { id -> _ui.value.catalog.series.firstOrNull { it.id == id } }
        if (baseSeries == null) {
            showMessage("تعذر العثور على المسلسل المرتبط بهذه الحلقة")
            return
        }

        viewModelScope.launch {
            _ui.update { it.copy(loading = true, loadingMessage = "جاري تجهيز الحلقة…", error = null) }
            runCatching { repository.loadSeries(baseSeries) }
                .onSuccess { loaded ->
                    loadedSeries[loaded.id] = loaded
                    val indexById = loaded.episodes.indexOfFirst { it.id == item.mediaId }
                    val index = when {
                        indexById >= 0 -> indexById
                        item.episodeIndex in loaded.episodes.indices -> item.episodeIndex
                        else -> -1
                    }
                    _ui.update { it.copy(loading = false, selectedSeries = loaded) }
                    if (index >= 0) playEpisode(loaded, index)
                    else showMessage("الحلقة لم تعد موجودة في القائمة الحالية")
                }
                .onFailure { e ->
                    _ui.update { it.copy(loading = false, error = e.message ?: "تعذر تحميل الحلقة") }
                }
        }
    }

    private fun loadIntroMarkers(request: PlaybackRequest) {
        viewModelScope.launch {
            val markers = runCatching { introMarkerProvider.markersFor(request) }.getOrDefault(emptyList())
            // Ignore a late result if the user already changed content.
            if (_ui.value.activePlayback?.id == request.id) {
                _ui.update { it.copy(introMarkers = markers.sortedBy { marker -> marker.startMs }) }
            }
        }
    }

    fun toggleFavorite(id: String) {
        val favorite = id !in _ui.value.favorites
        prefs.setFavorite(id, favorite)
        _ui.update { it.copy(favorites = prefs.favorites()) }
    }

    fun updatePlaybackPreferences(value: PlaybackPreferences) {
        prefs.savePlaybackPreferences(value)
        _ui.update { it.copy(playbackPreferences = value) }
    }

    fun clearContinueWatching() {
        prefs.clearHistory()
        _ui.update { it.copy(continueWatching = emptyList()) }
    }

    fun back() {
        val s = _ui.value.screen
        when (s) {
            BroScreen.Login, BroScreen.Home -> Unit
            BroScreen.Player -> {
                val req = _ui.value.activePlayback
                val destination = when (req?.kind) {
                    MediaKind.LIVE -> BroScreen.Live
                    MediaKind.MOVIE -> BroScreen.Movies
                    MediaKind.EPISODE -> _ui.value.selectedSeries?.let { BroScreen.SeriesDetail(it.id) } ?: BroScreen.SeriesList
                    else -> BroScreen.Home
                }
                _ui.update { it.copy(screen = destination) }
            }
            is BroScreen.MovieDetail -> navigate(BroScreen.Movies)
            is BroScreen.SeriesDetail -> navigate(BroScreen.SeriesList)
            else -> navigate(BroScreen.Home)
        }
    }

    fun dismissError() = _ui.update { it.copy(error = null) }

    private fun loadEpg(channel: Channel) {
        viewModelScope.launch {
            val epg = runCatching { repository.epg(channel) }.getOrDefault(EpgNowNext())
            if (_ui.value.activePlayback?.id == channel.id) {
                _ui.update { it.copy(activeEpg = epg) }
            }
        }
    }

    private fun showMessage(message: String) = _ui.update { it.copy(error = message) }
    private fun Int.floorMod(size: Int): Int = ((this % size) + size) % size
}
