package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tv
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.Catalog
import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.Movie
import com.brotv.iptvplayer.model.Series
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.MediaCard
import com.brotv.iptvplayer.ui.components.ScreenHeader
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun FavoritesScreen(
    catalog: Catalog,
    favorites: Set<String>,
    onPlayChannel: (Channel) -> Unit,
    onOpenMovie: (Movie) -> Unit,
    onOpenSeries: (Series) -> Unit,
    onToggleFavorite: (String) -> Unit,
) {
    val channels = catalog.channels.filter { it.id in favorites }
    val movies = catalog.movies.filter { it.id in favorites }
    val series = catalog.series.filter { it.id in favorites }
    BroBackground {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 50.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            item { ScreenHeader("المفضلة", "${channels.size + movies.size + series.size} عنصر") }
            if (channels.isNotEmpty()) item {
                FavoriteRow("القنوات", channels, { it.id }, { it.title }, { it.logoUrl }, Icons.Default.LiveTv, onPlayChannel, onToggleFavorite)
            }
            if (movies.isNotEmpty()) item {
                FavoriteRow("الأفلام", movies, { it.id }, { it.title }, { it.posterUrl }, Icons.Default.Movie, onOpenMovie, onToggleFavorite)
            }
            if (series.isNotEmpty()) item {
                FavoriteRow("المسلسلات", series, { it.id }, { it.title }, { it.posterUrl }, Icons.Default.Tv, onOpenSeries, onToggleFavorite)
            }
            if (channels.isEmpty() && movies.isEmpty() && series.isEmpty()) item {
                Text("لا توجد عناصر مفضلة. اضغط مطولًا على بطاقة قناة/فيلم/مسلسل لإضافتها.", color = BroTextMuted, fontSize = 19.sp)
            }
        }
    }
}

@Composable
private fun <T> FavoriteRow(
    title: String,
    items: List<T>,
    id: (T) -> String,
    name: (T) -> String,
    imageUrl: (T) -> String?,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: (T) -> Unit,
    onRemove: (String) -> Unit,
) {
    Column {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(9.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(items, key = id) { item ->
                MediaCard(
                    title = name(item),
                    subtitle = "مفضلة",
                    icon = icon,
                    imageUrl = imageUrl(item),
                    onClick = { onClick(item) },
                    onLongClick = { onRemove(id(item)) },
                    modifier = Modifier.width(245.dp).height(138.dp),
                    isFavorite = true,
                )
            }
        }
    }
}
