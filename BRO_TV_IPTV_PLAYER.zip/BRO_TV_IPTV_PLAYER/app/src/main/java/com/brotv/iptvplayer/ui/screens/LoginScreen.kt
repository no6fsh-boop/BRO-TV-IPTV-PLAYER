package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Button
import androidx.tv.material3.OutlinedButton
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.ProviderType
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.BroWordmark
import com.brotv.iptvplayer.ui.components.LabeledInput
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun LoginScreen(
    onM3uLogin: (name: String, url: String) -> Unit,
    onXtreamLogin: (name: String, host: String, username: String, password: String) -> Unit,
) {
    var type by remember { mutableStateOf(ProviderType.XTREAM) }
    var name by remember { mutableStateOf("") }
    var m3uUrl by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    BroBackground {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 72.dp, vertical = 44.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(70.dp),
        ) {
            Column(Modifier.weight(.42f), horizontalAlignment = Alignment.CenterHorizontally) {
                BroWordmark(Modifier.fillMaxWidth().height(150.dp))
                Text("IPTV PLAYER", fontSize = 18.sp, color = BroTextMuted, letterSpacing = 7.sp)
                Spacer(Modifier.height(20.dp))
                Text(
                    "واجهة عربية للتلفزيون · تنقّل كامل بالريموت",
                    fontSize = 16.sp,
                    color = BroTextMuted,
                )
            }

            Column(Modifier.weight(.58f), verticalArrangement = Arrangement.Center) {
                Text("تسجيل الدخول", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("أدخل بيانات مزوّدك. لا توجد بيانات تجريبية مضمّنة.", color = BroTextMuted, fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (type == ProviderType.XTREAM) {
                        Button(onClick = { type = ProviderType.XTREAM }) { Text("Xtream Codes") }
                        OutlinedButton(onClick = { type = ProviderType.M3U }) { Text("M3U URL") }
                    } else {
                        OutlinedButton(onClick = { type = ProviderType.XTREAM }) { Text("Xtream Codes") }
                        Button(onClick = { type = ProviderType.M3U }) { Text("M3U URL") }
                    }
                }

                Spacer(Modifier.height(18.dp))
                LabeledInput("اسم الاشتراك (اختياري)", name, { name = it })
                Spacer(Modifier.height(12.dp))

                if (type == ProviderType.M3U) {
                    LabeledInput("رابط M3U", m3uUrl, { m3uUrl = it }, url = true)
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = { if (m3uUrl.isNotBlank()) onM3uLogin(name, m3uUrl) },
                        enabled = m3uUrl.isNotBlank(),
                    ) { Text("اتصال وتحميل القائمة") }
                } else {
                    LabeledInput("Host — مثال: https://example.com:8080", host, { host = it }, url = true)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        LabeledInput("اسم المستخدم", username, { username = it }, Modifier.weight(1f))
                        LabeledInput("كلمة المرور", password, { password = it }, Modifier.weight(1f), password = true)
                    }
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = { if (host.isNotBlank() && username.isNotBlank() && password.isNotBlank()) onXtreamLogin(name, host, username, password) },
                        enabled = host.isNotBlank() && username.isNotBlank() && password.isNotBlank(),
                    ) { Text("تسجيل الدخول") }
                }

                Spacer(Modifier.height(12.dp))
                Text(
                    "يفضّل HTTPS. بعض مزوّدي IPTV يستخدمون HTTP؛ عندها تكون بيانات الدخول مكشوفة على الشبكة.",
                    color = BroTextMuted,
                    fontSize = 12.sp,
                )
            }
        }
    }
}
