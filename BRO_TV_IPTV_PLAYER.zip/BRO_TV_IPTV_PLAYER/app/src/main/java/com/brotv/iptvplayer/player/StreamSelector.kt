package com.brotv.iptvplayer.player

import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.PlaybackPreferences
import kotlin.math.max

internal data class SourceHealth(
    val sourceId: String,
    val errors: Int = 0,
    val rebuffers: Int = 0,
    val droppedFrames: Int = 0,
    val successfulStarts: Int = 0,
    val totalStartupMs: Long = 0L,
) {
    val averageStartupMs: Long
        get() = if (successfulStarts > 0) totalStartupMs / successfulStarts else 0L

    val score: Int
        get() {
            val startupPenalty = when {
                averageStartupMs <= 0L -> 0
                averageStartupMs < 1_500L -> 0
                averageStartupMs < 3_000L -> 3
                averageStartupMs < 6_000L -> 7
                else -> 12
            }
            val stableStartBonus = successfulStarts.coerceAtMost(4) * 2
            return (
                100 - errors * 22 - rebuffers * 8 - (droppedFrames / 25) * 4 - startupPenalty + stableStartBonus
            ).coerceIn(0, 100)
        }
}

internal class StreamHealthBook {
    private val map = mutableMapOf<String, SourceHealth>()

    fun health(id: String): SourceHealth = map[id] ?: SourceHealth(id)

    fun error(id: String) {
        val h = health(id)
        map[id] = h.copy(errors = h.errors + 1)
    }

    fun rebuffer(id: String) {
        val h = health(id)
        map[id] = h.copy(rebuffers = h.rebuffers + 1)
    }

    fun dropped(id: String, count: Int) {
        val h = health(id)
        map[id] = h.copy(droppedFrames = h.droppedFrames + count)
    }

    fun started(id: String, startupMs: Long) {
        if (startupMs <= 0) return
        val h = health(id)
        map[id] = h.copy(
            successfulStarts = h.successfulStarts + 1,
            totalStartupMs = h.totalStartupMs + startupMs,
        )
    }
}

internal object StreamSelector {
    fun rank(channels: List<Channel>, preferences: PlaybackPreferences, health: StreamHealthBook): List<Channel> {
        if (!preferences.autoBestStream) return channels.distinctBy { it.streamUrl }
        return channels.distinctBy { it.streamUrl }.sortedByDescending { channel ->
            health.health(channel.id).score * 10 + qualityScore(channel.title, preferences)
        }
    }

    private fun qualityScore(title: String, preferences: PlaybackPreferences): Int {
        val t = title.lowercase()
        var score = when {
            "2160" in t || "4k" in t || "uhd" in t -> 90
            "1080" in t || "fhd" in t -> 70
            "720" in t || Regex("\\bhd\\b").containsMatchIn(t) -> 50
            else -> 30
        }
        if ("hevc" in t || "h265" in t || "h.265" in t) score += 5
        if (preferences.conservative4k60Cap && ("90fps" in t || "120fps" in t)) score -= 80
        return max(0, score)
    }
}
