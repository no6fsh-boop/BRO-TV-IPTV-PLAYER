package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.BufferProfile
import com.brotv.iptvplayer.model.PlaybackPreferences
import com.brotv.iptvplayer.model.ProviderProfile
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.Pill
import com.brotv.iptvplayer.ui.components.ScreenHeader
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun SettingsScreen(
    profile: ProviderProfile?,
    preferences: PlaybackPreferences,
    onChange: (PlaybackPreferences) -> Unit,
    onRefresh: () -> Unit,
    onClearHistory: () -> Unit,
    onLogout: () -> Unit,
) {
    BroBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 58.dp, vertical = 30.dp)) {
            ScreenHeader("الإعدادات", profile?.name ?: "لا يوجد اشتراك")
            Spacer(Modifier.height(24.dp))

            SettingSection("التقديم والترجيع") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(10, 15, 30).forEach { seconds ->
                        Button(onClick = { onChange(preferences.copy(seekSeconds = seconds)) }) {
                            Text(if (preferences.seekSeconds == seconds) "✓ $seconds ثانية" else "$seconds ثانية")
                        }
                    }
                }
            }

            SettingSection("التخزين المؤقت") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BufferProfile.entries.forEach { profileValue ->
                        val label = when (profileValue) {
                            BufferProfile.LOW_LATENCY -> "زمن منخفض"
                            BufferProfile.BALANCED -> "متوازن"
                            BufferProfile.STABLE -> "ثابت"
                        }
                        Button(onClick = { onChange(preferences.copy(bufferProfile = profileValue)) }) {
                            Text(if (preferences.bufferProfile == profileValue) "✓ $label" else label)
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Text("إذا تكرر نفاد الـ buffer، يمكن للمشغل ترقية الجلسة تلقائيًا إلى ملف أكثر ثباتًا.", color = BroTextMuted, fontSize = 12.sp)
            }

            SettingSection("سلوك المشغل") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ToggleButton("إعادة الاتصال", preferences.autoReconnect) { onChange(preferences.copy(autoReconnect = !preferences.autoReconnect)) }
                    ToggleButton("Best Stream", preferences.autoBestStream) { onChange(preferences.copy(autoBestStream = !preferences.autoBestStream)) }
                    ToggleButton("الحلقة التالية", preferences.autoNextEpisode) { onChange(preferences.copy(autoNextEpisode = !preferences.autoNextEpisode)) }
                    ToggleButton("حد 4K60", preferences.conservative4k60Cap) { onChange(preferences.copy(conservative4k60Cap = !preferences.conservative4k60Cap)) }
                }
                Spacer(Modifier.height(9.dp))
                Text(
                    "حد 4K60 هو الإعداد المحافظ الافتراضي لـ Google TV Streamer 4K. شاشة الإحصاءات تعرض Source FPS وOutput Refresh كقيمتين منفصلتين؛ التطبيق لا يصف 90fps على أنه إخراج فيديو مدعوم.",
                    color = BroTextMuted,
                    fontSize = 12.sp,
                )
            }

            SettingSection("الاشتراك والأمان") {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onRefresh) { Text("تحديث القائمة") }
                    Button(onClick = onClearHistory) { Text("مسح متابعة المشاهدة") }
                    Button(onClick = onLogout) { Text("تسجيل الخروج وحذف بيانات الدخول") }
                }
                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(profile?.type?.name ?: "—")
                    profile?.host?.let { Pill(it.substringAfter("://").substringBefore('/')) }
                    profile?.m3uUrl?.let { Pill(it.substringAfter("://").substringBefore('/')) }
                }
                Spacer(Modifier.height(7.dp))
                Text(
                    "بيانات المزود مشفّرة محليًا بمفتاح AES-GCM غير قابل للتصدير داخل Android Keystore، والنسخ الاحتياطي للتطبيق معطّل.",
                    color = BroTextMuted,
                    fontSize = 12.sp,
                )
            }
        }
    }
}

@Composable
private fun SettingSection(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 22.dp)) {
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(9.dp))
        content()
    }
}

@Composable
private fun ToggleButton(title: String, enabled: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick) { Text(if (enabled) "✓ $title" else "○ $title") }
}
