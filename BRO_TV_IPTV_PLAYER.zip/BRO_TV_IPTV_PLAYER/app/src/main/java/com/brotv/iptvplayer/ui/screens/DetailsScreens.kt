package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Button
import androidx.tv.material3.Icon
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.Movie
import com.brotv.iptvplayer.model.Series
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.MediaCard
import com.brotv.iptvplayer.ui.components.Pill
import com.brotv.iptvplayer.ui.components.RemoteImage
import com.brotv.iptvplayer.ui.components.ScreenHeader
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun MovieDetailsScreen(
    movie: Movie,
    favorite: Boolean,
    onPlay: () -> Unit,
    onToggleFavorite: () -> Unit,
) {
    BroBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 64.dp, vertical = 34.dp)) {
            ScreenHeader("تفاصيل الفيلم", movie.category)
            Spacer(Modifier.height(50.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(42.dp)) {
                Box(
                    Modifier.width(250.dp).height(350.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF17181C), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (!movie.posterUrl.isNullOrBlank()) {
                        RemoteImage(movie.posterUrl, movie.title, Modifier.fillMaxSize())
                    } else {
                        androidx.tv.material3.Icon(Icons.Default.Movie, null, Modifier.width(150.dp).height(150.dp), tint = Color.White.copy(.45f))
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text(movie.title, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        movie.year?.let { Pill(it) }
                        movie.rating?.let { Pill("★ $it", accent = true) }
                        Pill(movie.category)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(movie.plot ?: "لا يوجد وصف من المزوّد.", color = BroTextMuted, fontSize = 18.sp, maxLines = 7)
                    Spacer(Modifier.height(28.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(onClick = onPlay) {
                            Icon(Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(8.dp))
                            Text("مشاهدة / متابعة")
                        }
                        Button(onClick = onToggleFavorite) {
                            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (favorite) "إزالة من المفضلة" else "إضافة للمفضلة")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SeriesDetailsScreen(
    series: Series,
    favorite: Boolean,
    onPlayEpisode: (Int) -> Unit,
    onToggleFavorite: () -> Unit,
) {
    val seasons = series.episodes.map { it.season }.distinct().sorted()
    var season by remember(series.id, seasons) { mutableIntStateOf(seasons.firstOrNull() ?: 1) }
    val episodes = series.episodes.withIndex().filter { it.value.season == season }

    BroBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 54.dp, vertical = 28.dp)) {
            ScreenHeader(series.title, series.plot ?: series.category) {
                Button(onClick = onToggleFavorite) {
                    Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                    Spacer(Modifier.width(7.dp))
                    Text(if (favorite) "مفضلة" else "إضافة للمفضلة")
                }
            }
            Spacer(Modifier.height(20.dp))
            if (seasons.isNotEmpty()) {
                Text("المواسم", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(seasons, key = { it }) { value ->
                        Button(onClick = { season = value }) { Text("الموسم $value") }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("الحلقات", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    itemsIndexed(episodes, key = { _, pair -> pair.value.id }) { _, pair ->
                        MediaCard(
                            title = pair.value.title,
                            subtitle = "S${pair.value.season} · E${pair.value.episode}",
                            icon = Icons.Default.PlayArrow,
                            imageUrl = series.posterUrl,
                            onClick = { onPlayEpisode(pair.index) },
                            modifier = Modifier.width(280.dp).height(145.dp),
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("بعد انتهاء الحلقة، يشغّل التطبيق الحلقة التالية تلقائيًا إذا كان الخيار مفعّلًا في الإعدادات.", color = BroTextMuted, fontSize = 14.sp)
            } else {
                Text("لا توجد حلقات متاحة من المزوّد.", color = BroTextMuted, fontSize = 20.sp)
            }
        }
    }
}
