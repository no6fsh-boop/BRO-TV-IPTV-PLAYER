package com.brotv.iptvplayer.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.brotv.iptvplayer.model.ProviderProfile
import com.brotv.iptvplayer.model.ProviderType
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores provider credentials encrypted at rest with a non-exportable Android Keystore AES key.
 * Only ciphertext + IV are stored in SharedPreferences. App backup is disabled in the manifest.
 */
class CredentialStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(profile: ProviderProfile) {
        val json = JSONObject().apply {
            put("id", profile.id)
            put("name", profile.name)
            put("type", profile.type.name)
            put("m3uUrl", profile.m3uUrl)
            put("host", profile.host)
            put("username", profile.username)
            put("password", profile.password)
        }.toString().toByteArray(Charsets.UTF_8)

        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(json)
        prefs.edit()
            .putString(KEY_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString(KEY_DATA, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .apply()
    }

    fun load(): ProviderProfile? = runCatching {
        val iv = prefs.getString(KEY_IV, null) ?: return null
        val data = prefs.getString(KEY_DATA, null) ?: return null
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(
            Cipher.DECRYPT_MODE,
            getOrCreateKey(),
            GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)),
        )
        val clear = cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)).toString(Charsets.UTF_8)
        val json = JSONObject(clear)
        ProviderProfile(
            id = json.getString("id"),
            name = json.optString("name", "IPTV"),
            type = ProviderType.valueOf(json.getString("type")),
            m3uUrl = json.optNullable("m3uUrl"),
            host = json.optNullable("host"),
            username = json.optNullable("username"),
            password = json.optNullable("password"),
        )
    }.getOrNull()

    fun clear() {
        prefs.edit().clear().apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun JSONObject.optNullable(key: String): String? =
        if (has(key) && !isNull(key)) optString(key).takeIf { it.isNotBlank() } else null

    companion object {
        private const val PREFS = "bro_secure_credentials"
        private const val KEY_ALIAS = "bro_tv_provider_credentials_v1"
        private const val KEY_IV = "iv"
        private const val KEY_DATA = "data"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
