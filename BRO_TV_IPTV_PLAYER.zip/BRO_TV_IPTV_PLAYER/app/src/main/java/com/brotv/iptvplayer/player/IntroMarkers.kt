package com.brotv.iptvplayer.player

import com.brotv.iptvplayer.model.PlaybackRequest
import com.brotv.iptvplayer.model.SkipSegment

/**
 * Extension point for provider/editor supplied skip markers.
 * BRO TV deliberately does not pretend to detect intros without metadata.
 */
interface IntroMarkerProvider {
    suspend fun markersFor(request: PlaybackRequest): List<SkipSegment>
}

object NoOpIntroMarkerProvider : IntroMarkerProvider {
    override suspend fun markersFor(request: PlaybackRequest): List<SkipSegment> = emptyList()
}
