package com.brotv.iptvplayer

import android.app.Application

class BroTvApplication : Application()
