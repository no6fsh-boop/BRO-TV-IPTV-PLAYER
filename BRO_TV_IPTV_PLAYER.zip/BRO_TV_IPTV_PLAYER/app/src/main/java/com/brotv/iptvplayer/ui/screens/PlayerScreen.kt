package com.brotv.iptvplayer.ui.screens

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.EpgNowNext
import com.brotv.iptvplayer.model.MediaKind
import com.brotv.iptvplayer.model.PlaybackPreferences
import com.brotv.iptvplayer.model.PlaybackRequest
import com.brotv.iptvplayer.model.SkipSegment
import com.brotv.iptvplayer.player.PlayerEngine
import com.brotv.iptvplayer.ui.components.Pill
import com.brotv.iptvplayer.ui.theme.BroRed
import com.brotv.iptvplayer.ui.theme.BroTextMuted
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    request: PlaybackRequest,
    preferences: PlaybackPreferences,
    epg: EpgNowNext,
    introMarkers: List<SkipSegment> = emptyList(),
    liveChannelNumber: Int? = null,
    liveChannelCount: Int = 0,
    onChangeLive: (Int) -> Unit,
    onTuneLiveNumber: (Int) -> Unit,
    onEnded: () -> Unit,
    onNextEpisode: () -> Unit,
    onProgress: (Long, Long) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val latestEnded by rememberUpdatedState(onEnded)
    val latestProgress by rememberUpdatedState(onProgress)
    val engine = remember(context) {
        PlayerEngine(
            context = context,
            initialPreferences = preferences,
            onEnded = { latestEnded() },
            onProgress = { p, d -> latestProgress(p, d) },
        )
    }
    val player by engine.player.collectAsState()
    val stats by engine.stats.collectAsState()
    val message by engine.message.collectAsState()
    var showInfo by remember(request.id) { mutableStateOf(true) }
    var positionMs by remember(request.id) { mutableLongStateOf(request.resumePositionMs) }
    var numericEntry by remember(request.id) { mutableStateOf("") }
    val dpadFocus = remember { FocusRequester() }

    BackHandler { onBack() }
    LaunchedEffect(Unit) { dpadFocus.requestFocus() }

    LaunchedEffect(preferences) { engine.updatePreferences(preferences) }
    LaunchedEffect(request.id, request.streamUrl) {
        showInfo = true
        engine.play(request, preferences)
    }
    LaunchedEffect(showInfo, request.id) {
        if (showInfo) {
            delay(5_500)
            showInfo = false
        }
    }
    LaunchedEffect(request.id) {
        while (true) {
            positionMs = engine.currentPosition()
            delay(500)
        }
    }
    LaunchedEffect(numericEntry) {
        if (numericEntry.isNotBlank()) {
            delay(1_200)
            val number = numericEntry.toIntOrNull()
            numericEntry = ""
            if (number != null) onTuneLiveNumber(number)
        }
    }
    DisposableEffect(Unit) { onDispose { engine.release() } }

    val activeSkip = introMarkers.firstOrNull { positionMs in it.startMs until it.endMs }
    val nextEpisode = if (request.kind == MediaKind.EPISODE && request.episodeIndex >= 0) {
        request.episodeQueue.getOrNull(request.episodeIndex + 1)
    } else null

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(dpadFocus)
            .focusable()
            .onPreviewKeyEvent { key ->
                if (key.type != KeyEventType.KeyDown || key.nativeKeyEvent.repeatCount > 0) return@onPreviewKeyEvent false
                when (key.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> if (request.kind == MediaKind.LIVE) {
                        onChangeLive(-1); true
                    } else false
                    KeyEvent.KEYCODE_DPAD_DOWN -> if (request.kind == MediaKind.LIVE) {
                        onChangeLive(+1); true
                    } else false
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        showInfo = !showInfo; true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> if (request.kind != MediaKind.LIVE) {
                        engine.seekBy(-preferences.seekSeconds * 1000L); showInfo = true; true
                    } else false
                    KeyEvent.KEYCODE_DPAD_RIGHT -> if (request.kind != MediaKind.LIVE) {
                        engine.seekBy(preferences.seekSeconds * 1000L); showInfo = true; true
                    } else false
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        engine.togglePlayPause(); showInfo = true; true
                    }
                    in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> if (request.kind == MediaKind.LIVE) {
                        val digit = key.nativeKeyEvent.keyCode - KeyEvent.KEYCODE_0
                        if (numericEntry.length < 4) numericEntry += digit.toString()
                        showInfo = true
                        true
                    } else false
                    else -> false
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    keepScreenOn = true
                    isFocusable = false
                    isFocusableInTouchMode = false
                    this.player = player
                }
            },
            update = { view -> view.player = player },
            modifier = Modifier.fillMaxSize(),
        )

        if (numericEntry.isNotBlank()) {
            Box(
                Modifier.align(Alignment.TopStart)
                    .padding(34.dp)
                    .background(Color(0xDD111214), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text("قناة $numericEntry", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (showInfo) {
            Box(
                Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE050505))))
                    .padding(horizontal = 42.dp, vertical = 26.dp)
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (request.kind == MediaKind.LIVE && liveChannelNumber != null) {
                                    Pill("$liveChannelNumber/$liveChannelCount", accent = true)
                                }
                                Text(request.title, fontSize = 28.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                            if (request.kind == MediaKind.LIVE) {
                                epg.now?.let { now ->
                                    Text("الآن: ${now.title} · ${time(now.startEpochSeconds)}–${time(now.endEpochSeconds)}", color = BroTextMuted, fontSize = 14.sp)
                                }
                                epg.next?.let { next -> Text("التالي: ${next.title} · ${time(next.startEpochSeconds)}", color = BroTextMuted, fontSize = 12.sp) }
                                epg.now?.let { now ->
                                    Spacer(Modifier.height(7.dp))
                                    val fraction = epgProgress(now.startEpochSeconds, now.endEpochSeconds)
                                    Box(Modifier.fillMaxWidth(.55f).height(4.dp).background(Color.White.copy(alpha = .18f))) {
                                        Box(Modifier.fillMaxWidth(fraction).height(4.dp).background(BroRed))
                                    }
                                }
                            } else {
                                Text(positionText(positionMs, engine.duration()), color = BroTextMuted, fontSize = 13.sp)
                            }
                        }
                        if (activeSkip != null) {
                            Button(onClick = { engine.skipTo(activeSkip.endMs) }) { Text(activeSkip.label) }
                            Spacer(Modifier.width(10.dp))
                        }
                        if (nextEpisode != null) {
                            Button(onClick = onNextEpisode) { Text("الحلقة التالية") }
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Pill(resolution(stats.width, stats.height), accent = true)
                        Pill("Source FPS ${formatHz(stats.sourceFps)}")
                        Pill("Output Refresh ${formatHz(stats.outputRefreshHz)} Hz")
                        Pill(stats.codec)
                        Pill(if (stats.bitrate > 0) "Stream ${"%.1f".format(Locale.US, stats.bitrate / 1_000_000f)} Mbps" else "Stream bitrate —")
                        if (stats.networkBitrate > 0) Pill("Network ${"%.1f".format(Locale.US, stats.networkBitrate / 1_000_000f)} Mbps")
                        Pill(stats.hdr)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Pill("Dropped ${stats.droppedFrames}")
                        Pill("Health ${stats.sourceHealth}/100", accent = stats.sourceHealth >= 75)
                        if (stats.startupMs > 0) Pill("Start ${stats.startupMs}ms")
                        if (stats.rebuffers > 0) Pill("Rebuffer ${stats.rebuffers}")
                        if (stats.reconnects > 0) Pill("Reconnect ${stats.reconnects}")
                        if (stats.activeSourceLabel.isNotBlank()) Pill("Best: ${stats.activeSourceLabel}")
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(
                        if (request.kind == MediaKind.LIVE)
                            "↑/↓ تغيير القناة · 0–9 رقم القناة · OK معلومات · Back رجوع"
                        else
                            "←/→ ${preferences.seekSeconds}s · OK معلومات · Play/Pause · Back رجوع",
                        color = BroTextMuted,
                        fontSize = 12.sp,
                    )
                    message?.let { Text(it, color = BroRed, fontSize = 12.sp) }
                }
            }
        }
    }
}

private fun epgProgress(start: Long, end: Long): Float {
    if (end <= start) return 0f
    val now = System.currentTimeMillis() / 1000L
    return ((now - start).toFloat() / (end - start).toFloat()).coerceIn(0f, 1f)
}

private fun resolution(width: Int, height: Int): String = when {
    width <= 0 || height <= 0 -> "Resolution —"
    height >= 2160 -> "${width}×${height} 4K"
    height >= 1080 -> "${width}×${height} FHD"
    height >= 720 -> "${width}×${height} HD"
    else -> "${width}×${height}"
}

private fun formatHz(value: Float): String = if (value > 0) "%.2f".format(Locale.US, value) else "—"
private fun time(epochSeconds: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(epochSeconds * 1000))
private fun positionText(positionMs: Long, durationMs: Long): String {
    fun f(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }
    return if (durationMs > 0) "${f(positionMs)} / ${f(durationMs)}" else f(positionMs)
}
