package com.brotv.iptvplayer.data

import android.content.Context
import com.brotv.iptvplayer.model.BufferProfile
import com.brotv.iptvplayer.model.ContinueItem
import com.brotv.iptvplayer.model.MediaKind
import com.brotv.iptvplayer.model.PlaybackPreferences
import org.json.JSONArray
import org.json.JSONObject

class AppPreferencesStore(context: Context) {
    private val prefs = context.getSharedPreferences("bro_tv_preferences", Context.MODE_PRIVATE)

    fun loadPlaybackPreferences(): PlaybackPreferences = PlaybackPreferences(
        seekSeconds = prefs.getInt("seek_seconds", 15).takeIf { it in setOf(10, 15, 30) } ?: 15,
        autoReconnect = prefs.getBoolean("auto_reconnect", true),
        autoBestStream = prefs.getBoolean("auto_best_stream", true),
        autoNextEpisode = prefs.getBoolean("auto_next_episode", true),
        bufferProfile = runCatching {
            BufferProfile.valueOf(prefs.getString("buffer_profile", BufferProfile.BALANCED.name)!!)
        }.getOrDefault(BufferProfile.BALANCED),
        conservative4k60Cap = prefs.getBoolean("cap_4k60", true),
    )

    fun savePlaybackPreferences(value: PlaybackPreferences) {
        prefs.edit()
            .putInt("seek_seconds", value.seekSeconds)
            .putBoolean("auto_reconnect", value.autoReconnect)
            .putBoolean("auto_best_stream", value.autoBestStream)
            .putBoolean("auto_next_episode", value.autoNextEpisode)
            .putString("buffer_profile", value.bufferProfile.name)
            .putBoolean("cap_4k60", value.conservative4k60Cap)
            .apply()
    }

    fun favorites(): Set<String> = prefs.getStringSet("favorites", emptySet())?.toSet().orEmpty()

    fun setFavorite(stableId: String, favorite: Boolean) {
        val updated = favorites().toMutableSet().apply {
            if (favorite) add(stableId) else remove(stableId)
        }
        prefs.edit().putStringSet("favorites", updated).apply()
    }

    fun history(): List<ContinueItem> = runCatching {
        val arr = JSONArray(prefs.getString("continue_watching", "[]"))
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    ContinueItem(
                        mediaId = o.getString("mediaId"),
                        kind = MediaKind.valueOf(o.getString("kind")),
                        title = o.getString("title"),
                        positionMs = o.getLong("positionMs"),
                        durationMs = o.getLong("durationMs"),
                        updatedAtMs = o.getLong("updatedAtMs"),
                        seriesId = o.optString("seriesId").takeIf { it.isNotBlank() },
                        episodeIndex = o.optInt("episodeIndex", -1),
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    /** Stores only stable IDs and positions; never stores credential-bearing Xtream stream URLs. */
    fun upsertHistory(item: ContinueItem) {
        val list = history().filterNot { it.mediaId == item.mediaId && it.kind == item.kind }.toMutableList()
        if (item.durationMs > 0 && item.positionMs in 10_000 until (item.durationMs - 10_000).coerceAtLeast(10_001)) {
            list.add(0, item)
        }
        val arr = JSONArray()
        list.sortedByDescending { it.updatedAtMs }.take(40).forEach { h ->
            arr.put(JSONObject().apply {
                put("mediaId", h.mediaId)
                put("kind", h.kind.name)
                put("title", h.title)
                put("positionMs", h.positionMs)
                put("durationMs", h.durationMs)
                put("updatedAtMs", h.updatedAtMs)
                h.seriesId?.let { put("seriesId", it) }
                put("episodeIndex", h.episodeIndex)
            })
        }
        prefs.edit().putString("continue_watching", arr.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().remove("continue_watching").apply()
    }

    fun removeHistory(mediaId: String, kind: MediaKind) {
        val arr = JSONArray()
        history().filterNot { it.mediaId == mediaId && it.kind == kind }.forEach { h ->
            arr.put(JSONObject().apply {
                put("mediaId", h.mediaId)
                put("kind", h.kind.name)
                put("title", h.title)
                put("positionMs", h.positionMs)
                put("durationMs", h.durationMs)
                put("updatedAtMs", h.updatedAtMs)
                h.seriesId?.let { put("seriesId", it) }
                put("episodeIndex", h.episodeIndex)
            })
        }
        prefs.edit().putString("continue_watching", arr.toString()).apply()
    }
}
