package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tv
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.Series
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.MediaCard
import com.brotv.iptvplayer.ui.components.RemoteImage
import com.brotv.iptvplayer.ui.components.ScreenHeader
import com.brotv.iptvplayer.ui.theme.BroRed
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun SeriesScreen(
    series: List<Series>,
    favorites: Set<String>,
    onOpenSeries: (Series) -> Unit,
    onToggleFavorite: (String) -> Unit,
) {
    val hero = series.firstOrNull()
    val groups = series.groupBy { it.category }.entries.sortedBy { it.key }
    BroBackground {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 26.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item { ScreenHeader("المسلسلات", "مواسم · حلقات · الحلقة التالية تلقائيًا") }
            if (hero != null) {
                item {
                    Box(
                        Modifier.fillMaxWidth().height(215.dp)
                            .background(Brush.horizontalGradient(listOf(Color(0xFF4A0B15), Color(0xFF17181C), Color(0xFF080808))))
                            .padding(28.dp)
                    ) {
                        hero.posterUrl?.let { url ->
                            RemoteImage(
                                url = url,
                                contentDescription = hero.title,
                                modifier = Modifier.align(Alignment.CenterEnd).width(370.dp).height(215.dp),
                            )
                        }
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xF9080808), Color(0xC617181C), Color.Transparent)
                                )
                            )
                        )
                        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(.62f)) {
                            Text("واجهة Hero", color = BroRed, fontSize = 14.sp)
                            Text(hero.title, fontSize = 35.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                            Spacer(Modifier.height(8.dp))
                            Text(hero.plot ?: hero.category, color = BroTextMuted, maxLines = 3)
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = { onOpenSeries(hero) }) { Text("عرض المواسم والحلقات") }
                        }
                        if (hero.posterUrl.isNullOrBlank()) {
                            androidx.tv.material3.Icon(Icons.Default.Tv, null, Modifier.align(Alignment.CenterEnd).width(150.dp).height(150.dp), tint = Color.White.copy(.16f))
                        }
                    }
                }
            }
            groups.forEach { (category, itemsInCategory) ->
                item(key = category) {
                    Column {
                        Text(category, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(itemsInCategory, key = { it.id }) { item ->
                                MediaCard(
                                    title = item.title,
                                    subtitle = item.rating?.let { "تقييم $it" } ?: category,
                                    icon = Icons.Default.Tv,
                                    imageUrl = item.posterUrl,
                                    onClick = { onOpenSeries(item) },
                                    onLongClick = { onToggleFavorite(item.id) },
                                    modifier = Modifier.width(245.dp).height(138.dp),
                                    isFavorite = item.id in favorites,
                                )
                            }
                        }
                    }
                }
            }
            if (series.isEmpty()) item { Text("لا توجد مسلسلات في هذه القائمة.", color = BroTextMuted, fontSize = 20.sp) }
        }
    }
}
