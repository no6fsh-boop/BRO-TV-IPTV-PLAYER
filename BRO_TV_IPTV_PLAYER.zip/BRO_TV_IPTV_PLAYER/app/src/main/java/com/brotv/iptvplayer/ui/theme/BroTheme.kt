package com.brotv.iptvplayer.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.darkColorScheme

val BroRed = Color(0xFFFF1834)
val BroRedDark = Color(0xFF8B0715)
val BroBlack = Color(0xFF050505)
val BroSurface = Color(0xFF111214)
val BroSurface2 = Color(0xFF1A1B1E)
val BroTextMuted = Color(0xFFB5B7BD)

private val BroColors = darkColorScheme(
    primary = BroRed,
    onPrimary = Color.White,
    primaryContainer = BroRedDark,
    onPrimaryContainer = Color.White,
    background = BroBlack,
    onBackground = Color.White,
    surface = BroSurface,
    onSurface = Color.White,
    surfaceVariant = BroSurface2,
    onSurfaceVariant = BroTextMuted,
    border = Color(0xFF44454A),
    error = Color(0xFFFF6B6B),
    onError = Color.Black,
)

@Composable
fun BroTvTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BroColors, content = content)
}
