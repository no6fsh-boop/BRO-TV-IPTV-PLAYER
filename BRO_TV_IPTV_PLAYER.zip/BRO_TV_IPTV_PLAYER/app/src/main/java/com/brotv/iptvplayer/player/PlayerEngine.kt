package com.brotv.iptvplayer.player

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.SystemClock
import android.view.Display
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import com.brotv.iptvplayer.model.BufferProfile
import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.MediaKind
import com.brotv.iptvplayer.model.PlaybackPreferences
import com.brotv.iptvplayer.model.PlaybackRequest
import com.brotv.iptvplayer.model.PlaybackStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.min

@UnstableApi
class PlayerEngine(
    context: Context,
    initialPreferences: PlaybackPreferences,
    private val onEnded: () -> Unit = {},
    private val onProgress: (positionMs: Long, durationMs: Long) -> Unit = { _, _ -> },
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val healthBook = StreamHealthBook()
    private val bandwidthMeter = DefaultBandwidthMeter.Builder(appContext).build()
    private var currentTrackSelector: DefaultTrackSelector? = null

    private var preferences = initialPreferences
    private var activeBufferProfile = initialPreferences.bufferProfile
    private var request: PlaybackRequest? = null
    private var candidates: List<Channel> = emptyList()
    private var candidateIndex = 0
    private var reconnectAttempt = 0
    private var hadBeenReady = false
    private var pendingRebuffer = false
    private var candidateStartedAtMs = 0L
    private var firstFrameRecorded = false
    private var progressJob: Job? = null
    private var reconnectJob: Job? = null

    private val _stats = MutableStateFlow(PlaybackStats(outputRefreshHz = outputRefreshHz()))
    val stats: StateFlow<PlaybackStats> = _stats.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    // Lazy initialization is intentional: buildPlayer attaches listeners declared later in this class.
    // Deferring creation until the first access avoids constructor-order hazards.
    private val _player: MutableStateFlow<ExoPlayer> by lazy(LazyThreadSafetyMode.NONE) {
        MutableStateFlow(buildPlayer(activeBufferProfile))
    }
    val player: StateFlow<ExoPlayer> by lazy(LazyThreadSafetyMode.NONE) { _player.asStateFlow() }

    fun play(newRequest: PlaybackRequest, newPreferences: PlaybackPreferences = preferences) {
        preferences = newPreferences
        request = newRequest
        reconnectAttempt = 0
        reconnectJob?.cancel()
        _stats.value = PlaybackStats(outputRefreshHz = outputRefreshHz())
        activeBufferProfile = newPreferences.bufferProfile
        candidates = buildCandidates(newRequest)
        candidateIndex = 0
        playCandidate(candidateIndex, newRequest.resumePositionMs)
        startProgressLoop()
    }

    fun updatePreferences(value: PlaybackPreferences) {
        val capChanged = preferences.conservative4k60Cap != value.conservative4k60Cap
        preferences = value
        if (capChanged) {
            currentTrackSelector?.let(::applyTrackLimits)
        }
    }

    fun seekBy(deltaMs: Long) {
        val p = _player.value
        if (request?.kind == MediaKind.LIVE) return
        val duration = p.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: Long.MAX_VALUE
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, duration))
    }

    fun togglePlayPause() {
        val p = _player.value
        if (p.isPlaying) p.pause() else p.play()
    }

    fun skipTo(positionMs: Long) {
        _player.value.seekTo(positionMs.coerceAtLeast(0L))
    }

    fun release() {
        progressJob?.cancel()
        reconnectJob?.cancel()
        scope.cancel()
        _player.value.release()
    }

    fun currentPosition(): Long = _player.value.currentPosition
    fun duration(): Long = _player.value.duration.takeIf { it != C.TIME_UNSET } ?: 0L

    private fun buildCandidates(req: PlaybackRequest): List<Channel> {
        if (req.kind != MediaKind.LIVE || req.channelAlternatives.isEmpty()) {
            return listOf(
                Channel(
                    id = req.id,
                    title = req.title,
                    streamUrl = req.streamUrl,
                    sourceLabel = "المصدر",
                )
            )
        }
        return StreamSelector.rank(req.channelAlternatives, preferences, healthBook)
    }

    private fun playCandidate(index: Int, positionMs: Long = 0L) {
        if (candidates.isEmpty()) return
        candidateIndex = index.coerceIn(0, candidates.lastIndex)
        val candidate = candidates[candidateIndex]
        val p = _player.value
        val mediaItem = MediaItem.Builder()
            .setMediaId(candidate.id)
            .setUri(candidate.streamUrl)
            .apply {
                val clean = candidate.streamUrl.substringBefore('?')
                when {
                    clean.endsWith(".m3u8", true) -> setMimeType(MimeTypes.APPLICATION_M3U8)
                    clean.endsWith(".mpd", true) -> setMimeType(MimeTypes.APPLICATION_MPD)
                }
            }
            .build()

        hadBeenReady = false
        pendingRebuffer = false
        firstFrameRecorded = false
        candidateStartedAtMs = SystemClock.elapsedRealtime()
        _stats.value = _stats.value.copy(
            activeSourceLabel = candidate.sourceLabel,
            sourceHealth = healthBook.health(candidate.id).score,
            startupMs = 0L,
        )
        _message.value = null
        p.setMediaItem(mediaItem, positionMs)
        p.prepare()
        p.playWhenReady = true
    }

    private fun buildPlayer(profile: BufferProfile): ExoPlayer {
        val trackSelector = DefaultTrackSelector(appContext).also {
            currentTrackSelector = it
            applyTrackLimits(it)
        }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMsForStreaming(
                minBufferMs = when (profile) {
                    BufferProfile.LOW_LATENCY -> 5_000
                    BufferProfile.BALANCED -> 12_000
                    BufferProfile.STABLE -> 25_000
                },
                maxBufferMs = when (profile) {
                    BufferProfile.LOW_LATENCY -> 18_000
                    BufferProfile.BALANCED -> 45_000
                    BufferProfile.STABLE -> 75_000
                },
                bufferForPlaybackMs = when (profile) {
                    BufferProfile.LOW_LATENCY -> 700
                    BufferProfile.BALANCED -> 1_500
                    BufferProfile.STABLE -> 2_500
                },
                bufferForPlaybackAfterRebufferMs = when (profile) {
                    BufferProfile.LOW_LATENCY -> 1_000
                    BufferProfile.BALANCED -> 2_500
                    BufferProfile.STABLE -> 5_000
                },
            )
            .setPrioritizeTimeOverSizeThresholdsForStreaming(true)
            .build()

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("BRO-TV-IPTV-PLAYER/0.2 AndroidTV")
            .setConnectTimeoutMs(12_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)
        val dataSourceFactory = DefaultDataSource.Factory(appContext, httpFactory)
            .setTransferListener(bandwidthMeter)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        return ExoPlayer.Builder(appContext)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setBandwidthMeter(bandwidthMeter)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .also { exo ->
                exo.addListener(playerListener)
                exo.addAnalyticsListener(analyticsListener)
            }
    }

    private fun applyTrackLimits(selector: DefaultTrackSelector) {
        selector.parameters = selector.parameters.buildUpon().apply {
            if (preferences.conservative4k60Cap) {
                setMaxVideoSize(3840, 2160)
                setMaxVideoFrameRate(60)
            } else {
                clearVideoSizeConstraints()
                setMaxVideoFrameRate(Int.MAX_VALUE)
            }
        }.build()
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_BUFFERING -> {
                    if (hadBeenReady) pendingRebuffer = true
                }
                Player.STATE_READY -> {
                    if (pendingRebuffer) registerRebuffer()
                    pendingRebuffer = false
                    hadBeenReady = true
                    reconnectAttempt = 0
                    updateFormatStats()
                }
                Player.STATE_ENDED -> onEnded()
            }
        }

        override fun onRenderedFirstFrame() {
            if (firstFrameRecorded) return
            firstFrameRecorded = true
            val startupMs = (SystemClock.elapsedRealtime() - candidateStartedAtMs).coerceAtLeast(0L)
            val current = candidates.getOrNull(candidateIndex)
            current?.let { healthBook.started(it.id, startupMs) }
            _stats.value = _stats.value.copy(
                startupMs = startupMs,
                sourceHealth = current?.let { healthBook.health(it.id).score } ?: _stats.value.sourceHealth,
            )
        }

        override fun onPlayerError(error: PlaybackException) {
            val current = candidates.getOrNull(candidateIndex)
            current?.let { healthBook.error(it.id) }
            _stats.value = _stats.value.copy(
                sourceHealth = current?.let { healthBook.health(it.id).score } ?: _stats.value.sourceHealth,
            )
            _message.value = "انقطع المصدر — إعادة الاتصال…"
            if (preferences.autoReconnect) scheduleReconnect(current?.id) else _message.value = "تعذر تشغيل المصدر"
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            _stats.value = _stats.value.copy(width = videoSize.width, height = videoSize.height)
            updateFormatStats()
        }

        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
            updateFormatStats()
        }
    }

    private val analyticsListener = object : AnalyticsListener {
        override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
            val current = candidates.getOrNull(candidateIndex)
            current?.let { healthBook.dropped(it.id, droppedFrames) }
            val total = _stats.value.droppedFrames + droppedFrames
            _stats.value = _stats.value.copy(
                droppedFrames = total,
                sourceHealth = current?.let { healthBook.health(it.id).score } ?: _stats.value.sourceHealth,
            )
        }
    }

    private fun registerRebuffer() {
        val current = candidates.getOrNull(candidateIndex)
        current?.let { healthBook.rebuffer(it.id) }
        val count = _stats.value.rebuffers + 1
        _stats.value = _stats.value.copy(
            rebuffers = count,
            sourceHealth = current?.let { healthBook.health(it.id).score } ?: _stats.value.sourceHealth,
        )
        // Adaptive buffering: repeated depletion promotes the session to a more stable profile.
        if (count >= 2 && activeBufferProfile != BufferProfile.STABLE) {
            rebuildPlayer(BufferProfile.STABLE)
        }
    }

    private fun rebuildPlayer(profile: BufferProfile) {
        val old = _player.value
        val pos = old.currentPosition
        val shouldPlay = old.playWhenReady
        old.removeListener(playerListener)
        old.removeAnalyticsListener(analyticsListener)
        old.release()
        activeBufferProfile = profile
        val replacement = buildPlayer(profile)
        _player.value = replacement
        if (candidates.isNotEmpty()) {
            playCandidate(candidateIndex, pos)
            replacement.playWhenReady = shouldPlay
        }
        _message.value = "تم توسيع التخزين المؤقت تلقائيًا"
    }

    private fun scheduleReconnect(failedId: String?) {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            reconnectAttempt += 1
            _stats.value = _stats.value.copy(reconnects = _stats.value.reconnects + 1)
            val delayMs = min(12_000L, 1_000L * (1 shl (reconnectAttempt - 1).coerceIn(0, 3)))
            delay(delayMs)
            if (!isActive) return@launch

            if (preferences.autoBestStream && request?.kind == MediaKind.LIVE && candidates.size > 1) {
                candidates = StreamSelector.rank(candidates, preferences, healthBook)
                val bestOther = candidates.indexOfFirst { it.id != failedId }
                candidateIndex = if (bestOther >= 0) bestOther else 0
            }

            val resumePosition = if (request?.kind == MediaKind.LIVE) 0L else _player.value.currentPosition
            playCandidate(candidateIndex, resumePosition)
        }
    }

    private fun updateFormatStats() {
        val format: Format = _player.value.videoFormat ?: return
        val rawCodec = format.codecs.orEmpty()
        val hdr = when {
            rawCodec.contains("dvhe", true) || rawCodec.contains("dvh1", true) -> "Dolby Vision"
            format.colorInfo?.colorTransfer == C.COLOR_TRANSFER_ST2084 -> "HDR10/PQ"
            format.colorInfo?.colorTransfer == C.COLOR_TRANSFER_HLG -> "HLG"
            format.colorInfo?.colorTransfer == C.COLOR_TRANSFER_SDR -> "SDR"
            else -> "SDR/Unknown"
        }
        val codec = friendlyCodec(rawCodec, format.sampleMimeType)
        _stats.value = _stats.value.copy(
            width = if (format.width > 0) format.width else _stats.value.width,
            height = if (format.height > 0) format.height else _stats.value.height,
            sourceFps = format.frameRate.takeIf { it > 0 } ?: 0f,
            outputRefreshHz = outputRefreshHz(),
            codec = codec,
            bitrate = format.bitrate.takeIf { it > 0 } ?: 0,
            networkBitrate = bandwidthMeter.bitrateEstimate.takeIf { it > 0 } ?: 0L,
            hdr = hdr,
        )
    }

    private fun friendlyCodec(codecs: String, mime: String?): String {
        val c = codecs.lowercase()
        return when {
            "dvhe" in c || "dvh1" in c -> "Dolby Vision"
            "hvc1" in c || "hev1" in c || mime.equals(MimeTypes.VIDEO_H265, true) -> "HEVC/H.265"
            "avc1" in c || "avc3" in c || mime.equals(MimeTypes.VIDEO_H264, true) -> "AVC/H.264"
            "av01" in c || mime.equals(MimeTypes.VIDEO_AV1, true) -> "AV1"
            "vp09" in c || mime.equals(MimeTypes.VIDEO_VP9, true) -> "VP9"
            codecs.isNotBlank() -> codecs.substringBefore(',').take(28)
            !mime.isNullOrBlank() -> mime.substringAfter('/')
            else -> "—"
        }
    }

    private fun outputRefreshHz(): Float {
        val display = (appContext.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager)
            ?.getDisplay(Display.DEFAULT_DISPLAY)
        return display?.mode?.refreshRate ?: display?.refreshRate ?: 0f
    }

    private fun startProgressLoop() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                delay(2_000)
                val p = _player.value
                val duration = p.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: 0L
                val estimate = bandwidthMeter.bitrateEstimate.takeIf { it > 0 } ?: 0L
                if (estimate != _stats.value.networkBitrate) {
                    _stats.value = _stats.value.copy(
                        networkBitrate = estimate,
                        outputRefreshHz = outputRefreshHz(),
                    )
                }
                onProgress(p.currentPosition, duration)
            }
        }
    }
}
