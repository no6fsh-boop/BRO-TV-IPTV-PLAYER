package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.Button
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.Pill
import com.brotv.iptvplayer.ui.components.RemoteImage
import com.brotv.iptvplayer.ui.components.ScreenHeader
import com.brotv.iptvplayer.ui.theme.BroRed
import com.brotv.iptvplayer.ui.theme.BroSurface
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun LiveTvScreen(
    channels: List<Channel>,
    favorites: Set<String>,
    onPlay: (Channel) -> Unit,
    onToggleFavorite: (String) -> Unit,
) {
    val groups = remember(channels) { channels.map { it.group }.distinct().sorted() }
    val channelNumbers = remember(channels) { channels.mapIndexed { index, item -> item.id to (index + 1) }.toMap() }
    var selectedGroup by remember(groups) { mutableStateOf<String?>(null) }
    val visible = remember(channels, selectedGroup) {
        selectedGroup?.let { group -> channels.filter { it.group == group } } ?: channels
    }
    var highlighted by remember(visible) { mutableStateOf(visible.firstOrNull()) }
    val firstChannelFocus = remember { FocusRequester() }
    LaunchedEffect(visible.firstOrNull()?.id) {
        if (visible.isNotEmpty()) firstChannelFocus.requestFocus()
    }

    BroBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 24.dp)) {
            ScreenHeader("البث المباشر", "واجهة قنوات شبيهة بالرسيفر · ↑/↓ داخل المشغل لتغيير القناة")
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.width(230.dp).fillMaxHeight()) {
                    Text("المجموعات", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        item {
                            GroupCard("كل القنوات", selectedGroup == null) { selectedGroup = null }
                        }
                        items(groups, key = { it }) { group ->
                            GroupCard(group, selectedGroup == group) { selectedGroup = group }
                        }
                    }
                }

                Column(Modifier.width(470.dp).fillMaxHeight()) {
                    Text("القنوات (${visible.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        itemsIndexed(visible, key = { _, item -> item.id }) { index, channel ->
                            Card(
                                onClick = { highlighted = channel; onPlay(channel) },
                                onLongClick = { onToggleFavorite(channel.id) },
                                modifier = Modifier
                                    .then(if (index == 0) Modifier.focusRequester(firstChannelFocus) else Modifier)
                                    .onFocusChanged { if (it.isFocused) highlighted = channel },
                                colors = CardDefaults.colors(
                                    containerColor = BroSurface,
                                    focusedContainerColor = Color(0xFF451019),
                                ),
                                border = CardDefaults.border(
                                    border = Border(border = BorderStroke(1.dp, Color(0xFF34363B)), shape = RoundedCornerShape(8.dp)),
                                    focusedBorder = Border(border = BorderStroke(3.dp, BroRed), shape = RoundedCornerShape(8.dp)),
                                ),
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("${channelNumbers[channel.id] ?: (index + 1)}", color = BroTextMuted, modifier = Modifier.width(46.dp))
                                    Box(Modifier.width(34.dp).height(34.dp), contentAlignment = Alignment.Center) {
                                        if (!channel.logoUrl.isNullOrBlank()) {
                                            RemoteImage(channel.logoUrl, channel.title, Modifier.fillMaxSize())
                                        } else {
                                            Icon(Icons.Default.LiveTv, null, tint = Color.White.copy(.82f))
                                        }
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(channel.title, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text(channel.group, color = BroTextMuted, fontSize = 11.sp, maxLines = 1)
                                    }
                                    if (channel.id in favorites) Icon(Icons.Default.Favorite, null, tint = BroRed)
                                }
                            }
                        }
                    }
                }

                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFF251016), Color(0xFF101114), Color(0xFF080808))),
                            RoundedCornerShape(16.dp),
                        )
                        .padding(28.dp)
                ) {
                    Column(Modifier.align(Alignment.CenterStart)) {
                        Box(Modifier.width(110.dp).height(110.dp), contentAlignment = Alignment.Center) {
                            val logo = highlighted?.logoUrl
                            if (!logo.isNullOrBlank()) {
                                RemoteImage(logo, highlighted?.title, Modifier.fillMaxSize())
                            } else {
                                Icon(Icons.Default.LiveTv, null, Modifier.width(90.dp).height(90.dp), tint = Color.White.copy(.28f))
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(highlighted?.title ?: "اختر قناة", fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                        Spacer(Modifier.height(8.dp))
                        highlighted?.let { channel ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Pill(channel.group)
                                Pill(channel.sourceLabel, accent = true)
                            }
                            Spacer(Modifier.height(16.dp))
                            Text(
                                "OK: تشغيل · ضغط مطوّل: مفضلة\nداخل المشغل: ↑/↓ قناة سابقة/تالية · OK معلومات القناة",
                                color = BroTextMuted,
                                fontSize = 14.sp,
                            )
                            Spacer(Modifier.height(18.dp))
                            Button(onClick = { onPlay(channel) }) { Text("تشغيل ملء الشاشة") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupCard(title: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        colors = CardDefaults.colors(
            containerColor = if (selected) Color(0xFF3A0B12) else BroSurface,
            focusedContainerColor = Color(0xFF5A111D),
        ),
        border = CardDefaults.border(
            focusedBorder = Border(border = BorderStroke(2.dp, BroRed), shape = RoundedCornerShape(8.dp))
        ),
    ) {
        Text(title, Modifier.fillMaxWidth().padding(12.dp), maxLines = 1)
    }
}
