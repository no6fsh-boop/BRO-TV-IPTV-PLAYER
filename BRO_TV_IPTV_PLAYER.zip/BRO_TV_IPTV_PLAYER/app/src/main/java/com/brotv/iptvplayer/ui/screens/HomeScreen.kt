package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import com.brotv.iptvplayer.BroScreen
import com.brotv.iptvplayer.model.Catalog
import com.brotv.iptvplayer.model.ContinueItem
import com.brotv.iptvplayer.model.MediaKind
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.HomeActionCard
import com.brotv.iptvplayer.ui.components.MediaCard
import com.brotv.iptvplayer.ui.components.ScreenHeader
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun HomeScreen(
    providerName: String,
    catalog: Catalog,
    continueWatching: List<ContinueItem>,
    onNavigate: (BroScreen) -> Unit,
    onRefresh: () -> Unit,
    onResume: (ContinueItem) -> Unit,
) {
    BroBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 54.dp, vertical = 28.dp)) {
            ScreenHeader(
                title = "الرئيسية",
                subtitle = "$providerName · ${catalog.channels.size} قناة · ${catalog.movies.size} فيلم · ${catalog.series.size} مسلسل",
            )
            Spacer(Modifier.height(20.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                HomeActionCard(
                    title = "البث المباشر",
                    subtitle = "قنوات + EPG",
                    icon = Icons.Default.LiveTv,
                    onClick = { onNavigate(BroScreen.Live) },
                    modifier = Modifier.weight(1f).height(215.dp),
                    initialFocus = true,
                )
                HomeActionCard(
                    title = "الأفلام",
                    subtitle = "VOD + متابعة المشاهدة",
                    icon = Icons.Default.Movie,
                    onClick = { onNavigate(BroScreen.Movies) },
                    modifier = Modifier.weight(1f).height(215.dp),
                )
                HomeActionCard(
                    title = "المسلسلات",
                    subtitle = "مواسم وحلقات",
                    icon = Icons.Default.Tv,
                    onClick = { onNavigate(BroScreen.SeriesList) },
                    modifier = Modifier.weight(1f).height(215.dp),
                )
                HomeActionCard(
                    title = "المفضلة",
                    subtitle = "اضغط مطولًا لإضافة العناصر",
                    icon = Icons.Default.Favorite,
                    onClick = { onNavigate(BroScreen.Favorites) },
                    modifier = Modifier.weight(1f).height(215.dp),
                )
            }

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onRefresh) { Text("تحديث القائمة") }
                Button(onClick = { onNavigate(BroScreen.Settings) }) {
                    androidx.tv.material3.Icon(Icons.Default.Settings, null)
                    Spacer(Modifier.width(8.dp))
                    Text("الإعدادات وإدارة الاشتراك")
                }
            }

            if (continueWatching.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text("متابعة المشاهدة", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("يتم حفظ موضع المشاهدة فقط، بدون حفظ روابط Xtream الحساسة.", color = BroTextMuted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(continueWatching, key = { "${it.kind}-${it.mediaId}" }) { item ->
                        val percent = if (item.durationMs > 0) ((item.positionMs * 100) / item.durationMs).coerceIn(0, 100) else 0
                        val imageUrl = when (item.kind) {
                            MediaKind.MOVIE -> catalog.movies.firstOrNull { it.id == item.mediaId }?.posterUrl
                            MediaKind.EPISODE -> item.seriesId?.let { id -> catalog.series.firstOrNull { it.id == id }?.posterUrl }
                            else -> null
                        }
                        MediaCard(
                            title = item.title,
                            subtitle = "متابعة من $percent%",
                            imageUrl = imageUrl,
                            onClick = { onResume(item) },
                            modifier = Modifier.width(260.dp).height(120.dp),
                        )
                    }
                }
            }
        }
    }
}
