package com.brotv.iptvplayer.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.KeyboardType
import androidx.tv.material3.Border
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import com.brotv.iptvplayer.R
import com.brotv.iptvplayer.ui.theme.BroBlack
import com.brotv.iptvplayer.ui.theme.BroRed
import com.brotv.iptvplayer.ui.theme.BroRedDark
import com.brotv.iptvplayer.ui.theme.BroSurface
import com.brotv.iptvplayer.ui.theme.BroSurface2
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun BroBackground(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF170106), BroBlack, BroBlack, Color(0xFF090001))
                )
            )
    ) { content() }
}

@Composable
fun BroWordmark(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.bro_wordmark),
        contentDescription = "BRO TV",
        modifier = modifier,
    )
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    actions: @Composable () -> Unit = {},
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column {
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(it, color = BroTextMuted, fontSize = 14.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            actions()
            Spacer(Modifier.width(20.dp))
            BroWordmark(Modifier.width(150.dp).height(70.dp))
        }
    }
}

@Composable
fun HomeActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    initialFocus: Boolean = false,
) {
    val requester = remember { FocusRequester() }
    Card(
        onClick = onClick,
        modifier = modifier.then(if (initialFocus) Modifier.focusRequester(requester) else Modifier),
        colors = CardDefaults.colors(
            containerColor = BroSurface,
            focusedContainerColor = BroRedDark,
        ),
        border = CardDefaults.border(
            border = Border(border = BorderStroke(1.dp, Color(0xFF44454A)), shape = RoundedCornerShape(14.dp)),
            focusedBorder = Border(border = BorderStroke(3.dp, Color(0xFFFF6677)), shape = RoundedCornerShape(14.dp)),
        ),
        scale = CardDefaults.scale(focusedScale = 1.04f),
    ) {
        Box(Modifier.fillMaxSize().padding(22.dp)) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(58.dp), tint = Color.White)
                Spacer(Modifier.height(16.dp))
                Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(subtitle, color = BroTextMuted, fontSize = 13.sp)
            }
        }
    }
    if (initialFocus) {
        androidx.compose.runtime.LaunchedEffect(Unit) { requester.requestFocus() }
    }
}

@Composable
fun MediaCard(
    title: String,
    subtitle: String? = null,
    icon: ImageVector = Icons.Default.PlayArrow,
    imageUrl: String? = null,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    isFavorite: Boolean = false,
) {
    Card(
        onClick = onClick,
        onLongClick = onLongClick,
        modifier = modifier,
        colors = CardDefaults.colors(
            containerColor = BroSurface2,
            focusedContainerColor = Color(0xFF3A1017),
        ),
        border = CardDefaults.border(
            border = Border(border = BorderStroke(1.dp, Color(0xFF34363B)), shape = RoundedCornerShape(12.dp)),
            focusedBorder = Border(border = BorderStroke(3.dp, BroRed), shape = RoundedCornerShape(12.dp)),
        ),
        scale = CardDefaults.scale(focusedScale = 1.055f),
    ) {
        Box(Modifier.fillMaxSize()) {
            if (!imageUrl.isNullOrBlank()) {
                RemoteImage(
                    url = imageUrl,
                    contentDescription = title,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.linearGradient(listOf(Color(0xFF22242A), Color(0xFF10090B), Color(0xFF080808)))
                    )
                )
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = .05f),
                                Color.Black.copy(alpha = .20f),
                                if (isFavorite) Color(0xDD3B0D15) else Color.Black.copy(alpha = .88f),
                            )
                        )
                    )
                    .padding(16.dp)
            ) {
                if (imageUrl.isNullOrBlank()) {
                    Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = .8f), modifier = Modifier.size(38.dp))
                }
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 2)
                    subtitle?.let { Text(it, color = BroTextMuted, fontSize = 12.sp, maxLines = 1) }
                }
            }
        }
    }
}

@Composable
fun LabeledInput(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    url: Boolean = false,
) {
    var focused by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, color = if (focused) BroRed else BroTextMuted, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF111214))
                .border(if (focused) 2.dp else 1.dp, if (focused) BroRed else Color(0xFF3B3D42), RoundedCornerShape(10.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 17.sp),
                cursorBrush = SolidColor(BroRed),
                visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(keyboardType = if (url) KeyboardType.Uri else if (password) KeyboardType.Password else KeyboardType.Text),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChangedCompat { focused = it },
            )
            if (value.isBlank()) {
                Text("…", color = Color(0xFF61636A))
            }
        }
    }
}

private fun Modifier.onFocusChangedCompat(block: (Boolean) -> Unit): Modifier =
    this.then(Modifier.onFocusChanged { block(it.isFocused) })

@Composable
fun Pill(text: String, accent: Boolean = false) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (accent) BroRed.copy(alpha = .18f) else Color(0xFF202126))
            .border(1.dp, if (accent) BroRed.copy(alpha = .7f) else Color(0xFF3C3E43), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, fontSize = 11.sp, color = if (accent) Color.White else BroTextMuted)
    }
}
