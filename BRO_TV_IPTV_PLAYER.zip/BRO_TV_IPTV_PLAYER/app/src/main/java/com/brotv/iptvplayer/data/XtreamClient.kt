package com.brotv.iptvplayer.data

import com.brotv.iptvplayer.model.Catalog
import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.Episode
import com.brotv.iptvplayer.model.Movie
import com.brotv.iptvplayer.model.ProviderProfile
import com.brotv.iptvplayer.model.Series
import com.brotv.iptvplayer.model.normalizeVariantKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class XtreamClient(private val http: HttpClient = HttpClient()) {
    private var profile: ProviderProfile? = null
    private var liveExtension: String = "ts"

    fun connect(profile: ProviderProfile): Catalog {
        require(!profile.host.isNullOrBlank() && !profile.username.isNullOrBlank() && !profile.password.isNullOrBlank())
        this.profile = profile.copy(host = UrlTools.normalizeHost(profile.host))
        val auth = JSONObject(http.getText(apiUrl()))
        val userInfo = auth.optJSONObject("user_info") ?: error("استجابة Xtream غير صالحة")
        val authenticated = userInfo.optInt("auth", 0) == 1 &&
            !userInfo.optString("status").equals("Banned", ignoreCase = true) &&
            !userInfo.optString("status").equals("Disabled", ignoreCase = true)
        if (!authenticated) error("تعذر تسجيل الدخول: تحقق من بيانات Xtream Codes")

        val allowed = userInfo.optJSONArray("allowed_output_formats")
        liveExtension = chooseLiveExtension(allowed)

        val liveCategories = fetchCategories("get_live_categories")
        val vodCategories = fetchCategories("get_vod_categories")
        val seriesCategories = fetchCategories("get_series_categories")

        val live = JSONArray(http.getText(apiUrl("get_live_streams")))
        val vod = JSONArray(http.getText(apiUrl("get_vod_streams")))
        val seriesJson = JSONArray(http.getText(apiUrl("get_series")))

        val channels = buildList {
            for (i in 0 until live.length()) {
                val o = live.optJSONObject(i) ?: continue
                val id = o.optString("stream_id").takeIf { it.isNotBlank() } ?: continue
                val title = o.optString("name", "قناة")
                add(
                    Channel(
                        id = "xt-live-$id",
                        title = title,
                        group = liveCategories[o.optString("category_id")] ?: "عام",
                        logoUrl = o.optString("stream_icon").takeIf { it.isNotBlank() },
                        epgId = o.optString("epg_channel_id").takeIf { it.isNotBlank() },
                        streamUrl = liveUrl(id),
                        variantKey = normalizeVariantKey(title),
                        sourceLabel = qualityLabel(title),
                    )
                )
            }
        }

        val movies = buildList {
            for (i in 0 until vod.length()) {
                val o = vod.optJSONObject(i) ?: continue
                val id = o.optString("stream_id").takeIf { it.isNotBlank() } ?: continue
                val ext = o.optString("container_extension", "mp4").ifBlank { "mp4" }
                add(
                    Movie(
                        id = "xt-movie-$id",
                        title = o.optString("name", "فيلم"),
                        category = vodCategories[o.optString("category_id")] ?: "أفلام",
                        posterUrl = o.optString("stream_icon").takeIf { it.isNotBlank() },
                        plot = o.optString("plot").takeIf { it.isNotBlank() },
                        year = o.optString("year").takeIf { it.isNotBlank() },
                        rating = o.optString("rating").takeIf { it.isNotBlank() },
                        streamUrl = movieUrl(id, ext),
                    )
                )
            }
        }

        val series = buildList {
            for (i in 0 until seriesJson.length()) {
                val o = seriesJson.optJSONObject(i) ?: continue
                val id = o.optString("series_id").takeIf { it.isNotBlank() } ?: continue
                add(
                    Series(
                        id = "xt-series-$id",
                        title = o.optString("name", "مسلسل"),
                        category = seriesCategories[o.optString("category_id")] ?: "مسلسلات",
                        posterUrl = o.optString("cover").takeIf { it.isNotBlank() },
                        plot = o.optString("plot").takeIf { it.isNotBlank() },
                        rating = o.optString("rating").takeIf { it.isNotBlank() },
                    )
                )
            }
        }

        val serverName = auth.optJSONObject("server_info")?.optString("url")?.takeIf { it.isNotBlank() }
        return Catalog(
            providerName = profile.name.ifBlank { serverName ?: "Xtream" },
            channels = channels,
            movies = movies,
            series = series,
        )
    }

    fun loadSeries(series: Series): Series {
        if (series.episodes.isNotEmpty()) return series
        val numericId = series.id.removePrefix("xt-series-")
        val json = JSONObject(http.getText(apiUrl("get_series_info", mapOf("series_id" to numericId))))
        val info = json.optJSONObject("info")
        val episodesObject = json.optJSONObject("episodes") ?: JSONObject()
        val episodes = mutableListOf<Episode>()
        val seasonKeys = episodesObject.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }
        seasonKeys.forEach { seasonKey ->
            val array = episodesObject.optJSONArray(seasonKey) ?: return@forEach
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val id = o.optString("id").takeIf { it.isNotBlank() } ?: continue
                val episodeNo = o.optInt("episode_num", i + 1)
                val seasonNo = o.optInt("season", seasonKey.toIntOrNull() ?: 1)
                val ext = o.optString("container_extension", "mp4").ifBlank { "mp4" }
                val duration = o.optJSONObject("info")?.optLong("duration_secs")?.takeIf { it > 0 }
                episodes += Episode(
                    id = "xt-episode-$id",
                    seriesId = series.id,
                    title = o.optString("title", "الحلقة $episodeNo"),
                    season = seasonNo,
                    episode = episodeNo,
                    streamUrl = seriesUrl(id, ext),
                    durationSeconds = duration,
                )
            }
        }
        return series.copy(
            plot = info?.optString("plot")?.takeIf { it.isNotBlank() } ?: series.plot,
            rating = info?.optString("rating")?.takeIf { it.isNotBlank() } ?: series.rating,
            episodes = episodes.sortedWith(compareBy<Episode> { it.season }.thenBy { it.episode }),
        )
    }

    fun shortEpg(streamId: String, limit: Int = 4): String {
        val numeric = streamId.removePrefix("xt-live-")
        return http.getText(apiUrl("get_short_epg", mapOf("stream_id" to numeric, "limit" to limit.toString())))
    }

    private fun fetchCategories(action: String): Map<String, String> = runCatching {
        val arr = JSONArray(http.getText(apiUrl(action)))
        buildMap {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("category_id")
                val name = o.optString("category_name")
                if (id.isNotBlank() && name.isNotBlank()) put(id, name)
            }
        }
    }.getOrDefault(emptyMap())

    private fun apiUrl(action: String? = null, extra: Map<String, String> = emptyMap()): String {
        val p = requireNotNull(profile) { "XtreamClient غير متصل" }
        val base = p.host!!.trimEnd('/') + "/player_api.php"
        val params = linkedMapOf(
            "username" to p.username.orEmpty(),
            "password" to p.password.orEmpty(),
        )
        if (action != null) params["action"] = action
        params.putAll(extra)
        return base + "?" + params.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
    }

    private fun liveUrl(streamId: String): String {
        val p = requireNotNull(profile)
        return "${p.host!!.trimEnd('/')}/live/${path(p.username!!)}/${path(p.password!!)}/$streamId.$liveExtension"
    }

    private fun movieUrl(streamId: String, ext: String): String {
        val p = requireNotNull(profile)
        return "${p.host!!.trimEnd('/')}/movie/${path(p.username!!)}/${path(p.password!!)}/$streamId.${sanitizeExt(ext)}"
    }

    private fun seriesUrl(streamId: String, ext: String): String {
        val p = requireNotNull(profile)
        return "${p.host!!.trimEnd('/')}/series/${path(p.username!!)}/${path(p.password!!)}/$streamId.${sanitizeExt(ext)}"
    }

    private fun chooseLiveExtension(allowed: JSONArray?): String {
        if (allowed == null) return "ts"
        val items = (0 until allowed.length()).map { allowed.optString(it).lowercase() }
        return when {
            "m3u8" in items -> "m3u8"
            "ts" in items -> "ts"
            items.isNotEmpty() -> sanitizeExt(items.first())
            else -> "ts"
        }
    }

    private fun sanitizeExt(value: String): String = value.lowercase().replace(Regex("[^a-z0-9]"), "").ifBlank { "mp4" }
    private fun enc(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
    private fun path(value: String): String = enc(value).replace("+", "%20")

    private fun qualityLabel(title: String): String = when {
        title.contains("4K", true) || title.contains("2160", true) -> "4K"
        title.contains("FHD", true) || title.contains("1080", true) -> "FHD"
        title.contains("HD", true) || title.contains("720", true) -> "HD"
        else -> "Auto"
    }
}
