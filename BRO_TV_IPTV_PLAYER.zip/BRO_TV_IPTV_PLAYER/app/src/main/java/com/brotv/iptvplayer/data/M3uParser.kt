package com.brotv.iptvplayer.data

import com.brotv.iptvplayer.model.Catalog
import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.Episode
import com.brotv.iptvplayer.model.Movie
import com.brotv.iptvplayer.model.Series
import com.brotv.iptvplayer.model.normalizeVariantKey
import java.net.URI
import java.security.MessageDigest

internal data class M3uEntry(
    val title: String,
    val url: String,
    val group: String,
    val tvgId: String?,
    val tvgLogo: String?,
)

class M3uParser {
    fun parse(text: String, sourceUrl: String, providerName: String = "M3U"): Catalog {
        val normalized = text.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        val lines = normalized.lines()
        val header = lines.firstOrNull()?.takeIf { it.startsWith("#EXTM3U") }.orEmpty()
        val epgUrl = (attribute(header, "x-tvg-url")
            ?: attribute(header, "url-tvg")
            ?: attribute(header, "tvg-url"))
            ?.split(',')
            ?.firstOrNull()
            ?.trim()
            ?.takeIf { it.isNotBlank() }

        val entries = mutableListOf<M3uEntry>()
        var extinf: String? = null
        lines.forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> extinf = line
                line.isBlank() || line.startsWith("#") -> Unit
                extinf != null -> {
                    val info = extinf!!
                    val title = info.substringAfterLast(',', "قناة").trim().ifBlank { "قناة" }
                    val group = attribute(info, "group-title")?.ifBlank { null } ?: "عام"
                    val resolved = resolve(sourceUrl, line)
                    entries += M3uEntry(
                        title = title,
                        url = resolved,
                        group = group,
                        tvgId = attribute(info, "tvg-id") ?: attribute(info, "tvg-name"),
                        tvgLogo = attribute(info, "tvg-logo"),
                    )
                    extinf = null
                }
                else -> {
                    // A plain HLS URL/file can still be opened as a one-channel catalog.
                    entries += M3uEntry(
                        title = "البث",
                        url = resolve(sourceUrl, line),
                        group = "عام",
                        tvgId = null,
                        tvgLogo = null,
                    )
                }
            }
        }

        val channels = mutableListOf<Channel>()
        val movies = mutableListOf<Movie>()
        val episodeEntries = mutableListOf<M3uEntry>()

        entries.forEach { e ->
            when {
                looksLikeEpisode(e) -> episodeEntries += e
                looksLikeMovie(e) -> movies += Movie(
                    id = "m3u-movie-${hash(e.url)}",
                    title = e.title,
                    category = e.group,
                    posterUrl = e.tvgLogo,
                    streamUrl = e.url,
                )
                else -> channels += Channel(
                    id = "m3u-live-${hash(e.url)}",
                    title = e.title,
                    group = e.group,
                    logoUrl = e.tvgLogo,
                    epgId = e.tvgId,
                    streamUrl = e.url,
                    variantKey = normalizeVariantKey(e.title),
                    sourceLabel = qualityLabel(e.title),
                )
            }
        }

        val series = episodeEntries
            .groupBy { seriesBaseTitle(it.title) }
            .map { (seriesTitle, eps) ->
                val seriesId = "m3u-series-${hash(seriesTitle)}"
                Series(
                    id = seriesId,
                    title = seriesTitle,
                    category = eps.firstOrNull()?.group ?: "مسلسلات",
                    posterUrl = eps.firstOrNull()?.tvgLogo,
                    episodes = eps.mapIndexed { index, e ->
                        val numbers = episodeNumbers(e.title)
                        Episode(
                            id = "m3u-episode-${hash(e.url)}",
                            seriesId = seriesId,
                            title = e.title,
                            season = numbers?.first ?: 1,
                            episode = numbers?.second ?: (index + 1),
                            streamUrl = e.url,
                        )
                    }.sortedWith(compareBy<Episode> { it.season }.thenBy { it.episode })
                )
            }.sortedBy { it.title }

        return Catalog(
            providerName = providerName,
            channels = channels,
            movies = movies,
            series = series,
            m3uEpgUrl = epgUrl?.let { resolve(sourceUrl, it) },
        )
    }

    private fun looksLikeMovie(e: M3uEntry): Boolean {
        val group = e.group.lowercase()
        return listOf("movie", "movies", "vod", "film", "films", "أفلام", "افلام").any { group.contains(it) }
    }

    private fun looksLikeEpisode(e: M3uEntry): Boolean {
        val group = e.group.lowercase()
        val title = e.title.lowercase()
        return Regex("(?i)\\bS\\d{1,2}E\\d{1,3}\\b").containsMatchIn(title) ||
            listOf("series", "مسلسلات", "episodes", "حلقات").any { group.contains(it) }
    }

    private fun episodeNumbers(title: String): Pair<Int, Int>? {
        val m = Regex("(?i)\\bS(\\d{1,2})E(\\d{1,3})\\b").find(title) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    private fun seriesBaseTitle(title: String): String = title
        .replace(Regex("(?i)\\bS\\d{1,2}E\\d{1,3}\\b.*$"), "")
        .replace(Regex("(?i)[-_ ]+(season|episode|حلقة|الموسم).*$"), "")
        .trim().ifBlank { title }

    private fun attribute(line: String, key: String): String? {
        val quoted = Regex("(?i)${Regex.escape(key)}\\s*=\\s*\"([^\"]*)\"").find(line)?.groupValues?.get(1)
        if (!quoted.isNullOrBlank()) return quoted
        return Regex("(?i)${Regex.escape(key)}\\s*=\\s*'([^']*)'").find(line)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
    }

    private fun resolve(baseUrl: String, candidate: String): String = runCatching {
        URI(baseUrl).resolve(candidate.trim()).toString()
    }.getOrElse { candidate.trim() }

    private fun hash(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return bytes.take(8).joinToString("") { "%02x".format(it) }
    }

    private fun qualityLabel(title: String): String = when {
        title.contains("4K", true) || title.contains("2160", true) -> "4K"
        title.contains("FHD", true) || title.contains("1080", true) -> "FHD"
        title.contains("HD", true) || title.contains("720", true) -> "HD"
        else -> "Auto"
    }
}
