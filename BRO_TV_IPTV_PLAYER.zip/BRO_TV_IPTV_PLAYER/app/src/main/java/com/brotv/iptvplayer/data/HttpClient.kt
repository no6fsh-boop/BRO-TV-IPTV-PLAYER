package com.brotv.iptvplayer.data

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.util.zip.GZIPInputStream

class HttpClient(
    private val connectTimeoutMs: Int = 12_000,
    private val readTimeoutMs: Int = 20_000,
) {
    fun getText(url: String, headers: Map<String, String> = emptyMap()): String =
        getBytes(url, headers).toString(Charsets.UTF_8)

    fun getBytes(
        url: String,
        headers: Map<String, String> = emptyMap(),
        maxBytes: Int = 128 * 1024 * 1024,
    ): ByteArray {
        var current = URI(url).toURL()
        repeat(6) {
            val connection = (current.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                instanceFollowRedirects = false
                connectTimeout = connectTimeoutMs
                readTimeout = readTimeoutMs
                setRequestProperty("User-Agent", "BRO-TV-IPTV-PLAYER/0.2 AndroidTV")
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Encoding", "gzip")
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
            }
            try {
                val code = connection.responseCode
                if (code in 300..399) {
                    val location = connection.getHeaderField("Location")
                        ?: error("HTTP $code بدون مسار إعادة توجيه")
                    current = URI(current.toString()).resolve(location).toURL()
                    return@repeat
                }
                if (code !in 200..299) {
                    val message = connection.errorStream?.bufferedReader()?.use { it.readText().take(500) }
                    error("HTTP $code ${message.orEmpty()}".trim())
                }
                val contentLength = connection.contentLengthLong
                require(contentLength <= 0 || contentLength <= maxBytes) { "الاستجابة أكبر من الحد المسموح" }

                val raw = BufferedInputStream(connection.inputStream)
                val stream = if (
                    connection.contentEncoding.equals("gzip", ignoreCase = true) ||
                    current.path.endsWith(".gz", ignoreCase = true)
                ) GZIPInputStream(raw) else raw
                return stream.use { input ->
                    val out = ByteArrayOutputStream()
                    val buffer = ByteArray(16 * 1024)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count <= 0) break
                        total += count
                        require(total <= maxBytes) { "الاستجابة أكبر من الحد المسموح" }
                        out.write(buffer, 0, count)
                    }
                    out.toByteArray()
                }
            } finally {
                connection.disconnect()
            }
        }
        error("عدد كبير من عمليات إعادة التوجيه")
    }
}

object UrlTools {
    fun normalizeHost(input: String): String {
        var value = input.trim()
        if (value.isBlank()) return value
        if (!value.startsWith("http://", true) && !value.startsWith("https://", true)) {
            value = "https://$value"
        }

        return runCatching {
            val uri = URI(value)
            val scheme = uri.scheme?.lowercase() ?: "https"
            val authority = uri.rawAuthority ?: return@runCatching value.substringBefore('?').trimEnd('/')
            var path = uri.rawPath.orEmpty().trimEnd('/')
            val knownFiles = listOf("/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php")
            knownFiles.firstOrNull { path.endsWith(it, ignoreCase = true) }?.let { suffix ->
                path = path.dropLast(suffix.length).trimEnd('/')
            }
            "$scheme://$authority$path".trimEnd('/')
        }.getOrDefault(value.substringBefore('?').trimEnd('/'))
    }

    fun redact(input: String): String = input
        .replace(Regex("(?i)(username=)[^&]+"), "$1***")
        .replace(Regex("(?i)(password=)[^&]+"), "$1***")
        .replace(Regex("/(live|movie|series)/[^/]+/[^/]+/"), "/$1/***/***/")
}
