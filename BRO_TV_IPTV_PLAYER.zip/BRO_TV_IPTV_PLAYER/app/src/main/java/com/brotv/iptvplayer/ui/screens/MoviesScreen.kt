package com.brotv.iptvplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import com.brotv.iptvplayer.model.ContinueItem
import com.brotv.iptvplayer.model.MediaKind
import com.brotv.iptvplayer.model.Movie
import com.brotv.iptvplayer.ui.components.BroBackground
import com.brotv.iptvplayer.ui.components.MediaCard
import com.brotv.iptvplayer.ui.components.RemoteImage
import com.brotv.iptvplayer.ui.components.ScreenHeader
import com.brotv.iptvplayer.ui.theme.BroRed
import com.brotv.iptvplayer.ui.theme.BroTextMuted

@Composable
fun MoviesScreen(
    movies: List<Movie>,
    favorites: Set<String>,
    continueWatching: List<ContinueItem>,
    onOpenMovie: (Movie) -> Unit,
    onPlayMovie: (Movie) -> Unit,
    onToggleFavorite: (String) -> Unit,
) {
    val hero = movies.firstOrNull()
    val groups = movies.groupBy { it.category }.entries.sortedBy { it.key }
    val movieHistory = continueWatching.filter { it.kind == MediaKind.MOVIE }

    BroBackground {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 26.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item {
                ScreenHeader("الأفلام", "${movies.size} عنوان · اضغط مطولًا للإضافة إلى المفضلة")
            }
            if (hero != null) {
                item {
                    Box(
                        Modifier.fillMaxWidth().height(230.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF51101B), Color(0xFF17181C), Color(0xFF080808))
                                )
                            )
                            .padding(28.dp)
                    ) {
                        hero.posterUrl?.let { url ->
                            RemoteImage(
                                url = url,
                                contentDescription = hero.title,
                                modifier = Modifier.align(Alignment.CenterEnd).width(390.dp).height(230.dp),
                            )
                        }
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xF9080808), Color(0xC617181C), Color.Transparent)
                                )
                            )
                        )
                        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(.62f)) {
                            Text("مختار من قائمتك", color = BroRed, fontSize = 14.sp)
                            Text(hero.title, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                hero.plot ?: listOfNotNull(hero.year, hero.rating?.let { "تقييم $it" }).joinToString(" · ").ifBlank { hero.category },
                                color = BroTextMuted,
                                maxLines = 3,
                            )
                            Spacer(Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = { onPlayMovie(hero) }) { Text("مشاهدة") }
                                Button(onClick = { onOpenMovie(hero) }) { Text("التفاصيل") }
                            }
                        }
                        if (hero.posterUrl.isNullOrBlank()) {
                            androidx.tv.material3.Icon(Icons.Default.Movie, null, Modifier.align(Alignment.CenterEnd).width(150.dp).height(150.dp), tint = Color.White.copy(.16f))
                        }
                    }
                }
            }
            if (movieHistory.isNotEmpty()) {
                item {
                    Column {
                        Text("متابعة المشاهدة", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(movieHistory, key = { it.mediaId }) { history ->
                                movies.firstOrNull { it.id == history.mediaId }?.let { movie ->
                                    MediaCard(
                                        title = movie.title,
                                        subtitle = "متابعة",
                                        imageUrl = movie.posterUrl,
                                        onClick = { onPlayMovie(movie) },
                                        modifier = Modifier.width(245.dp).height(128.dp),
                                        isFavorite = movie.id in favorites,
                                    )
                                }
                            }
                        }
                    }
                }
            }
            groups.forEach { (category, itemsInCategory) ->
                item(key = category) {
                    Column {
                        Text(category, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(itemsInCategory, key = { it.id }) { movie ->
                                MediaCard(
                                    title = movie.title,
                                    subtitle = listOfNotNull(movie.year, movie.rating).joinToString(" · ").ifBlank { category },
                                    icon = Icons.Default.Movie,
                                    imageUrl = movie.posterUrl,
                                    onClick = { onOpenMovie(movie) },
                                    onLongClick = { onToggleFavorite(movie.id) },
                                    modifier = Modifier.width(245.dp).height(138.dp),
                                    isFavorite = movie.id in favorites,
                                )
                            }
                        }
                    }
                }
            }
            if (movies.isEmpty()) {
                item { Text("لا توجد أفلام في هذه القائمة.", color = BroTextMuted, fontSize = 20.sp) }
            }
        }
    }
}
