package com.brotv.iptvplayer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import com.brotv.iptvplayer.AppUiState
import com.brotv.iptvplayer.BroScreen
import com.brotv.iptvplayer.MainViewModel
import com.brotv.iptvplayer.ui.screens.FavoritesScreen
import com.brotv.iptvplayer.ui.screens.HomeScreen
import com.brotv.iptvplayer.ui.screens.LiveTvScreen
import com.brotv.iptvplayer.ui.screens.LoginScreen
import com.brotv.iptvplayer.ui.screens.MovieDetailsScreen
import com.brotv.iptvplayer.ui.screens.MoviesScreen
import com.brotv.iptvplayer.ui.screens.PlayerScreen
import com.brotv.iptvplayer.ui.screens.SeriesDetailsScreen
import com.brotv.iptvplayer.ui.screens.SeriesScreen
import com.brotv.iptvplayer.ui.screens.SettingsScreen
import com.brotv.iptvplayer.ui.theme.BroRed
import com.brotv.iptvplayer.ui.theme.BroTvTheme

@Composable
fun BroTvApp(viewModel: MainViewModel) {
    val state by viewModel.ui.collectAsState()
    BroTvTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(Modifier.fillMaxSize()) {
                ScreenHost(state, viewModel)
                if (state.loading) LoadingOverlay(state.loadingMessage)
                state.error?.let { ErrorOverlay(it, viewModel::dismissError) }
            }
        }
    }

    BackHandler(
        enabled = state.screen != BroScreen.Login && state.screen != BroScreen.Home && state.screen != BroScreen.Player,
    ) { viewModel.back() }
}

@Composable
private fun ScreenHost(state: AppUiState, vm: MainViewModel) {
    when (val screen = state.screen) {
        BroScreen.Login -> LoginScreen(vm::loginM3u, vm::loginXtream)
        BroScreen.Home -> HomeScreen(
            providerName = state.catalog.providerName.ifBlank { state.profile?.name.orEmpty() },
            catalog = state.catalog,
            continueWatching = state.continueWatching,
            onNavigate = vm::navigate,
            onRefresh = vm::refreshCatalog,
            onResume = vm::resume,
        )
        BroScreen.Live -> LiveTvScreen(
            channels = state.catalog.channels,
            favorites = state.favorites,
            onPlay = vm::playChannel,
            onToggleFavorite = vm::toggleFavorite,
        )
        BroScreen.Movies -> MoviesScreen(
            movies = state.catalog.movies,
            favorites = state.favorites,
            continueWatching = state.continueWatching,
            onOpenMovie = vm::openMovie,
            onPlayMovie = vm::playMovie,
            onToggleFavorite = vm::toggleFavorite,
        )
        BroScreen.SeriesList -> SeriesScreen(
            series = state.catalog.series,
            favorites = state.favorites,
            onOpenSeries = vm::openSeries,
            onToggleFavorite = vm::toggleFavorite,
        )
        BroScreen.Favorites -> FavoritesScreen(
            catalog = state.catalog,
            favorites = state.favorites,
            onPlayChannel = vm::playChannel,
            onOpenMovie = vm::openMovie,
            onOpenSeries = vm::openSeries,
            onToggleFavorite = vm::toggleFavorite,
        )
        BroScreen.Settings -> SettingsScreen(
            profile = state.profile,
            preferences = state.playbackPreferences,
            onChange = vm::updatePlaybackPreferences,
            onRefresh = vm::refreshCatalog,
            onClearHistory = vm::clearContinueWatching,
            onLogout = vm::logout,
        )
        is BroScreen.MovieDetail -> {
            val movie = state.catalog.movies.firstOrNull { it.id == screen.movieId }
            if (movie != null) {
                MovieDetailsScreen(
                    movie = movie,
                    favorite = movie.id in state.favorites,
                    onPlay = { vm.playMovie(movie) },
                    onToggleFavorite = { vm.toggleFavorite(movie.id) },
                )
            } else EmptyScreen("الفيلم غير موجود")
        }
        is BroScreen.SeriesDetail -> {
            val series = state.selectedSeries?.takeIf { it.id == screen.seriesId }
                ?: state.catalog.series.firstOrNull { it.id == screen.seriesId }
            if (series != null) {
                SeriesDetailsScreen(
                    series = series,
                    favorite = series.id in state.favorites,
                    onPlayEpisode = { vm.playEpisode(series, it) },
                    onToggleFavorite = { vm.toggleFavorite(series.id) },
                )
            } else EmptyScreen("المسلسل غير موجود")
        }
        BroScreen.Player -> {
            val request = state.activePlayback
            if (request != null) {
                val liveNumber = if (request.kind == com.brotv.iptvplayer.model.MediaKind.LIVE) {
                    state.catalog.channels.indexOfFirst { it.id == request.id }.takeIf { it >= 0 }?.plus(1)
                } else null
                PlayerScreen(
                    request = request,
                    preferences = state.playbackPreferences,
                    epg = state.activeEpg,
                    introMarkers = state.introMarkers,
                    liveChannelNumber = liveNumber,
                    liveChannelCount = state.catalog.channels.size,
                    onChangeLive = vm::stepLive,
                    onTuneLiveNumber = vm::tuneLive,
                    onEnded = vm::onPlaybackEnded,
                    onNextEpisode = vm::playNextEpisode,
                    onProgress = vm::onPlaybackProgress,
                    onBack = vm::back,
                )
            } else EmptyScreen("لا يوجد محتوى للتشغيل")
        }
    }
}

@Composable
private fun LoadingOverlay(message: String) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .82f)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("BRO TV", color = BroRed, fontSize = 34.sp)
            Spacer(Modifier.height(10.dp))
            Text(message, fontSize = 17.sp)
        }
    }
}

@Composable
private fun ErrorOverlay(message: String, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .68f)), contentAlignment = Alignment.Center) {
        Column(
            Modifier.width(620.dp).background(Color(0xFF201014), RoundedCornerShape(16.dp)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("تعذر إكمال العملية", color = BroRed, fontSize = 24.sp)
            Spacer(Modifier.height(10.dp))
            Text(message, fontSize = 15.sp)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onDismiss) { Text("حسنًا") }
        }
    }
}

@Composable
private fun EmptyScreen(message: String) {
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Text(message, fontSize = 24.sp)
    }
}
