package com.brotv.iptvplayer.model

import java.util.UUID

enum class ProviderType { M3U, XTREAM }
enum class MediaKind { LIVE, MOVIE, SERIES, EPISODE }

data class ProviderProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ProviderType,
    val m3uUrl: String? = null,
    val host: String? = null,
    val username: String? = null,
    val password: String? = null,
)

data class Channel(
    val id: String,
    val title: String,
    val group: String = "عام",
    val logoUrl: String? = null,
    val epgId: String? = null,
    val streamUrl: String,
    val variantKey: String = normalizeVariantKey(title),
    val sourceLabel: String = title,
)

data class Movie(
    val id: String,
    val title: String,
    val category: String = "أفلام",
    val posterUrl: String? = null,
    val plot: String? = null,
    val year: String? = null,
    val rating: String? = null,
    val streamUrl: String,
)

data class Episode(
    val id: String,
    val seriesId: String,
    val title: String,
    val season: Int,
    val episode: Int,
    val streamUrl: String,
    val durationSeconds: Long? = null,
)

data class Series(
    val id: String,
    val title: String,
    val category: String = "مسلسلات",
    val posterUrl: String? = null,
    val plot: String? = null,
    val rating: String? = null,
    val episodes: List<Episode> = emptyList(),
)

data class Catalog(
    val providerName: String = "",
    val channels: List<Channel> = emptyList(),
    val movies: List<Movie> = emptyList(),
    val series: List<Series> = emptyList(),
    val m3uEpgUrl: String? = null,
) {
    val liveGroups: List<String> get() = channels.map { it.group }.distinct().sorted()
    val movieCategories: List<String> get() = movies.map { it.category }.distinct().sorted()
    val seriesCategories: List<String> get() = series.map { it.category }.distinct().sorted()
}

data class EpgProgramme(
    val channelId: String,
    val title: String,
    val description: String? = null,
    val startEpochSeconds: Long,
    val endEpochSeconds: Long,
)

data class EpgNowNext(
    val now: EpgProgramme? = null,
    val next: EpgProgramme? = null,
)

data class ContinueItem(
    val mediaId: String,
    val kind: MediaKind,
    val title: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAtMs: Long,
    /** Needed to resume an episode after an app restart without persisting its credential-bearing URL. */
    val seriesId: String? = null,
    val episodeIndex: Int = -1,
)

data class PlaybackRequest(
    val id: String,
    val title: String,
    val kind: MediaKind,
    val streamUrl: String,
    val channelAlternatives: List<Channel> = emptyList(),
    val episodeQueue: List<Episode> = emptyList(),
    val episodeIndex: Int = -1,
    val resumePositionMs: Long = 0L,
)

enum class BufferProfile { LOW_LATENCY, BALANCED, STABLE }

data class PlaybackPreferences(
    val seekSeconds: Int = 15,
    val autoReconnect: Boolean = true,
    val autoBestStream: Boolean = true,
    val autoNextEpisode: Boolean = true,
    val bufferProfile: BufferProfile = BufferProfile.BALANCED,
    val conservative4k60Cap: Boolean = true,
)

data class PlaybackStats(
    val width: Int = 0,
    val height: Int = 0,
    val sourceFps: Float = 0f,
    val outputRefreshHz: Float = 0f,
    /** Declared/selected stream bitrate from Media3 Format, when the source exposes it. */
    val bitrate: Int = 0,
    /** Estimated available network throughput measured by Media3's bandwidth meter. */
    val networkBitrate: Long = 0L,
    val codec: String = "—",
    val hdr: String = "SDR/Unknown",
    val droppedFrames: Int = 0,
    val reconnects: Int = 0,
    val rebuffers: Int = 0,
    val startupMs: Long = 0L,
    val sourceHealth: Int = 100,
    val activeSourceLabel: String = "",
)

data class SkipSegment(
    val startMs: Long,
    val endMs: Long,
    val label: String = "تخطي المقدمة",
)

fun normalizeVariantKey(input: String): String = input
    .lowercase()
    .replace(Regex("\\b(4k|uhd|2160p|fhd|1080p|hd|720p|sd|hevc|h265|h264|avc|\\d{2,3}fps)\\b"), " ")
    .replace(Regex("[\\[\\]()_-]+"), " ")
    .replace(Regex("\\s+"), " ")
    .trim()
