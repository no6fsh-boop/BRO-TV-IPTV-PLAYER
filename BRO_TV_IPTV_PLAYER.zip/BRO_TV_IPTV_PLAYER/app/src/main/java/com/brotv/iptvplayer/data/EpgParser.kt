package com.brotv.iptvplayer.data

import android.util.Base64
import android.util.Xml
import com.brotv.iptvplayer.model.EpgNowNext
import com.brotv.iptvplayer.model.EpgProgramme
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EpgParser {
    fun parseXmlTvNowNext(bytes: ByteArray, wantedIds: Set<String>, nowEpochSeconds: Long = System.currentTimeMillis() / 1000): Map<String, EpgNowNext> {
        if (wantedIds.isEmpty()) return emptyMap()
        val parser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(ByteArrayInputStream(bytes), "UTF-8")
        }
        val current = mutableMapOf<String, EpgProgramme>()
        val next = mutableMapOf<String, EpgProgramme>()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "programme") {
                val channel = parser.getAttributeValue(null, "channel").orEmpty()
                val start = parseXmlTvTime(parser.getAttributeValue(null, "start"))
                val stop = parseXmlTvTime(parser.getAttributeValue(null, "stop"))
                var title = ""
                var desc: String? = null
                var depth = parser.depth
                while (true) {
                    event = parser.next()
                    if (event == XmlPullParser.START_TAG) {
                        when (parser.name) {
                            "title" -> title = parser.nextText().trim()
                            "desc" -> desc = parser.nextText().trim().takeIf { it.isNotBlank() }
                        }
                    }
                    if (event == XmlPullParser.END_TAG && parser.depth == depth && parser.name == "programme") break
                    if (event == XmlPullParser.END_DOCUMENT) break
                }
                if (channel in wantedIds && start != null && stop != null) {
                    val p = EpgProgramme(channel, title.ifBlank { "—" }, desc, start, stop)
                    if (nowEpochSeconds in start until stop) {
                        current[channel] = p
                    } else if (start > nowEpochSeconds) {
                        val existing = next[channel]
                        if (existing == null || start < existing.startEpochSeconds) next[channel] = p
                    }
                }
            }
            event = parser.next()
        }
        return wantedIds.associateWith { id -> EpgNowNext(current[id], next[id]) }
    }

    fun parseXtreamShortEpg(text: String, channelId: String, nowEpochSeconds: Long = System.currentTimeMillis() / 1000): EpgNowNext {
        val root = JSONObject(text)
        val arr = root.optJSONArray("epg_listings") ?: return EpgNowNext()
        val list = buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val start = o.optLong("start_timestamp", -1L)
                val end = o.optLong("stop_timestamp", o.optLong("end_timestamp", -1L))
                if (start <= 0 || end <= 0) continue
                add(
                    EpgProgramme(
                        channelId = channelId,
                        title = decodeMaybeBase64(o.optString("title")).ifBlank { "—" },
                        description = decodeMaybeBase64(o.optString("description")).takeIf { it.isNotBlank() },
                        startEpochSeconds = start,
                        endEpochSeconds = end,
                    )
                )
            }
        }.sortedBy { it.startEpochSeconds }
        val current = list.firstOrNull { nowEpochSeconds in it.startEpochSeconds until it.endEpochSeconds }
        val next = list.firstOrNull { it.startEpochSeconds > nowEpochSeconds }
        return EpgNowNext(current, next)
    }

    private fun decodeMaybeBase64(value: String): String {
        val trimmed = value.trim()
        if (trimmed.isBlank()) return ""
        return runCatching {
            val decoded = String(Base64.decode(trimmed, Base64.DEFAULT), Charsets.UTF_8)
            if (decoded.any { it.isLetterOrDigit() } && !decoded.contains('\u0000')) decoded else trimmed
        }.getOrDefault(trimmed)
    }

    private fun parseXmlTvTime(value: String?): Long? {
        if (value.isNullOrBlank()) return null
        val clean = value.trim().replace(Regex("\\s+"), " ")
        val patterns = listOf("yyyyMMddHHmmss Z", "yyyyMMddHHmmssZ", "yyyyMMddHHmmss")
        for (pattern in patterns) {
            val date: Date = runCatching {
                SimpleDateFormat(pattern, Locale.US).apply { isLenient = true }.parse(clean)
            }.getOrNull() ?: continue
            return date.time / 1000
        }
        return null
    }
}
