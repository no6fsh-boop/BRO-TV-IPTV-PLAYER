package com.brotv.iptvplayer.data

import com.brotv.iptvplayer.model.Catalog
import com.brotv.iptvplayer.model.Channel
import com.brotv.iptvplayer.model.EpgNowNext
import com.brotv.iptvplayer.model.ProviderProfile
import com.brotv.iptvplayer.model.ProviderType
import com.brotv.iptvplayer.model.Series
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URI

class ProviderRepository(
    private val http: HttpClient = HttpClient(),
    private val m3uParser: M3uParser = M3uParser(),
    private val epgParser: EpgParser = EpgParser(),
) {
    private var activeProfile: ProviderProfile? = null
    private var activeCatalog: Catalog = Catalog()
    private var xtream: XtreamClient? = null
    private var m3uEpgCache: Map<String, EpgNowNext>? = null
    private var m3uEpgCacheAtMs: Long = 0L

    suspend fun connect(profile: ProviderProfile): Catalog = withContext(Dispatchers.IO) {
        val catalog = when (profile.type) {
            ProviderType.M3U -> {
                val url = profile.m3uUrl?.trim().orEmpty()
                require(url.startsWith("http://") || url.startsWith("https://")) { "رابط M3U يجب أن يبدأ بـ http:// أو https://" }
                val text = http.getText(url)
                m3uParser.parse(text, sourceUrl = url, providerName = profile.name.ifBlank { hostLabel(url) })
            }
            ProviderType.XTREAM -> {
                val client = XtreamClient(http)
                xtream = client
                client.connect(profile)
            }
        }
        activeProfile = profile
        activeCatalog = catalog
        m3uEpgCache = null
        m3uEpgCacheAtMs = 0L
        catalog
    }

    suspend fun refresh(): Catalog {
        val profile = activeProfile ?: error("لا يوجد اشتراك نشط")
        return connect(profile)
    }

    suspend fun loadSeries(series: Series): Series = withContext(Dispatchers.IO) {
        if (series.episodes.isNotEmpty()) return@withContext series
        if (activeProfile?.type == ProviderType.XTREAM) {
            xtream?.loadSeries(series) ?: series
        } else series
    }

    suspend fun epg(channel: Channel): EpgNowNext = withContext(Dispatchers.IO) {
        when (activeProfile?.type) {
            ProviderType.XTREAM -> runCatching {
                epgParser.parseXtreamShortEpg(xtream!!.shortEpg(channel.id), channel.epgId ?: channel.id)
            }.getOrDefault(EpgNowNext())
            ProviderType.M3U -> {
                val url = activeCatalog.m3uEpgUrl ?: return@withContext EpgNowNext()
                val nowMs = System.currentTimeMillis()
                if (m3uEpgCache == null || nowMs - m3uEpgCacheAtMs > 5 * 60 * 1000L) {
                    val ids = activeCatalog.channels.mapNotNull { it.epgId }.toSet()
                    m3uEpgCache = runCatching { epgParser.parseXmlTvNowNext(http.getBytes(url), ids) }.getOrDefault(emptyMap())
                    m3uEpgCacheAtMs = nowMs
                }
                channel.epgId?.let { m3uEpgCache?.get(it) } ?: EpgNowNext()
            }
            null -> EpgNowNext()
        }
    }

    fun alternativesFor(channel: Channel): List<Channel> = activeCatalog.channels
        .filter { it.variantKey == channel.variantKey }
        .ifEmpty { listOf(channel) }

    private fun hostLabel(url: String): String = runCatching { URI(url).host ?: "M3U" }.getOrDefault("M3U")
}
