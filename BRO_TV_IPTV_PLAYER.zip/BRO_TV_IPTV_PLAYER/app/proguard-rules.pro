# Media3 and AndroidX ship consumer rules. Keep project rules minimal.
