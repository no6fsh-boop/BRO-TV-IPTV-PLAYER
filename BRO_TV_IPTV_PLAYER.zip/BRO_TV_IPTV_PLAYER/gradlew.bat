@echo off
setlocal enabledelayedexpansion
set "GRADLE_VERSION=9.6.0"
set "GRADLE_SHA256=bbaeb2fef8710818cf0e261201dab964c572f92b942812df0c3620d62a529a01"
if "%GRADLE_USER_HOME%"=="" (set "BASE=%USERPROFILE%\.gradle\brotv-bootstrap") else (set "BASE=%GRADLE_USER_HOME%\brotv-bootstrap")
set "ZIP=%BASE%\gradle-%GRADLE_VERSION%-bin.zip"
set "DIST=%BASE%\gradle-%GRADLE_VERSION%"
if not exist "%BASE%" mkdir "%BASE%"
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$h=(Get-FileHash -Algorithm SHA256 '%ZIP%').Hash.ToLower(); if($h -ne '%GRADLE_SHA256%'){Write-Error 'Gradle checksum mismatch'; exit 1}"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%BASE%'"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
