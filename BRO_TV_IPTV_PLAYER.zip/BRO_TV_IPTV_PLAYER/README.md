# BRO TV IPTV PLAYER

مشروع Android TV / Google TV فعلي بـ **Kotlin + Jetpack Compose for TV + AndroidX Media3/ExoPlayer**، بهوية سوداء/حمراء مستوحاة من الصور التي رفعها صاحب المشروع. تم تضمين **الشعار المرفوع فقط** كأصل داخل التطبيق؛ صور الواجهة الأخرى استُخدمت كمرجع بصري ولم تُنسخ كخلفيات أو محتوى.

> التطبيق **مشغّل فقط** ولا يحتوي قوائم IPTV أو قنوات أو أفلام أو بيانات اشتراك. استخدمه فقط مع مصادر لديك حق الوصول إليها.

## تحديث 0.2.0

هذه النسخة تكمل طبقة التشغيل والـTV UX: تحميل Posters/شعارات المزود مع cache ذاكرة، إدخال رقم القناة 0–9، EPG progress، قياس startup وnetwork bandwidth، Source Health أدق، إعادة ترتيب Best Stream بعد الفشل، adaptive buffering لا يحتسب startup كـ rebuffer، استعادة Continue Watching للحلقات بعد إعادة التشغيل، وزر للحلقة التالية ومسح سجل المتابعة. راجع `CHANGELOG.md` للتفاصيل.

## ما تم تنفيذه

- تسجيل دخول **M3U URL** أو **Xtream Codes** (Host + Username + Password).
- RTL عربي أولًا، تنقل D-pad، وتصميم TV focus واضح.
- Home + Live TV + Movies + Series + Favorites + Settings + Details + Player.
- Live TV بقائمة قنوات شبيهة بالرسيفر، وداخل المشغل: `↑/↓` قناة سابقة/تالية و`OK` لإظهار/إخفاء معلومات القناة.
- EPG: دعم XMLTV من خصائص `x-tvg-url` / `url-tvg` في M3U، وShort EPG في Xtream إن كان المزوّد يدعمه.
- Media3 stats: Resolution، **Source FPS**، **Output Refresh**، Codec، Bitrate، HDR transfer، Dropped Frames، Reconnect count وSource Health.
- Auto reconnect بتأخير متدرج، source health scoring، تحويل تلقائي إلى Buffer Profile أكثر ثباتًا بعد تكرار rebuffer.
- Best Stream: تجميع النسخ المتشابهة من القناة بالاسم المطبّع، ترتيب جودة/صحة المصدر، والتبديل بين البدائل عند الفشل.
- VOD: hero/rows، Continue Watching، تفاصيل، مواسم/حلقات، seek قابل للضبط 10/15/30 ثانية، Next Episode.
- Skip Intro كـ architecture extension point عبر `IntroMarkerProvider` من دون ادعاء اكتشاف تلقائي غير موجود.

## 4K / FPS على Google TV

الوضع الافتراضي يضع سقف اختيار الفيديو في Media3 عند **3840×2160 و60fps**. الواجهة لا تصف 90fps كقدرة إخراج. يتم عرض **Source FPS** القادم من الـ Format و**Output Refresh** القادم من شاشة Android كقيمتين منفصلتين. وجود Source 90fps لا يعني أن الجهاز يخرجه 90Hz.

## البناء

المتطلبات المقترحة:

- Android Studio حديث يدعم AGP 9.4.x.
- JDK 17 أو أحدث لتشغيل Gradle (المشروع يترجم Java bytecode 17).
- Android SDK 36.
- اتصال إنترنت أول مرة لتنزيل Gradle/dependencies.

من جذر المشروع:

```bash
./gradlew test
./gradlew :app:assembleDebug
```

على Windows:

```bat
gradlew.bat test
gradlew.bat :app:assembleDebug
```

`gradlew` هنا self-bootstrapping صغير ومقروء بدل شحن ملف `gradle-wrapper.jar` ثنائي غير قابل للمراجعة؛ ينزّل Gradle 9.6.0 ويتحقق من SHA-256 الرسمي قبل التشغيل. توجد أيضًا `gradle/wrapper/gradle-wrapper.properties` لمرجع إعداد Android Studio. يمكنك لاحقًا توليد Wrapper قياسي بـ `gradle wrapper --gradle-version 9.6.0` إن رغبت.

## أين تضع بيانات تسجيل الدخول؟

**لا تضعها في الكود أو `local.properties` أو `BuildConfig`.** شغّل التطبيق وأدخلها من شاشة Login:

- M3U: رابط القائمة الكامل.
- Xtream: Host + Username + Password.

عند نجاح الاتصال تحفظ `CredentialStore.kt` ملف تعريف المزوّد مشفّرًا باستخدام **AES/GCM** ومفتاح غير قابل للتصدير في **Android Keystore**. SharedPreferences يحتوي فقط على IV + ciphertext. `android:allowBackup="false"` يمنع النسخ الاحتياطي للتطبيق.

`AppPreferencesStore.kt` يحفظ إعدادات غير حساسة والمفضلة وسجل المشاهدة. سجل المشاهدة **لا يحفظ stream URLs** لأن روابط Xtream غالبًا تتضمن username/password في المسار.

### ملاحظة HTTP

بعض مزوّدي IPTV القدامى يعملون عبر `http://` فقط، لذلك `usesCleartextTraffic=true` مفعّل للتوافق. هذا يعني أن الاعتماديات يمكن أن تنتقل دون TLS إذا كان المزوّد يستخدم HTTP. استخدم HTTPS متى كان متاحًا؛ وإذا كان مزوّدك HTTPS فقط يمكنك تغييرها إلى `false` في Manifest لسياسة أشد.

## هيكل مهم

```text
app/src/main/java/com/brotv/iptvplayer/
├── data/       # M3U, Xtream, XMLTV/EPG, HTTP, secure credential store
├── model/      # domain models + playback preferences/stats
├── player/     # ExoPlayer engine, health scoring, best-stream, intro markers
└── ui/         # TV theme, RTL screens, D-pad/focus UI
```

- `PlayerEngine.kt`: Media3 player، 4K60 cap، stats، reconnect، adaptive buffer.
- `StreamSelector.kt`: health + quality ranking للنسخ البديلة.
- `ProviderRepository.kt`: نقطة توحيد M3U/Xtream/EPG.
- `IntroMarkers.kt`: واجهة لإضافة markers من مزود/قاعدة بيانات/خدمة مستقبلية.
- `CredentialStore.kt`: التخزين المشفر.

## ملاحظات التوافق

Xtream Codes ليس معيارًا موحدًا رسميًا؛ المشروع يدعم نمط `player_api.php` الشائع وlive/vod/series/short EPG، لكن بعض المزوّدين يغيرون JSON أو المسارات وقد يحتاجون adapter صغير داخل `XtreamClient.kt`.

M3U لا يملك طريقة موحدة لتمييز Live/VOD/Series. parser يستخدم `group-title` ومؤشرات `SxxExx` كـ heuristics. يمكن تعديلها في `M3uParser.kt` لمزوّد محدد.

## الأصول والهوية

- `bro_logo.png`, `bro_wordmark.png`, `ic_launcher.png`, `app_banner.png` مشتقة فقط من شعار BRO TV الذي رفعه المستخدم في المحادثة.
- لم تتم إضافة posters أو صور أفلام/مسلسلات أو أعمال محمية من مصادر خارجية.
- Posters وشعارات القنوات تُحمّل من URLs التي يرجعها مزود IPTV فقط، مع cache ذاكرة داخل العملية وحد 12MB للصورة؛ لا توجد صور أعمال طرف ثالث مضمّنة في المشروع.

## الاختبارات

توجد اختبارات JVM للـ M3U parsing (بما فيه BOM/XMLTV URL)، URL normalization/redaction، تطبيع أسماء نسخ القنوات، وSource Health/Best Stream داخل `app/src/test`.

## التحقق في هذه الحزمة

تم فحص طبقة Kotlin المستقلة (models/M3U/stream selection/URL tools) محليًا باستخدام `kotlinc`، وفحص XML وPNG قبل ضغط الحزمة. **لم يتم تشغيل Android Gradle build كامل داخل بيئة إنشاء هذه الحزمة لعدم توفر Android SDK فيها**؛ لذلك ابنِ `assembleDebug` في Android Studio/بيئة Android SDK قبل التوزيع، ثم اختبر playback على جهاز Google TV/Android TV فعلي.

## قبل النشر

- غيّر `applicationId` إذا لزم لحساب Play Console.
- أضف Privacy Policy المناسبة لخدمتك.
- اختبر مزوّدك الفعلي على Google TV Streamer/Chromecast/Android TV لأن codec/container capabilities تختلف حسب الجهاز.
- لا تسجّل URLs/headers التي تحتوي بيانات اعتماد في analytics أو crash reports.

## Downloader / GitHub Actions

يوجد workflow باسم `.github/workflows/build-downloader-apk.yml` يبني APK للاختبار/التثبيت الجانبي تلقائيًا على GitHub Actions، ثم يرفعه إلى Release ثابت باسم `downloader-latest` كملف `BRO-TV-IPTV-PLAYER.apk`. بعد إنشاء مستودع GitHub ودفع المشروع، يمكن استخدام رابط ملف الـAPK المباشر في Downloader أو في خدمة توليد أكواد Downloader.

> هذا الـAPK موقّع بمفتاح debug الخاص ببيئة البناء ومخصص للاختبار/التثبيت الجانبي. للنشر الدائم والتحديثات الموقعة استخدم keystore خاصًا محفوظًا في GitHub Secrets ولا تضع المفتاح أو كلمات مروره داخل المستودع.
