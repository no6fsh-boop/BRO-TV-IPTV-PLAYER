# Security notes

- Provider credentials are encrypted at rest with AES/GCM; the encryption key is generated inside Android Keystore and is not exported.
- App backup is disabled (`android:allowBackup="false"`).
- Continue-watching history stores stable IDs, timestamps and playback positions only; it never stores credential-bearing Xtream stream URLs.
- `UrlTools.redact()` is provided for future logging. Never log raw M3U/Xtream URLs, authorization headers, usernames or passwords.
- Remote artwork is downloaded only from URLs returned by the configured provider, decoded with sampling, capped at 12 MB per image, and cached in process memory only by the custom image loader.
- The player follows HTTP redirects for provider compatibility. A provider can redirect from HTTPS to HTTP, so treat legacy cleartext sources as insecure transport.
- Cleartext HTTP is enabled globally for legacy IPTV compatibility. Prefer HTTPS; deployments that only use HTTPS should set `android:usesCleartextTraffic="false"` or provide a stricter Network Security Config.
- No provider credentials, playlists, channel URLs, EPG data, analytics keys, or subscriptions are bundled in this repository.
- Release signing keys must never be committed to this project. Configure signing through local/CI secrets.
