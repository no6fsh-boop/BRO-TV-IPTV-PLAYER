# Changelog

## 0.2.0

- أضيف تحميل شعارات القنوات وPosters القادمة من مزود IPTV مع cache ذاكرة محدود، من دون إضافة مكتبة صور خارجية.
- تحسين Live TV ليحاكي الرسيفر: التركيز يتابع الـD-pad، ترقيم موحد للقنوات، وإدخال رقم القناة مباشرة من 0–9.
- إضافة EPG progress للبرنامج الحالي داخل شاشة البث.
- فصل **Source FPS** عن **Output Refresh**، وفصل bitrate المعلن في الـstream عن تقدير bandwidth الشبكة.
- إضافة قياس startup latency إلى Source Health وتحسين العقوبات على errors/rebuffers/dropped frames.
- تحسين Auto reconnect وBest Stream: بعد فشل مصدر حي يعاد ترتيب البدائل حسب الجودة والصحة.
- تحسين adaptive buffering بحيث لا تُحسب مرحلة startup كـ rebuffer، مع الترقية إلى ملف Stable عند تكرار نفاد buffer.
- Media3 يستخدم HTTP data source مخصصًا بمهلات واضحة وUser-Agent وتحويلات redirects، مع BandwidthMeter مشترك.
- تحسين M3U: دعم BOM، معالجة أول XMLTV URL عند وجود أكثر من رابط، وتحديث EPG cache دوريًا.
- تحسين Xtream host normalization لقبول Host خام أو رابط `player_api.php/get.php` ملصقًا بالكامل.
- Continue Watching للحلقات أصبح قابلًا للاستعادة بعد إعادة تشغيل التطبيق عبر series/episode IDs من دون تخزين stream URL الحساس.
- إضافة زر لمسح سجل متابعة المشاهدة، وزر يدوي للحلقة التالية.
- تحديث الإصدار إلى `0.2.0` (`versionCode 2`).
