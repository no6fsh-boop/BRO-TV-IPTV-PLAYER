## 2.0.8 (TV search stability)
- Search now uses a debounced pre-normalized background index instead of scanning the entire catalog on the UI thread for every character.
- Voice results and mobile/QR typing now trigger a real search even if catalog loading completes after the query arrives.
- Added remote-focusable All / Live / Movies / Series search scopes with strong focus indication.
- Live channels can be found by visible channel number or numeric Xtream stream code.
- QR/mobile search now debounces typing and offers an explicit submit action.
- Stale result rails are hidden while a new query is being typed or when the query is cleared.

## 2.0.7 (Single-connection provider handoff fix)
- Release live preview before opening the full player so single-connection Xtream accounts do not see two BRO TV sessions during Activity handoff.
- When Xtream `active_cons` is stale immediately after a local release, re-probe with bounded settle waits before showing provider-limit errors.
- Live retries and the single automatic alternative now close the failed HTTP stream first and wait for provider session settlement before reconnecting.
- No unbounded retry/failover loop was reintroduced.

## 2.0.6 (Bounded Live Fallback)
- Restored live-channel continuity without bringing back the retry loop: one same-source retry, then at most one automatic alternative source per channel session.
- A second source failure stops recovery and moves focus to manual source selection instead of cycling indefinitely.
- Channel changes invalidate pending recovery callbacks and reset the one-fallback budget.
- Manual source choices are respected; the app will not auto-switch away from a manually selected source.
- Removed the misleading "Auto" quality label while stream resolution is still being detected.

## 2.0.5 (Live stability + TV navigation field fix)
- Disabled automatic live-source failover loops; live playback retries the same source at most once and then requires manual source selection.
- Channel/source changes cancel stale recovery callbacks so an old failing channel cannot keep affecting the new channel.
- Reduced live freeze/black-screen recovery to one conservative recovery attempt before returning control to the viewer.
- Removed the green playback diagnostics overlay and its normal settings entry.
- Rebuilt the live info bar with channel number/name, EPG progress/times, clock/date, TV Guide and manual quality/source selection.
- Added a Home refresh/reconnect button for the active IPTV server without deleting account data.
- Reduced Series Details dimensions so seasons/favorite controls remain inside TV safe bounds.
- Fixed Movies/Series D-pad navigation so the poster grid can reach the sort row and return from it.

## 2.0.4 (Field UX batch)
- Rebuilt Movies and Series browsing around a left navigation rail with provider folders kept in provider order, quick lists, hero details, poster grid, and sort controls.
- Rebuilt Series Details with poster, seasons, resume/favorite actions, episode sorting and richer episode rows.
- Live player OK opens the current-folder channel overlay; Back first hides live chrome, then returns to the same folder/channel.
- Live chrome focuses TV controls and exposes Guide plus quality/source without leaving playback.
- Channel surfing is scoped to the opened folder and follows its current/provider order.
- Hiding a channel stays in the same folder and moves focus to the next channel, or previous when hiding the last one.
- TV popup lists use a high-contrast focus selector.
- Channel-folder reorder now uses OK to pick/drop and Up/Down to move the selected folder in-place.

## 2.0.3 field UX hotfix

- Live playback no longer exposes VOD-style seek/±15 controls.
- Live chrome now auto-hides after a short timeout and reappears on remote input.
- Bottom live controls now expose TV Guide, current channel/programme, and manual quality/source selection.
- DPAD Up/Down channel surfing is locked to the opened folder/category and preserves provider order.
- TV Guide inside the player uses the same opened folder/category scope.

## 2.0.2 live playback hotfix
- Fixed false live black-screen recovery that could restart a healthy stream roughly every five seconds on some TV decoders.
- Live AUTO buffer adaptation no longer recreates ExoPlayer mid-channel.
- Increased freeze/startup recovery thresholds to avoid aggressive recovery on normal IPTV jitter.
- DPAD Up/Down now changes live channels directly from the player on standard Android TV remotes.

## 2.0.1
- Fixed Android TV home-card focus ring being hidden behind oversized/center-cropped artwork.
- Focus border now renders as a foreground layer above card art.
- Added subtle TV focus scale/elevation and disabled row clipping so focus remains clearly visible.

## 2.0.0 final polish
- Android TV image controls now include localized accessibility descriptions; decorative artwork is explicitly ignored by accessibility services.
- Added finite, periodically renewed DVR wake-lock protection for long recordings instead of an open-ended power lock.
- Removed the last hardcoded search hint and aligned search text input/autofill behavior with Android TV.
- Reduced localization-related runtime text concatenation across EPG, catch-up, channel ordering and source status surfaces.
- Refactored repeated view lookups flagged by Android Lint without changing player behavior.

## 2.0.0 RC4 final hardening
- Pairing QR tokens now use `SecureRandom`, 12-character QR-friendly tokens and constant-time comparison.
- Local phone pairing rejects non-LAN clients, authenticates POST requests before body parsing, caps request bodies at 64 KiB, disables caching/referrers and sends a restrictive CSP.
- Self-Healing playback recreates ExoPlayer after decoder crashes so decoder fallback/blacklisting actually takes effect.
- Delayed playback retries are generation-gated to prevent retry storms and stale recovery callbacks from affecting a newly selected channel.
- Recovery timers are isolated from seek-overlay timers, so remote seek input can no longer cancel freeze/black-screen/dynamic-buffer recovery.
- XMLTV gzip detection now handles `.xml.gz?token=...` provider URLs even when the origin omits `Content-Encoding`.

## 2.0.0 RC3 hardening
- Fixed HLS DVR resume when a live playlist window slides past the previous byte-range segment.
- DVR checkpoints now persist only sequence numbers, SHA-256 URI hashes and resolved byte-range coordinates; stream URLs and credentials are never stored.
- Unsafe implicit HLS byte ranges are rejected when no explicit/current/checkpoint predecessor can resolve the offset, preventing silent corrupt recordings.
- Added a regression test covering process restart plus a slid live playlist window on a shared byte-range media object.

## 2.0.0 Commercial RC hardening
- Removed the unused microphone permission/feature; voice search delegates to the system recognizer without direct microphone access.
- Voice recognition now follows the selected BRO TV UI language (Arabic/English).
- Localized major live/VOD/series/search/catch-up/profile/subtitle/backup error surfaces and the phone pairing page.
- Hardened HLS DVR parsing for BOM/mixed-case playlists, AVERAGE-BANDWIDTH selection and invalid/overflowing byte ranges.
- Reduced component exposure by keeping the boot receiver non-exported while retaining system boot/update delivery.

## 2.0.0 Commercial
- Commercial feature freeze after integrated player, Xtream/M3U/EPG/Catch-up/DVR/Timeshift/VOD/Series, parental controls and TV-remote UX hardening.
- Production package identity: `com.brotv.player`.
- Unified live/VOD recovery paths, numeric channel selection, Arabic-aware unified search, Sleep Timer and commercial signing infrastructure.
- Security hardening includes encrypted credentials/backup paths, hashed parental PINs and disabled Android auto-backup for sensitive app state.

## 1.3.6
- Parental PIN hashes now persist the PBKDF2 algorithm used, so OS upgrades cannot invalidate an existing PIN.
- Removed inactive live-only controls from the VOD player surface to avoid dead remote-focus targets.

## 1.3.5
- Added Sleep Timer controls to live and VOD playback (30/60/90/120 minutes or off).
- Connected the previously passive player settings icon to the real Settings screen.

## 1.3.4
- Extended Self-Healing playback to VOD and Series with bounded exponential retries and network-change recovery.
- Preserves playback position across retry attempts and stops retrying on authentication/not-found/unsupported-format failures.

## 1.3.3
- Added direct numeric channel selection from TV remotes (1-based channel numbers with a short commit timeout).
- Enforced parental-control gates during in-player channel changes, including guide selection, channel surf, and numeric jumps.

## 1.3.2
- Added environment-driven commercial release signing support without embedding signing secrets in source control.
- Release builds can now be reproducibly signed with a stable BRO TV keystore while debug/internal verification remains unchanged.

## 1.3.1
- Unified search now includes live channels alongside movies and series.
- Added Arabic-aware search normalization, category matching, hidden-content filtering, and bounded per-type results for TV performance.
- Live search results open through the full production player and therefore inherit parental gating and playback recovery.

## 1.3.0
- Adopted the production package identity `com.brotv.player` across the Android app and tests.
- Kept the commercial parental-control and unified-player work from the preceding internal build.

## 1.2.2
- Added commercial parental controls with PBKDF2-hashed PINs, 15-minute unlock sessions, and lockable Live/VOD/Series categories.
- Enforced parental gates centrally in full-screen live and VOD playback, including catch-up.
- Unified the last legacy live-channel launch path with the full production player.
- ChannelListActivity now uses FullPlayerActivity, preserving EPG/archive metadata through a tested Channel -> MergedChannel mapper.
- Removes a user-visible split where one live-TV screen previously bypassed failover, freeze detection, AFR, timeshift controls, smart quality, subtitles and network recovery.

## 1.2.1
- Centralized Xtream URL construction so credentials and query values are encoded consistently across playback, provider health, account info and resource-quota probes.
- Hardened provider health checks: only 2xx responses count as healthy, redirects are followed, UTF-8 is explicit, and connections are always disconnected.
- Hardened account/quota probes with the shared Xtream URL codec and consistent BRO TV User-Agent behavior.
- Added JVM tests for credentials containing spaces and reserved URL characters.

# BRO TV Changelog

## 1.2.0
- Hardened Xtream networking across Live, EPG, VOD, Series and Catch-up: HTTP status validation, redirects, deterministic disconnect and explicit JSON accept headers.
- Percent-encodes Xtream usernames, passwords and request parameters so accounts containing spaces, `+`, `@`, `/`, `&` and other reserved characters work correctly.
- Hardened Xtream stream URL parsing for encoded credentials, ports and invalid/non-live URLs.
- Sanitizes provider-supplied container extensions before building VOD/Series URLs.
- Clamps invalid Catch-up duration values and URL-encodes archive parameters.
- Added JVM compatibility tests for credential encoding, URL parsing, extension sanitization and Catch-up URL safety.

## 1.1.2
- Improved M3U provider compatibility: `#EXTINF` and metadata keys are now case-insensitive.
- Added support for `#EXTGRP` channel grouping and unquoted/single-quoted M3U metadata values.
- Hardened M3U HTTP loading by checking non-2xx responses and always disconnecting the connection.
- Added compatibility tests for mixed-case metadata, `#EXTGRP`, unquoted/single-quoted values and UTF-8 BOM input.

## 1.1.1
- Hardened HLS DVR byte-range recording for IPTV/CDN origins that ignore HTTP `Range` and return the full object. The recorder now slices the requested range locally or fails explicitly if the response cannot satisfy it.
- DVR checkpoint segment identities now use the resolved byte range, including implicit offsets, for safer restart/resume behavior.
- Added an integration test covering ignored-Range origins.

# Changelog

## 1.1.0 (versionCode 2)

- تثبيت اتجاه واجهة BRO TV على LTR.
- إضافة Connection / Resource Guard مع أولويات الجلسات وحدود Xtream والذاكرة/Decoder.
- إضافة DVR مباشر وتسجيل البرنامج الحالي من EPG.
- إضافة Scheduled Recording وAlarmManager والاستعادة بعد boot/update.
- إضافة Foreground Recording Service متعدد التسجيلات وربطه بأولوية المشغل الرئيسي.
- إضافة HLS DVR: master variants، AES-128، fMP4 init maps، byte ranges، polling وfailover.
- إضافة HLS checkpoint hash-only للاستكمال بعد إعادة تشغيل العملية.
- إضافة شاشة التسجيلات ومشغل التسجيلات المحلي.
- تشفير روابط التسجيل وحماية التسجيل عند انخفاض مساحة التخزين.
- إضافة اختبارات HLS parser وتحسينات تحقق الموارد والترجمة.

### 3.0.0-dev8
- Added BRO Doctor playback failure diagnosis foundation.
- Improved recovery classification for HTTP, network, decoder and malformed/unsupported streams.

### 3.0.0-dev10
- Faster Home return via short-lived account metadata cache.
- Manual provider refresh bypasses cached account state.
- Smoother rapid D-pad focus transitions on Home cards.

### 3.0.0-dev11
- Reduced poster-grid memory/network churn in Movies and Series.
- Cancelled obsolete Coil image requests on rebind/recycle.
- Cleared recycled poster views/listeners for smoother long-list navigation on Android TV.

## 3.0.0-dev12
- Faster movie D-pad navigation by cancelling/debouncing per-focus detail requests.
- Prevents stale movie-detail network work from accumulating during fast scrolling.

### 3.0.0-dev13
- Optimized series episode browsing for low-memory TV devices.
- Cancelled off-screen episode artwork work and reduced unnecessary list animation/GPU overhead.

### 3.0.0-dev15
- Faster Live TV startup by eliminating a competing pre-playback provider probe.
- Reduced TV navigation churn across Live, Movies, Series, Continue Watching and DVR lists.
- Added a redesigned BRO TV onboarding/login screen with Xtream, M3U and local QR pairing.
- Reorganized Settings into clear source, playback, experience, library and backup sections.
- Improved focus behavior and removed several animation/image-loading sources of jank.
- Hardened login errors so raw Android/provider exceptions are not shown to users.
- Movies and Series now restore the exact focused card after returning from playback/details and preserve category/sort state across Activity recreation.
- Series Details now preserves season, episode focus and sort order when returning from an episode.
- Rebalanced media grids to seven portrait-oriented columns and removed the always-on fake HD badge.
- Enabled Android RTL support so Arabic layouts can follow the selected locale correctly.
- Added a local mock Xtream server and ADB UI helper for provider-independent Android TV QA.
- Fixed mixed Arabic/Latin provider metadata direction so punctuation and English titles no longer render backwards.
- Added a branded series-poster fallback for missing/broken provider artwork.
