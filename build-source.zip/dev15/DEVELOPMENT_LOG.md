# BRO TV 3.0 development log

## Dev 1 — Playback intelligence foundation
- Added central `AutoPilotEngine` for source ranking.
- Startup now prefers proven stable sources instead of always source #1.
- Unknown sources are probed only when history cannot make a reliable decision.
- VOD failover now uses the same centralized ranking logic.
- Preserved bounded live recovery to prevent retry/failover storms.
- Added unit coverage for the health-history foundation.
- Bumped development version to 3.0.0-dev1 / versionCode 30.

Next engineering focus: channel-zap latency, preview lifecycle/resource contention, persistent health history, and large-list UI performance.

## 3.0.0-dev2 — Fast zapping pass
- Removed pre-playback network probing from the Live TV startup hot path.
- AutoPilot now selects instantly from observed playback history; unknown streams preserve provider order.
- Channel +/- and guide switching now use the same zero-network-I/O source selector.
- Background connection measurement still runs after playback starts, so future choices improve without delaying the viewer.
- Added AutoPilot hot-path unit tests (playlist order, exclusion, healthier observed source).
- Build/test command attempted offline; blocked before compilation because Gradle 8.6 is not cached and this environment cannot resolve services.gradle.org.

## 3.0.0-dev3 — Playback stability
- Added `PlaybackRecoveryGuard` to rate-limit expensive decoder/player recovery operations.
- Freeze and black-screen self-healing now avoids recovery storms on unstable providers and low-end Android TV hardware.
- Uses monotonic elapsed time for recovery throttling so wall-clock changes cannot break cooldowns.
- Added unit coverage for cooldown, rolling recovery window, and reset behavior.

## Dev4 — Rapid-zap workload control
- Cancel stale stream quality probes when the viewer changes channel again.
- Cancel stale EPG lookup/refresh jobs during rapid CHANNEL+/CHANNEL- navigation.
- Preserve immediate cached EPG rendering while ensuring background work follows only the selected channel.
- Explicitly cancel both jobs during player destruction.
- Goal: prevent coroutine/network-work buildup that can cause UI/decoder contention on low-memory Android TV devices.

## Dev5 — VOD/Series responsiveness
- Load independent Xtream movie and series catalogs concurrently instead of serially, capped at 3 providers to avoid socket/rate-limit pressure on TV hardware and IPTV servers.
- Provider failures are isolated with supervisor semantics; one dead provider no longer blocks successful providers from completing.
- Preserve configured provider ordering after concurrent fetches.
- Movie/Series poster grids now keep a single ListAdapter and use DiffUtil rather than rebuilding the entire RecyclerView adapter on every category/sort/favorite change.
- Disabled RecyclerView change animations and poster crossfades on dense TV grids to reduce GPU churn and remote-focus glitches.
- Marked poster grids fixed-size for cheaper layout passes.
- Full Gradle test attempted; still blocked before compilation because Gradle 8.6 cannot be downloaded in this environment.

## Dev6 — VOD recovery stability
- Applied PlaybackRecoveryGuard to movies/episodes so unstable VOD cannot trigger player rebuild storms.
- Recovery budget resets only after playback is READY, after network restoration, or when changing episode.
- Kept bounded exponential retry delays and terminal handling for auth/not-found/unsupported media errors.
- Added unit coverage for cooldown, recovery-window limit, and reset behavior.

## Dev7 — Conservative Smart Merge
- Rebuilt ChannelMerger to prefer false negatives over dangerous false-positive merges.
- Added EPG conflict protection and category compatibility checks.
- Added normalization for common Arabic/region/quality noise without fuzzy guessing.
- Stable merged IDs no longer embed raw channel names.
- Added focused ChannelMerger unit tests.

## Dev8 — BRO Doctor foundation
- Added deterministic `PlaybackDoctor` classification for auth/not-found/rate-limit/server/network/decoder/format failures.
- Wired live/full-player permanent-vs-retryable decision to the diagnosis engine.
- Added unit tests for all primary diagnosis classes.
- Kept diagnosis local/offline: no cloud cost or playback latency.

## Dev9
- BRO Doctor now executes guarded decoder rebuild recovery instead of only classifying the error.
- Added concise Arabic/English recovery status messages for decoder, network, and source/server failures.
- Decoder recovery is rate-limited by PlaybackRecoveryGuard to prevent player rebuild storms on low-end TVs.
- Added stable diagnosis message keys and unit coverage.
- Android XML resources parsed successfully; PlaybackDoctor pure Kotlin compilation checked when compiler is available.
- Full Gradle test remains blocked because Gradle 8.6 is not cached and services.gradle.org is unreachable in this environment.

## Dev10 — Home responsiveness / TV focus
- Added 60-second in-memory Xtream account-info cache so returning to Home does not trigger a fresh provider request on every `onResume`.
- Manual server refresh explicitly bypasses the cache, preserving truthful refresh behavior.
- Cache stores parsed account metadata only; provider credentials are not duplicated/persisted by the cache.
- Cancelled queued card focus animations before starting the next animation, improving rapid D-pad navigation on lower-end Android TV hardware.
- Static sanity checks passed.
- Full Gradle test remains blocked before compilation because Gradle 8.6 wrapper is not installed and services.gradle.org is unreachable in this environment.

## Dev11 — poster lifecycle / memory pressure
- Cancel Coil poster requests whenever a recycled TV grid cell is rebound or recycled.
- Clear recycled ImageViews and focus/click listeners to reduce stale references and wrong-poster flashes during fast scrolling.
- Applied consistently to Movies and Series grids.
- Bumped version to 3.0.0-dev11 (35).
- Gradle test attempted offline; wrapper still cannot obtain Gradle 8.6 in this environment, so full project compilation remains blocked by the build environment.

## Dev12 — 2026-09-18
- Audited Movies focus path for D-pad navigation.
- Found provider movie-details request was launched on every focused poster.
- Added cancellable/debounced hero-details job (300 ms): transient focus no longer creates network request storms.
- Cancels pending hero detail work on Activity destroy.
- Version bumped to 3.0.0-dev12 (36).

## Dev13 — Series episode list performance
- Cancel stale Coil artwork requests when episode rows are recycled.
- Disable episode artwork crossfade to reduce GPU work during rapid DPAD scrolling.
- Disable RecyclerView change animations for seasons/episodes and mark lists fixed-size.
- Limit off-screen episode row cache to reduce memory retention/GC pauses on low-RAM Android TV devices.

## Dev15 — TV-first UI, list efficiency and QA hardening
- Removed the extra live-source probe that competed with ExoPlayer during initial tune/zapping.
- Reused/diffed Live, VOD, Series, episode, resume and recording lists instead of rebuilding large RecyclerView trees.
- Cancelled stale artwork/detail work and disabled costly list/crossfade animations on dense TV screens.
- Reworked Login into a premium two-panel layout while preserving Xtream/M3U and local QR pairing.
- Moved the welcome header beside the BRO TV logo so all Xtream fields and the primary action remain visible at Android TV 1080p density.
- Reorganized Settings into real section headers with three-column action cards and deterministic D-pad focus.
- Replaced raw provider/network exception text with user-facing BRO TV connection messages.
- CI now builds with Java 17 / Gradle 8.6 and exercises Android TV; benchmark scripting is being tightened to keep the app foreground and measure deterministic D-pad navigation separately from stress input.
### Dev15 — media navigation continuity and reproducible UI QA
- Preserve focused Movies/Series cards when returning from child screens instead of jumping to the first item.
- Preserve Series Details season/sort/episode focus through playback return and Activity recreation.
- Switch VOD/Series grids to seven portrait-oriented columns, strengthen animation-free gold focus, and stop claiming HD when quality is unknown.
- Enable locale RTL at the application level for Arabic TV layouts.
- Add a deterministic local Xtream mock service plus ADB UI helper so Home/Live/Movies/Series/Settings can be exercised in CI without customer credentials or third-party content.


## Dev15 - deterministic VOD back navigation
- Player BACK is now handled explicitly on Android TV: it saves progress and returns to the caller instead of allowing Media3/controller focus to consume BACK and leave the player screen active.
- Auto-next countdown keeps its existing behavior: BACK cancels the countdown first.

## Dev15 - deterministic VOD return + resilient TV QA
- Route Android back dispatch and legacy TV BACK through one VodPlayerActivity handler so Media3 controller chrome cannot swallow the user's return action.
- Save resume progress before leaving playback and return to the exact caller Activity.
- Tighten QA to require SeriesDetailActivity to be the top resumed Activity after episode playback, not merely present in the task stack.
- Retry transient UIAutomator dump/pull/parse failures to avoid misclassifying emulator null-root timing hiccups as BRO TV failures.

## Dev15 - VOD back navigation reliability
- Fixed Back in VOD/episode player so it always exits to the previous screen while cancelling any auto-next countdown.
- Cleared stale auto-next state before advancing to the next episode, preventing a later Back press from being consumed unexpectedly.
### Dev15 — mixed-language metadata polish and series artwork fallback
- Changed provider-driven movie/series titles, metadata and plots from forced RTL to first-strong bidi so English/Arabic content keeps punctuation in the correct order while the TV layout stays RTL-friendly.
- Applied the same bidi handling to episode text.
- Added a visible series artwork fallback and only switches to center-crop after poster loading succeeds, avoiding an empty black poster panel when a provider image is missing or broken.

