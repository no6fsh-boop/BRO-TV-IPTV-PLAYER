#!/usr/bin/env bash
set -euxo pipefail
PKG='com.brotv.player'
APK='app/build/outputs/apk/debug/app-debug.apk'
UI='python3 ci/adb_ui.py'

adb install -r "$APK"
adb shell pm clear "$PKG" >/dev/null
adb logcat -c
adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 >/dev/null
sleep 5
$UI wait-id tabXtream --timeout 12
adb exec-out screencap -p > brotv-login-before.png
adb shell dumpsys gfxinfo "$PKG" reset || true
for i in $(seq 1 40); do
  adb shell input keyevent KEYCODE_DPAD_RIGHT
  adb shell input keyevent KEYCODE_DPAD_LEFT
  adb shell input keyevent KEYCODE_DPAD_DOWN
  adb shell input keyevent KEYCODE_DPAD_UP
done
adb shell dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' > focus-login.txt || true
grep -q "$PKG" focus-login.txt
adb exec-out screencap -p > brotv-login-after-nav.png

nohup python3 ci/mock_xtream_server.py --port 18080 > mock-xtream.log 2>&1 &
MOCK_PID=$!
sleep 1
curl --fail --silent 'http://127.0.0.1:18080/player_api.php?username=demo&password=demo' > mock-account.json

adb shell pm clear "$PKG" >/dev/null
adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 >/dev/null
sleep 4
$UI wait-id editPlaylistName --timeout 12
$UI text-id editPlaylistName BRO_QA
adb shell input keyevent KEYCODE_BACK
$UI text-id editUsername demo
adb shell input keyevent KEYCODE_BACK
$UI text-id editPassword demo
adb shell input keyevent KEYCODE_BACK
$UI text-id editHost 'http://10.0.2.2:18080'
adb shell input keyevent KEYCODE_BACK
$UI tap-id btnLogin
$UI wait-text 'Live TV' --timeout 25
sleep 2
adb exec-out screencap -p > brotv-home-mock.png

$UI tap-text 'Movies'
$UI wait-text 'All Movies' --timeout 20
sleep 3
adb exec-out screencap -p > brotv-movies-mock.png
# Remote contract: sidebar -> grid -> sidebar must be deterministic.
$UI assert-focus-within recyclerCategories --timeout 6
adb shell input keyevent KEYCODE_DPAD_RIGHT
$UI assert-focus-within recyclerMovies --timeout 6
adb shell input keyevent KEYCODE_DPAD_LEFT
$UI assert-focus-within recyclerCategories --timeout 6
adb shell input keyevent KEYCODE_DPAD_RIGHT
$UI assert-focus-within recyclerMovies --timeout 6
adb shell dumpsys gfxinfo "$PKG" reset || true
for i in $(seq 1 20); do adb shell input keyevent KEYCODE_DPAD_RIGHT; done
for i in $(seq 1 8); do adb shell input keyevent KEYCODE_DPAD_LEFT; done
adb shell dumpsys gfxinfo "$PKG" > gfxinfo-movies.txt || true
adb exec-out screencap -p > brotv-movies-after-nav.png

# Exercise actual VOD decode/seek using the local mock MP4.
$UI tap-text 'BRO Demo Movie 01'
$UI wait-id playerView --timeout 15
sleep 2
adb shell input keyevent KEYCODE_DPAD_RIGHT
adb shell input keyevent KEYCODE_DPAD_LEFT
adb exec-out screencap -p > brotv-movie-player-mock.png
adb shell input keyevent KEYCODE_BACK
$UI wait-text 'All Movies' --timeout 12

adb shell input keyevent KEYCODE_BACK
$UI wait-text 'Live TV' --timeout 12
$UI tap-text 'Series'
$UI wait-text 'All series' --timeout 20
sleep 3
adb exec-out screencap -p > brotv-series-mock.png
$UI assert-focus-within recyclerCategories --timeout 6
adb shell input keyevent KEYCODE_DPAD_RIGHT
$UI assert-focus-within recyclerSeries --timeout 6
adb shell input keyevent KEYCODE_DPAD_LEFT
$UI assert-focus-within recyclerCategories --timeout 6
adb shell input keyevent KEYCODE_DPAD_RIGHT
$UI assert-focus-within recyclerSeries --timeout 6
$UI tap-text 'BRO Demo Series 01'
sleep 1
adb shell dumpsys activity activities > activity-series-open.txt || true
adb exec-out screencap -p > brotv-series-after-open.png
$UI wait-id recyclerEpisodes --timeout 20
sleep 3
adb exec-out screencap -p > brotv-series-detail-mock.png
adb shell uiautomator dump /sdcard/brotv-series-detail.xml >/dev/null
adb pull /sdcard/brotv-series-detail.xml series-detail-ui.xml >/dev/null
python3 - <<'PYQA'
import re, sys
text=open('series-detail-ui.xml',encoding='utf-8').read()
if re.search(r'[\u0600-\u06FF]', text):
    print('Mixed Arabic text found while English locale is active', file=sys.stderr)
    sys.exit(1)
PYQA

# Open a real episode through the same mock provider and exercise transport keys.
$UI tap-text 'Episode 8'
$UI wait-id playerView --timeout 15
sleep 2
adb shell input keyevent KEYCODE_DPAD_RIGHT
adb shell input keyevent KEYCODE_DPAD_LEFT
adb exec-out screencap -p > brotv-episode-player-mock.png
adb shell input keyevent KEYCODE_BACK
sleep 1
adb shell dumpsys activity activities > activity-after-episode-back.txt || true
grep -Eq 'topResumedActivity=.*SeriesDetailActivity' activity-after-episode-back.txt
$UI wait-id recyclerEpisodes --timeout 12

adb shell input keyevent KEYCODE_BACK
adb shell input keyevent KEYCODE_BACK
$UI wait-text 'Live TV' --timeout 12
$UI tap-id btnSettings
$UI wait-id recyclerSettings --timeout 12
sleep 2
adb exec-out screencap -p > brotv-settings-mock.png

adb shell input keyevent KEYCODE_BACK
$UI wait-text 'Live TV' --timeout 12
$UI tap-id btnSearch
$UI wait-id keyboardRows --timeout 12
sleep 1
adb exec-out screencap -p > brotv-search-mock.png
adb shell input keyevent KEYCODE_BACK
$UI wait-text 'Live TV' --timeout 12
$UI tap-text 'Live TV'
$UI wait-id recyclerChannels --timeout 20
sleep 4
$UI assert-focus-within recyclerChannels --timeout 6
adb shell input keyevent KEYCODE_DPAD_LEFT
$UI assert-focus-within recyclerCategories --timeout 6
adb shell input keyevent KEYCODE_DPAD_RIGHT
$UI assert-focus-within recyclerChannels --timeout 6
adb exec-out screencap -p > brotv-live-mock.png
$UI tap-text 'BRO Demo Channel 01'
$UI wait-id btnLiveSource --timeout 15
sleep 2
adb shell input keyevent KEYCODE_DPAD_CENTER
adb exec-out screencap -p > brotv-live-player-mock.png
adb shell input keyevent KEYCODE_BACK
sleep 1
# Live player uses the first BACK to hide chrome; a second BACK returns to ChannelBrowseActivity.
if adb shell dumpsys activity activities | grep -Eq 'topResumedActivity=.*FullPlayerActivity'; then
  adb shell input keyevent KEYCODE_BACK
fi
$UI wait-id recyclerChannels --timeout 12

adb shell dumpsys meminfo "$PKG" > meminfo.txt || true
adb shell dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' > focus-final.txt || true
grep -q "$PKG" focus-final.txt
adb logcat -d '*:E' > android-tv-errors.log
! grep -Eq 'FATAL EXCEPTION|ANR in com\.brotv\.player' android-tv-errors.log
kill "$MOCK_PID" || true
