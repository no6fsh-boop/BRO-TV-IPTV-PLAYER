#!/usr/bin/env python3
import argparse, os, re, subprocess, tempfile, time, xml.etree.ElementTree as ET

def adb(*args, check=True, capture=False):
    p=subprocess.run(['adb',*args],check=check,text=True,capture_output=capture)
    return p.stdout if capture else ''

def dump(retries=6):
    remote='/sdcard/brotv-window.xml'
    last_error=None
    for attempt in range(retries):
        fd=tempfile.NamedTemporaryFile(delete=False,suffix='.xml'); fd.close()
        try:
            # Android TV emulators occasionally return a null/half-written UI root
            # while a new Activity is drawing. Retry the dump instead of turning an
            # emulator timing hiccup into an app failure.
            adb('shell','uiautomator','dump',remote)
            adb('pull',remote,fd.name)
            root=ET.parse(fd.name).getroot()
            if root is not None and any(True for _ in root.iter('node')):
                return root
            last_error=RuntimeError('empty UI hierarchy')
        except (subprocess.CalledProcessError, ET.ParseError, OSError, RuntimeError) as exc:
            last_error=exc
        finally:
            try: os.unlink(fd.name)
            except OSError: pass
        time.sleep(0.45 + attempt * 0.15)
    raise RuntimeError(f'UI hierarchy unavailable after {retries} attempts: {last_error}')

def center(bounds):
    n=list(map(int,re.findall(r'\d+',bounds)))
    return ((n[0]+n[2])//2,(n[1]+n[3])//2)

def find_all(root, rid=None, text=None):
    matches=[]
    for node in root.iter('node'):
        if rid and not node.attrib.get('resource-id','').endswith(':id/'+rid): continue
        if text is not None and node.attrib.get('text','') != text: continue
        if node.attrib.get('bounds',''): matches.append(node)
    return matches

def find(root, rid=None, text=None):
    matches=find_all(root,rid=rid,text=text)
    if matches: return matches[0]
    raise SystemExit(f'UI node not found rid={rid!r} text={text!r}')

def clickable_target(root, node):
    parents={child:parent for parent in root.iter() for child in parent}
    cur=node
    while cur is not None:
        if cur.attrib.get('clickable')=='true': return cur
        cur=parents.get(cur)
    return node

def tap(root, node):
    node=clickable_target(root,node)
    x,y=center(node.attrib['bounds']); adb('shell','input','tap',str(x),str(y)); time.sleep(.35)

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('tap-id'); p.add_argument('id')
    p=sub.add_parser('tap-text'); p.add_argument('text')
    p=sub.add_parser('text-id'); p.add_argument('id'); p.add_argument('text')
    p=sub.add_parser('wait-text'); p.add_argument('text'); p.add_argument('--timeout',type=float,default=12)
    p=sub.add_parser('wait-id'); p.add_argument('id'); p.add_argument('--timeout',type=float,default=12)
    p=sub.add_parser('assert-id'); p.add_argument('id')
    p=sub.add_parser('assert-focus-within'); p.add_argument('id'); p.add_argument('--timeout',type=float,default=6)
    a=ap.parse_args()
    if a.cmd in ('wait-text','wait-id','assert-focus-within'):
        end=time.time()+a.timeout
        while time.time()<end:
            try:
                root=dump()
                if a.cmd=='wait-text':
                    find(root,text=a.text)
                elif a.cmd=='wait-id':
                    find(root,rid=a.id)
                else:
                    container=find(root,rid=a.id)
                    if not any(n.attrib.get('focused')=='true' for n in container.iter('node')):
                        raise RuntimeError(f'focus is not within {a.id}')
                return
            except (SystemExit, RuntimeError):
                time.sleep(.5)
        target=a.text if a.cmd=='wait-text' else a.id
        detail=''
        if a.cmd=='assert-focus-within':
            try:
                root=dump()
                focused=[(n.attrib.get('resource-id',''), n.attrib.get('text',''), n.attrib.get('class',''))
                         for n in root.iter('node') if n.attrib.get('focused')=='true']
                detail=f'; focused nodes: {focused!r}'
            except RuntimeError as exc:
                detail=f'; final hierarchy unavailable: {exc}'
        raise SystemExit(f'timeout waiting for {a.cmd} {target!r}{detail}')
    root=dump()
    if a.cmd=='tap-id': tap(root,find(root,rid=a.id))
    elif a.cmd=='tap-text':
        matches=find_all(root,text=a.text)
        if not matches: raise SystemExit(f'UI node not found text={a.text!r}')
        # Hero titles and poster titles may contain the same text. Prefer a node
        # whose clickable ancestor is truly interactive so visual QA opens the card.
        chosen=None
        for node in matches:
            target=clickable_target(root,node)
            if target.attrib.get('clickable')=='true' or target.attrib.get('focusable')=='true':
                chosen=node; break
        tap(root,chosen or matches[0])
    elif a.cmd=='assert-id': find(root,rid=a.id)
    elif a.cmd=='text-id':
        node=find(root,rid=a.id); tap(root,node)
        adb('shell','input','keyevent','KEYCODE_CTRL_A',check=False)
        adb('shell','input','text',a.text)
        time.sleep(.25)

if __name__=='__main__': main()
