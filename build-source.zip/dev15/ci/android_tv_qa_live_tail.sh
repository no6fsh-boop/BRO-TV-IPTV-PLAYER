#!/usr/bin/env bash
set -euxo pipefail
PKG='com.brotv.player'
APK="${BROTV_QA_APK:-app-debug.apk}"
UI='python3 ci/adb_ui.py'

adb install -r "$APK"
adb shell pm clear "$PKG" >/dev/null
adb logcat -c

nohup python3 ci/mock_xtream_server.py --port 18080 > mock-xtream-live-tail.log 2>&1 &
MOCK_PID=$!
trap 'kill "$MOCK_PID" >/dev/null 2>&1 || true' EXIT
sleep 1
curl --fail --silent 'http://127.0.0.1:18080/player_api.php?username=demo&password=demo' > mock-account-live-tail.json

adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 >/dev/null
sleep 4
$UI wait-id editPlaylistName --timeout 12
$UI text-id editPlaylistName BRO_QA
adb shell input keyevent KEYCODE_BACK
$UI text-id editUsername demo
adb shell input keyevent KEYCODE_BACK
$UI text-id editPassword demo
adb shell input keyevent KEYCODE_BACK
$UI text-id editHost 'http://10.0.2.2:18080'
adb shell input keyevent KEYCODE_BACK
$UI tap-id btnLogin
$UI wait-text 'Live TV' --timeout 25

# Resume exactly at the point where the full QA previously stopped: Live TV.
$UI tap-text 'Live TV'
$UI wait-id recyclerChannels --timeout 20
$UI assert-focus-within recyclerChannels --timeout 6
adb shell input keyevent KEYCODE_DPAD_LEFT
$UI assert-focus-within recyclerCategories --timeout 6
adb shell input keyevent KEYCODE_DPAD_RIGHT
$UI assert-focus-within recyclerChannels --timeout 6
adb exec-out screencap -p > brotv-live-tail-list.png

$UI tap-text 'BRO Demo Channel 01'
$UI wait-id btnLiveSource --timeout 15
sleep 2
adb exec-out screencap -p > brotv-live-tail-player.png

# Source control must remain inside the player even if this fixture has only one source.
$UI tap-id btnLiveSource
sleep 1
adb shell dumpsys activity activities > live-tail-after-source.txt
if ! grep -Eq 'topResumedActivity=.*FullPlayerActivity' live-tail-after-source.txt; then
  echo 'Source action unexpectedly left FullPlayerActivity' >&2
  exit 1
fi

# Contract: first BACK hides live chrome; second BACK returns to the live channel list.
adb shell input keyevent KEYCODE_BACK
sleep 1
adb shell dumpsys activity activities > live-tail-after-back1.txt
if ! grep -Eq 'topResumedActivity=.*FullPlayerActivity' live-tail-after-back1.txt; then
  echo 'First BACK should keep the live player open while hiding chrome' >&2
  exit 1
fi
adb shell input keyevent KEYCODE_BACK
$UI wait-id recyclerChannels --timeout 12
adb shell dumpsys activity activities > live-tail-after-back2.txt
if ! grep -Eq 'topResumedActivity=.*ChannelBrowseActivity' live-tail-after-back2.txt; then
  echo 'Second BACK did not return to ChannelBrowseActivity' >&2
  exit 1
fi
$UI assert-focus-within recyclerChannels --timeout 6
adb exec-out screencap -p > brotv-live-tail-return.png

# Re-open and verify channel-guide behavior from the hidden-chrome state.
$UI tap-text 'BRO Demo Channel 01'
$UI wait-id btnLiveSource --timeout 15
adb shell input keyevent KEYCODE_BACK
sleep 1
adb shell input keyevent KEYCODE_DPAD_CENTER
$UI wait-id epgGuideOverlay --timeout 8
adb shell input keyevent KEYCODE_BACK
sleep 1
adb shell dumpsys activity activities > live-tail-after-guide-close.txt
if ! grep -Eq 'topResumedActivity=.*FullPlayerActivity' live-tail-after-guide-close.txt; then
  echo 'Closing guide unexpectedly left FullPlayerActivity' >&2
  exit 1
fi
adb shell input keyevent KEYCODE_BACK
$UI wait-id recyclerChannels --timeout 12

adb shell dumpsys meminfo "$PKG" > meminfo-live-tail.txt || true
adb shell dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' > focus-live-tail.txt || true
grep -q "$PKG" focus-live-tail.txt
adb logcat -d '*:E' > android-tv-errors-live-tail.log
! grep -Eq 'FATAL EXCEPTION|ANR in com\.brotv\.player' android-tv-errors-live-tail.log
