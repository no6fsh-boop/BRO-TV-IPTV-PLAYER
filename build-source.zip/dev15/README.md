# BRO TV 1.1.0 — Android TV IPTV Player

BRO TV مشروع Android TV مكتوب بـ Kotlin ومصمم للتنقل الكامل بالريموت. الواجهة مثبتة **LTR** (تبدأ من اليسار) مع دعم العربية والإنجليزية، وتشغيل Live TV / Movies / Series من Xtream Codes وM3U.

## المتطلبات والبناء

- Android Studio حديث
- JDK 17
- Android SDK 34
- Gradle Wrapper 8.6 (مرفق داخل المشروع)

افتح مجلد `IPTVPlayer` في Android Studio، نفّذ Gradle Sync ثم `assembleDebug` أو شغّل التطبيق على Android TV. أول Sync يحتاج اتصالاً لتحميل الاعتماديات إذا لم تكن موجودة في الـcache.

## الميزات الرئيسية

### IPTV والمشغل
- Xtream Codes وM3U/M3U8 مع مصادر متعددة.
- دمج نسخ القناة نفسها من أكثر من مصدر مع Auto-Failover.
- Live TV، Movies، Series، Continue Watching، Favorites، Profiles، Search وCatch-up.
- XMLTV EPG مع fallback إلى Xtream EPG.
- ترجمة Media3 حقيقية واختيار Track من داخل المشغل.
- Seek بالريموت، Picture-in-Picture، Match Frame Rate، أوضاع Buffer/Quality، وإحصاءات تشغيل تقنية.
- Multiview مع إدارة الموارد والأولوية.

### Connection / Resource Guard
- Lease لكل اتصال بث داخل التطبيق.
- قراءة `max_connections` و`active_cons` لحسابات Xtream عند توفرهما.
- أولوية المشغل الرئيسي أعلى من DVR وMultiview/Preview.
- DVR يمكنه إزاحة الأحمال الثانوية، والمشغل الرئيسي يمكنه إيقاف DVR محلياً عند الحاجة.
- حماية من ضغط الذاكرة وحدود Video Decoder للأحمال التي تحتاج Decoder.
- لا تُعرض بيانات الاعتماد في مفاتيح المزود أو التشخيص.

### DVR والتسجيل المجدول
- تسجيل مباشر للقناة الحالية.
- تسجيل البرنامج الحالي حتى نهاية وقت EPG.
- جدولة برامج قادمة من EPG حتى 48 ساعة من شاشة المشغل.
- شاشة تسجيلات لإيقاف/إلغاء/تشغيل/حذف التسجيلات.
- Foreground Service متعدد الوظائف مع WakeLock أثناء التسجيل.
- استعادة الجداول بعد إعادة تشغيل الجهاز أو تحديث التطبيق.
- AlarmManager Exact Alarm عند توفر الإذن، مع fallback آمن عند عدم توفره.
- تكامل كامل مع ResourceGuard حتى لا يتجاوز التسجيل حد اتصالات المزود.
- Failover بين مصادر القناة أثناء التسجيل.
- حماية مساحة التخزين وإنتاج `PARTIAL` بدلاً من الادعاء باكتمال ملف ناقص.
- HLS: Master variants، AES-128، `EXT-X-MAP`/fMP4، `EXT-X-BYTERANGE`، Live playlist polling.
- Checkpoint جانبي يحتوي **Hashes فقط** لاستكمال HLS بعد توقف العملية بدون تكرار المقاطع السابقة قدر الإمكان، ويُحذف عند إنهاء التسجيل.
- روابط البث المستخدمة في جداول DVR مشفرة في Room بواسطة Android Keystore.

> HLS المشفر بـ SAMPLE-AES/DRM لا يتم تسجيله كملف تالف؛ يتم رفض الصيغة بوضوح. التسجيل يحفظ الملفات داخل مساحة التطبيق (`Movies/BROTV_Recordings`) ولا يحتاج صلاحية Storage عامة.

### الأمان والنسخ الاحتياطي
- بيانات Xtream وروابط M3U/XMLTV مشفرة في قاعدة البيانات بـ Android Keystore.
- Device Backup مشفر بمفتاح الجهاز.
- Portable Backup مشفر بكلمة مرور باستخدام PBKDF2 + AES-GCM ويمكن نقله لجهاز آخر.
- الاستعادة تتحقق من الحمولة وتستخدم rollback إذا فشل التطبيق في منتصف العملية.
- QR pairing يعمل محلياً داخل نفس شبكة Wi‑Fi بدون خدمة سحابية خارجية.

## الاختبارات

المشروع يحتوي Unit Tests لسياسات ResourceGuard، Multiview، Timeshift، Buffer/Quality، XMLTV وHLS DVR parser. يوصى قبل إصدار APK بتنفيذ:

```bash
./gradlew testDebugUnitTest lintDebug assembleDebug
```

ثم تجربة APK على Android TV فعلي، خصوصاً حساب Xtream محدود الاتصالات، إعادة التشغيل أثناء تسجيل HLS، التسجيلات المتداخلة، وامتلاء مساحة التخزين.

## ملاحظات تشغيل

- منافذ الاقتران المحلي: `8098` لتسجيل الدخول و`8099` للبحث من الجوال.
- ميزات الجوال تتطلب أن يكون التلفزيون والجوال على شبكة LAN نفسها.
- Movies/Series تعتمد على دعم المزود لواجهات Xtream الخاصة بـ VOD/Series.
- عند حساب Xtream بحد اتصال واحد، يحمي BRO TV القناة الرئيسية؛ قد ينتظر DVR حتى يصبح اتصال متاحاً بدلاً من تجاوز الحد.
