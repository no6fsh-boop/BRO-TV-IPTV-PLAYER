plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-kapt")
}

val broTvKeystorePath = System.getenv("BROTV_KEYSTORE")
val broTvStorePassword = System.getenv("BROTV_STORE_PASSWORD")
val broTvKeyAlias = System.getenv("BROTV_KEY_ALIAS")
val broTvKeyPassword = System.getenv("BROTV_KEY_PASSWORD")

android {
    namespace = "com.brotv.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.brotv.player"
        minSdk = 21
        targetSdk = 34
        versionCode = 38
        versionName = "3.0.0-dev15"
    }

    signingConfigs {
        create("commercialRelease") {
            if (!broTvKeystorePath.isNullOrBlank()) {
                storeFile = file(broTvKeystorePath)
                storePassword = broTvStorePassword
                keyAlias = broTvKeyAlias
                keyPassword = broTvKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (!broTvKeystorePath.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("commercialRelease")
            }
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.leanback:leanback:1.0.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // ExoPlayer (Media3) لتشغيل بث HLS / M3U8 / DASH
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")

    // فك تشفير صوتي بديل بالسوفتوير (FFmpeg) لصيغ ما يدعمها ديكودر الجهاز أحياناً:
    // AC-3, E-AC-3, DTS, MP2, TrueHD (يطابق ميزة StreamVault). نسخة 1.3.1+2 مبنية
    // ومنشورة جاهزة على Maven Central خصيصاً لتطابق media3 1.3.1 الحالي عندنا — بدون
    // أي حاجة لترقية باقي وحدات media3 أو بناء الامتداد يدوياً (Jellyfin prebuilt AAR،
    // بديل رسمي عن امتداد FFmpeg من Google غير المنشور بسبب ترخيص FFmpeg).
    // DefaultRenderersFactory في PlayerEngine.kt مفعّل عليه EXTENSION_RENDERER_MODE_ON
    // مسبقاً، فبمجرد وجود هذا الديكودر بالـ classpath يتكشف ويُستخدم تلقائياً كـ fallback
    // فقط، بدون أي تعديل إضافي بالكود.
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+2")

    // Coroutines لتحميل القوائم بدون تجميد الواجهة
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // توليد كود QR محلياً (بدون أي سيرفر خارجي)
    implementation("com.google.zxing:core:3.5.3")

    // سيرفر HTTP محلي خفيف لاستقبال بيانات الجوال على نفس شبكة الواي فاي
    implementation("org.nanohttpd:nanohttpd:2.3.1")

    // تحميل صور البوسترات (الأفلام/المسلسلات) من روابط الإنترنت
    implementation("io.coil-kt:coil:2.6.0")

    // Room Database — أساس معماري حقيقي بدل SharedPreferences للبيانات المنظّمة (مصادر، تسجيل مشاهدة، مفضلة)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    testImplementation("junit:junit:4.13.2")
}
