package com.brotv.player.data

import android.content.Context
import com.brotv.player.model.Movie
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** يجمع أفلام كل حسابات Xtream المحفوظة مع بعض (الأفلام متوفرة فقط عبر Xtream API). */
class MovieRepository(context: Context) {

    private val sourcesManager = SourcesManager(context)

    suspend fun getMovies(): List<Movie> {
        val sources = sourcesManager.getXtreamSources()
        if (sources.isEmpty()) return emptyList()

        // Providers are independent. Loading them sequentially made the whole VOD screen wait
        // for every slow/dead provider. Keep concurrency deliberately small: many IPTV servers
        // rate-limit aggressive clients, and TV boxes have limited sockets/memory.
        val gate = Semaphore(3)
        return supervisorScope {
            sources.map { source ->
                async {
                    gate.withPermit {
                        runCatching {
                            val client = XtreamClient(source.xtreamServer, source.xtreamUsername, source.xtreamPassword)
                            client.getMovies(source.id)
                        }.getOrElse { emptyList() }
                    }
                }
            }.awaitAll().flatten() // awaitAll preserves configured provider order.
        }
    }

    /** id الفيلم بالصيغة movie::sourceId::numericId، نستخدم sourceId عشان نرجع لنفس الحساب الصحيح. */
    suspend fun getMovieDetails(movie: Movie): String {
        val parts = movie.id.split("::")
        if (parts.size < 3) return ""
        val sourceId = parts[1]
        val numericId = parts[2]

        val source = sourcesManager.getXtreamSources().firstOrNull { it.id == sourceId } ?: return movie.plot
        val client = XtreamClient(source.xtreamServer, source.xtreamUsername, source.xtreamPassword)
        // Focus movement should never crash Movies because one provider's details endpoint is
        // slow or malformed. Keep the list metadata as the visual fallback.
        return runCatching { client.getMovieDetails(numericId) }.getOrElse { movie.plot }
    }

    suspend fun isSourceSupported(): Boolean = sourcesManager.getXtreamSources().isNotEmpty()
}
