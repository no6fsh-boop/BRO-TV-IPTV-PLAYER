package com.brotv.player.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.db.RecordingEntity
import com.brotv.player.data.db.RecordingStatus
import com.brotv.player.dvr.DvrRecordingService
import com.brotv.player.dvr.DvrRepository
import kotlinx.coroutines.launch
import java.io.File

class RecordingsActivity : AppCompatActivity() {
    private lateinit var repository: DvrRepository
    private lateinit var adapter: RecordingAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recordings)
        repository = DvrRepository(this)
        adapter = RecordingAdapter(::onPrimaryAction, ::confirmDelete)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<RecyclerView>(R.id.recyclerRecordings).apply {
            layoutManager = LinearLayoutManager(this@RecordingsActivity)
            setHasFixedSize(true)
            setItemViewCacheSize(6)
            itemAnimator = null
            adapter = this@RecordingsActivity.adapter
        }
        requestNotificationPermissionIfNeeded()
        lifecycleScope.launch {
            repository.observeAll().collect { rows ->
                adapter.submitList(rows)
                findViewById<TextView>(R.id.txtEmpty).visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            repository.getFutureScheduled().forEach { row ->
                com.brotv.player.dvr.DvrScheduler.schedule(this@RecordingsActivity, row.id, row.scheduledStartMs, row.scheduledEndMs)
            }
        }
    }

    private fun onPrimaryAction(row: RecordingEntity) {
        when (RecordingStatus.from(row.status)) {
            RecordingStatus.RECORDING, RecordingStatus.WAITING_RESOURCE, RecordingStatus.INTERRUPTED -> {
                DvrRecordingService.stop(this, row.id)
            }
            RecordingStatus.SCHEDULED -> lifecycleScope.launch { repository.cancel(row.id) }
            RecordingStatus.COMPLETED, RecordingStatus.PARTIAL -> play(row)
            RecordingStatus.FAILED, RecordingStatus.MISSED, RecordingStatus.CANCELLED -> lifecycleScope.launch { repository.cancel(row.id) }
        }
    }

    private fun play(row: RecordingEntity) {
        if (row.filePath.isBlank() || !File(row.filePath).exists()) {
            Toast.makeText(this, R.string.dvr_file_missing, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, RecordingPlayerActivity::class.java).apply {
            putExtra(RecordingPlayerActivity.EXTRA_PATH, row.filePath)
            putExtra(RecordingPlayerActivity.EXTRA_MIME, row.mimeType)
            putExtra(RecordingPlayerActivity.EXTRA_TITLE, row.title)
        })
    }

    private fun confirmDelete(row: RecordingEntity) {
        val status = RecordingStatus.from(row.status)
        if (status in setOf(RecordingStatus.RECORDING, RecordingStatus.WAITING_RESOURCE, RecordingStatus.INTERRUPTED)) {
            Toast.makeText(this, R.string.dvr_cannot_delete_active, Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.dvr_delete_confirm_title)
            .setMessage(R.string.dvr_delete_confirm_message)
            .setPositiveButton(R.string.delete) { _, _ -> lifecycleScope.launch { repository.delete(row.id) } }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 710)
        }
    }
}
