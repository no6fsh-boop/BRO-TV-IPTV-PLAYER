package com.brotv.player.model

data class EpgProgram(
    val title: String,
    val startTime: String,
    val endTime: String,
    val progressPercent: Int,
    val startTimeMs: Long = 0L,
    val endTimeMs: Long = 0L,
    val description: String = ""
)
