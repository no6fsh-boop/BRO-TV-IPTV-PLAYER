package com.brotv.player.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R

class SeasonAdapter(
    private val seasons: List<Pair<Int, Int>>, // رقم الموسم إلى عدد حلقاته
    initialSelectedSeason: Int,
    private val onSelected: (Int) -> Unit
) : RecyclerView.Adapter<SeasonAdapter.SeasonViewHolder>() {

    private var selectedPosition = seasons.indexOfFirst { it.first == initialSelectedSeason }.coerceAtLeast(0)

    class SeasonViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.txtSeasonName)
        val count: TextView = view.findViewById(R.id.txtSeasonCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeasonViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_season, parent, false)
        return SeasonViewHolder(view)
    }

    override fun onBindViewHolder(holder: SeasonViewHolder, position: Int) {
        val (seasonNumber, episodeCount) = seasons[position]
        holder.name.text = holder.itemView.context.getString(R.string.season_number, seasonNumber)
        holder.count.text = holder.itemView.context.getString(R.string.episodes_count_short, episodeCount)
        holder.itemView.isSelected = position == selectedPosition

        holder.itemView.setOnClickListener {
            val previous = selectedPosition
            selectedPosition = holder.bindingAdapterPosition
            notifyItemChanged(previous)
            notifyItemChanged(selectedPosition)
            onSelected(seasonNumber)
        }
    }

    override fun getItemCount(): Int = seasons.size
}
