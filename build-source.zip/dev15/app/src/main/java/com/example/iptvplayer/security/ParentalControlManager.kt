package com.brotv.player.security

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * رقابة أبوية محلية: لا نخزن PIN كنص صريح. يتم حفظ salt + PBKDF2 hash فقط.
 * فتح الرقابة مؤقت على مستوى عملية التطبيق حتى لا يكرر المستخدم إدخال الرمز لكل حلقة.
 */
class ParentalControlManager(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    val isEnabled: Boolean get() = prefs.getString(KEY_HASH, null) != null

    fun setPin(pin: String) {
        require(isValidPin(pin))
        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val algorithm = preferredAlgorithm(android.os.Build.VERSION.SDK_INT)
        val hash = derive(pin, salt, algorithm)
        prefs.edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .putString(KEY_ALGORITHM, algorithm)
            .apply()
        unlockedUntilMs = 0L
    }

    fun disable() {
        prefs.edit().remove(KEY_SALT).remove(KEY_HASH).remove(KEY_ALGORITHM).apply()
        unlockedUntilMs = 0L
    }

    fun verify(pin: String): Boolean {
        val salt = prefs.getString(KEY_SALT, null)?.let { decode(it) } ?: return false
        val expected = prefs.getString(KEY_HASH, null)?.let { decode(it) } ?: return false
        val algorithm = prefs.getString(KEY_ALGORITHM, null)
            ?: preferredAlgorithm(android.os.Build.VERSION.SDK_INT)
        val actual = derive(pin, salt, algorithm)
        val ok = constantTimeEquals(expected, actual)
        if (ok) unlockedUntilMs = System.currentTimeMillis() + SESSION_UNLOCK_MS
        return ok
    }

    fun isSessionUnlocked(nowMs: Long = System.currentTimeMillis()): Boolean = nowMs < unlockedUntilMs

    fun requiresPin(category: String?, lockedCategories: Set<String>): Boolean {
        if (!isEnabled || isSessionUnlocked()) return false
        val normalized = category?.trim()?.takeIf { it.isNotEmpty() } ?: return false
        return lockedCategories.any { it.equals(normalized, ignoreCase = true) }
    }

    companion object {
        private const val PREFS_NAME = "parental_control"
        private const val KEY_SALT = "pin_salt"
        private const val KEY_HASH = "pin_hash"
        private const val KEY_ALGORITHM = "pin_algorithm"
        private const val SALT_BYTES = 16
        private const val ITERATIONS = 120_000
        private const val KEY_BITS = 256
        private const val SESSION_UNLOCK_MS = 15L * 60L * 1000L
        @Volatile private var unlockedUntilMs: Long = 0L

        fun isValidPin(pin: String): Boolean = pin.length in 4..8 && pin.all(Char::isDigit)

        internal fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
            if (a.size != b.size) return false
            var diff = 0
            for (i in a.indices) diff = diff or (a[i].toInt() xor b[i].toInt())
            return diff == 0
        }

        internal fun preferredAlgorithm(apiLevel: Int): String =
            if (apiLevel >= 26) "PBKDF2WithHmacSHA256" else "PBKDF2WithHmacSHA1"

        private fun derive(pin: String, salt: ByteArray, algorithm: String): ByteArray {
            val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_BITS)
            return try {
                SecretKeyFactory.getInstance(algorithm).generateSecret(spec).encoded
            } finally {
                spec.clearPassword()
            }
        }

        private fun decode(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP)
    }
}
