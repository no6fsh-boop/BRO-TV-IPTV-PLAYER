package com.brotv.player.player

/**
 * Keeps live channel surfing inside the folder/context the viewer opened.
 * Filtering never re-sorts the input list, so provider/folder order is preserved.
 */
object ChannelSurfScopePolicy {
    const val ALL = "__all__"
    const val FAVORITES = "__favorites__"

    fun resolve(explicitScope: String?, currentGroup: String): String {
        return explicitScope?.takeIf { it.isNotBlank() } ?: currentGroup
    }

    fun accepts(scope: String, groupTitle: String, isFavorite: Boolean): Boolean = when (scope) {
        ALL -> true
        FAVORITES -> isFavorite
        else -> groupTitle == scope
    }
}
