package com.brotv.player.player

/** Wrap-around channel navigation used by CHANNEL+/CHANNEL- remotes. */
object ChannelSurfPolicy {
    fun targetIndex(currentIndex: Int, size: Int, direction: Int): Int {
        if (size <= 0) return -1
        val start = currentIndex.takeIf { it in 0 until size } ?: 0
        val step = if (direction >= 0) 1 else -1
        return (start + step + size) % size
    }
}
