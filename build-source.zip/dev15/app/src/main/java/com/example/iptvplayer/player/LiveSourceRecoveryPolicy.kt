package com.brotv.player.player

/**
 * Bounded live-TV recovery. The current source gets at most one lightweight retry. Automatic
 * switching to an alternative source is DISABLED per field feedback: on real devices the
 * automatic source hop kept flapping between sources and stalled the device. After the retry is
 * exhausted, recovery stops and the viewer always chooses the source manually.
 */
object LiveSourceRecoveryPolicy {
    const val MAX_SAME_SOURCE_RETRIES = 1

    enum class Action { RETRY_CURRENT_SOURCE, TRY_ONE_ALTERNATIVE, REQUIRE_MANUAL_SOURCE }

    fun actionFor(
        retryAttempts: Int,
        permanentFailure: Boolean,
        alternativeAvailable: Boolean,
        automaticAlternativeAlreadyUsed: Boolean
    ): Action {
        if (!permanentFailure && retryAttempts < MAX_SAME_SOURCE_RETRIES) {
            return Action.RETRY_CURRENT_SOURCE
        }
        // Automatic alternative-source switching is intentionally disabled (see class doc).
        return Action.REQUIRE_MANUAL_SOURCE
    }
}
