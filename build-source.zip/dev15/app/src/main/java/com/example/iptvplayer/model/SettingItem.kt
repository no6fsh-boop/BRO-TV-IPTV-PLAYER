package com.brotv.player.model

data class SettingItem(
    val title: String,
    val iconRes: Int,
    val sectionTitle: String,
    val action: () -> Unit
)
