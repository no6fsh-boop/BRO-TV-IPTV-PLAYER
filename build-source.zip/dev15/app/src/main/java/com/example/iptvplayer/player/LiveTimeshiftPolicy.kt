package com.brotv.player.player

/**
 * Pure policy for native live-window timeshift.
 *
 * This does not record or rewrite the stream. It only exposes seeking when the
 * current HLS/DASH/live source already publishes a seekable sliding window.
 * Keeping the policy pure makes it easy to test without an Android runtime.
 */
object LiveTimeshiftPolicy {
    const val LIVE_EDGE_THRESHOLD_MS = 3_000L
    const val MIN_USEFUL_WINDOW_MS = 10_000L

    data class State(
        val supported: Boolean,
        val windowDurationMs: Long,
        val positionMs: Long,
        val behindLiveMs: Long,
        val atLiveEdge: Boolean,
        val canRewind: Boolean,
        val canForward: Boolean
    )

    fun evaluate(
        isLive: Boolean,
        isSeekable: Boolean,
        durationMs: Long,
        positionMs: Long
    ): State {
        val validDuration = durationMs.coerceAtLeast(0L)
        val validPosition = positionMs.coerceIn(0L, validDuration.coerceAtLeast(0L))
        val supported = isLive && isSeekable && validDuration >= MIN_USEFUL_WINDOW_MS
        val behindLive = if (supported) (validDuration - validPosition).coerceAtLeast(0L) else 0L
        val atLiveEdge = !supported || behindLive <= LIVE_EDGE_THRESHOLD_MS

        return State(
            supported = supported,
            windowDurationMs = validDuration,
            positionMs = validPosition,
            behindLiveMs = behindLive,
            atLiveEdge = atLiveEdge,
            canRewind = supported && validPosition > 0L,
            canForward = supported && !atLiveEdge
        )
    }

    fun clampSeek(targetMs: Long, windowDurationMs: Long): Long =
        targetMs.coerceIn(0L, windowDurationMs.coerceAtLeast(0L))
}
