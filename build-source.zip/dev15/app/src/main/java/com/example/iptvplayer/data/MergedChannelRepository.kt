package com.brotv.player.data

import android.content.Context
import com.brotv.player.model.MergedChannel

/**
 * يبني قائمة القنوات النهائية (مدمجة) من مصدر المستخدم المحفوظ،
 * مع تطبيق ترتيب المستخدم اليدوي المحفوظ مسبقاً.
 */
class MergedChannelRepository(context: Context) {

    private val channelRepository = ChannelRepository(context)
    private val prefs = PrefsManager(context)

    suspend fun loadMergedChannels(): List<MergedChannel> {
        val raw = channelRepository.loadChannels()
        val merged = ChannelMerger.merge(raw)
        return applySavedOrder(merged)
    }

    private fun applySavedOrder(channels: List<MergedChannel>): List<MergedChannel> {
        val order = prefs.channelOrder
        if (order.isEmpty()) return channels
        val byId = channels.associateBy { it.id }
        val ordered = order.mapNotNull { byId[it] }.toMutableList()
        ordered.addAll(channels.filter { it.id !in order })
        return ordered
    }

    fun saveOrder(channels: List<MergedChannel>) {
        prefs.channelOrder = channels.map { it.id }
    }
}
