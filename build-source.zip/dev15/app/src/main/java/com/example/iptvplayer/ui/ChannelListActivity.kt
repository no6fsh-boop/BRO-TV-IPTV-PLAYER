package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.ChannelRepository
import com.brotv.player.model.Channel
import com.brotv.player.model.toMergedChannel
import kotlinx.coroutines.launch

/**
 * تعرض قائمة القنوات المحمّلة من المصدر المحفوظ (M3U أو Xtream)
 * وتفتح مشغّل الفيديو عند اختيار قناة.
 */
class ChannelListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_channel_list)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerChannels)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        val txtEmpty = findViewById<TextView>(R.id.txtEmpty)

        recyclerView.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            try {
                val channels = ChannelRepository(this@ChannelListActivity).loadChannels()
                progressBar.visibility = View.GONE

                if (channels.isEmpty()) {
                    txtEmpty.text = getString(R.string.error_no_channels)
                    txtEmpty.visibility = View.VISIBLE
                    return@launch
                }

                recyclerView.adapter = ChannelAdapter(channels) { channel -> openPlayer(channel) }

            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                txtEmpty.text = e.message ?: getString(R.string.error_generic)
                txtEmpty.visibility = View.VISIBLE
            }
        }
    }

    private fun openPlayer(channel: Channel) {
        val intent = Intent(this, FullPlayerActivity::class.java)
        intent.putExtra(FullPlayerActivity.EXTRA_CHANNEL, channel.toMergedChannel())
        intent.putExtra(FullPlayerActivity.EXTRA_IS_LIVE, true)
        startActivity(intent)
    }
}
