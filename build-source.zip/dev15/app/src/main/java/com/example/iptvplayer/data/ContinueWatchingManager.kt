package com.brotv.player.data

import android.content.Context
import com.brotv.player.model.ContinueWatchingItem
import com.brotv.player.model.ContinueWatchingType
import org.json.JSONArray
import org.json.JSONObject

/**
 * يحفظ نقطة التوقف لكل فيلم/حلقة محلياً على الجهاز، ويستخدمها كرت
 * "استكمال المشاهدة" بالواجهة الرئيسية لعرض آخر شي كان المستخدم يتابعه.
 */
class ContinueWatchingManager(context: Context) {

    private val profileId = ProfileManager(context).activeProfileId
    private val prefs = context.getSharedPreferences("continue_watching_$profileId", Context.MODE_PRIVATE)

    /** ما يحفظ نقطة التوقف إلا لو تعدّى نسبة بسيطة من المدة، وما يحفظها لو قارب يخلص (تعتبر انتهت). */
    fun savePosition(item: ContinueWatchingItem) {
        if (item.durationMs <= 0) return
        val progress = item.positionMs.toFloat() / item.durationMs
        if (progress < 0.02f || progress > 0.95f) {
            remove(item.contentId)
            return
        }

        val all = getAll().toMutableList()
        all.removeAll { it.contentId == item.contentId }
        all.add(0, item)
        saveAll(all.take(MAX_ITEMS))
    }

    fun remove(contentId: String) {
        val all = getAll().filter { it.contentId != contentId }
        saveAll(all)
    }

    /** يمسح كل عناصر استكمال المشاهدة من نوع معيّن بس (أفلام أو حلقات)، يُستخدم من الإعدادات. */
    fun clearByType(type: ContinueWatchingType) {
        val remaining = getAll().filter { it.type != type }
        saveAll(remaining)
    }

    fun getAll(): List<ContinueWatchingItem> {
        val raw = prefs.getString(KEY_ITEMS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                ContinueWatchingItem(
                    contentId = obj.getString("contentId"),
                    type = ContinueWatchingType.valueOf(obj.getString("type")),
                    title = obj.getString("title"),
                    subtitle = obj.optString("subtitle", ""),
                    posterUrl = if (obj.isNull("posterUrl")) null else obj.optString("posterUrl", ""),
                    streamUrl = obj.getString("streamUrl"),
                    positionMs = obj.getLong("positionMs"),
                    durationMs = obj.getLong("durationMs"),
                    updatedAt = obj.getLong("updatedAt"),
                    seriesId = obj.optString("seriesId", "").ifBlank { null }
                )
            }.sortedByDescending { it.updatedAt }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getPosition(contentId: String): Long =
        getAll().firstOrNull { it.contentId == contentId }?.positionMs ?: 0L

    private fun saveAll(items: List<ContinueWatchingItem>) {
        val array = JSONArray()
        items.forEach { item ->
            val obj = JSONObject()
            obj.put("contentId", item.contentId)
            obj.put("type", item.type.name)
            obj.put("title", item.title)
            obj.put("subtitle", item.subtitle)
            obj.put("posterUrl", item.posterUrl)
            obj.put("streamUrl", item.streamUrl)
            obj.put("positionMs", item.positionMs)
            obj.put("durationMs", item.durationMs)
            obj.put("updatedAt", item.updatedAt)
            obj.put("seriesId", item.seriesId ?: "")
            array.put(obj)
        }
        prefs.edit().putString(KEY_ITEMS, array.toString()).apply()
    }

    companion object {
        private const val KEY_ITEMS = "items"
        private const val MAX_ITEMS = 30

        /** يقرأ استكمال المشاهدة لبروفايل معيّن بالاسم مباشرة (يُستخدم من BackupManager فقط). */
        fun getRawJsonForProfile(context: Context, profileId: String): String? {
            val prefs = context.getSharedPreferences("continue_watching_$profileId", Context.MODE_PRIVATE)
            return prefs.getString(KEY_ITEMS, null)
        }

        fun setRawJsonForProfile(context: Context, profileId: String, json: String) {
            val prefs = context.getSharedPreferences("continue_watching_$profileId", Context.MODE_PRIVATE)
            prefs.edit().putString(KEY_ITEMS, json).apply()
        }
    }
}
