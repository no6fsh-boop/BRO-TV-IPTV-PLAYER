package com.brotv.player.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load
import com.brotv.player.R
import com.brotv.player.model.ContinueWatchingItem

/**
 * Resume rows are diffed and recycle artwork aggressively so returning from playback does not
 * rebuild every row or keep stale image requests alive while the user scrolls with a TV remote.
 */
class ContinueWatchingAdapter(
    items: List<ContinueWatchingItem>,
    private val onClick: (ContinueWatchingItem) -> Unit
) : ListAdapter<ContinueWatchingItem, ContinueWatchingAdapter.CwViewHolder>(DIFF) {

    init {
        setHasStableIds(true)
        submitList(items.toList())
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<ContinueWatchingItem>() {
            override fun areItemsTheSame(oldItem: ContinueWatchingItem, newItem: ContinueWatchingItem): Boolean =
                oldItem.contentId == newItem.contentId && oldItem.type == newItem.type

            override fun areContentsTheSame(oldItem: ContinueWatchingItem, newItem: ContinueWatchingItem): Boolean =
                oldItem == newItem
        }
    }

    class CwViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val poster: ImageView = view.findViewById(R.id.imgCwPoster)
        val title: TextView = view.findViewById(R.id.txtCwTitle)
        val subtitle: TextView = view.findViewById(R.id.txtCwSubtitle)
        val progress: ProgressBar = view.findViewById(R.id.progressCw)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CwViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_continue_watching, parent, false)
        return CwViewHolder(view)
    }

    override fun getItemId(position: Int): Long {
        val item = getItem(position)
        return "${item.type}:${item.contentId}".hashCode().toLong()
    }

    override fun onBindViewHolder(holder: CwViewHolder, position: Int) {
        val item = getItem(position)
        holder.title.text = item.title
        holder.subtitle.text = item.subtitle
        val percent = if (item.durationMs > 0) ((item.positionMs * 100) / item.durationMs).toInt() else 0
        holder.progress.progress = percent.coerceIn(0, 100)
        holder.itemView.setOnClickListener { onClick(item) }

        holder.poster.dispose()
        if (item.posterUrl.isNullOrBlank()) {
            holder.poster.setImageDrawable(null)
        } else {
            holder.poster.load(item.posterUrl) { crossfade(false) }
        }
    }

    override fun onViewRecycled(holder: CwViewHolder) {
        holder.poster.dispose()
        holder.poster.setImageDrawable(null)
        holder.itemView.setOnClickListener(null)
        super.onViewRecycled(holder)
    }
}
