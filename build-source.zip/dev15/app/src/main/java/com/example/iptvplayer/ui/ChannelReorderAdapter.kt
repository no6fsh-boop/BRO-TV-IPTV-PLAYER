package com.brotv.player.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R

/**
 * ترتيب مجلدات البث بالريموت: OK يمسك المجلد، ↑/↓ يحركانه فعلياً، وOK يثبته.
 */
class ChannelReorderAdapter(
    private val folders: MutableList<String>,
    private val onOrderChanged: (List<String>) -> Unit,
    private val onRequestFocusAt: (Int) -> Unit
) : RecyclerView.Adapter<ChannelReorderAdapter.ReorderViewHolder>() {

    private var movingPosition = RecyclerView.NO_POSITION

    class ReorderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val index: TextView = view.findViewById(R.id.txtChannelIndex)
        val name: TextView = view.findViewById(R.id.txtChannelName)
        val state: TextView = view.findViewById(R.id.txtMoveState)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReorderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_reorder_channel, parent, false)
        return ReorderViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReorderViewHolder, position: Int) {
        val folder = folders[position]
        val context = holder.itemView.context
        val isMoving = position == movingPosition

        holder.index.text = context.getString(R.string.position_number, position + 1)
        holder.name.text = folder
        holder.state.text = context.getString(if (isMoving) R.string.reorder_move_hint else R.string.reorder_pick_hint)
        holder.itemView.isActivated = isMoving

        holder.itemView.setOnClickListener {
            val adapterPosition = holder.bindingAdapterPosition
            if (adapterPosition == RecyclerView.NO_POSITION) return@setOnClickListener
            if (movingPosition == RecyclerView.NO_POSITION) {
                movingPosition = adapterPosition
                notifyItemChanged(adapterPosition)
                onRequestFocusAt(adapterPosition)
            } else if (movingPosition == adapterPosition) {
                val previous = movingPosition
                movingPosition = RecyclerView.NO_POSITION
                notifyItemChanged(previous)
                onOrderChanged(folders.toList())
                onRequestFocusAt(adapterPosition)
            }
        }

        holder.itemView.setOnKeyListener { _, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return@setOnKeyListener false
            val adapterPosition = holder.bindingAdapterPosition
            if (adapterPosition == RecyclerView.NO_POSITION || movingPosition != adapterPosition) return@setOnKeyListener false

            val target = when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> adapterPosition - 1
                KeyEvent.KEYCODE_DPAD_DOWN -> adapterPosition + 1
                KeyEvent.KEYCODE_BACK -> {
                    movingPosition = RecyclerView.NO_POSITION
                    notifyItemChanged(adapterPosition)
                    onRequestFocusAt(adapterPosition)
                    return@setOnKeyListener true
                }
                else -> return@setOnKeyListener false
            }
            if (target !in folders.indices) return@setOnKeyListener true

            val item = folders.removeAt(adapterPosition)
            folders.add(target, item)
            movingPosition = target
            notifyItemMoved(adapterPosition, target)
            notifyItemChanged(adapterPosition)
            notifyItemChanged(target)
            onOrderChanged(folders.toList())
            onRequestFocusAt(target)
            true
        }
    }

    override fun getItemCount(): Int = folders.size
}
