package com.brotv.player.model

data class ChannelCategory(
    val id: String,
    val name: String,
    val count: Int,
    val iconRes: Int
)
