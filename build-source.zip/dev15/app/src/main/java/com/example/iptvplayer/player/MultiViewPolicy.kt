package com.brotv.player.player

/**
 * سياسة محافظة للـMultiview. الهدف حماية جودة البث وسلاسة الجهاز قبل تعظيم عدد النوافذ.
 * لا تفترض أن كل Android TV يقدر يشغل 4 Decoders في نفس الوقت.
 */
object MultiViewPolicy {

    data class DeviceProfile(
        val lowRamDevice: Boolean,
        val memoryClassMb: Int,
        val sdkInt: Int
    )

    fun maxPanes(profile: DeviceProfile): Int = when {
        profile.lowRamDevice -> 2
        profile.sdkInt < 23 -> 2
        profile.memoryClassMb < 192 -> 2
        profile.memoryClassMb < 256 -> 3
        else -> 4
    }

    /**
     * النافذة النشطة تحصل دائماً على أفضل سقف ممكن ضمن حمل الـMultiview،
     * والنوافذ الخلفية تُخفّض فقط عند 3-4 بثوث لحماية dropped frames والاستقرار.
     */
    fun ceiling(activePanes: Int, focused: Boolean): SmartQualityGuard.Ceiling = when {
        activePanes <= 1 -> SmartQualityGuard.Ceiling.USER_MAX
        activePanes == 2 && focused -> SmartQualityGuard.Ceiling.USER_MAX
        activePanes == 2 -> SmartQualityGuard.Ceiling.FHD_1080P
        focused -> SmartQualityGuard.Ceiling.FHD_1080P
        else -> SmartQualityGuard.Ceiling.HD_720P
    }

    /** تشغيل البثوث بتدرج يمنع دفعة اتصالات/Decoder واحدة عند استعادة الشاشة. */
    fun startupStaggerMs(paneIndex: Int): Long = paneIndex.coerceAtLeast(0) * 300L
}
