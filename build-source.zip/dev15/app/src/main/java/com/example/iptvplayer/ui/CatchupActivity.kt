package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.XtreamClient
import com.brotv.player.model.CatchupProgram
import com.brotv.player.model.MergedChannel
import kotlinx.coroutines.launch

/**
 * إعادة بث حقيقية عبر Xtream Archive/Timeshift API. تعمل فقط مع القنوات اللي
 * مزوّد الخدمة فعّل لها tv_archive، وبس ضمن مدة الاحتفاظ بالأرشيف (tv_archive_duration).
 */
class CatchupActivity : AppCompatActivity() {

    private var selectedChannel: MergedChannel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_catchup)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<RecyclerView>(R.id.recyclerArchiveChannels).layoutManager = LinearLayoutManager(this)
        findViewById<RecyclerView>(R.id.recyclerPrograms).layoutManager = LinearLayoutManager(this)

        loadArchiveChannels()
    }

    private fun loadArchiveChannels() {
        setLoading(true)
        lifecycleScope.launch {
            val allChannels = MergedChannelRepository(this@CatchupActivity).loadMergedChannels()
            val archiveChannels = allChannels.filter { it.hasArchive && it.archiveDurationDays > 0 }
            setLoading(false)

            if (archiveChannels.isEmpty()) {
                showEmpty(getString(R.string.catchup_no_channels))
                return@launch
            }

            findViewById<RecyclerView>(R.id.recyclerArchiveChannels).adapter =
                CatchupChannelAdapter(archiveChannels) { channel -> selectChannel(channel) }
        }
    }

    private fun selectChannel(channel: MergedChannel) {
        selectedChannel = channel
        findViewById<TextView>(R.id.txtSelectedChannel).text = channel.name
        findViewById<TextView>(R.id.txtEmpty).visibility = View.GONE
        setLoading(true)

        lifecycleScope.launch {
            val url = channel.sourceUrls.firstOrNull()
            val client = url?.let { XtreamClient.fromLiveStreamUrl(it) }
            val streamId = url?.let { client?.extractStreamId(it) }

            if (client == null || streamId == null) {
                setLoading(false)
                showEmpty(getString(R.string.catchup_stream_id_failed))
                return@launch
            }

            val programs = client.getEpgHistory(streamId)
            setLoading(false)

            if (programs.isEmpty()) {
                showEmpty(getString(R.string.catchup_no_programs))
                return@launch
            }

            findViewById<RecyclerView>(R.id.recyclerPrograms).adapter =
                CatchupProgramAdapter(programs) { program -> playProgram(channel, streamId, program) }
        }
    }

    private fun playProgram(channel: MergedChannel, streamId: String, program: CatchupProgram) {
        val url = channel.sourceUrls.firstOrNull() ?: return
        val client = XtreamClient.fromLiveStreamUrl(url) ?: return
        val catchupUrl = client.buildCatchupUrl(streamId, program.startUnix, program.durationMinutes)

        val intent = Intent(this, VodPlayerActivity::class.java)
        intent.putExtra(VodPlayerActivity.EXTRA_CONTENT_ID, "catchup_${channel.id}_${program.startUnix}")
        intent.putExtra(VodPlayerActivity.EXTRA_TITLE, program.title)
        intent.putExtra(VodPlayerActivity.EXTRA_SUBTITLE, "${channel.name} • ${program.startLabel}")
        intent.putExtra(VodPlayerActivity.EXTRA_STREAM_URL, catchupUrl)
        intent.putExtra(VodPlayerActivity.EXTRA_IS_MOVIE, true)
        intent.putExtra(VodPlayerActivity.EXTRA_PARENTAL_CATEGORY, channel.groupTitle)
        intent.putExtra(VodPlayerActivity.EXTRA_PARENTAL_SCOPE, VodPlayerActivity.PARENTAL_SCOPE_LIVE)
        startActivity(intent)
    }

    private fun setLoading(loading: Boolean) {
        findViewById<ProgressBar>(R.id.progressBar).visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showEmpty(message: String) {
        findViewById<TextView>(R.id.txtEmpty).apply {
            text = message
            visibility = View.VISIBLE
        }
    }
}
