package com.brotv.player.data

import android.content.Context
import androidx.appcompat.app.AlertDialog
import androidx.media3.common.C
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import com.brotv.player.R
import java.util.Locale

/**
 * يتحكم بترجمة الفيديو تلقائياً: ما يحتاج المستخدم يربط أي ملف ترجمة بنفسه.
 * لو الفيديو نفسه فيه مسار ترجمة مدمج (زي أغلب ملفات الأفلام/المسلسلات وبعض بث IPTV)،
 * التطبيق يفعّله تلقائياً لو لقى لغة تطابق لغة جهاز المستخدم، أو أول لغة متوفرة كحل احتياطي.
 */
object SubtitleController {

    /** يُستدعى مباشرة بعد تجهيز المشغل: يخلي Media3 يفعّل الترجمة تلقائياً لو لقى مسار مناسب. */
    fun enableAutoSubtitles(player: ExoPlayer) {
        val deviceLanguage = Locale.getDefault().language
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage(deviceLanguage)
            .setSelectUndeterminedTextLanguage(true) // كثير من مصادر IPTV ما تحدد لغة الترجمة، فنفعّلها لو موجودة برضه
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
    }

    /**
     * يفتح قائمة بكل مسارات الترجمة المتوفرة فعلياً بهذا الفيديو (تُكتشف تلقائياً من الملف نفسه)
     * مع خيار "إيقاف الترجمة"، تُستخدم فقط لو المستخدم يبي يبدّل يدوياً عن الاختيار التلقائي.
     */
    fun showSubtitleTracksDialog(context: Context, player: ExoPlayer) {
        val textGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }

        if (textGroups.isEmpty()) {
            AlertDialog.Builder(context, R.style.BroTvDialog)
                .setTitle(R.string.subtitles)
                .setMessage(R.string.subtitles_none)
                .setPositiveButton(R.string.ok_action, null)
                .show()
            return
        }

        val labels = mutableListOf(context.getString(R.string.subtitles_off))
        val optionsMap = mutableListOf<Pair<Int, Int>?>(null) // null = إيقاف

        textGroups.forEachIndexed { groupIndex, group ->
            for (trackIndex in 0 until group.length) {
                val format = group.getTrackFormat(trackIndex)
                val language = format.language?.uppercase(Locale.getDefault()) ?: context.getString(R.string.language_unknown)
                val label = format.label ?: language
                labels.add(label)
                optionsMap.add(groupIndex to trackIndex)
            }
        }

        AlertDialog.Builder(context, R.style.BroTvDialog)
            .setTitle(R.string.subtitles_choose_language)
            .setItems(labels.toTypedArray()) { _, which ->
                val selection = optionsMap[which]
                if (selection == null) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                        .build()
                } else {
                    val (groupIndex, trackIndex) = selection
                    val mediaTrackGroup = textGroups[groupIndex].mediaTrackGroup
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(TrackSelectionOverride(mediaTrackGroup, trackIndex))
                        .build()
                }
            }
            .show()
    }
}
