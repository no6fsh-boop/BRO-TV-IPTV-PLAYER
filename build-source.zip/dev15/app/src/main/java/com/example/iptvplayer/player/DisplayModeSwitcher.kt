package com.brotv.player.player

import android.app.Activity
import android.os.Build
import android.util.Log

/**
 * يبدّل دقة/معدل تحديث خرج HDMI فعلياً (Seamless Display Mode Switching) ليطابق دقة
 * المحتوى الحالي بدل ما يبقى الجهاز مثبّت على وضع واحد (غالباً 1080p) ويكبّر/يصغّر
 * الفيديو داخلياً بالسوفتوير فقط.
 *
 * ليش هذا مهم فعلياً (مو بس تجميلي): `DefaultTrackSelector` في Media3 افتراضياً يقيّد
 * اختيار الجودة من قوائم HLS/DASH التكيفية (Adaptive) بحسب "viewport" الشاشة الحالي —
 * يعني لو خرج الجهاز HDMI حالياً على 1080p، بيختار أعلى نسخة ≤1080p من البث حتى لو
 * فيه نسخة 4K متوفرة أصلاً (PlayerEngine.buildQualityParameters يعطّل هذا القيد
 * الافتراضي بشكل منفصل). أما هذا الملف فمسؤول عن الشق الثاني: تبديل *دقة خرج الجهاز
 * الفعلية* لتطابق المحتوى، وهذا هو اللي يخلي شاشة التلفزيون (زي LG) تعرض إشعار "4K"
 * الحقيقي — لأنه إشعار مبني على إشارة HDMI الفعلية الواصلة له، مو على شيء داخلي بالتطبيق.
 */
object DisplayModeSwitcher {
    private const val TAG = "DisplayModeSwitcher"

    /** تمثيل خفيف لوضع عرض مدعوم على الشاشة — بدون أي اعتمادية Android، لتسهيل الاختبار. */
    data class ModeInfo(val modeId: Int, val width: Int, val height: Int, val refreshRate: Float)

    /**
     * يختار أنسب `modeId` من بين الأوضاع المدعومة لدقة/معدل تحديث محتوى معيّن.
     * دالة صرفة بالكامل (بدون Android) — تُستخدم من `applyBestDisplayMode` وتُختبر مباشرة.
     *
     * منطق الاختيار:
     * 1) نفضّل أي وضع دقته تكفي المحتوى فعلياً بدون تصغير (width/height ≥ المحتوى).
     * 2) من بين المرشحين، نفضّل أقرب دقة فعلية (نتجنب وضع أكبر من اللازم بلا داعٍ).
     * 3) من بين المتقاربين بالدقة، نفضّل معدل تحديث يطابق معدل الفيديو أو مضاعف صحيح له
     *    (24fps على شاشة 48/72/96Hz مثلاً) لتفادي الـjudder، وإلا أقرب معدل متاح.
     */
    internal fun bestMatchingModeId(
        modes: List<ModeInfo>,
        contentWidth: Int,
        contentHeight: Int,
        contentFrameRate: Float
    ): Int? {
        if (modes.isEmpty() || contentWidth <= 0 || contentHeight <= 0) return null

        val sufficient = modes.filter { it.width >= contentWidth && it.height >= contentHeight }
        val candidates = if (sufficient.isNotEmpty()) sufficient else modes

        val minResDiff = candidates.minOf { resolutionDistance(it, contentWidth, contentHeight) }
        val closestRes = candidates.filter { resolutionDistance(it, contentWidth, contentHeight) == minResDiff }

        if (contentFrameRate <= 0f) {
            return closestRes.minByOrNull { it.modeId }?.modeId
        }
        return closestRes.minByOrNull { refreshRateScore(it.refreshRate, contentFrameRate) }?.modeId
    }

    private fun resolutionDistance(mode: ModeInfo, contentWidth: Int, contentHeight: Int): Long {
        val modeArea = mode.width.toLong() * mode.height.toLong()
        val contentArea = contentWidth.toLong() * contentHeight.toLong()
        return kotlin.math.abs(modeArea - contentArea)
    }

    private fun refreshRateScore(modeRate: Float, contentRate: Float): Float {
        if (modeRate <= 0f || contentRate <= 0f) return Float.MAX_VALUE
        val ratio = modeRate / contentRate
        val nearestMultiple = kotlin.math.round(ratio).coerceAtLeast(1f)
        val multipleError = kotlin.math.abs(ratio - nearestMultiple)
        // فرق بسيط جداً كـtie-breaker فقط، ما يطغى على دقة تقارب المضاعف الصحيح.
        return multipleError + kotlin.math.abs(modeRate - contentRate) * 0.001f
    }

    /**
     * يطبّق أنسب وضع عرض فعلي على نافذة الـActivity ليطابق دقة/معدل تحديث المحتوى الحالي،
     * ويرجّع الوضع (`ModeInfo`) اللي انطبّق فعلياً — سواء بدّلناه الآن أو كان مطابق أصلاً —
     * حتى يقدر المتصل يتأكد ويُظهر للمستخدم إن دقة الخرج الفعلية صارت 4K حقيقي، لا مجرد
     * فك ترميز داخلي. يرجّع null لو الجهاز أقدم من Android 6 أو ما قدرنا نحدد وضع مناسب.
     */
    fun applyBestDisplayMode(activity: Activity, contentWidth: Int, contentHeight: Int, contentFrameRate: Float): ModeInfo? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null
        if (contentWidth <= 0 || contentHeight <= 0) return null
        return runCatching {
            @Suppress("DEPRECATION")
            val display = activity.windowManager?.defaultDisplay ?: return@runCatching null
            val supportedModes = display.supportedModes ?: return@runCatching null
            val modes = supportedModes.map { ModeInfo(it.modeId, it.physicalWidth, it.physicalHeight, it.refreshRate) }
            val bestId = bestMatchingModeId(modes, contentWidth, contentHeight, contentFrameRate) ?: return@runCatching null
            val bestMode = modes.firstOrNull { it.modeId == bestId } ?: return@runCatching null

            val window = activity.window ?: return@runCatching null
            val params = window.attributes
            if (params.preferredDisplayModeId != bestId) {
                params.preferredDisplayModeId = bestId
                window.attributes = params
            }
            bestMode
        }.onFailure { Log.w(TAG, "failed to apply display mode", it) }.getOrNull()
    }

    /** يرجّع الجهاز لوضع العرض الافتراضي (النظام يختار) — يُستدعى عند إغلاق المشغّل. */
    fun resetDisplayMode(activity: Activity) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        runCatching {
            val window = activity.window ?: return
            val params = window.attributes
            if (params.preferredDisplayModeId == 0) return
            params.preferredDisplayModeId = 0
            window.attributes = params
        }.onFailure { Log.w(TAG, "failed to reset display mode", it) }
    }
}
