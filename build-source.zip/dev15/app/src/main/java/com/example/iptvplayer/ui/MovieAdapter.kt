package com.brotv.player.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load
import com.brotv.player.R
import com.brotv.player.model.Movie

class MovieAdapter(
    movies: List<Movie>,
    private val onFocus: (Movie) -> Unit = {},
    private val onLeftEdge: () -> Unit = {},
    private val onClick: (Movie) -> Unit
) : ListAdapter<Movie, MovieAdapter.MovieViewHolder>(DIFF) {

    init {
        setHasStableIds(true)
        submitList(movies)
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Movie>() {
            override fun areItemsTheSame(oldItem: Movie, newItem: Movie) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Movie, newItem: Movie) = oldItem == newItem
        }
    }

    class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val poster: ImageView = view.findViewById(R.id.imgPoster)
        val placeholder: ImageView = view.findViewById(R.id.imgPosterPlaceholder)
        val title: TextView = view.findViewById(R.id.txtPosterTitle)
        val subtitle: TextView = view.findViewById(R.id.txtPosterSubtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_poster, parent, false)
        return MovieViewHolder(view)
    }

    override fun getItemId(position: Int): Long = getItem(position).id.hashCode().toLong()

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = getItem(position)
        holder.title.text = movie.name
        holder.subtitle.text = movie.year
        holder.itemView.setOnFocusChangeListener { _, hasFocus ->
            holder.itemView.scaleX = if (hasFocus) 1.035f else 1f
            holder.itemView.scaleY = if (hasFocus) 1.035f else 1f
            holder.itemView.elevation = if (hasFocus) 8f * holder.itemView.resources.displayMetrics.density else 0f
            if (hasFocus) onFocus(movie)
        }
        holder.itemView.nextFocusUpId = if (position < 4) R.id.btnSortDefault else View.NO_ID
        holder.itemView.setOnKeyListener { _, keyCode, event ->
            val adapterPosition = holder.bindingAdapterPosition
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_LEFT &&
                adapterPosition != RecyclerView.NO_POSITION && adapterPosition % 4 == 0
            ) {
                onLeftEdge()
                true
            } else {
                false
            }
        }
        holder.itemView.setOnClickListener { onClick(movie) }

        holder.poster.dispose()
        holder.poster.tag = movie.id
        holder.placeholder.setImageResource(R.drawable.ic_movie)
        holder.placeholder.visibility = View.VISIBLE
        if (movie.posterUrl.isNullOrBlank()) {
            holder.poster.setImageDrawable(null)
        } else {
            holder.poster.load(movie.posterUrl) {
                // Keep a branded placeholder visible until artwork really succeeds.
                // Broken/slow provider artwork should never leave an empty black card.
                crossfade(false)
                listener(
                    onSuccess = { _, _ ->
                        if (holder.poster.tag == movie.id) holder.placeholder.visibility = View.GONE
                    },
                    onError = { _, _ ->
                        if (holder.poster.tag == movie.id) holder.placeholder.visibility = View.VISIBLE
                    }
                )
            }
        }
    }

    override fun onViewRecycled(holder: MovieViewHolder) {
        holder.poster.dispose()
        holder.poster.tag = null
        holder.poster.setImageDrawable(null)
        holder.placeholder.visibility = View.VISIBLE
        holder.itemView.setOnFocusChangeListener(null)
        holder.itemView.setOnKeyListener(null)
        holder.itemView.setOnClickListener(null)
        holder.itemView.scaleX = 1f
        holder.itemView.scaleY = 1f
        holder.itemView.elevation = 0f
        super.onViewRecycled(holder)
    }

}
