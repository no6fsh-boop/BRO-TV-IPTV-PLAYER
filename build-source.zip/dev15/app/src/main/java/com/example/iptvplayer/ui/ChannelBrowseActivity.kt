package com.brotv.player.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.PrefsManager
import com.brotv.player.model.ChannelCategory
import com.brotv.player.model.MergedChannel
import com.brotv.player.player.ResourceBudget
import com.brotv.player.player.ResourceGuard
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * شاشة تصفح القنوات الرئيسية: مجلدات على اليسار، قائمة القنوات بالوسط،
 * ومعاينة حية على اليمين مع أزرار إخفاء/الجودة/المفضلة.
 * تدعم Auto-Failover: لو تعطل مصدر القناة أثناء المعاينة يجرب المصدر التالي تلقائياً.
 */
class ChannelBrowseActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private var allChannels: List<MergedChannel> = emptyList()
    private var currentChannel: MergedChannel? = null
    private var currentCategoryId: String = com.brotv.player.player.ChannelSurfScopePolicy.ALL
    private var currentSourceIndex = 0
    private val failedSourceUrlsThisSession = mutableSetOf<String>()
    private var previewPlayer: ExoPlayer? = null
    private var previewLease: ResourceGuard.Lease? = null
    private var previewRequestToken = 0L
    private var previewEpgJob: Job? = null
    private val xmltvEpgRepository by lazy { com.brotv.player.data.XmltvEpgRepository(this) }
    private lateinit var channelAdapter: MergedChannelAdapter
    private var pendingChannelFocus: Int? = null
    private var channelFocusListener: RecyclerView.OnChildAttachStateChangeListener? = null

    private val fullPlayerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val data = result.data ?: return@registerForActivityResult
        val returned = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            data.getParcelableExtra(FullPlayerActivity.EXTRA_RETURN_CHANNEL, MergedChannel::class.java)
        } else {
            @Suppress("DEPRECATION")
            data.getParcelableExtra(FullPlayerActivity.EXTRA_RETURN_CHANNEL)
        } ?: return@registerForActivityResult

        if (allChannels.none { it.id == returned.id }) return@registerForActivityResult
        currentChannel = returned
        showChannels(currentVisibleChannels(), focusChannelId = returned.id, autoPreview = false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_channel_browse)
        prefs = PrefsManager(this)
        findViewById<TextView>(R.id.btnTopLive).isSelected = true

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.imgHeaderLogo).setOnClickListener { finish() }
        findViewById<TextView>(R.id.btnTopLive).setOnClickListener { focusChannelList() }
        findViewById<TextView>(R.id.btnTopMovies).setOnClickListener { switchSection(MoviesActivity::class.java) }
        findViewById<TextView>(R.id.btnTopSeries).setOnClickListener { switchSection(SeriesActivity::class.java) }
        findViewById<ImageView>(R.id.btnSearchLive).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java).apply {
                putExtra(SearchActivity.EXTRA_SCOPE, SearchActivity.Scope.LIVE.name)
            })
        }

        findViewById<RecyclerView>(R.id.recyclerCategories).apply {
            layoutManager = LinearLayoutManager(this@ChannelBrowseActivity)
            setHasFixedSize(true)
            itemAnimator = null
        }
        channelAdapter = MergedChannelAdapter(
            gridSpanCount = CHANNEL_GRID_SPAN,
            onLeftEdge = { focusSelectedCategory() },
            onClick = { selected -> onChannelSelected(selected) }
        )
        findViewById<RecyclerView>(R.id.recyclerChannels).apply {
            // شبكة شعارات القنوات (Grid) بدل القائمة النصية، لتطابق تصميم شعارات القنوات.
            layoutManager = GridLayoutManager(this@ChannelBrowseActivity, CHANNEL_GRID_SPAN)
            setHasFixedSize(true)
            setItemViewCacheSize(CHANNEL_GRID_SPAN * 3)
            itemAnimator = null
            adapter = channelAdapter
        }

        loadChannels()
        setupPreviewActions()
    }

    private fun switchSection(target: Class<out AppCompatActivity>) {
        startActivity(Intent(this, target))
        finish()
    }

    private fun focusChannelList() {
        val currentId = currentChannel?.id
        val index = currentId?.let { id -> channelAdapter.currentList.indexOfFirst { it.id == id } } ?: -1
        if (channelAdapter.itemCount > 0) focusChannelAt(index.takeIf { it >= 0 } ?: 0)
    }

    private fun clearPendingChannelFocus(recycler: RecyclerView) {
        channelFocusListener?.let(recycler::removeOnChildAttachStateChangeListener)
        channelFocusListener = null
        pendingChannelFocus = null
    }

    private fun tryFocusChannel(recycler: RecyclerView, position: Int) {
        if (pendingChannelFocus != position || isFinishing) return
        val item = recycler.findViewHolderForAdapterPosition(position)?.itemView ?: return
        if (item.requestFocus() && recycler.hasWindowFocus()) clearPendingChannelFocus(recycler)
    }

    private fun focusChannelAt(position: Int) {
        val recycler = findViewById<RecyclerView>(R.id.recyclerChannels)
        clearPendingChannelFocus(recycler)
        pendingChannelFocus = position
        val listener = object : RecyclerView.OnChildAttachStateChangeListener {
            override fun onChildViewAttachedToWindow(view: View) {
                if (recycler.getChildAdapterPosition(view) == position) {
                    recycler.post { tryFocusChannel(recycler, position) }
                }
            }

            override fun onChildViewDetachedFromWindow(view: View) = Unit
        }
        channelFocusListener = listener
        recycler.addOnChildAttachStateChangeListener(listener)
        recycler.scrollToPosition(position)
        recycler.post { tryFocusChannel(recycler, position) }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::channelAdapter.isInitialized) {
            pendingChannelFocus?.let { position ->
                val recycler = findViewById<RecyclerView>(R.id.recyclerChannels)
                recycler.post { tryFocusChannel(recycler, position) }
            }
        }
    }

    private fun focusSelectedCategory() {
        val recycler = findViewById<RecyclerView>(R.id.recyclerCategories)
        val position = (recycler.adapter as? CategoryAdapter)?.selectedAdapterPosition() ?: 0
        recycler.scrollToPosition(position)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus() ?: recycler.requestFocus()
        }
    }

    private fun loadChannels() {
        setLoading(true)
        lifecycleScope.launch {
            val repository = MergedChannelRepository(this@ChannelBrowseActivity)
            val hidden = prefs.hiddenChannelIds
            val hiddenCategories = prefs.hiddenLiveCategories
            allChannels = repository.loadMergedChannels()
                .filter { it.id !in hidden }
                .filter { it.groupTitle !in hiddenCategories }
            setLoading(false)
            buildCategories()
            showChannels(allChannels, autoPreview = false)
        }
    }

    private fun buildCategories(): List<ChannelCategory> {
        val grouped = allChannels.groupBy { it.groupTitle }
        val savedOrder = prefs.liveCategoryOrder
        val orderedTitles = buildList {
            addAll(savedOrder.filter { it in grouped })
            addAll(grouped.keys.filter { it !in savedOrder })
        }
        val categories = mutableListOf(
            ChannelCategory("all", getString(R.string.all_channels), allChannels.size, R.drawable.ic_all_channels)
        )
        orderedTitles.forEach { title ->
            val list = grouped[title].orEmpty()
            categories.add(ChannelCategory(title, title, list.size, R.drawable.ic_folder))
        }

        val selectedId = if (currentCategoryId == com.brotv.player.player.ChannelSurfScopePolicy.ALL) "all" else currentCategoryId
        findViewById<RecyclerView>(R.id.recyclerCategories).adapter = CategoryAdapter(
            categories = categories,
            selectedCategoryId = selectedId,
            onMoveRight = { focusChannelList() }
        ) { category ->
            currentCategoryId = if (category.id == "all") com.brotv.player.player.ChannelSurfScopePolicy.ALL else category.id
            currentChannel = null
            showChannels(currentVisibleChannels(), autoPreview = false)
        }
        return categories
    }

    private fun currentVisibleChannels(): List<MergedChannel> =
        if (currentCategoryId == com.brotv.player.player.ChannelSurfScopePolicy.ALL) {
            allChannels
        } else {
            allChannels.filter { it.groupTitle == currentCategoryId }
        }

    private fun showChannels(
        list: List<MergedChannel>,
        focusChannelId: String? = null,
        autoPreview: Boolean = true
    ) {
        val recycler = findViewById<RecyclerView>(R.id.recyclerChannels)
        val targetIndex = when {
            focusChannelId != null -> list.indexOfFirst { it.id == focusChannelId }.takeIf { it >= 0 }
            currentChannel != null -> list.indexOfFirst { it.id == currentChannel?.id }.takeIf { it >= 0 }
            list.isNotEmpty() -> 0
            else -> null
        }
        val target = targetIndex?.let(list::getOrNull)
        if (autoPreview && target != null && previewPlayer != null) {
            playPreview(target)
        }
        // ListAdapter diffs on a background thread. Wait for its commit before scrolling to
        // and focusing the selected card; a RecyclerView with no children cannot take focus.
        channelAdapter.submitList(list.toList()) {
            if (targetIndex != null) focusChannelAt(targetIndex)
            else clearPendingChannelFocus(recycler)
        }
    }

    /** TV-first: a channel click opens the full player without holding a second preview socket. */
    private fun onChannelSelected(channel: MergedChannel) {
        currentChannel = channel
        openFullPlayer(channel)
    }

    private fun openFullPlayer(channel: MergedChannel) {
        // Close the preview socket before the full player asks the provider for another slot.
        // Relying only on onStop() is too late on single-connection Xtream accounts.
        previewRequestToken++
        releasePreview(releaseLease = true)

        val intent = Intent(this, FullPlayerActivity::class.java)
        intent.putExtra(FullPlayerActivity.EXTRA_CHANNEL, channel)
        intent.putExtra(FullPlayerActivity.EXTRA_IS_LIVE, true)
        intent.putExtra(FullPlayerActivity.EXTRA_SURF_SCOPE, currentCategoryId)
        fullPlayerLauncher.launch(intent)
    }

    // ---------- المعاينة الحية ----------

    private fun playPreview(channel: MergedChannel, sourceIndex: Int = 0, isManualSelection: Boolean = true) {
        currentChannel = channel
        currentSourceIndex = sourceIndex
        if (isManualSelection) failedSourceUrlsThisSession.clear() // اختيار جديد من المستخدم = نبدأ صفحة جديدة

        findViewById<TextView>(R.id.txtPreviewName).text = channel.name
        findViewById<TextView>(R.id.txtPreviewProgram).text = channel.groupTitle
        updateFavoriteButtonState()
        loadEpgForChannel(channel, sourceIndex)

        val url = channel.sourceUrls.getOrNull(sourceIndex) ?: return
        val targetProviderKey = ResourceGuard.providerKeyFor(url)
        val reusableLease = previewLease?.takeIf { it.providerKey == targetProviderKey }
        val token = ++previewRequestToken

        // Close only the previous media item while zapping; keep the ExoPlayer/decoder object
        // alive so CHANNEL navigation does not pay a full player construction cost every time.
        stopPreviewStream(releaseLease = reusableLease == null)
        findViewById<ProgressBar>(R.id.progressLoading).visibility = View.VISIBLE

        lifecycleScope.launch {
            val lease = if (reusableLease != null) {
                reusableLease.updateKind(ResourceBudget.SessionKind.PREVIEW)
                reusableLease
            } else {
                when (val result = ResourceGuard.acquire(
                    context = this@ChannelBrowseActivity,
                    streamUrl = url,
                    kind = ResourceBudget.SessionKind.PREVIEW,
                    onPreempt = { leaseId ->
                        runOnUiThread {
                            if (previewLease?.id == leaseId) {
                                previewRequestToken++
                                releasePreview(releaseLease = true)
                            }
                        }
                    }
                )) {
                    is ResourceGuard.AcquireResult.Granted -> result.lease
                    is ResourceGuard.AcquireResult.Denied -> {
                        if (token == previewRequestToken) {
                            findViewById<ProgressBar>(R.id.progressLoading).visibility = View.GONE
                            when (result.reason) {
                                ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT ->
                                    tryNextSourceOnFailure(channel, url)
                                ResourceBudget.DenialReason.DEVICE_DECODER_LIMIT,
                                ResourceBudget.DenialReason.DEVICE_MEMORY_PRESSURE ->
                                    Toast.makeText(
                                        this@ChannelBrowseActivity,
                                        getString(R.string.preview_resource_limited),
                                        Toast.LENGTH_SHORT
                                    ).show()
                            }
                        }
                        return@launch
                    }
                }
            }

            if (token != previewRequestToken || currentChannel?.id != channel.id ||
                currentSourceIndex != sourceIndex || isFinishing
            ) {
                if (lease !== reusableLease) lease.release()
                return@launch
            }

            previewLease = lease
            val player = ensurePreviewPlayer()
            findViewById<ProgressBar>(R.id.progressLoading).visibility = View.GONE

            player.setMediaItem(MediaItem.fromUri(url))
            player.prepare()
            player.playWhenReady = true
        }
    }

    private fun ensurePreviewPlayer(): ExoPlayer {
        previewPlayer?.let { return it }
        val player = com.brotv.player.player.PlayerEngine.buildPlayer(
            this,
            com.brotv.player.player.PlayerEngine.BufferProfile.LOW_LATENCY
        )
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (previewPlayer !== player) return
                val activeChannel = currentChannel ?: return
                val failedUrl = activeChannel.sourceUrls.getOrNull(currentSourceIndex) ?: return
                tryNextSourceOnFailure(activeChannel, failedUrl)
            }
        })
        previewPlayer = player
        findViewById<PlayerView>(R.id.previewPlayerView).player = player
        return player
    }

    private fun stopPreviewStream(releaseLease: Boolean) {
        previewPlayer?.stop()
        previewPlayer?.clearMediaItems()
        if (releaseLease) {
            previewLease?.release()
            previewLease = null
        }
    }

    private fun releasePreview(releaseLease: Boolean) {
        stopPreviewStream(releaseLease)
        previewPlayer?.release()
        previewPlayer = null
        if (::prefs.isInitialized) {
            findViewById<PlayerView>(R.id.previewPlayerView).player = null
        }
    }

    /**
     * Preview EPG is cache-only. Rapid focus changes must never create an Xtream/API request
     * per channel row; the full player can do the heavier refresh after playback is established.
     */
    private fun loadEpgForChannel(channel: MergedChannel, sourceIndex: Int) {
        if (channel.sourceUrls.getOrNull(sourceIndex) == null) return
        previewEpgJob?.cancel()
        previewEpgJob = lifecycleScope.launch {
            val program = xmltvEpgRepository.currentCachedProgram(channel)
            if (currentChannel?.id != channel.id || currentSourceIndex != sourceIndex) return@launch
            findViewById<TextView>(R.id.txtPreviewProgram).text = if (program != null) {
                getString(R.string.epg_program_with_time, program.title, program.startTime, program.endTime)
            } else {
                channel.groupTitle
            }
        }
    }

    /**
     * Auto-Failover: يفحص كل المصادر اللي ما فشلت بنفس الجلسة ويختار أفضلها جودة.
     * لا يعيد تجربة أي مصدر فشل قبل كذا خلال نفس محاولة التشغيل (يمنع الدوران A→B→A→B).
     */
    private fun tryNextSourceOnFailure(channel: MergedChannel, failedUrl: String) {
        failedSourceUrlsThisSession.add(failedUrl)
        val remaining = channel.sourceUrls.filter { it !in failedSourceUrlsThisSession }
        if (remaining.isEmpty()) {
            Toast.makeText(this, R.string.all_sources_failed, Toast.LENGTH_LONG).show()
            return
        }

        // Failure recovery must not probe every candidate stream. Use playback history when
        // available, otherwise keep playlist order and reconnect immediately.
        val nextUrl = com.brotv.player.data.AutoPilotEngine.bestKnownSource(remaining) ?: remaining.first()
        val nextIndex = channel.sourceUrls.indexOf(nextUrl)
        if (nextIndex == -1) return
        Toast.makeText(this, R.string.failover_switched, Toast.LENGTH_SHORT).show()
        playPreview(channel, nextIndex, isManualSelection = false)
    }

    private fun setupPreviewActions() {
        findViewById<LinearLayout>(R.id.btnHideChannel).setOnClickListener {
            val hiddenChannel = currentChannel ?: return@setOnClickListener
            val before = currentVisibleChannels()
            val hiddenIndex = before.indexOfFirst { it.id == hiddenChannel.id }.coerceAtLeast(0)

            prefs.hideChannel(hiddenChannel.id)
            allChannels = allChannels.filter { it.id != hiddenChannel.id }
            releasePreview(releaseLease = true)
            currentChannel = null

            // نبقى في نفس المجلد: ننتقل للقناة التي كانت تحت المخفية، وإن كانت الأخيرة نرجع للي فوقها.
            val remaining = currentVisibleChannels()
            val nextIndex = hiddenIndex.coerceAtMost((remaining.size - 1).coerceAtLeast(0))
            val nextChannel = remaining.getOrNull(nextIndex)
            buildCategories()
            showChannels(remaining, focusChannelId = nextChannel?.id, autoPreview = false)
        }

        findViewById<LinearLayout>(R.id.btnQuality).setOnClickListener {
            showQualityDialog()
        }

        findViewById<LinearLayout>(R.id.btnMultiView).setOnClickListener {
            val channel = currentChannel ?: return@setOnClickListener
            startActivity(Intent(this, MultiViewActivity::class.java).apply {
                putExtra(MultiViewActivity.EXTRA_CHANNEL, channel)
            })
        }

        findViewById<LinearLayout>(R.id.btnFavorite).setOnClickListener {
            val channel = currentChannel ?: return@setOnClickListener
            prefs.toggleChannelFavorite(channel.id)
            updateFavoriteButtonState()
        }
    }

    private fun showQualityDialog() {
        val channel = currentChannel ?: return
        if (channel.sourceUrls.size <= 1) {
            Toast.makeText(this, R.string.no_alternative_sources, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = channel.sourceUrls.mapIndexed { index, _ -> getString(R.string.source_number, index + 1) }.toTypedArray()
        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.choose_source)
            .setItems(labels) { _, which -> playPreview(channel, which) }
            .show()
            .enableTvListFocus(currentSourceIndex)
    }

    private fun updateFavoriteButtonState() {
        val channel = currentChannel ?: return
        val isFavorite = channel.id in prefs.favoriteChannelIds
        val favBtn = findViewById<LinearLayout>(R.id.btnFavorite)
        favBtn.setBackgroundResource(
            if (isFavorite) R.drawable.preview_action_selector_gold else R.drawable.preview_action_selector
        )
    }

    private fun setLoading(loading: Boolean) {
        findViewById<ProgressBar>(R.id.progressLoading).visibility = if (loading) View.VISIBLE else View.GONE
    }

    override fun onStop() {
        super.onStop()
        previewRequestToken++
        previewEpgJob?.cancel()
        previewEpgJob = null
        releasePreview(releaseLease = true)
    }

    override fun onStart() {
        super.onStart()
        // Browse screen intentionally keeps no second live preview connection open.
    }

    override fun onDestroy() {
        clearPendingChannelFocus(findViewById(R.id.recyclerChannels))
        previewRequestToken++
        previewEpgJob?.cancel()
        previewEpgJob = null
        releasePreview(releaseLease = true)
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_GRID_SPAN = 4
    }
}
