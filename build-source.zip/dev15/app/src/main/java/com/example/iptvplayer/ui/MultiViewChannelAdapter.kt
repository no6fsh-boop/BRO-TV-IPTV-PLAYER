package com.brotv.player.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.model.MergedChannel

/** قائمة خفيفة للـMultiview: بلا فحوص شبكة لكل صف حتى لا نضيف حمل أثناء 2-4 بثوث حية. */
class MultiViewChannelAdapter(
    private val channels: List<MergedChannel>,
    private val onClick: (MergedChannel) -> Unit
) : RecyclerView.Adapter<MultiViewChannelAdapter.ViewHolder>() {

    class ViewHolder(parent: ViewGroup) : RecyclerView.ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_multiview_channel, parent, false)
    ) {
        val name: TextView = itemView.findViewById(R.id.txtMultiChannelName)
        val group: TextView = itemView.findViewById(R.id.txtMultiChannelGroup)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(parent)

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val channel = channels[position]
        holder.name.text = channel.name
        holder.group.text = channel.groupTitle
        holder.itemView.setOnClickListener { onClick(channel) }
    }

    override fun getItemCount(): Int = channels.size
}
