package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.BackupManager
import com.brotv.player.data.ContinueWatchingManager
import com.brotv.player.data.LocaleManager
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.MovieRepository
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.SeriesRepository
import com.brotv.player.model.ContinueWatchingType
import com.brotv.player.model.SettingItem
import com.brotv.player.security.ParentalControlManager
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * شاشة إعدادات BRO TV. لا تحتوي على أي خيارات رقابة أبوية.
 * كل بند هنا مربوط بوظيفة فعلية (مو Placeholder).
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<TextView>(R.id.btnSettingsSources).isSelected = true
        prefs = PrefsManager(this)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        buildList()

        val mac = getDeviceMacLabel()
        val deviceKey = getOrCreateDeviceKey()
        findViewById<TextView>(R.id.txtDeviceInfo).text = getString(R.string.device_key_mac_info, deviceKey, mac)
    }

    private fun buildList() {
        fun item(sectionRes: Int, titleRes: Int, iconRes: Int, action: () -> Unit) =
            SettingItem(getString(titleRes), iconRes, getString(sectionRes), action)

        val items = listOf(
            SettingItem("اللغة", R.drawable.ic_language, "عام") { showLanguageDialog() },
            SettingItem("المظهر", R.drawable.ic_layout, "عام") { toggleLayout() },
            SettingItem("تنسيق الوقت", R.drawable.ic_clock, "عام") { toggleTimeFormat() },
            SettingItem("التحكم في المشغل", R.drawable.ic_tv, "عام") { showBufferProfileDialog() },
            SettingItem("المصادر والمحتويات", R.drawable.ic_playlist, "عام") { startActivity(Intent(this, SourcesActivity::class.java)) },
            SettingItem("النسخ الاحتياطي", R.drawable.ic_folder, "عام") { exportBackup() }
        ) + listOf(
            item(R.string.settings_section_sources, R.string.settings_sources, R.drawable.ic_playlist) {
                startActivity(Intent(this, SourcesActivity::class.java))
            },
            item(R.string.settings_section_sources, R.string.settings_reorder_channels, R.drawable.ic_sort) {
                startActivity(Intent(this, ChannelReorderActivity::class.java))
            },
            item(R.string.settings_section_sources, R.string.settings_hidden_channels, R.drawable.ic_hide) {
                startActivity(Intent(this, HiddenChannelsActivity::class.java))
            },
            item(R.string.settings_section_sources, R.string.settings_hide_live, R.drawable.ic_hide) { showHideCategoriesDialog(CategoryScope.LIVE) },
            item(R.string.settings_section_sources, R.string.settings_hide_vod, R.drawable.ic_hide) { showHideCategoriesDialog(CategoryScope.MOVIES) },
            item(R.string.settings_section_sources, R.string.settings_hide_series, R.drawable.ic_hide) { showHideCategoriesDialog(CategoryScope.SERIES) },
            item(R.string.settings_section_sources, R.string.settings_reset_channel_order, R.drawable.ic_sort) { resetChannelOrder() },
            item(R.string.settings_section_sources, R.string.settings_unhide_all_channels, R.drawable.ic_hide) { unhideAllChannels() },

            item(R.string.settings_section_playback, R.string.settings_buffer_profile, R.drawable.ic_tv) { showBufferProfileDialog() },
            item(R.string.settings_section_playback, R.string.settings_quality_mode, R.drawable.ic_hd_quality) { showQualityModeDialog() },
            item(R.string.settings_section_playback, R.string.settings_smart_quality_guard, R.drawable.ic_signal_good) { toggleSmartQualityGuard() },
            item(R.string.settings_section_playback, R.string.settings_match_frame_rate, R.drawable.ic_tv) { showMatchFrameRateDialog() },
            item(R.string.settings_section_playback, R.string.settings_audio_output, R.drawable.ic_tv) { showAudioOutputDialog() },
            item(R.string.settings_section_playback, R.string.settings_live_format, R.drawable.ic_live) { toggleLiveFormat() },

            item(R.string.settings_section_experience, R.string.settings_language, R.drawable.ic_language) { showLanguageDialog() },
            item(R.string.settings_section_experience, R.string.settings_layout, R.drawable.ic_layout) { toggleLayout() },
            item(R.string.settings_section_experience, R.string.settings_time_format, R.drawable.ic_clock) { toggleTimeFormat() },
            item(R.string.settings_section_experience, R.string.settings_parental_controls, R.drawable.ic_profile) { showParentalControls() },

            item(R.string.settings_section_library, R.string.settings_recordings, R.drawable.ic_record) {
                startActivity(Intent(this, RecordingsActivity::class.java))
            },
            item(R.string.settings_section_library, R.string.settings_clear_movies_history, R.drawable.ic_trash) { clearMoviesHistory() },
            item(R.string.settings_section_library, R.string.settings_clear_series_history, R.drawable.ic_trash) { clearSeriesHistory() },

            item(R.string.settings_section_data, R.string.settings_backup_export, R.drawable.ic_playlist) { exportBackup() },
            item(R.string.settings_section_data, R.string.settings_backup_import, R.drawable.ic_history) { importBackup() },
            item(R.string.settings_section_data, R.string.settings_backup_portable_export, R.drawable.ic_playlist) { exportPortableBackup() },
            item(R.string.settings_section_data, R.string.settings_backup_portable_import, R.drawable.ic_history) { importPortableBackup() },

            item(R.string.settings_section_support, R.string.settings_crash_reports, R.drawable.ic_history) { showCrashReportsDialog() }
        )

        val recycler = findViewById<RecyclerView>(R.id.recyclerSettings)
        val settingsAdapter = SettingsAdapter(items)
        val grid = GridLayoutManager(this, 1)
        recycler.layoutManager = grid
        recycler.setHasFixedSize(true)
        recycler.setItemViewCacheSize(12)
        recycler.itemAnimator = null
        recycler.adapter = settingsAdapter

        val sideSections = mapOf(
            R.id.btnSettingsSources to "عام",
            R.id.btnSettingsPlayback to getString(R.string.settings_section_experience),
            R.id.btnSettingsExperience to getString(R.string.settings_section_playback),
            R.id.btnSettingsLibrary to getString(R.string.settings_section_library),
            R.id.btnSettingsData to getString(R.string.settings_section_data),
            R.id.btnSettingsSupport to getString(R.string.settings_section_support)
        )
        sideSections.forEach { (viewId, title) ->
            findViewById<TextView>(viewId).setOnClickListener {
                sideSections.keys.forEach { id -> findViewById<TextView>(id).isSelected = id == viewId }
                grid.scrollToPositionWithOffset(settingsAdapter.headerPosition(title), 0)
            }
        }
    }

    /** معرّف محلي عشوائي للتطبيق؛ لا يعتمد على Serial/MAC أو أي Hardware ID. */
    private fun getOrCreateDeviceKey(): String {
        val store = getSharedPreferences("device_identity", MODE_PRIVATE)
        store.getString("device_key", null)?.takeIf { it.length == 6 }?.let { return it }
        val generated = UUID.randomUUID().toString().replace("-", "")
            .take(6).uppercase(Locale.US)
        store.edit().putString("device_key", generated).apply()
        return generated
    }

    /** Android TV الحديث لا يتيح MAC الحقيقي للتطبيقات العادية؛ لا نعرض قيمة وهمية للمستخدم. */
    private fun getDeviceMacLabel(): String = getString(R.string.mac_not_available)

    // ---------- اللغة ----------

    private fun showLanguageDialog() {
        val options = arrayOf(getString(R.string.language_arabic), getString(R.string.language_english))
        val current = if (LocaleManager.isEnglish()) 1 else 0

        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.settings_language))
            .setSingleChoiceItems(options, current) { dialog, which ->
                val code = if (which == 0) LocaleManager.LANGUAGE_ARABIC else LocaleManager.LANGUAGE_ENGLISH
                LocaleManager.setLocale(code)
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ---------- إخفاء الفئات ----------

    private enum class CategoryScope { LIVE, MOVIES, SERIES }

    private fun showHideCategoriesDialog(scope: CategoryScope) {
        Toast.makeText(this, getString(R.string.loading_categories), Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val allCategories: List<String>
            val hiddenSet: MutableSet<String>

            when (scope) {
                CategoryScope.LIVE -> {
                    val channels = MergedChannelRepository(this@SettingsActivity).loadMergedChannels()
                    allCategories = channels.map { it.groupTitle }.filter { it.isNotBlank() }.distinct().sorted()
                    hiddenSet = prefs.hiddenLiveCategories
                }
                CategoryScope.MOVIES -> {
                    val movies = MovieRepository(this@SettingsActivity).getMovies()
                    allCategories = movies.map { it.providerCategoryName.ifBlank { it.genre } }.filter { it.isNotBlank() }.distinct()
                    hiddenSet = prefs.hiddenVodCategories
                }
                CategoryScope.SERIES -> {
                    val series = SeriesRepository(this@SettingsActivity).getSeriesList()
                    allCategories = series.map { it.providerCategoryName.ifBlank { it.genre } }.filter { it.isNotBlank() }.distinct()
                    hiddenSet = prefs.hiddenSeriesCategories
                }
            }

            if (allCategories.isEmpty()) {
                Toast.makeText(this@SettingsActivity, getString(R.string.no_categories_available), Toast.LENGTH_SHORT).show()
                return@launch
            }

            val checkedItems = allCategories.map { it in hiddenSet }.toBooleanArray()

            AlertDialog.Builder(this@SettingsActivity, R.style.BroTvDialog)
                .setTitle(getString(R.string.dialog_choose_categories_title))
                .setMultiChoiceItems(allCategories.toTypedArray(), checkedItems) { _, index, isChecked ->
                    if (isChecked) hiddenSet.add(allCategories[index]) else hiddenSet.remove(allCategories[index])
                }
                .setPositiveButton(getString(R.string.dialog_save)) { _, _ ->
                    when (scope) {
                        CategoryScope.LIVE -> prefs.hiddenLiveCategories = hiddenSet
                        CategoryScope.MOVIES -> prefs.hiddenVodCategories = hiddenSet
                        CategoryScope.SERIES -> prefs.hiddenSeriesCategories = hiddenSet
                    }
                    Toast.makeText(this@SettingsActivity, getString(R.string.saved_confirmation), Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    // ---------- التخطيط والتنسيق ----------

    private fun toggleLayout() {
        prefs.compactChannelList = !prefs.compactChannelList
        val mode = getString(if (prefs.compactChannelList) R.string.layout_compact else R.string.layout_comfortable)
        Toast.makeText(this, getString(R.string.layout_changed_to, mode), Toast.LENGTH_SHORT).show()
    }

    private fun toggleLiveFormat() {
        prefs.showChannelNumbers = !prefs.showChannelNumbers
        val mode = getString(if (prefs.showChannelNumbers) R.string.live_format_with_numbers else R.string.live_format_without_numbers)
        Toast.makeText(this, getString(R.string.live_format_changed_to, mode), Toast.LENGTH_SHORT).show()
    }

    private fun toggleTimeFormat() {
        prefs.use24HourTime = !prefs.use24HourTime
        val mode = getString(if (prefs.use24HourTime) R.string.time_format_24h else R.string.time_format_12h)
        Toast.makeText(this, getString(R.string.time_format_changed_to, mode), Toast.LENGTH_SHORT).show()
    }

    // ---------- مسح السجل ----------

    private fun resetChannelOrder() {
        prefs.channelOrder = emptyList()
        Toast.makeText(this, getString(R.string.reset_order_done), Toast.LENGTH_SHORT).show()
    }

    private fun unhideAllChannels() {
        prefs.hiddenChannelIds = mutableSetOf()
        Toast.makeText(this, getString(R.string.unhide_all_done), Toast.LENGTH_SHORT).show()
    }

    private fun clearMoviesHistory() {
        ContinueWatchingManager(this).clearByType(ContinueWatchingType.MOVIE)
        Toast.makeText(this, getString(R.string.clear_movies_history_done), Toast.LENGTH_SHORT).show()
    }

    private fun clearSeriesHistory() {
        ContinueWatchingManager(this).clearByType(ContinueWatchingType.EPISODE)
        prefs.watchedEpisodeIds = mutableSetOf()
        Toast.makeText(this, getString(R.string.clear_series_history_done), Toast.LENGTH_SHORT).show()
    }

    // ---------- جودة التشغيل ----------

    private fun showBufferProfileDialog() {
        val options = arrayOf(
            getString(R.string.buffer_auto),
            getString(R.string.buffer_low_latency),
            getString(R.string.buffer_balanced),
            getString(R.string.buffer_stable)
        )
        val values = arrayOf("AUTO", "LOW_LATENCY", "BALANCED", "STABLE")
        val current = values.indexOf(prefs.bufferProfile).coerceAtLeast(0)

        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.settings_buffer_profile))
            .setSingleChoiceItems(options, current) { dialog, which ->
                prefs.bufferProfile = values[which]
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun toggleStatsOverlay() {
        prefs.playerStatsOverlayEnabled = !prefs.playerStatsOverlayEnabled
        val state = if (prefs.playerStatsOverlayEnabled) getString(R.string.enabled) else getString(R.string.disabled)
        Toast.makeText(this, getString(R.string.stats_overlay_changed, state), Toast.LENGTH_SHORT).show()
    }

    private fun showQualityModeDialog() {
        val labels = arrayOf(
            getString(R.string.quality_auto), getString(R.string.quality_source),
            getString(R.string.quality_4k), getString(R.string.quality_1080p), getString(R.string.quality_720p)
        )
        val values = arrayOf("AUTO", "SOURCE", "UHD_4K", "FHD_1080P", "HD_720P")
        val current = values.indexOf(prefs.qualityMode).coerceAtLeast(0)

        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.settings_quality_mode))
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.qualityMode = values[which]
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun toggleSmartQualityGuard() {
        prefs.smartQualityGuardEnabled = !prefs.smartQualityGuardEnabled
        val state = if (prefs.smartQualityGuardEnabled) getString(R.string.enabled) else getString(R.string.disabled)
        Toast.makeText(this, getString(R.string.smart_quality_guard_changed, state), Toast.LENGTH_SHORT).show()
    }

    private fun showMatchFrameRateDialog() {
        val labels = arrayOf(getString(R.string.frame_rate_off), getString(R.string.frame_rate_auto), getString(R.string.frame_rate_always))
        val values = arrayOf("OFF", "AUTO", "ALWAYS")
        val current = values.indexOf(prefs.matchFrameRateMode).coerceAtLeast(0)

        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.settings_match_frame_rate))
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.matchFrameRateMode = values[which]
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showAudioOutputDialog() {
        val labels = arrayOf(
            getString(R.string.audio_auto),
            getString(R.string.audio_pcm),
            getString(R.string.audio_passthrough)
        )
        val values = arrayOf("AUTO", "PCM", "PASSTHROUGH")
        val current = values.indexOf(prefs.audioOutputMode).coerceAtLeast(0)

        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.settings_audio_output))
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.audioOutputMode = values[which]
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ---------- الرقابة الأبوية ----------

    private fun showParentalControls() {
        val manager = ParentalControlManager(this)
        if (!manager.isEnabled) {
            showSetParentalPin {
                Toast.makeText(this, R.string.parental_enabled, Toast.LENGTH_SHORT).show()
                showParentalControls()
            }
            return
        }

        showVerifyParentalPin {
            val items = arrayOf(
                getString(R.string.parental_manage_live),
                getString(R.string.parental_manage_movies),
                getString(R.string.parental_manage_series),
                getString(R.string.parental_change_pin),
                getString(R.string.parental_disable)
            )
            AlertDialog.Builder(this, R.style.BroTvDialog)
                .setTitle(getString(R.string.settings_parental_controls))
                .setItems(items) { _, which ->
                    when (which) {
                        0 -> showLockedCategoriesDialog(CategoryScope.LIVE)
                        1 -> showLockedCategoriesDialog(CategoryScope.MOVIES)
                        2 -> showLockedCategoriesDialog(CategoryScope.SERIES)
                        3 -> showSetParentalPin()
                        4 -> {
                            manager.disable()
                            prefs.lockedLiveCategories = mutableSetOf()
                            prefs.lockedVodCategories = mutableSetOf()
                            prefs.lockedSeriesCategories = mutableSetOf()
                            Toast.makeText(this, R.string.parental_disabled, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun showSetParentalPin(onSaved: (() -> Unit)? = null) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            isSingleLine = true
        }
        val dialog = AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.parental_create_pin))
            .setView(input)
            .setPositiveButton(getString(R.string.dialog_save), null)
            .setNegativeButton(getString(R.string.cancel), null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val pin = input.text?.toString().orEmpty()
                if (!ParentalControlManager.isValidPin(pin)) {
                    input.error = getString(R.string.parental_invalid_pin)
                    return@setOnClickListener
                }
                ParentalControlManager(this).setPin(pin)
                dialog.dismiss()
                onSaved?.invoke()
            }
        }
        dialog.show()
    }

    private fun showVerifyParentalPin(onVerified: () -> Unit) {
        val manager = ParentalControlManager(this)
        if (manager.isSessionUnlocked()) {
            onVerified()
            return
        }
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            isSingleLine = true
        }
        val dialog = AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.parental_enter_pin))
            .setView(input)
            .setPositiveButton(android.R.string.ok, null)
            .setNegativeButton(getString(R.string.cancel), null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (manager.verify(input.text?.toString().orEmpty())) {
                    dialog.dismiss()
                    onVerified()
                } else {
                    input.text?.clear()
                    input.error = getString(R.string.parental_wrong_pin)
                }
            }
        }
        dialog.show()
    }

    private fun showLockedCategoriesDialog(scope: CategoryScope) {
        lifecycleScope.launch {
            val allCategories = when (scope) {
                CategoryScope.LIVE -> MergedChannelRepository(this@SettingsActivity).loadMergedChannels()
                    .map { it.groupTitle }
                CategoryScope.MOVIES -> MovieRepository(this@SettingsActivity).getMovies()
                    .map { it.providerCategoryName.ifBlank { it.genre } }
                CategoryScope.SERIES -> SeriesRepository(this@SettingsActivity).getSeriesList()
                    .map { it.providerCategoryName.ifBlank { it.genre } }
            }.filter { it.isNotBlank() }.distinct()

            if (allCategories.isEmpty()) {
                Toast.makeText(this@SettingsActivity, R.string.no_categories_available, Toast.LENGTH_SHORT).show()
                return@launch
            }

            val locked = when (scope) {
                CategoryScope.LIVE -> prefs.lockedLiveCategories
                CategoryScope.MOVIES -> prefs.lockedVodCategories
                CategoryScope.SERIES -> prefs.lockedSeriesCategories
            }
            val checked = allCategories.map { it in locked }.toBooleanArray()
            AlertDialog.Builder(this@SettingsActivity, R.style.BroTvDialog)
                .setTitle(getString(when (scope) {
                    CategoryScope.LIVE -> R.string.parental_manage_live
                    CategoryScope.MOVIES -> R.string.parental_manage_movies
                    CategoryScope.SERIES -> R.string.parental_manage_series
                }))
                .setMultiChoiceItems(allCategories.toTypedArray(), checked) { _, index, value ->
                    if (value) locked.add(allCategories[index]) else locked.remove(allCategories[index])
                }
                .setPositiveButton(getString(R.string.dialog_save)) { _, _ ->
                    when (scope) {
                        CategoryScope.LIVE -> prefs.lockedLiveCategories = locked
                        CategoryScope.MOVIES -> prefs.lockedVodCategories = locked
                        CategoryScope.SERIES -> prefs.lockedSeriesCategories = locked
                    }
                    Toast.makeText(this@SettingsActivity, R.string.saved_confirmation, Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    // ---------- نسخ احتياطي ----------

    private fun exportBackup() {
        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.backup_warning_title))
            .setMessage(getString(R.string.backup_warning_message))
            .setPositiveButton(getString(R.string.backup_warning_continue)) { _, _ ->
                lifecycleScope.launch {
                    try {
                        val file = BackupManager.exportToFile(this@SettingsActivity)
                        Toast.makeText(this@SettingsActivity, getString(R.string.backup_saved_to, file.absolutePath), Toast.LENGTH_LONG).show()
                    } catch (_: Exception) {
                        Toast.makeText(
                            this@SettingsActivity,
                            BackupManager.lastErrorMessage ?: getString(R.string.backup_export_failed),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun importBackup() {
        val file = BackupManager.getBackupFile(this)
        if (!file.exists()) {
            Toast.makeText(this, getString(R.string.backup_not_found), Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.backup_restore_title))
            .setMessage(getString(R.string.backup_restore_message))
            .setPositiveButton(getString(R.string.backup_restore_confirm)) { _, _ ->
                lifecycleScope.launch {
                    val success = BackupManager.importFromFile(this@SettingsActivity, file)
                    Toast.makeText(
                        this@SettingsActivity,
                        if (success) {
                            getString(R.string.backup_restore_success)
                        } else {
                            BackupManager.lastErrorMessage ?: getString(R.string.backup_restore_failed)
                        },
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    private fun exportPortableBackup() {
        showBackupPasswordDialog(getString(R.string.backup_portable_export_title), requireConfirmation = true) { password ->
            lifecycleScope.launch {
                try {
                    val chars = password.toCharArray()
                    try {
                        val file = BackupManager.exportPortableToFile(this@SettingsActivity, chars)
                        Toast.makeText(this@SettingsActivity, getString(R.string.backup_saved_to, file.absolutePath), Toast.LENGTH_LONG).show()
                    } finally {
                        chars.fill('\u0000')
                    }
                } catch (_: Exception) {
                    Toast.makeText(
                        this@SettingsActivity,
                        BackupManager.lastErrorMessage ?: getString(R.string.backup_export_failed),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun importPortableBackup() {
        val file = BackupManager.getPortableBackupFile(this)
        if (!file.exists()) {
            Toast.makeText(this, getString(R.string.backup_portable_not_found), Toast.LENGTH_SHORT).show()
            return
        }
        showBackupPasswordDialog(getString(R.string.backup_portable_import_title), requireConfirmation = false) { password ->
            lifecycleScope.launch {
                val chars = password.toCharArray()
                val success = try {
                    BackupManager.importPortableFromFile(this@SettingsActivity, file, chars)
                } finally {
                    chars.fill('\u0000')
                }
                Toast.makeText(
                    this@SettingsActivity,
                    if (success) getString(R.string.backup_restore_success)
                    else BackupManager.lastErrorMessage ?: getString(R.string.backup_restore_failed),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /** يعرض تقارير الأعطال المحفوظة محلياً (CrashLogger) مع خيار مشاركتها أو مسحها. */
    private fun showCrashReportsDialog() {
        val reports = com.brotv.player.data.CrashLogger.recentReports(this)
        if (reports.isEmpty()) {
            Toast.makeText(this, getString(R.string.settings_crash_reports_empty), Toast.LENGTH_SHORT).show()
            return
        }
        val message = getString(R.string.settings_crash_reports_summary, reports.size)
        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.settings_crash_reports)
            .setMessage(message)
            .setPositiveButton(R.string.settings_crash_reports_share) { _, _ -> shareCrashReports() }
            .setNegativeButton(R.string.settings_crash_reports_clear) { _, _ ->
                com.brotv.player.data.CrashLogger.clearReports(this)
                Toast.makeText(this, getString(R.string.settings_crash_reports_cleared), Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(R.string.cancel, null)
            .show()
    }

    private fun shareCrashReports() {
        val text = com.brotv.player.data.CrashLogger.buildCombinedReportText(this)
        if (text.isBlank()) return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "BRO TV — ${getString(R.string.settings_crash_reports)}")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.settings_crash_reports_share)))
    }

    private fun showBackupPasswordDialog(
        title: String,
        requireConfirmation: Boolean,
        onPassword: (String) -> Unit
    ) {
        val density = resources.displayMetrics.density
        val padding = (24 * density).toInt()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, (8 * density).toInt(), padding, 0)
        }
        val password = EditText(this).apply {
            hint = getString(R.string.backup_password_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }
        container.addView(password)
        val confirmation = if (requireConfirmation) {
            EditText(this).apply {
                hint = getString(R.string.backup_password_confirm_hint)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                isSingleLine = true
                container.addView(this)
            }
        } else null

        val dialog = AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(title)
            .setMessage(getString(R.string.backup_portable_password_message))
            .setView(container)
            .setPositiveButton(getString(R.string.backup_warning_continue), null)
            .setNegativeButton(getString(R.string.cancel), null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val value = password.text?.toString().orEmpty()
                if (value.length < 8) {
                    password.error = getString(R.string.backup_password_too_short)
                    return@setOnClickListener
                }
                if (confirmation != null && value != confirmation.text?.toString().orEmpty()) {
                    confirmation.error = getString(R.string.backup_password_mismatch)
                    return@setOnClickListener
                }
                dialog.dismiss()
                onPassword(value)
            }
        }
        dialog.show()
    }

}
