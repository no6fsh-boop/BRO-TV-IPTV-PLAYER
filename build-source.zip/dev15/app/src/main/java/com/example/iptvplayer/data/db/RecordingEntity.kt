package com.brotv.player.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Persistent DVR job and recording metadata. Stream URLs are stored encrypted. */
@Entity(
    tableName = "recordings",
    indices = [
        Index(value = ["status"]),
        Index(value = ["scheduledStartMs"]),
        Index(value = ["scheduledEndMs"]),
        Index(value = ["channelId"])
    ]
)
data class RecordingEntity(
    @PrimaryKey val id: String,
    val channelId: String,
    val channelName: String,
    val title: String,
    val encryptedSourceUrls: String,
    val scheduledStartMs: Long,
    /** 0 means manual recording until the user stops it. */
    val scheduledEndMs: Long = 0L,
    val actualStartMs: Long = 0L,
    val actualEndMs: Long = 0L,
    val filePath: String = "",
    val mimeType: String = "video/mp2t",
    val status: String = RecordingStatus.SCHEDULED.name,
    val bytesWritten: Long = 0L,
    val errorMessage: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

enum class RecordingStatus {
    SCHEDULED,
    WAITING_RESOURCE,
    RECORDING,
    COMPLETED,
    PARTIAL,
    MISSED,
    FAILED,
    CANCELLED,
    INTERRUPTED;

    companion object {
        fun from(value: String): RecordingStatus =
            entries.firstOrNull { it.name == value } ?: FAILED
    }
}
