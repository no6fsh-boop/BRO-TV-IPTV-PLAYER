package com.brotv.player.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.model.CatchupProgram

class CatchupProgramAdapter(
    private val programs: List<CatchupProgram>,
    private val onClick: (CatchupProgram) -> Unit
) : RecyclerView.Adapter<CatchupProgramAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.txtProgramTitle)
        val time: TextView = view.findViewById(R.id.txtProgramTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_catchup_program, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val program = programs[position]
        holder.title.text = program.title
        holder.time.text = holder.itemView.context.getString(R.string.program_time_range, program.startLabel, program.endLabel)
        holder.itemView.setOnClickListener { onClick(program) }
    }

    override fun getItemCount(): Int = programs.size
}
