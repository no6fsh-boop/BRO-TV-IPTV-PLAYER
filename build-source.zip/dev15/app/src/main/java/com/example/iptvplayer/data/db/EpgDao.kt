package com.brotv.player.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface EpgDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(programs: List<EpgProgramEntity>)

    @Query("DELETE FROM epg_programs WHERE sourceId = :sourceId")
    suspend fun deleteBySource(sourceId: String)

    @Query("DELETE FROM epg_programs")
    suspend fun deleteAll()

    @Query("DELETE FROM epg_programs WHERE endTimeMs < :beforeMs")
    suspend fun deleteExpired(beforeMs: Long)

    @Query("SELECT MAX(updatedAt) FROM epg_programs WHERE sourceId = :sourceId")
    suspend fun latestUpdate(sourceId: String): Long?

    @Query("SELECT * FROM epg_programs WHERE sourceId = :sourceId AND channelId = :channelId AND startTimeMs <= :nowMs AND endTimeMs > :nowMs ORDER BY startTimeMs DESC LIMIT 1")
    suspend fun currentByChannelId(sourceId: String, channelId: String, nowMs: Long): EpgProgramEntity?

    @Query("SELECT * FROM epg_programs WHERE sourceId = :sourceId AND normalizedChannelName = :normalizedName AND startTimeMs <= :nowMs AND endTimeMs > :nowMs ORDER BY startTimeMs DESC LIMIT 1")
    suspend fun currentByName(sourceId: String, normalizedName: String, nowMs: Long): EpgProgramEntity?

    @Query("SELECT * FROM epg_programs WHERE sourceId = :sourceId AND channelId = :channelId AND endTimeMs > :fromMs AND startTimeMs < :toMs ORDER BY startTimeMs ASC LIMIT :limit")
    suspend fun rangeByChannelId(sourceId: String, channelId: String, fromMs: Long, toMs: Long, limit: Int): List<EpgProgramEntity>

    @Query("SELECT * FROM epg_programs WHERE sourceId = :sourceId AND normalizedChannelName = :normalizedName AND endTimeMs > :fromMs AND startTimeMs < :toMs ORDER BY startTimeMs ASC LIMIT :limit")
    suspend fun rangeByName(sourceId: String, normalizedName: String, fromMs: Long, toMs: Long, limit: Int): List<EpgProgramEntity>

}
