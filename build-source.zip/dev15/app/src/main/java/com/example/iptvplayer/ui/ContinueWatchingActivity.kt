package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.ContinueWatchingManager
import com.brotv.player.model.ContinueWatchingItem
import com.brotv.player.model.ContinueWatchingType

class ContinueWatchingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_continue_watching)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        val recycler = findViewById<RecyclerView>(R.id.recyclerContinueWatching)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.setHasFixedSize(true)
        recycler.setItemViewCacheSize(6)
        recycler.itemAnimator = null

        val items = ContinueWatchingManager(this).getAll()
        if (items.isEmpty()) {
            findViewById<TextView>(R.id.txtEmpty).visibility = View.VISIBLE
            return
        }

        recycler.adapter = ContinueWatchingAdapter(items) { item -> resumePlayback(item) }
    }

    private fun resumePlayback(item: ContinueWatchingItem) {
        val intent = Intent(this, VodPlayerActivity::class.java)
        intent.putExtra(VodPlayerActivity.EXTRA_CONTENT_ID, item.contentId)
        intent.putExtra(VodPlayerActivity.EXTRA_TITLE, item.title)
        intent.putExtra(VodPlayerActivity.EXTRA_SUBTITLE, item.subtitle)
        intent.putExtra(VodPlayerActivity.EXTRA_STREAM_URL, item.streamUrl)
        intent.putExtra(VodPlayerActivity.EXTRA_POSTER_URL, item.posterUrl)
        intent.putExtra(VodPlayerActivity.EXTRA_IS_MOVIE, item.type == ContinueWatchingType.MOVIE)
        if (item.seriesId != null) {
            intent.putExtra(VodPlayerActivity.EXTRA_SERIES_ID, item.seriesId)
        }
        startActivity(intent)
    }
}
