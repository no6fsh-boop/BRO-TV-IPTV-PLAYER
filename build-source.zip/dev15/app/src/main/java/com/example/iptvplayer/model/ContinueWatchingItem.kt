package com.brotv.player.model

/** نوع المحتوى المحفوظ باستكمال المشاهدة. */
enum class ContinueWatchingType { MOVIE, EPISODE }

data class ContinueWatchingItem(
    val contentId: String,
    val type: ContinueWatchingType,
    val title: String,
    val subtitle: String,
    val posterUrl: String?,
    val streamUrl: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long,
    val seriesId: String? = null
)
