package com.brotv.player.data

import android.content.Context
import com.brotv.player.data.db.AppDatabase
import com.brotv.player.data.db.ProviderEntity
import com.brotv.player.data.db.ProviderStatus
import com.brotv.player.data.db.ProviderType
import androidx.room.withTransaction
import org.json.JSONArray

/**
 * يدير كل مصادر القنوات (M3U وXtream) عبر Room بدل SharedPreferences، وبمواصفات
 * احترافية: تفعيل/تعطيل بدون حذف، إعادة تسمية، ترتيب، مصدر افتراضي، وحالة اتصال
 * لكل مصدر (متصل/بطيء/متوقف). يهاجر تلقائياً أي بيانات قديمة كانت محفوظة بالطريقة السابقة.
 */
class SourcesManager(private val context: Context) {

    private val database = AppDatabase.getInstance(context)
    private val dao = database.providerDao()
    private val epgDao = database.epgDao()
    private val legacyPrefs = context.getSharedPreferences("sources", Context.MODE_PRIVATE)

    suspend fun getSources(): List<SourceConfig> {
        migrateLegacyDataIfNeeded(); migrateEncryptionIfNeeded()
        return dao.getAll().map { it.toSourceConfig(context) }
    }

    suspend fun getEnabledSources(): List<SourceConfig> {
        migrateLegacyDataIfNeeded(); migrateEncryptionIfNeeded()
        return dao.getEnabled().map { it.toSourceConfig(context) }
    }

    suspend fun getXtreamSources(): List<SourceConfig> {
        migrateLegacyDataIfNeeded(); migrateEncryptionIfNeeded()
        return dao.getEnabledByType(ProviderType.XTREAM).map { it.toSourceConfig(context) }
    }

    /** يرجّع false لو فشل تشفير أي حقل حساس — بهالحالة ما نضيف المصدر أبداً بدل ما نخزن بيانات ناقصة. */
    suspend fun addSource(config: SourceConfig): Boolean {
        return addSourcesAtomically(listOf(config))
    }

    /**
     * يشفّر جميع المصادر أولاً، ثم يكتبها داخل معاملة Room واحدة.
     * إذا فشل تشفير مصدر واحد فلن يُكتب أي مصدر من الدفعة.
     */
    suspend fun addSourcesAtomically(configs: List<SourceConfig>): Boolean {
        if (configs.isEmpty()) return true
        if (configs.map { it.id }.distinct().size != configs.size) return false

        val cipher = com.brotv.player.security.CredentialCipher
        val existingById = dao.getAll().associateBy { it.id }
        val existingCount = existingById.size
        val prepared = ArrayList<ProviderEntity>(configs.size)

        // لا نلمس قاعدة البيانات أثناء التشفير؛ لذلك يبقى الفشل بلا آثار جزئية.
        configs.forEachIndexed { index, config ->
            val encryptedM3u = cipher.encryptOrNull(context, config.m3uUrl) ?: return false
            val encryptedUser = cipher.encryptOrNull(context, config.xtreamUsername) ?: return false
            val encryptedPass = cipher.encryptOrNull(context, config.xtreamPassword) ?: return false
            val encryptedEpg = cipher.encryptOrNull(context, config.epgUrl) ?: return false
            val previous = existingById[config.id]

            prepared += config.toEntity(
                encryptedM3u = encryptedM3u,
                encryptedUsername = encryptedUser,
                encryptedPassword = encryptedPass,
                encryptedEpgUrl = encryptedEpg,
                isDefault = previous?.isDefault
                    ?: (existingCount == 0 && index == 0)
            ).copy(
                sortOrder = previous?.sortOrder ?: (existingCount + index),
                status = previous?.status ?: ProviderStatus.UNKNOWN,
                lastCheckedAt = previous?.lastCheckedAt ?: 0L,
                lastSyncAt = previous?.lastSyncAt ?: 0L,
                createdAt = previous?.createdAt ?: System.currentTimeMillis()
            )
        }

        return try {
            database.withTransaction {
                prepared.forEach { dao.upsert(it) }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * استبدال كامل للمصادر في معاملة Room واحدة. يُستخدم للـRestore والـRollback حتى
     * لا يترك التطبيق مزيجاً من مصادر قديمة وجديدة إذا كانت النسخة الاحتياطية تمثل حالة كاملة.
     */
    suspend fun replaceSourcesAtomically(configs: List<SourceConfig>, defaultSourceId: String? = null): Boolean {
        if (configs.map { it.id }.distinct().size != configs.size) return false
        val cipher = com.brotv.player.security.CredentialCipher
        val prepared = ArrayList<ProviderEntity>(configs.size)
        configs.forEachIndexed { index, config ->
            val encryptedM3u = cipher.encryptOrNull(context, config.m3uUrl) ?: return false
            val encryptedUser = cipher.encryptOrNull(context, config.xtreamUsername) ?: return false
            val encryptedPass = cipher.encryptOrNull(context, config.xtreamPassword) ?: return false
            val encryptedEpg = cipher.encryptOrNull(context, config.epgUrl) ?: return false
            prepared += config.toEntity(
                encryptedM3u = encryptedM3u,
                encryptedUsername = encryptedUser,
                encryptedPassword = encryptedPass,
                encryptedEpgUrl = encryptedEpg,
                isDefault = if (defaultSourceId.isNullOrBlank()) index == 0 else config.id == defaultSourceId
            ).copy(
                sortOrder = index,
                status = ProviderStatus.UNKNOWN,
                lastCheckedAt = 0L,
                lastSyncAt = 0L,
                createdAt = System.currentTimeMillis() + index
            )
        }
        return try {
            database.withTransaction {
                epgDao.deleteAll()
                dao.deleteAll()
                prepared.forEach { dao.upsert(it) }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun removeSource(id: String) {
        database.withTransaction {
            epgDao.deleteBySource(id)
            dao.deleteById(id)
        }
    }

    suspend fun updateEpgUrl(id: String, epgUrl: String): Boolean {
        val encrypted = com.brotv.player.security.CredentialCipher.encryptOrNull(context, epgUrl.trim()) ?: return false
        val current = dao.getById(id) ?: return false
        return try {
            database.withTransaction {
                if (current.epgUrl != encrypted) epgDao.deleteBySource(id)
                dao.update(current.copy(epgUrl = encrypted))
            }
            true
        } catch (_: Exception) { false }
    }

    suspend fun setEnabled(id: String, enabled: Boolean) = dao.setEnabled(id, enabled)

    suspend fun rename(id: String, newName: String) = dao.rename(id, newName)

    suspend fun setDefault(id: String) {
        dao.clearDefault()
        dao.setDefault(id)
    }

    suspend fun getDefaultSource(): SourceConfig? = dao.getDefault()?.toSourceConfig(context)

    /** يحفظ ترتيب المصادر بالضبط بنفس ترتيب القائمة المُمررة. */
    suspend fun saveOrder(orderedIds: List<String>) {
        orderedIds.forEachIndexed { index, id -> dao.setSortOrder(id, index) }
    }

    suspend fun updateStatus(id: String, status: ProviderStatus) =
        dao.updateStatus(id, status, System.currentTimeMillis())

    suspend fun getProviderEntities(): List<ProviderEntity> {
        migrateLegacyDataIfNeeded(); migrateEncryptionIfNeeded()
        return dao.getAll()
    }

    suspend fun hasAnySource(): Boolean {
        migrateLegacyDataIfNeeded(); migrateEncryptionIfNeeded()
        return dao.count() > 0
    }

    /**
     * ترحيل تشفير آمن (بند "إصلاح Migration"): يمر على كل مصدر، ولو لقى حقل حساس
     * (يوزر/باسورد/رابط M3U) غير مشفّر (بدون بادئة enc:v1:)، يشفّره ويحدّث السجل.
     * ما يمسح القيمة القديمة إلا بعد ما ننجح نبني القيمة المشفّرة ونحفظها فعلياً.
     * يشتغل مرة وحدة بس بفضل علم needsEncryptionMigration المخزّن بذاكرة الجلسة.
     */
    private var encryptionMigrationChecked = false

    private suspend fun migrateEncryptionIfNeeded() {
        if (encryptionMigrationChecked) return

        val cipher = com.brotv.player.security.CredentialCipher
        var allSucceeded = true

        dao.getAll().forEach { entity ->
            val needsMigration = (entity.m3uUrl.isNotEmpty() && !cipher.isEncrypted(entity.m3uUrl)) ||
                (entity.xtreamUsername.isNotEmpty() && !cipher.isEncrypted(entity.xtreamUsername)) ||
                (entity.xtreamPassword.isNotEmpty() && !cipher.isEncrypted(entity.xtreamPassword)) ||
                (entity.epgUrl.isNotEmpty() && !cipher.isEncrypted(entity.epgUrl))

            if (!needsMigration) return@forEach

            val newM3u = if (entity.m3uUrl.isNotEmpty() && !cipher.isEncrypted(entity.m3uUrl))
                cipher.encryptOrNull(context, entity.m3uUrl) else entity.m3uUrl
            val newUser = if (entity.xtreamUsername.isNotEmpty() && !cipher.isEncrypted(entity.xtreamUsername))
                cipher.encryptOrNull(context, entity.xtreamUsername) else entity.xtreamUsername
            val newPass = if (entity.xtreamPassword.isNotEmpty() && !cipher.isEncrypted(entity.xtreamPassword))
                cipher.encryptOrNull(context, entity.xtreamPassword) else entity.xtreamPassword
            val newEpg = if (entity.epgUrl.isNotEmpty() && !cipher.isEncrypted(entity.epgUrl))
                cipher.encryptOrNull(context, entity.epgUrl) else entity.epgUrl

            // لو أي حقل رجع null (فشل تشفير حقيقي)، نتخطى هالسجل تماماً بدون ما نلمسه،
            // ونسيب allSucceeded = false عشان نحاول له مرة ثانية بالمرة الجاية بدل ما نعلّمها "خلصت"
            if (newM3u == null || newUser == null || newPass == null || newEpg == null) {
                allSucceeded = false
                return@forEach
            }

            dao.update(entity.copy(m3uUrl = newM3u, xtreamUsername = newUser, xtreamPassword = newPass, epgUrl = newEpg))
        }

        // ما نعلّم الترحيل "خلص" إلا لو نجحت كل السجلات فعلاً — لو فيه سجل فشل، نعيد المحاولة
        // تلقائياً بالمرة الجاية اللي يفتح فيها المستخدم شاشة تعتمد على المصادر
        if (allSucceeded) encryptionMigrationChecked = true
    }

    // ---------- توافق مع النسخة القديمة (SharedPreferences) ----------

    private var migrated = false
    private companion object {
        const val LEGACY_MIGRATION_DONE = "legacy_migration_done"
        const val LEGACY_SOURCES_KEY = "sources_list"
    }

    private suspend fun migrateLegacyDataIfNeeded() {
        if (migrated || legacyPrefs.getBoolean(LEGACY_MIGRATION_DONE, false)) {
            migrated = true
            return
        }

        val raw = legacyPrefs.getString(LEGACY_SOURCES_KEY, null)
        if (raw == null) {
            legacyPrefs.edit().putBoolean(LEGACY_MIGRATION_DONE, true).apply()
            migrated = true
            return
        }

        val configs: List<SourceConfig> = try {
            val array = JSONArray(raw)
            val parsed = mutableListOf<SourceConfig>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                parsed.add(
                    SourceConfig(
                        id = obj.getString("id"),
                        name = obj.optString("name", ""),
                        type = PrefsManager.SourceType.valueOf(obj.getString("type")),
                        m3uUrl = obj.optString("m3uUrl", ""),
                        xtreamServer = obj.optString("xtreamServer", ""),
                        xtreamUsername = obj.optString("xtreamUsername", ""),
                        xtreamPassword = obj.optString("xtreamPassword", ""),
                        epgUrl = obj.optString("epgUrl", "")
                    )
                )
            }
            parsed
        } catch (_: Exception) {
            // نترك البيانات القديمة والعلم بدون تغيير حتى تعاد المحاولة لاحقاً.
            return
        }

        // لا نمسح SharedPreferences إلا بعد نجاح تشفير وكتابة كل المصادر.
        if (!addSourcesAtomically(configs)) return

        legacyPrefs.edit()
            .remove(LEGACY_SOURCES_KEY)
            .putBoolean(LEGACY_MIGRATION_DONE, true)
            .apply()
        migrated = true
    }
}

private fun ProviderEntity.toSourceConfig(context: Context) = SourceConfig(
    id = id,
    name = name,
    type = if (type == ProviderType.XTREAM) PrefsManager.SourceType.XTREAM else PrefsManager.SourceType.M3U,
    // لو فشل فك التشفير فعلياً (null)، نستخدم فاضي بس بالعرض المؤقت هنا فقط —
    // البيانات الأصلية بقاعدة البيانات ما تنمسح أبداً إلا بعد نجاح إعادة الحفظ (شوف migrateEncryptionIfNeeded).
    m3uUrl = com.brotv.player.security.CredentialCipher.decryptOrNull(context, m3uUrl) ?: "",
    xtreamServer = xtreamServer,
    xtreamUsername = com.brotv.player.security.CredentialCipher.decryptOrNull(context, xtreamUsername) ?: "",
    xtreamPassword = com.brotv.player.security.CredentialCipher.decryptOrNull(context, xtreamPassword) ?: "",
    epgUrl = com.brotv.player.security.CredentialCipher.decryptOrNull(context, epgUrl) ?: "",
    enabled = enabled
)

private fun SourceConfig.toEntity(
    encryptedM3u: String,
    encryptedUsername: String,
    encryptedPassword: String,
    encryptedEpgUrl: String,
    isDefault: Boolean = false
) = ProviderEntity(
    id = id,
    name = name,
    type = if (type == PrefsManager.SourceType.XTREAM) ProviderType.XTREAM else ProviderType.M3U,
    m3uUrl = encryptedM3u,
    xtreamServer = xtreamServer,
    xtreamUsername = encryptedUsername,
    xtreamPassword = encryptedPassword,
    epgUrl = encryptedEpgUrl,
    enabled = enabled,
    isDefault = isDefault
)
