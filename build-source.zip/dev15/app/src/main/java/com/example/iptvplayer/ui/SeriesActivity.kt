package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.brotv.player.R
import com.brotv.player.data.ContinueWatchingManager
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.SeriesRepository
import com.brotv.player.model.ChannelCategory
import com.brotv.player.model.ContinueWatchingType
import com.brotv.player.model.Series
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class SeriesActivity : AppCompatActivity() {

    private enum class QuickList { NONE, CONTINUE, FAVORITES, RED, FAMILY }
    private enum class SortMode { DEFAULT, NEWEST, OLDEST, AZ, ZA }

    private lateinit var prefs: PrefsManager
    private var allSeries: List<Series> = emptyList()
    private var selectedSeries: Series? = null
    private var currentCategoryId = "all"
    private var quickList = QuickList.NONE
    private var sortMode = SortMode.DEFAULT
    private lateinit var contentAdapter: SeriesAdapter
    private var heroArtworkJob: Job? = null
    private var lastFocusedSeriesId: String? = null
    private var restoreGridFocusOnResume = false
    private var pendingGridFocusRestore = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series)
        prefs = PrefsManager(this)
        savedInstanceState?.let { state ->
            currentCategoryId = state.getString(STATE_CATEGORY_ID, currentCategoryId)
            quickList = state.getString(STATE_QUICK_LIST)?.let { runCatching { QuickList.valueOf(it) }.getOrNull() } ?: quickList
            sortMode = state.getString(STATE_SORT_MODE)?.let { runCatching { SortMode.valueOf(it) }.getOrNull() } ?: sortMode
            lastFocusedSeriesId = state.getString(STATE_FOCUSED_SERIES_ID)
        }

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.imgHeaderLogo).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.btnHeaderSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.btnTopLive).setOnClickListener { switchSection(ChannelBrowseActivity::class.java) }
        findViewById<TextView>(R.id.btnTopMovies).setOnClickListener { switchSection(MoviesActivity::class.java) }
        findViewById<TextView>(R.id.btnTopSeries).setOnClickListener { focusCurrentGrid() }
        findViewById<ImageView>(R.id.btnSearchSeries).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java).apply {
                putExtra(SearchActivity.EXTRA_SCOPE, SearchActivity.Scope.SERIES.name)
            })
        }
        findViewById<RecyclerView>(R.id.recyclerCategories).apply {
            layoutManager = LinearLayoutManager(this@SeriesActivity, LinearLayoutManager.HORIZONTAL, false)
            setHasFixedSize(true)
            setItemViewCacheSize(8)
            itemAnimator = null
        }
        findViewById<RecyclerView>(R.id.recyclerSeries).apply {
            layoutManager = GridLayoutManager(this@SeriesActivity, MEDIA_GRID_SPAN)
            setHasFixedSize(true)
            setItemViewCacheSize(MEDIA_GRID_SPAN)
            itemAnimator = null // TV grids feel faster and avoid focus glitches without change animations.
        }
        contentAdapter = SeriesAdapter(
            seriesList = emptyList(),
            onFocus = { selectSeries(it) },
            onLeftEdge = { focusActiveSidebarItem() },
            onClick = { openDetails(it) }
        )
        findViewById<RecyclerView>(R.id.recyclerSeries).adapter = contentAdapter

        findViewById<LinearLayout>(R.id.btnOpenSeriesHero).setOnClickListener { selectedSeries?.let(::openDetails) }
        findViewById<LinearLayout>(R.id.btnFavoriteHero).setOnClickListener {
            selectedSeries?.let {
                prefs.toggleSeriesFavorite(it.id)
                updateFavoriteHeroState()
                updateQuickCounts()
                if (quickList == QuickList.FAVORITES) applyFiltersAndShow()
            }
        }

        findViewById<LinearLayout>(R.id.btnContinueWatching).setOnClickListener { selectQuickList(QuickList.CONTINUE) }
        findViewById<LinearLayout>(R.id.btnFavoritesFilter).setOnClickListener { selectQuickList(QuickList.FAVORITES) }
        findViewById<LinearLayout>(R.id.btnRedList).setOnClickListener { selectQuickList(QuickList.RED) }
        findViewById<LinearLayout>(R.id.btnFamilyList).setOnClickListener { selectQuickList(QuickList.FAMILY) }
        setupSidebarDpad()
        setupSortButtons()
        loadSeries()
    }

    override fun onResume() {
        super.onResume()
        pendingGridFocusRestore = restoreGridFocusOnResume
        if (allSeries.isNotEmpty()) {
            updateQuickCounts()
            applyFiltersAndShow()
        }
    }

    override fun onPause() {
        val recycler = findViewById<RecyclerView>(R.id.recyclerSeries)
        restoreGridFocusOnResume = currentFocus?.let { recycler.findContainingItemView(it) != null } == true
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString(STATE_CATEGORY_ID, currentCategoryId)
        outState.putString(STATE_QUICK_LIST, quickList.name)
        outState.putString(STATE_SORT_MODE, sortMode.name)
        outState.putString(STATE_FOCUSED_SERIES_ID, lastFocusedSeriesId)
        super.onSaveInstanceState(outState)
    }

    private fun switchSection(target: Class<out AppCompatActivity>) {
        if (target == this::class.java) return
        startActivity(Intent(this, target))
        finish()
    }

    private fun focusCurrentGrid() {
        val recycler = findViewById<RecyclerView>(R.id.recyclerSeries)
        val preferred = lastFocusedSeriesId
        val index = preferred?.let { id -> contentAdapter.currentList.indexOfFirst { it.id == id } } ?: -1
        val target = index.takeIf { it >= 0 } ?: 0
        recycler.scrollToPosition(target)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(target)?.itemView?.requestFocus() ?: recycler.requestFocus()
        }
    }

    private fun setupSidebarDpad() {
        listOf(
            R.id.btnContinueWatching,
            R.id.btnFavoritesFilter,
            R.id.btnRedList,
            R.id.btnFamilyList
        ).forEach { id ->
            findViewById<View>(id).setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    focusCurrentGrid()
                    true
                } else false
            }
        }
    }

    private fun focusActiveSidebarItem() {
        val quickTarget = when (quickList) {
            QuickList.CONTINUE -> R.id.btnContinueWatching
            QuickList.FAVORITES -> R.id.btnFavoritesFilter
            QuickList.RED -> R.id.btnRedList
            QuickList.FAMILY -> R.id.btnFamilyList
            QuickList.NONE -> View.NO_ID
        }
        if (quickTarget != View.NO_ID) {
            findViewById<View>(quickTarget).requestFocus()
            return
        }
        val recycler = findViewById<RecyclerView>(R.id.recyclerCategories)
        val position = (recycler.adapter as? CategoryAdapter)?.selectedAdapterPosition() ?: 0
        recycler.scrollToPosition(position)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus() ?: recycler.requestFocus()
        }
    }

    private fun loadSeries() {
        val repository = SeriesRepository(this)
        setLoading(true)
        lifecycleScope.launch {
            if (!repository.isSourceSupported()) {
                showEmpty(getString(R.string.series_xtream_only))
                return@launch
            }
            val hidden = prefs.hiddenSeriesCategories
            allSeries = repository.getSeriesList().filter {
                it.providerCategoryName !in hidden && it.genre !in hidden
            }
            setLoading(false)
            if (allSeries.isEmpty()) {
                showEmpty(getString(R.string.series_none_source))
                return@launch
            }
            buildCategories()
            updateQuickCounts()
            applyFiltersAndShow()
        }
    }

    private fun buildCategories() {
        val sourceOrder = allSeries.mapNotNull { it.id.split("::").getOrNull(1) }.distinct()
        val sourceRank = sourceOrder.withIndex().associate { it.value to it.index }
        val grouped = allSeries.filter { it.providerCategoryKey.isNotBlank() }.groupBy { it.providerCategoryKey }
        val orderedKeys = grouped.keys.sortedWith(
            compareBy<String> { key -> sourceRank[key.substringBefore("::")] ?: Int.MAX_VALUE }
                .thenBy { key -> grouped[key]?.firstOrNull()?.providerCategoryOrder ?: Int.MAX_VALUE }
        )
        val categories = mutableListOf(
            ChannelCategory("all", getString(R.string.all_series), allSeries.size, R.drawable.ic_all_channels)
        )
        orderedKeys.forEach { key ->
            val items = grouped[key].orEmpty()
            val name = items.firstOrNull()?.providerCategoryName.orEmpty().ifBlank { getString(R.string.uncategorized_label) }
            categories += ChannelCategory(key, name, items.size, R.drawable.ic_folder)
        }
        val categoryRecycler = findViewById<RecyclerView>(R.id.recyclerCategories)
        val categoryAdapter = CategoryAdapter(
            categories = categories,
            selectedCategoryId = currentCategoryId,
            onMoveRight = { focusCurrentGrid() },
            compact = true
        ) { category ->
            quickList = QuickList.NONE
            currentCategoryId = category.id
            updateQuickSelection()
            applyFiltersAndShow()
        }
        categoryRecycler.adapter = categoryAdapter

        // Android TV does not guarantee which newly-inflated focusable wins first focus.
        // Entering a media section must start on the selected category so RIGHT always
        // moves deterministically into the content grid.
        val selectedPosition = categoryAdapter.selectedAdapterPosition()
        categoryRecycler.scrollToPosition(selectedPosition)
        categoryRecycler.post {
            categoryRecycler.findViewHolderForAdapterPosition(selectedPosition)?.itemView?.requestFocus()
                ?: categoryRecycler.requestFocus()
        }
    }

    private fun selectQuickList(value: QuickList) {
        quickList = value
        updateQuickSelection()
        applyFiltersAndShow()
    }

    private fun updateQuickSelection() {
        findViewById<LinearLayout>(R.id.btnContinueWatching).isSelected = quickList == QuickList.CONTINUE
        findViewById<LinearLayout>(R.id.btnFavoritesFilter).isSelected = quickList == QuickList.FAVORITES
        findViewById<LinearLayout>(R.id.btnRedList).isSelected = quickList == QuickList.RED
        findViewById<LinearLayout>(R.id.btnFamilyList).isSelected = quickList == QuickList.FAMILY
    }

    private fun updateQuickCounts() {
        val continueSeriesIds = ContinueWatchingManager(this).getAll()
            .filter { it.type == ContinueWatchingType.EPISODE }
            .mapNotNull { it.seriesId }
            .toSet()
        findViewById<TextView>(R.id.txtContinueCount).text = allSeries.count { it.id in continueSeriesIds }.toString()
        findViewById<TextView>(R.id.txtFavoritesCount).text = allSeries.count { it.id in prefs.favoriteSeriesIds }.toString()
        findViewById<TextView>(R.id.txtRedCount).text = allSeries.count(::isRedListSeries).toString()
        findViewById<TextView>(R.id.txtFamilyCount).text = allSeries.count(::isFamilySeries).toString()
    }

    private fun isRedListSeries(item: Series): Boolean {
        val text = "${item.providerCategoryName} ${item.genre}".lowercase(Locale.ROOT)
        return listOf("حمراء", "أحمر", "red").any(text::contains)
    }

    private fun isFamilySeries(item: Series): Boolean {
        val text = "${item.providerCategoryName} ${item.genre}".lowercase(Locale.ROOT)
        return listOf("عائل", "أطفال", "اطفال", "family", "kids", "children").any(text::contains)
    }

    private fun applyFiltersAndShow() {
        var list = when (quickList) {
            QuickList.CONTINUE -> {
                val ids = ContinueWatchingManager(this).getAll()
                    .filter { it.type == ContinueWatchingType.EPISODE }
                    .mapNotNull { it.seriesId }
                    .toSet()
                allSeries.filter { it.id in ids }
            }
            QuickList.FAVORITES -> allSeries.filter { it.id in prefs.favoriteSeriesIds }
            QuickList.RED -> allSeries.filter(::isRedListSeries)
            QuickList.FAMILY -> allSeries.filter(::isFamilySeries)
            QuickList.NONE -> if (currentCategoryId == "all") allSeries else allSeries.filter { it.providerCategoryKey == currentCategoryId }
        }
        list = when (sortMode) {
            SortMode.DEFAULT -> list
            SortMode.NEWEST -> list.sortedByDescending { it.year.toIntOrNull() ?: 0 }
            SortMode.OLDEST -> list.sortedBy { it.year.toIntOrNull() ?: Int.MAX_VALUE }
            SortMode.AZ -> list.sortedBy { it.name.lowercase(Locale.getDefault()) }
            SortMode.ZA -> list.sortedByDescending { it.name.lowercase(Locale.getDefault()) }
        }

        val title = when (quickList) {
            QuickList.CONTINUE -> getString(R.string.home_continue_watching)
            QuickList.FAVORITES -> getString(R.string.home_favorites)
            QuickList.RED -> getString(R.string.media_red_list)
            QuickList.FAMILY -> getString(R.string.media_family_list)
            QuickList.NONE -> if (currentCategoryId == "all") getString(R.string.all_series)
                else allSeries.firstOrNull { it.providerCategoryKey == currentCategoryId }?.providerCategoryName.orEmpty()
        }
        findViewById<TextView>(R.id.txtSectionTitle).text = title
        showSeries(list)
    }

    private fun showSeries(list: List<Series>) {
        val empty = findViewById<TextView>(R.id.txtEmpty)
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        if (list.isEmpty()) {
            empty.text = getString(R.string.media_list_empty)
            selectedSeries = null
            contentAdapter.submitList(emptyList())
            return
        }

        val preferred = list.firstOrNull { it.id == lastFocusedSeriesId }
            ?: list.firstOrNull { it.id == selectedSeries?.id }
            ?: list.first()
        selectSeries(preferred)
        contentAdapter.submitList(list) {
            if (pendingGridFocusRestore) {
                pendingGridFocusRestore = false
                restoreSeriesFocus(list, preferred.id)
            }
        }
    }

    private fun restoreSeriesFocus(list: List<Series>, seriesId: String) {
        val index = list.indexOfFirst { it.id == seriesId }
        if (index < 0) return
        val recycler = findViewById<RecyclerView>(R.id.recyclerSeries)
        recycler.scrollToPosition(index)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus()
                ?: recycler.requestFocus()
        }
    }

    private fun setupSortButtons() {
        val buttons = mapOf(
            R.id.btnSortDefault to SortMode.DEFAULT,
            R.id.btnSortNewest to SortMode.NEWEST,
            R.id.btnSortOldest to SortMode.OLDEST,
            R.id.btnSortAz to SortMode.AZ,
            R.id.btnSortZa to SortMode.ZA
        )
        buttons.forEach { (id, mode) ->
            findViewById<TextView>(id).setOnClickListener {
                sortMode = mode
                buttons.forEach { (buttonId, buttonMode) ->
                    findViewById<TextView>(buttonId).isSelected = buttonMode == sortMode
                }
                applyFiltersAndShow()
            }
        }
        buttons.keys.forEach { id ->
            findViewById<TextView>(id).setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    val recycler = findViewById<RecyclerView>(R.id.recyclerSeries)
                    recycler.scrollToPosition(0)
                    recycler.post {
                        recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                            ?: recycler.requestFocus()
                    }
                    true
                } else false
            }
        }
        buttons.forEach { (buttonId, buttonMode) ->
            findViewById<TextView>(buttonId).isSelected = buttonMode == sortMode
        }
    }

    private fun selectSeries(item: Series) {
        selectedSeries = item
        lastFocusedSeriesId = item.id
        findViewById<TextView>(R.id.txtHeroTitle).text = item.name
        findViewById<TextView>(R.id.txtHeroMeta).text = listOfNotNull(
            item.rating.takeIf { it.isNotBlank() }?.let { "IMDb $it" },
            item.year.takeIf { it.isNotBlank() },
            item.genre.takeIf { it.isNotBlank() },
            item.providerCategoryName.takeIf { it.isNotBlank() }
        ).joinToString("   |   ")
        findViewById<TextView>(R.id.txtHeroPlot).text = item.plot
        val hero = findViewById<ImageView>(R.id.imgHeroBackground)
        heroArtworkJob?.cancel()
        heroArtworkJob = lifecycleScope.launch {
            delay(HERO_ARTWORK_DEBOUNCE_MS)
            if (selectedSeries?.id != item.id) return@launch
            if (item.posterUrl.isNullOrBlank()) {
                hero.setImageResource(R.drawable.media_hero_fallback)
            } else {
                hero.load(item.posterUrl) {
                    crossfade(false)
                    placeholder(R.drawable.media_hero_fallback)
                    error(R.drawable.media_hero_fallback)
                }
            }
        }
        updateFavoriteHeroState()
    }

    private fun updateFavoriteHeroState() {
        val item = selectedSeries ?: return
        findViewById<LinearLayout>(R.id.btnFavoriteHero).isSelected = item.id in prefs.favoriteSeriesIds
    }

    private fun openDetails(series: Series) {
        startActivity(Intent(this, SeriesDetailActivity::class.java).apply {
            putExtra(SeriesDetailActivity.EXTRA_SERIES, series)
        })
    }

    private fun setLoading(loading: Boolean) {
        findViewById<ProgressBar>(R.id.progressBar).visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showEmpty(message: String) {
        setLoading(false)
        findViewById<TextView>(R.id.txtEmpty).apply {
            text = message
            visibility = View.VISIBLE
        }
    }
    override fun onDestroy() {
        heroArtworkJob?.cancel()
        heroArtworkJob = null
        super.onDestroy()
    }

    private companion object {
        const val HERO_ARTWORK_DEBOUNCE_MS = 120L
        const val STATE_CATEGORY_ID = "series_category_id"
        const val STATE_QUICK_LIST = "series_quick_list"
        const val STATE_SORT_MODE = "series_sort_mode"
        const val STATE_FOCUSED_SERIES_ID = "series_focused_id"
        const val MEDIA_GRID_SPAN = 4
    }

}
