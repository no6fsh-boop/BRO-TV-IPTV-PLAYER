package com.brotv.player.ui

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.model.SettingItem

/**
 * Settings are presented as real sections instead of repeating a section label in every card.
 * Header rows span the TV grid while action cards stay predictable for D-pad navigation.
 */
class SettingsAdapter(items: List<SettingItem>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private sealed interface Row {
        data class Header(val title: String) : Row
        data class Action(val item: SettingItem) : Row
    }

    private val rows: List<Row> = buildList {
        var previousSection: String? = null
        items.forEach { item ->
            if (item.sectionTitle != previousSection) {
                add(Row.Header(item.sectionTitle))
                previousSection = item.sectionTitle
            }
            add(Row.Action(item))
        }
    }

    init {
        setHasStableIds(true)
    }

    fun isHeader(position: Int): Boolean = rows.getOrNull(position) is Row.Header

    fun headerPosition(title: String): Int = rows.indexOfFirst { row ->
        row is Row.Header && row.title == title
    }.coerceAtLeast(0)

    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.txtSettingsSectionHeader)
    }

    class SettingViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.imgSettingIcon)
        val title: TextView = view.findViewById(R.id.txtSettingTitle)
    }

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Header -> VIEW_HEADER
        is Row.Action -> VIEW_ACTION
    }

    override fun getItemId(position: Int): Long = when (val row = rows[position]) {
        is Row.Header -> ("header:${row.title}").hashCode().toLong()
        is Row.Action -> ("action:${row.item.sectionTitle}:${row.item.title}").hashCode().toLong()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == VIEW_HEADER) {
            HeaderViewHolder(inflater.inflate(R.layout.item_settings_section_header, parent, false))
        } else {
            SettingViewHolder(inflater.inflate(R.layout.item_settings_card, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder as HeaderViewHolder).title.text = row.title
            is Row.Action -> bindAction(holder as SettingViewHolder, row.item)
        }
    }

    private fun bindAction(holder: SettingViewHolder, item: SettingItem) {
        val context = holder.itemView.context
        val white = ContextCompat.getColor(context, R.color.brand_white)
        val gold = ContextCompat.getColor(context, R.color.brand_gold)
        val iconDefault = ColorStateList.valueOf(white)
        val iconFocused = ColorStateList.valueOf(gold)

        holder.icon.setImageResource(item.iconRes)
        holder.icon.imageTintList = iconDefault
        holder.title.text = item.title
        holder.title.setTextColor(white)
        holder.itemView.setOnClickListener { item.action() }
        holder.itemView.setOnFocusChangeListener { _, hasFocus ->
            holder.icon.imageTintList = if (hasFocus) iconFocused else iconDefault
            holder.title.setTextColor(white)
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        if (holder is SettingViewHolder) {
            holder.itemView.setOnClickListener(null)
            holder.itemView.setOnFocusChangeListener(null)
        }
        super.onViewRecycled(holder)
    }

    override fun getItemCount(): Int = rows.size

    private companion object {
        const val VIEW_HEADER = 0
        const val VIEW_ACTION = 1
    }
}
