package com.brotv.player.dvr

import java.net.URI

/** Small, dependency-free HLS parser focused on lossless recording. */
object HlsRecorderParser {
    data class Variant(val uri: String, val bandwidth: Long = 0L)
    data class ByteRange(val length: Long, val offset: Long?)
    data class KeySpec(val method: String, val uri: String?, val ivHex: String?)
    data class InitMap(val uri: String, val byteRange: ByteRange?)
    data class Segment(
        val uri: String,
        val sequence: Long,
        val durationSeconds: Double,
        val byteRange: ByteRange?,
        val key: KeySpec?,
        val initMap: InitMap?
    )
    data class MediaPlaylist(
        val segments: List<Segment>,
        val targetDurationSeconds: Int,
        val endList: Boolean,
        val isFmp4: Boolean
    )

    fun isPlaylist(text: String): Boolean = text.trimStart().removePrefix("\uFEFF").trimStart().startsWith("#EXTM3U", ignoreCase = true)

    fun parseMaster(text: String, baseUrl: String): List<Variant> {
        val lines = text.lineSequence().map(String::trim).filter(String::isNotEmpty).toList()
        val result = mutableListOf<Variant>()
        var pendingBandwidth = 0L
        var waitingForUri = false
        for (line in lines) {
            when {
                line.startsWith("#EXT-X-STREAM-INF:", true) -> {
                    val attrs = parseAttributes(line.substringAfter(':'))
                    pendingBandwidth = attrs["AVERAGE-BANDWIDTH"]?.toLongOrNull()
                        ?: attrs["BANDWIDTH"]?.toLongOrNull()
                        ?: 0L
                    waitingForUri = true
                }
                waitingForUri && !line.startsWith('#') -> {
                    result += Variant(resolve(baseUrl, line), pendingBandwidth)
                    waitingForUri = false
                    pendingBandwidth = 0L
                }
            }
        }
        return result
    }

    fun selectBestVariant(text: String, baseUrl: String): Variant? =
        parseMaster(text, baseUrl).maxByOrNull { it.bandwidth }

    fun parseMedia(text: String, baseUrl: String): MediaPlaylist {
        var mediaSequence = 0L
        var targetDuration = 4
        var currentDuration = 0.0
        var currentRange: ByteRange? = null
        var currentKey: KeySpec? = null
        var currentMap: InitMap? = null
        var segmentIndex = 0L
        var endList = false
        val segments = mutableListOf<Segment>()

        text.lineSequence().map(String::trim).forEach { line ->
            when {
                line.startsWith("#EXT-X-MEDIA-SEQUENCE:", true) -> {
                    mediaSequence = line.substringAfter(':').trim().toLongOrNull() ?: 0L
                }
                line.startsWith("#EXT-X-TARGETDURATION:", true) -> {
                    targetDuration = line.substringAfter(':').trim().toIntOrNull()?.coerceAtLeast(1) ?: targetDuration
                }
                line.startsWith("#EXTINF:", true) -> {
                    currentDuration = line.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: 0.0
                }
                line.startsWith("#EXT-X-BYTERANGE:", true) -> {
                    currentRange = parseByteRange(line.substringAfter(':').trim())
                }
                line.startsWith("#EXT-X-KEY:", true) -> {
                    val attrs = parseAttributes(line.substringAfter(':'))
                    val method = attrs["METHOD"].orEmpty().uppercase()
                    currentKey = if (method == "NONE") null else KeySpec(
                        method = method,
                        uri = attrs["URI"]?.let { resolve(baseUrl, it) },
                        ivHex = attrs["IV"]
                    )
                }
                line.startsWith("#EXT-X-MAP:", true) -> {
                    val attrs = parseAttributes(line.substringAfter(':'))
                    val uri = attrs["URI"]
                    currentMap = if (uri.isNullOrBlank()) null else InitMap(
                        uri = resolve(baseUrl, uri),
                        byteRange = attrs["BYTERANGE"]?.let(::parseByteRange)
                    )
                }
                line.equals("#EXT-X-ENDLIST", true) -> endList = true
                line.isNotBlank() && !line.startsWith('#') -> {
                    segments += Segment(
                        uri = resolve(baseUrl, line),
                        sequence = mediaSequence + segmentIndex,
                        durationSeconds = currentDuration,
                        byteRange = currentRange,
                        key = currentKey,
                        initMap = currentMap
                    )
                    segmentIndex++
                    currentDuration = 0.0
                    currentRange = null
                }
            }
        }

        return MediaPlaylist(
            segments = segments,
            targetDurationSeconds = targetDuration,
            endList = endList,
            isFmp4 = segments.any { it.initMap != null }
        )
    }

    fun parseByteRange(raw: String): ByteRange? {
        val clean = raw.trim().trim('"')
        val length = clean.substringBefore('@').toLongOrNull()?.takeIf { it > 0L } ?: return null
        val hasExplicitOffset = clean.contains('@')
        val offset = if (hasExplicitOffset) {
            clean.substringAfter('@', "")
                .takeIf(String::isNotBlank)
                ?.toLongOrNull()
                ?.takeIf { it >= 0L }
                ?: return null
        } else {
            null
        }
        if (offset != null && offset > Long.MAX_VALUE - length) return null
        return ByteRange(length, offset)
    }

    internal fun parseAttributes(raw: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val token = StringBuilder()
        var quoted = false
        val parts = mutableListOf<String>()
        raw.forEach { ch ->
            when (ch) {
                '"' -> { quoted = !quoted; token.append(ch) }
                ',' -> if (quoted) token.append(ch) else { parts += token.toString(); token.setLength(0) }
                else -> token.append(ch)
            }
        }
        if (token.isNotEmpty()) parts += token.toString()
        parts.forEach { part ->
            val key = part.substringBefore('=', "").trim().uppercase()
            if (key.isBlank()) return@forEach
            var value = part.substringAfter('=', "").trim()
            if (value.length >= 2 && value.first() == '"' && value.last() == '"') {
                value = value.substring(1, value.length - 1)
            }
            result[key] = value
        }
        return result
    }

    private fun resolve(baseUrl: String, child: String): String = try {
        URI(baseUrl).resolve(child).toString()
    } catch (_: Exception) {
        child
    }
}
