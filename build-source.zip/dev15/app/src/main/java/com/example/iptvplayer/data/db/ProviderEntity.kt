package com.brotv.player.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ProviderType { M3U, XTREAM }

/** حالة اتصال المصدر، تُحدَّث دورياً بالخلفية (بند "فحص صحة المصادر"). */
enum class ProviderStatus { UNKNOWN, CONNECTED, SLOW, OFFLINE, EXPIRED }

@Entity(tableName = "providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: ProviderType,
    val m3uUrl: String = "",
    val xtreamServer: String = "",
    val xtreamUsername: String = "",
    val xtreamPassword: String = "",
    @ColumnInfo(defaultValue = "''") val epgUrl: String = "",
    val enabled: Boolean = true,
    val isDefault: Boolean = false,
    val sortOrder: Int = 0,
    val status: ProviderStatus = ProviderStatus.UNKNOWN,
    val lastCheckedAt: Long = 0L,
    val lastSyncAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
