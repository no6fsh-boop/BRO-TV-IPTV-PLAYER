package com.brotv.player.player

import java.util.ArrayDeque

/**
 * Prevents recovery storms on unstable IPTV streams. A decoder rebuild/failover is expensive
 * on low-end Android TV devices, so repeated automatic recoveries are rate limited per session.
 */
class PlaybackRecoveryGuard(
    private val cooldownMs: Long = 8_000L,
    private val windowMs: Long = 60_000L,
    private val maxRecoveriesInWindow: Int = 3
) {
    private val recoveryTimes = ArrayDeque<Long>()
    private var lastRecoveryAtMs = Long.MIN_VALUE

    fun reset() {
        recoveryTimes.clear()
        lastRecoveryAtMs = Long.MIN_VALUE
    }

    fun canRecover(nowMs: Long): Boolean {
        trim(nowMs)
        if (lastRecoveryAtMs != Long.MIN_VALUE && nowMs - lastRecoveryAtMs < cooldownMs) return false
        return recoveryTimes.size < maxRecoveriesInWindow
    }

    fun recordRecovery(nowMs: Long) {
        trim(nowMs)
        recoveryTimes.addLast(nowMs)
        lastRecoveryAtMs = nowMs
    }

    private fun trim(nowMs: Long) {
        while (recoveryTimes.isNotEmpty() && nowMs - recoveryTimes.first() >= windowMs) {
            recoveryTimes.removeFirst()
        }
    }
}
