package com.brotv.player.model

enum class SearchResultType { CHANNEL, MOVIE, SERIES }

data class SearchResultItem(
    val type: SearchResultType,
    val title: String,
    val subtitle: String,
    val channel: MergedChannel? = null,
    val movie: Movie? = null,
    val series: Series? = null
)
