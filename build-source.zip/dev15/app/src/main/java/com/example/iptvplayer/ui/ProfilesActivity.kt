package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.brotv.player.R
import com.brotv.player.data.ProfileManager

/**
 * شاشة "من يشاهد الآن؟": تعرض كل البروفايلات، تختار وحد وتفتح الرئيسية،
 * أو تضيف بروفايل جديد. كل بروفايل له مفضلة واستكمال مشاهدة مستقل بدون أي رقابة.
 */
class ProfilesActivity : AppCompatActivity() {

    private lateinit var profileManager: ProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profiles)
        profileManager = ProfileManager(this)

        findViewById<LinearLayout>(R.id.btnAddProfile).setOnClickListener { showAddProfileDialog() }
        renderProfiles()
    }

    private fun renderProfiles() {
        val row = findViewById<LinearLayout>(R.id.profilesRow)
        row.removeAllViews()
        val inflater = LayoutInflater.from(this)

        profileManager.getProfiles().forEach { profile ->
            val view = inflater.inflate(R.layout.item_profile, row, false)
            view.findViewById<TextView>(R.id.txtProfileName).text = profile.name
            view.setOnClickListener {
                profileManager.activeProfileId = profile.id
                goToHome()
            }
            row.addView(view)
        }
    }

    private fun showAddProfileDialog() {
        val input = EditText(this)
        input.hint = getString(R.string.profile_name_hint)

        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.profiles_add_new)
            .setView(input)
            .setPositiveButton(R.string.add_action) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    profileManager.addProfile(name)
                    renderProfiles()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun goToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
