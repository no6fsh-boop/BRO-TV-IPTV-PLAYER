package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.ProviderHealthChecker
import com.brotv.player.data.SourceConfig
import com.brotv.player.data.SourcesManager
import com.brotv.player.data.db.ProviderStatus
import kotlinx.coroutines.launch

/**
 * إدارة مصادر القنوات الاحترافية: تفعيل/تعطيل بدون حذف، إعادة تسمية، ترتيب،
 * تحديد مصدر افتراضي، وفحص حالة اتصال حقيقي لكل مصدر (متصل/بطيء/متوقف/منتهي).
 */
class SourcesActivity : AppCompatActivity() {

    private lateinit var sourcesManager: SourcesManager
    private var sources: MutableList<SourceConfig> = mutableListOf()
    private var defaultId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sources)
        sourcesManager = SourcesManager(this)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<LinearLayout>(R.id.btnAddSource).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
        findViewById<RecyclerView>(R.id.recyclerSources).layoutManager = LinearLayoutManager(this)

        renderSources()
    }

    override fun onResume() {
        super.onResume()
        renderSources() // نحدّث القائمة كل ما نرجع لها (بعد إضافة مصدر جديد مثلاً)
    }

    private fun renderSources() {
        lifecycleScope.launch {
            sources = sourcesManager.getSources().toMutableList()
            defaultId = sourcesManager.getDefaultSource()?.id
            findViewById<TextView>(R.id.txtEmpty).visibility = if (sources.isEmpty()) View.VISIBLE else View.GONE

            findViewById<RecyclerView>(R.id.recyclerSources).adapter = SourceAdapter(
                sources = sources,
                defaultId = defaultId,
                onToggleEnabled = { source, enabled ->
                    lifecycleScope.launch { sourcesManager.setEnabled(source.id, enabled) }
                },
                onSetDefault = { source ->
                    lifecycleScope.launch {
                        sourcesManager.setDefault(source.id)
                        renderSources()
                    }
                },
                onRename = { source -> showRenameDialog(source) },
                onEditEpg = { source -> showEpgDialog(source) },
                onMoveUp = { position -> moveSource(position, position - 1) },
                onMoveDown = { position -> moveSource(position, position + 1) },
                onDelete = { source ->
                    lifecycleScope.launch {
                        sourcesManager.removeSource(source.id)
                        renderSources()
                    }
                }
            )

            checkAllStatuses()
        }
    }

    private fun moveSource(from: Int, to: Int) {
        if (to < 0 || to >= sources.size) return
        val item = sources.removeAt(from)
        sources.add(to, item)
        lifecycleScope.launch {
            sourcesManager.saveOrder(sources.map { it.id })
            renderSources()
        }
    }

    private fun showRenameDialog(source: SourceConfig) {
        val input = EditText(this)
        input.setText(source.name)

        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.rename_source))
            .setView(input)
            .setPositiveButton(getString(R.string.dialog_save)) { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    lifecycleScope.launch {
                        sourcesManager.rename(source.id, newName)
                        renderSources()
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }


    private fun showEpgDialog(source: SourceConfig) {
        val input = EditText(this).apply {
            setText(source.epgUrl)
            hint = getString(R.string.epg_url_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
        }
        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(getString(R.string.epg_source_title))
            .setMessage(getString(R.string.epg_source_message))
            .setView(input)
            .setPositiveButton(getString(R.string.dialog_save)) { _, _ ->
                lifecycleScope.launch {
                    val ok = sourcesManager.updateEpgUrl(source.id, input.text.toString().trim())
                    if (!ok) {
                        android.widget.Toast.makeText(this@SourcesActivity, getString(R.string.error_encryption_failed), android.widget.Toast.LENGTH_LONG).show()
                    }
                    renderSources()
                }
            }
            .setNeutralButton(getString(R.string.epg_remove)) { _, _ ->
                lifecycleScope.launch { sourcesManager.updateEpgUrl(source.id, ""); renderSources() }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    /** يفحص حالة كل مصدر بالخلفية بالتوازي، بدون ما يعلّق الواجهة. */
    private fun checkAllStatuses() {
        val adapter = findViewById<RecyclerView>(R.id.recyclerSources).adapter as? SourceAdapter ?: return
        sources.forEachIndexed { index, source ->
            lifecycleScope.launch {
                val status = ProviderHealthChecker.check(source)
                sourcesManager.updateStatus(source.id, status)
                adapter.updateStatusAt(index, status)
            }
        }
    }
}

private class SourceAdapter(
    private val sources: List<SourceConfig>,
    private val defaultId: String?,
    private val onToggleEnabled: (SourceConfig, Boolean) -> Unit,
    private val onSetDefault: (SourceConfig) -> Unit,
    private val onRename: (SourceConfig) -> Unit,
    private val onEditEpg: (SourceConfig) -> Unit,
    private val onMoveUp: (Int) -> Unit,
    private val onMoveDown: (Int) -> Unit,
    private val onDelete: (SourceConfig) -> Unit
) : RecyclerView.Adapter<SourceAdapter.SourceViewHolder>() {

    private val statuses = HashMap<String, ProviderStatus>()

    fun updateStatusAt(position: Int, status: ProviderStatus) {
        if (position !in sources.indices) return
        statuses[sources[position].id] = status
        notifyItemChanged(position)
    }

    class SourceViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.txtSourceName)
        val type: TextView = view.findViewById(R.id.txtSourceType)
        val statusDot: View = view.findViewById(R.id.viewStatusDot)
        val defaultStar: ImageView = view.findViewById(R.id.imgDefaultStar)
        val enabledSwitch: SwitchCompat = view.findViewById(R.id.switchEnabled)
        val moveUp: ImageView = view.findViewById(R.id.btnMoveUpSource)
        val moveDown: ImageView = view.findViewById(R.id.btnMoveDownSource)
        val rename: ImageView = view.findViewById(R.id.btnRenameSource)
        val epg: TextView = view.findViewById(R.id.btnEpgSource)
        val delete: ImageView = view.findViewById(R.id.btnDeleteSource)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SourceViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_source, parent, false)
        return SourceViewHolder(view)
    }

    override fun onBindViewHolder(holder: SourceViewHolder, position: Int) {
        val context = holder.itemView.context
        val source = sources[position]
        val isDefault = source.id == defaultId
        val status = statuses[source.id] ?: ProviderStatus.UNKNOWN

        holder.name.text = source.name
        val typeLabel = if (source.type == PrefsManager.SourceType.XTREAM) "Xtream Codes" else "M3U"
        holder.type.text = context.getString(R.string.source_type_status, typeLabel, statusLabel(context, status))

        holder.statusDot.setBackgroundResource(
            when (status) {
                ProviderStatus.CONNECTED -> R.drawable.status_dot_connected
                ProviderStatus.SLOW -> R.drawable.status_dot_slow
                ProviderStatus.OFFLINE, ProviderStatus.EXPIRED -> R.drawable.status_dot_offline
                ProviderStatus.UNKNOWN -> R.drawable.status_dot_unknown
            }
        )

        holder.defaultStar.setColorFilter(
            ContextCompat.getColor(context, if (isDefault) R.color.brand_gold else R.color.brand_text_secondary)
        )
        holder.defaultStar.setOnClickListener { onSetDefault(source) }

        holder.enabledSwitch.setOnCheckedChangeListener(null)
        holder.enabledSwitch.isChecked = source.enabled
        holder.enabledSwitch.setOnCheckedChangeListener { _, checked -> onToggleEnabled(source, checked) }

        holder.moveUp.setOnClickListener { onMoveUp(holder.bindingAdapterPosition) }
        holder.moveDown.setOnClickListener { onMoveDown(holder.bindingAdapterPosition) }
        holder.rename.setOnClickListener { onRename(source) }
        holder.epg.text = if (source.epgUrl.isBlank()) context.getString(R.string.epg_add_short) else context.getString(R.string.epg_edit_short)
        holder.epg.setOnClickListener { onEditEpg(source) }
        holder.delete.setOnClickListener { onDelete(source) }
    }

    private fun statusLabel(context: android.content.Context, status: ProviderStatus): String = when (status) {
        ProviderStatus.CONNECTED -> context.getString(R.string.status_connected)
        ProviderStatus.SLOW -> context.getString(R.string.status_slow)
        ProviderStatus.OFFLINE -> context.getString(R.string.status_offline)
        ProviderStatus.EXPIRED -> context.getString(R.string.status_expired)
        ProviderStatus.UNKNOWN -> context.getString(R.string.status_checking)
    }

    override fun getItemCount(): Int = sources.size
}
