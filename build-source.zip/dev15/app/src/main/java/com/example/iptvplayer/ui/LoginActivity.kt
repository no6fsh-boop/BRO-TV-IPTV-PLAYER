package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.brotv.player.R
import com.brotv.player.data.LocalPairingServer
import com.brotv.player.data.LocaleManager
import com.brotv.player.data.M3uParser
import com.brotv.player.data.NetworkUtils
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.QrCodeGenerator
import com.brotv.player.data.SourceConfig
import com.brotv.player.data.SourcesManager
import com.brotv.player.data.XtreamClient
import com.brotv.player.model.Channel
import kotlinx.coroutines.launch

/**
 * شاشة تسجيل الدخول: تبويبات Xtream Codes / رابط M3U، بالإضافة إلى
 * إمكانية تعبئة البيانات من الجوال عبر كود QR محلي (بدون أي سيرفر خارجي).
 *
 * كل مرة تسجل فيها مصدر جديد يُضاف لقائمة المصادر المحفوظة (ما يستبدل القديم)،
 * وتُدمج كل القنوات/الأفلام/المسلسلات من كل المصادر مع بعض تلقائياً.
 */
class LoginActivity : AppCompatActivity() {

    private enum class SourceTab { XTREAM, M3U }

    private var currentTab = SourceTab.M3U
    private var pairingServer: LocalPairingServer? = null
    private val tokenHandler = Handler(Looper.getMainLooper())
    private var currentToken = NetworkUtils.generateToken()
    private lateinit var sourcesManager: SourcesManager

    private val tokenRotationRunnable = object : Runnable {
        override fun run() {
            currentToken = NetworkUtils.generateToken()
            pairingServer?.updateToken(currentToken)
            refreshQrCode()
            tokenHandler.postDelayed(this, TOKEN_ROTATION_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        sourcesManager = SourcesManager(this)

        val tabXtream = findViewById<TextView>(R.id.tabXtream)
        val tabM3u = findViewById<TextView>(R.id.tabM3u)
        val xtreamFields = findViewById<LinearLayout>(R.id.xtreamFields)
        val m3uFields = findViewById<LinearLayout>(R.id.m3uFields)

        tabXtream.setOnClickListener {
            currentTab = SourceTab.XTREAM
            updateTabsUi(tabXtream, tabM3u, xtreamFields, m3uFields)
            findViewById<LinearLayout>(R.id.manualLoginPanel).visibility = View.VISIBLE
        }
        tabM3u.setOnClickListener {
            currentTab = SourceTab.M3U
            updateTabsUi(tabXtream, tabM3u, xtreamFields, m3uFields)
            findViewById<LinearLayout>(R.id.manualLoginPanel).visibility = View.VISIBLE
            findViewById<EditText>(R.id.editM3uUrl).requestFocus()
        }
        findViewById<TextView>(R.id.btnContinue).setOnClickListener {
            findViewById<LinearLayout>(R.id.manualLoginPanel).visibility = View.VISIBLE
            findViewById<EditText>(if (currentTab == SourceTab.M3U) R.id.editM3uUrl else R.id.editHost).requestFocus()
        }
        findViewById<TextView>(R.id.btnShowQr).setOnClickListener { findViewById<LinearLayout>(R.id.qrPanel).requestFocus() }

        findViewById<Button>(R.id.btnLogin).setOnClickListener { attemptManualLogin() }
        setupPasswordToggle()

        updateTabsUi(tabXtream, tabM3u, xtreamFields, m3uFields)
        tabM3u.post { tabM3u.requestFocus() }
        startPairingServer()
    }

    private fun updateTabsUi(
        tabXtream: TextView, tabM3u: TextView,
        xtreamFields: LinearLayout, m3uFields: LinearLayout
    ) {
        val isXtream = currentTab == SourceTab.XTREAM
        tabXtream.isSelected = isXtream
        tabM3u.isSelected = !isXtream
        tabXtream.setTextColor(ContextCompat.getColor(this, if (isXtream) R.color.brand_gold else R.color.brand_text_secondary))
        tabM3u.setTextColor(ContextCompat.getColor(this, if (!isXtream) R.color.brand_gold else R.color.brand_text_secondary))
        xtreamFields.visibility = if (isXtream) View.VISIBLE else View.GONE
        m3uFields.visibility = if (isXtream) View.GONE else View.VISIBLE
        findViewById<EditText>(R.id.editPlaylistName).nextFocusDownId =
            if (isXtream) R.id.editUsername else R.id.editM3uUrl
    }

    private fun setupPasswordToggle() {
        val editPassword = findViewById<EditText>(R.id.editPassword)
        val toggle = findViewById<ImageView>(R.id.btnTogglePassword)
        var isVisible = false
        toggle.setOnClickListener {
            isVisible = !isVisible
            editPassword.inputType = if (isVisible) {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            } else {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            editPassword.setSelection(editPassword.text.length)
            toggle.setImageResource(if (isVisible) R.drawable.ic_show else R.drawable.ic_hide)
            toggle.contentDescription = getString(R.string.cd_toggle_password)
        }
    }

    // ---------- تسجيل الدخول اليدوي ----------

    private fun attemptManualLogin() {
        val playlistName = findViewById<EditText>(R.id.editPlaylistName).text.toString().trim()
            .ifBlank { getString(if (currentTab == SourceTab.XTREAM) R.string.default_xtream_account else R.string.default_m3u_playlist) }
        findViewById<TextView>(R.id.txtError).visibility = View.GONE
        setLoading(true)

        lifecycleScope.launch {
            try {
                val channels: List<Channel>
                val sourceId = "src_${System.currentTimeMillis()}"

                if (currentTab == SourceTab.XTREAM) {
                    val user = findViewById<EditText>(R.id.editUsername).text.toString().trim()
                    val pass = findViewById<EditText>(R.id.editPassword).text.toString().trim()
                    val host = findViewById<EditText>(R.id.editHost).text.toString().trim()
                    if (user.isEmpty() || pass.isEmpty() || host.isEmpty()) {
                        throw IllegalArgumentException(getString(R.string.error_empty_fields))
                    }
                    channels = XtreamClient(host, user, pass).getLiveChannels()
                    if (channels.isEmpty()) throw IllegalStateException(getString(R.string.error_no_channels))

                    val saved = sourcesManager.addSource(
                        SourceConfig(sourceId, playlistName, PrefsManager.SourceType.XTREAM,
                            xtreamServer = host, xtreamUsername = user, xtreamPassword = pass)
                    )
                    if (!saved) throw IllegalStateException(getString(R.string.error_encryption_failed))
                } else {
                    val url = findViewById<EditText>(R.id.editM3uUrl).text.toString().trim()
                    if (url.isEmpty()) throw IllegalArgumentException(getString(R.string.error_empty_url))
                    channels = M3uParser.fetchAndParse(url)
                    if (channels.isEmpty()) throw IllegalStateException(getString(R.string.error_no_channels))

                    val saved = sourcesManager.addSource(
                        SourceConfig(sourceId, playlistName, PrefsManager.SourceType.M3U, m3uUrl = url)
                    )
                    if (!saved) throw IllegalStateException(getString(R.string.error_encryption_failed))
                }

                goToHome()
            } catch (e: Exception) {
                showError(friendlyError(e))
            } finally {
                setLoading(false)
            }
        }
    }

    // ---------- تسجيل الدخول عبر الجوال (QR محلي) ----------

    private fun startPairingServer() {
        try {
            pairingServer = LocalPairingServer(
                port = PAIRING_PORT,
                mode = LocalPairingServer.Mode.LOGIN,
                currentToken = currentToken,
                languageCode = LocaleManager.getCurrentLanguage()
            ) { data -> onPhoneDataReceived(data) }
            pairingServer?.start()
            refreshQrCode()
            tokenHandler.postDelayed(tokenRotationRunnable, TOKEN_ROTATION_MS)
        } catch (e: Exception) {
            // لو تعذر تشغيل السيرفر المحلي (مثلاً المنفذ مشغول)، يبقى التسجيل اليدوي متاح بدون مشاكل
        }
    }

    private fun refreshQrCode() {
        val ip = NetworkUtils.getLocalIpAddress(this) ?: return
        val url = "http://$ip:$PAIRING_PORT/pair?token=$currentToken"
        val bitmap = QrCodeGenerator.generate(url)
        findViewById<ImageView>(R.id.imgQrCode).setImageBitmap(bitmap)
    }

    /**
     * يُستدعى من ثريد السيرفر المحلي عند وصول بيانات من الجوال؛ يدعم Xtream وM3U مع بعض
     * (النوع يوصل بحقل "type")، وينفذ الدخول على ثريد الواجهة.
     */
    private fun onPhoneDataReceived(data: Map<String, String>) {
        runOnUiThread {
            val type = data["type"] ?: "xtream"
            val playlistName = data["playlistName"]?.takeIf { it.isNotBlank() } ?: getString(R.string.source_from_phone)

            setLoading(true)
            lifecycleScope.launch {
                try {
                    val sourceId = "src_${System.currentTimeMillis()}"
                    val channels: List<Channel>

                    if (type == "m3u") {
                        val m3uUrl = data["m3uUrl"] ?: ""
                        if (m3uUrl.isBlank()) throw IllegalArgumentException(getString(R.string.error_empty_url))
                        channels = M3uParser.fetchAndParse(m3uUrl)
                        if (channels.isEmpty()) throw IllegalStateException(getString(R.string.error_no_channels))

                        val saved = sourcesManager.addSource(
                            SourceConfig(sourceId, playlistName, PrefsManager.SourceType.M3U, m3uUrl = m3uUrl)
                        )
                        if (!saved) throw IllegalStateException(getString(R.string.error_encryption_failed))
                    } else {
                        val host = data["host"] ?: ""
                        val username = data["username"] ?: ""
                        val password = data["password"] ?: ""
                        if (host.isBlank()) throw IllegalArgumentException(getString(R.string.error_empty_fields))

                        channels = XtreamClient(host, username, password).getLiveChannels()
                        if (channels.isEmpty()) throw IllegalStateException(getString(R.string.error_no_channels))

                        val saved = sourcesManager.addSource(
                            SourceConfig(sourceId, playlistName, PrefsManager.SourceType.XTREAM,
                                xtreamServer = host, xtreamUsername = username, xtreamPassword = password)
                        )
                        if (!saved) throw IllegalStateException(getString(R.string.error_encryption_failed))
                    }

                    // تسجيل دخول تلقائي فوري بدون أي تأكيد إضافي، لأن الجوال هو نفسه التأكيد
                    goToHome()
                } catch (e: Exception) {
                    showError(friendlyError(e))
                } finally {
                    setLoading(false)
                }
            }
        }
    }

    // ---------- أدوات مساعدة ----------

    private fun setLoading(loading: Boolean) {
        findViewById<ProgressBar>(R.id.progressBar).visibility = if (loading) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.btnLogin).isEnabled = !loading
    }

    private fun showError(message: String) {
        val txtError = findViewById<TextView>(R.id.txtError)
        txtError.text = message
        txtError.visibility = View.VISIBLE
    }

    /** Never surface provider/HTTP stack text directly on the TV. */
    private fun friendlyError(error: Exception): String {
        val message = error.message.orEmpty()
        val userMessages = setOf(
            getString(R.string.error_empty_fields),
            getString(R.string.error_empty_url),
            getString(R.string.error_no_channels),
            getString(R.string.error_encryption_failed)
        )
        return message.takeIf { it in userMessages } ?: getString(R.string.error_generic)
    }

    private fun goToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        tokenHandler.removeCallbacks(tokenRotationRunnable)
        pairingServer?.stop()
    }

    companion object {
        private const val PAIRING_PORT = 8098
        private const val TOKEN_ROTATION_MS = 5 * 60 * 1000L // 5 دقائق
    }
}
