package com.brotv.player.data

import com.brotv.player.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * يقوم بتحميل رابط قائمة M3U/M3U8 وتحليله إلى قائمة قنوات (Channel).
 */
object M3uParser {

    private val extInfRegex = Regex("""#EXTINF:.*?,(.*)$""", RegexOption.IGNORE_CASE)

    suspend fun fetchAndParse(url: String): List<Channel> = withContext(Dispatchers.IO) {
        val content = downloadText(url)
        parse(content)
    }

    private fun downloadText(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        return try {
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.requestMethod = "GET"
            connection.instanceFollowRedirects = true

            val status = connection.responseCode
            if (status !in 200..299) {
                throw IllegalStateException("M3U request failed with HTTP $status")
            }

            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    fun parse(content: String): List<Channel> {
        val lines = content.lines()
        val channels = mutableListOf<Channel>()

        var pendingName: String? = null
        var pendingLogo: String? = null
        var pendingGroup: String = "عام"
        var pendingEpgId: String? = null
        var counter = 0

        for (rawLine in lines) {
            val line = rawLine.trim().removePrefix("\uFEFF")
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val nameMatch = extInfRegex.find(line)
                    pendingName = nameMatch?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }
                        ?: "قناة ${counter + 1}"
                    pendingLogo = attributeValue(line, "tvg-logo")?.trim()?.takeIf { it.isNotEmpty() }
                    pendingEpgId = attributeValue(line, "tvg-id")?.trim()?.takeIf { it.isNotEmpty() }
                    pendingGroup = attributeValue(line, "group-title")?.trim()?.takeIf { it.isNotEmpty() }
                        ?: "عام"
                }

                line.startsWith("#EXTGRP:", ignoreCase = true) && pendingName != null -> {
                    pendingGroup = line.substringAfter(':').trim().takeIf { it.isNotEmpty() } ?: pendingGroup
                }

                line.isNotEmpty() && !line.startsWith("#") -> {
                    // هذا هو رابط البث الفعلي، يأتي عادة بعد سطر EXTINF مباشرة.
                    val name = pendingName ?: "قناة ${counter + 1}"
                    channels.add(
                        Channel(
                            id = "m3u_$counter",
                            name = name,
                            streamUrl = line,
                            logoUrl = pendingLogo,
                            groupTitle = pendingGroup,
                            epgId = pendingEpgId
                        )
                    )
                    counter++
                    pendingName = null
                    pendingLogo = null
                    pendingEpgId = null
                    pendingGroup = "عام"
                }
            }
        }
        return channels
    }

    private fun attributeValue(line: String, key: String): String? {
        val escapedKey = Regex.escape(key)
        val regex = Regex(
            """(?:^|\s)$escapedKey\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))""",
            RegexOption.IGNORE_CASE
        )
        val match = regex.find(line) ?: return null
        return match.groupValues.drop(1).firstOrNull { it.isNotEmpty() }
    }
}
