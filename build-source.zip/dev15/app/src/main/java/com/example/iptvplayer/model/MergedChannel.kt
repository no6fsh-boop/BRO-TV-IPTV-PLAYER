package com.brotv.player.model

import android.os.Parcel
import android.os.Parcelable

/**
 * قناة واحدة نهائية بعد دمج كل مصادرها المتشابهة بالاسم (مثلاً 8 نسخ من "بي إن سبورت"
 * تصير قناة وحدة هنا، وكل نسخة تتحول لعنصر داخل sourceUrls).
 */
data class MergedChannel(
    val id: String,
    val name: String,
    val groupTitle: String,
    val logoUrl: String?,
    val sourceUrls: List<String>,
    val epgIds: List<String> = emptyList(),
    val hasArchive: Boolean = false,
    val archiveDurationDays: Int = 0
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "عام",
        parcel.readString(),
        parcel.createStringArrayList() ?: emptyList(),
        parcel.createStringArrayList() ?: emptyList(),
        parcel.readByte() != 0.toByte(),
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(name)
        parcel.writeString(groupTitle)
        parcel.writeString(logoUrl)
        parcel.writeStringList(sourceUrls)
        parcel.writeStringList(epgIds)
        parcel.writeByte(if (hasArchive) 1 else 0)
        parcel.writeInt(archiveDurationDays)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<MergedChannel> {
        override fun createFromParcel(parcel: Parcel): MergedChannel = MergedChannel(parcel)
        override fun newArray(size: Int): Array<MergedChannel?> = arrayOfNulls(size)
    }
}
