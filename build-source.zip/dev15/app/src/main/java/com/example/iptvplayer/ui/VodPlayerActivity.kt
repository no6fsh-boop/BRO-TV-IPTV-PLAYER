package com.brotv.player.ui

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.ui.PlayerView
import com.brotv.player.R
import com.brotv.player.data.ContinueWatchingManager
import com.brotv.player.data.NetworkUtils
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.SeriesRepository
import com.brotv.player.model.ContinueWatchingItem
import com.brotv.player.model.ContinueWatchingType
import com.brotv.player.model.Episode
import com.brotv.player.player.DisplayModeSwitcher
import com.brotv.player.player.ResourceBudget
import com.brotv.player.player.ResourceGuard
import com.brotv.player.player.PlaybackRecoveryGuard
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * مشغل الأفلام والحلقات: يستأنف من آخر نقطة توقف تلقائياً، ويحفظ التقدم بالخلفية،
 * ويدعم التشغيل التلقائي للحلقة التالية بعدّاد قابل للإلغاء.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class VodPlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private var lastAppliedDisplayModeWidth = 0
    private var lastAppliedDisplayModeHeight = 0
    private var resourceLease: ResourceGuard.Lease? = null
    private var resourceRequestToken = 0L
    private lateinit var continueWatching: ContinueWatchingManager
    private lateinit var prefs: PrefsManager

    private var contentId = ""
    private var title = ""
    private var subtitle = ""
    private var streamUrl = ""
    private var posterUrl: String? = null
    private var isMovie = true

    // بيانات خاصة بالحلقات فقط (تُستخدم للحلقة التالية/السابقة)
    private var seriesId: String? = null
    private var seasonEpisodes: List<Episode> = emptyList()
    private var currentEpisodeIndex = -1

    private val progressHandler = Handler(Looper.getMainLooper())
    private val seekIndicatorHandler = Handler(Looper.getMainLooper())
    private val sleepTimerHandler = Handler(Looper.getMainLooper())
    private var sleepTimerRunnable: Runnable? = null
    private var seekIndicatorHideRunnable: Runnable? = null

    // ---------- إخفاء شريط التحكم تلقائياً (Movies/Series) ----------
    private val chromeHandler = Handler(Looper.getMainLooper())
    private val hideChromeRunnable = Runnable {
        // لا نخفي الشريط والفيديو متوقف مؤقتاً؛ فقط أثناء التشغيل الفعلي.
        if (player?.isPlaying == true) setPlayerChromeVisible(false)
    }
    private var autoNextJob: Runnable? = null
    private var lastPeriodicProgressSaveAtMs = 0L
    private var playbackRetryAttempts = 0
    private val playbackRecoveryGuard = PlaybackRecoveryGuard(
        cooldownMs = 2_000L,
        windowMs = 60_000L,
        maxRecoveriesInWindow = 4
    )
    private var wasNetworkLost = false
    private var networkCallbackRegistered = false
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onLost(network: Network) {
            wasNetworkLost = true
            runOnUiThread { showRecoveryMessage(getString(R.string.vod_waiting_for_connection)) }
        }

        override fun onAvailable(network: Network) {
            if (!wasNetworkLost) return
            wasNetworkLost = false
            runOnUiThread {
                playbackRetryAttempts = 0
                playbackRecoveryGuard.reset()
                startPlayback(player?.currentPosition ?: continueWatching.getPosition(contentId))
            }
        }
    }

    private val resizeModes = listOf(
        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT,
        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private var resizeModeIndex = 0

    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgressUi()

            // Keep the on-screen progress smooth without serialising the whole
            // continue-watching list every few seconds on the UI thread.
            val now = SystemClock.elapsedRealtime()
            if (player?.isPlaying == true && now - lastPeriodicProgressSaveAtMs >= PROGRESS_SAVE_INTERVAL_MS) {
                saveProgressIfNeeded()
                lastPeriodicProgressSaveAtMs = now
            }
            progressHandler.postDelayed(this, PROGRESS_UI_INTERVAL_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_player)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handlePlayerBack()
            }
        })
        continueWatching = ContinueWatchingManager(this)
        prefs = PrefsManager(this)

        contentId = intent.getStringExtra(EXTRA_CONTENT_ID) ?: return finishSelf()
        title = intent.getStringExtra(EXTRA_TITLE) ?: ""
        subtitle = intent.getStringExtra(EXTRA_SUBTITLE) ?: ""
        streamUrl = intent.getStringExtra(EXTRA_STREAM_URL) ?: return finishSelf()
        posterUrl = intent.getStringExtra(EXTRA_POSTER_URL)
        isMovie = intent.getBooleanExtra(EXTRA_IS_MOVIE, true)
        seriesId = intent.getStringExtra(EXTRA_SERIES_ID)
        val parentalCategory = intent.getStringExtra(EXTRA_PARENTAL_CATEGORY) ?: subtitle
        val parentalScope = intent.getStringExtra(EXTRA_PARENTAL_SCOPE)

        findViewById<TextView>(R.id.txtContentType).text = getString(if (isMovie) R.string.movie_label else R.string.series_label)
        findViewById<TextView>(R.id.txtContentTitle).text = title
        findViewById<TextView>(R.id.txtContentSubtitle).text = subtitle
        findViewById<TextView>(R.id.txtPlayerClock).text = NetworkUtils.currentTimeFormatted(this)
        findViewById<TextView>(R.id.txtFailoverAlert).text = getString(R.string.playback_resumed)
        findViewById<ImageView>(R.id.btnRecord).visibility = View.GONE
        findViewById<ImageView>(R.id.btnGuide).visibility = View.GONE
        findViewById<ImageView>(R.id.btnStats).visibility = View.GONE
        findViewById<ImageView>(R.id.btnPip).visibility = View.GONE

        if (isMovie) {
            findViewById<ImageView>(R.id.btnNextEpisode).visibility = View.GONE
            findViewById<ImageView>(R.id.btnPreviousEpisode).visibility = View.GONE
        } else {
            loadSeriesEpisodesForNavigation()
        }

        val lockedCategories = when (parentalScope) {
            PARENTAL_SCOPE_LIVE -> prefs.lockedLiveCategories
            PARENTAL_SCOPE_SERIES -> prefs.lockedSeriesCategories
            else -> if (isMovie) prefs.lockedVodCategories else prefs.lockedSeriesCategories
        }
        ParentalGate.requirePinIfNeeded(
            activity = this,
            category = parentalCategory,
            lockedCategories = lockedCategories,
            onGranted = {
                setupControls()
                val resumePosition = continueWatching.getPosition(contentId)
                startPlayback(resumePosition)
                progressHandler.removeCallbacks(progressRunnable)
                lastPeriodicProgressSaveAtMs = SystemClock.elapsedRealtime()
                progressHandler.post(progressRunnable)
                registerNetworkCallback()
            },
            onDenied = { finish() }
        )
    }

    private fun finishSelf() {
        finish()
    }

    private fun setupControls() {
        findViewById<ImageView>(R.id.btnPlayPause).setOnClickListener {
            player?.let { it.playWhenReady = !it.playWhenReady }
            showControlsTemporarily()
        }
        findViewById<FrameLayout>(R.id.btnForward15).setOnClickListener { seekBy(15_000); showControlsTemporarily() }
        findViewById<FrameLayout>(R.id.btnRewind15).setOnClickListener { seekBy(-15_000); showControlsTemporarily() }
        findViewById<ImageView>(R.id.btnAspectRatio).setOnClickListener { cycleAspectRatio(); showControlsTemporarily() }
        findViewById<ImageView>(R.id.btnSubtitles).setOnClickListener {
            player?.let { com.brotv.player.data.SubtitleController.showSubtitleTracksDialog(this, it) }
            showControlsTemporarily()
        }
        findViewById<ImageView>(R.id.btnNextEpisode).setOnClickListener { playAdjacentEpisode(1) }
        findViewById<ImageView>(R.id.btnPreviousEpisode).setOnClickListener { playAdjacentEpisode(-1) }
        findViewById<ImageView>(R.id.btnSleepTimer).setOnClickListener { showSleepTimerDialog() }
        findViewById<ImageView>(R.id.btnPlayerSettings).setOnClickListener {
            startActivity(android.content.Intent(this, SettingsActivity::class.java))
        }

        findViewById<SeekBar>(R.id.seekBar).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) player?.seekTo(progress.toLong())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                chromeHandler.removeCallbacks(hideChromeRunnable)
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                showControlsTemporarily()
            }
        })

        // الشريط يبدأ ظاهراً ويُخفى تلقائياً بعد مهلة الخمول أثناء التشغيل الفعلي فقط.
        showControlsTemporarily()
    }

    private fun showSleepTimerDialog() {
        val minutes = intArrayOf(0, 30, 60, 90, 120)
        val labels = minutes.map { value ->
            if (value == 0) getString(R.string.sleep_timer_off)
            else getString(R.string.sleep_timer_minutes, value)
        }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.sleep_timer)
            .setItems(labels) { _, which -> scheduleSleepTimer(minutes[which]) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun scheduleSleepTimer(minutes: Int) {
        sleepTimerRunnable?.let(sleepTimerHandler::removeCallbacks)
        sleepTimerRunnable = null
        if (minutes <= 0) {
            Toast.makeText(this, R.string.sleep_timer_cancelled, Toast.LENGTH_SHORT).show()
            return
        }
        val task = Runnable {
            player?.pause()
            Toast.makeText(this, R.string.sleep_timer_finished, Toast.LENGTH_SHORT).show()
            finish()
        }
        sleepTimerRunnable = task
        sleepTimerHandler.postDelayed(task, minutes * 60_000L)
        Toast.makeText(this, getString(R.string.sleep_timer_set, minutes), Toast.LENGTH_SHORT).show()
    }

    // ---------- التشغيل ----------

    private fun currentBufferProfile(): com.brotv.player.player.PlayerEngine.BufferProfile {
        return try {
            com.brotv.player.player.PlayerEngine.BufferProfile.valueOf(prefs.bufferProfile)
        } catch (e: Exception) {
            com.brotv.player.player.PlayerEngine.BufferProfile.BALANCED
        }
    }

    private fun startPlayback(resumePositionMs: Long) {
        val requestUrl = streamUrl
        val providerKey = ResourceGuard.providerKeyFor(requestUrl)
        val reusableLease = resourceLease?.takeIf { it.providerKey == providerKey }
        val token = ++resourceRequestToken

        if (reusableLease != null) {
            reusableLease.updateKind(ResourceBudget.SessionKind.PRIMARY_PLAYBACK)
            startPlaybackWithGrantedResource(requestUrl, resumePositionMs)
            return
        }

        player?.release()
        player = null
        findViewById<PlayerView>(R.id.playerView).player = null
        resourceLease?.release()
        resourceLease = null
        findViewById<ProgressBar>(R.id.progressBar).visibility = View.VISIBLE

        lifecycleScope.launch {
            when (val result = ResourceGuard.acquire(
                context = this@VodPlayerActivity,
                streamUrl = requestUrl,
                kind = ResourceBudget.SessionKind.PRIMARY_PLAYBACK
            )) {
                is ResourceGuard.AcquireResult.Granted -> {
                    if (token != resourceRequestToken || streamUrl != requestUrl || isFinishing || isDestroyed) {
                        result.lease.release()
                        return@launch
                    }
                    resourceLease = result.lease
                    startPlaybackWithGrantedResource(requestUrl, resumePositionMs)
                }
                is ResourceGuard.AcquireResult.Denied -> {
                    if (token != resourceRequestToken) return@launch
                    findViewById<ProgressBar>(R.id.progressBar).visibility = View.GONE
                    val message = if (result.reason == ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT) {
                        getString(R.string.provider_connection_limit_reached)
                    } else {
                        getString(R.string.primary_resource_unavailable)
                    }
                    Toast.makeText(this@VodPlayerActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun startPlaybackWithGrantedResource(requestUrl: String, resumePositionMs: Long) {
        player?.release()
        val exoPlayer = com.brotv.player.player.PlayerEngine.buildPlayer(this, currentBufferProfile())
        player = exoPlayer
        findViewById<PlayerView>(R.id.playerView).player = exoPlayer

        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                findViewById<ProgressBar>(R.id.progressBar).visibility =
                    if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE

                if (state == Player.STATE_READY) {
                    playbackRetryAttempts = 0
                    playbackRecoveryGuard.reset()
                }
                if (state == Player.STATE_ENDED) onPlaybackEnded()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                findViewById<ImageView>(R.id.btnPlayPause).setImageResource(
                    if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                )
                if (isPlaying) {
                    showControlsTemporarily()
                } else {
                    // متوقف مؤقتاً: نبقي الشريط ظاهراً ونلغي مؤقت الإخفاء.
                    chromeHandler.removeCallbacks(hideChromeRunnable)
                    setPlayerChromeVisible(true)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                handlePlaybackError(error)
            }
        })

        exoPlayer.addAnalyticsListener(object : AnalyticsListener {
            override fun onVideoInputFormatChanged(
                eventTime: AnalyticsListener.EventTime,
                format: androidx.media3.common.Format,
                decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?
            ) {
                applyBestDisplayResolution(format.width, format.height, format.frameRate)
            }
        })

        exoPlayer.setMediaItem(MediaItem.fromUri(requestUrl))
        exoPlayer.prepare()
        com.brotv.player.data.SubtitleController.enableAutoSubtitles(exoPlayer)
        if (resumePositionMs > 0) exoPlayer.seekTo(resumePositionMs)
        exoPlayer.playWhenReady = true

        if (resumePositionMs > 0) {
            val alert = findViewById<TextView>(R.id.txtFailoverAlert)
            alert.visibility = View.VISIBLE
            seekIndicatorHandler.postDelayed({ alert.visibility = View.GONE }, 2500L)
        }
    }

    /**
     * يبدّل دقة خرج HDMI الفعلية لتطابق دقة الفلم/الحلقة الحالية (4K حقيقي بدل تكبير
     * داخلي)، وهذا هو اللي يخلي التلفزيون (زي LG) يعرض إشعار "4K" الحقيقي على شاشته.
     * مربوط بنفس إعداد "مطابقة معدل التحديث" المستخدم بمشغل المباشر، ويعرض تنبيه بسيط
     * للمستخدم فقط لما يتأكد إن المحتوى وخرج الجهاز فعلاً 4K الاثنين مع بعض.
     */
    private fun applyBestDisplayResolution(width: Int, height: Int, frameRate: Float) {
        if (width <= 0 || height <= 0) return
        if (PrefsManager(this).matchFrameRateMode == "OFF") return
        if (width == lastAppliedDisplayModeWidth && height == lastAppliedDisplayModeHeight) return
        lastAppliedDisplayModeWidth = width
        lastAppliedDisplayModeHeight = height
        val appliedMode = DisplayModeSwitcher.applyBestDisplayMode(this, width, height, frameRate)
        val contentIsUhd = width >= UHD_MIN_WIDTH && height >= UHD_MIN_HEIGHT
        val outputIsUhd = appliedMode != null &&
            appliedMode.width >= UHD_MIN_WIDTH && appliedMode.height >= UHD_MIN_HEIGHT
        if (contentIsUhd && outputIsUhd) {
            Toast.makeText(this, getString(R.string.uhd_4k_activated), Toast.LENGTH_SHORT).show()
        }
    }

    private fun handlePlaybackError(error: PlaybackException) {
        val httpCode = extractHttpStatusCode(error)
        val retryable = httpCode !in setOf(401, 403, 404) &&
            error.errorCode != PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED &&
            error.errorCode != PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED

        val now = android.os.SystemClock.elapsedRealtime()
        if (!retryable || playbackRetryAttempts >= MAX_PLAYBACK_RETRIES || !playbackRecoveryGuard.canRecover(now)) {
            findViewById<ProgressBar>(R.id.progressBar).visibility = View.GONE
            Toast.makeText(this, R.string.vod_playback_failed, Toast.LENGTH_LONG).show()
            return
        }
        playbackRecoveryGuard.recordRecovery(now)

        val resumePosition = player?.currentPosition?.coerceAtLeast(0L)
            ?: continueWatching.getPosition(contentId)
        val expectedContent = contentId
        val expectedUrl = streamUrl
        val delayMs = (BASE_RETRY_DELAY_MS * (1L shl playbackRetryAttempts))
            .coerceAtMost(MAX_RETRY_DELAY_MS)
        playbackRetryAttempts++
        showRecoveryMessage(getString(R.string.vod_reconnecting, playbackRetryAttempts, MAX_PLAYBACK_RETRIES))
        seekIndicatorHandler.postDelayed({
            if (!isFinishing && !isDestroyed && contentId == expectedContent && streamUrl == expectedUrl) {
                startPlayback(resumePosition)
            }
        }, delayMs)
    }

    private fun extractHttpStatusCode(error: PlaybackException): Int? {
        var cause: Throwable? = error
        var depth = 0
        while (cause != null && depth < 6) {
            if (cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                return cause.responseCode
            }
            cause = cause.cause
            depth++
        }
        return null
    }

    private fun showRecoveryMessage(message: String) {
        findViewById<TextView>(R.id.txtFailoverAlert).apply {
            text = message
            visibility = View.VISIBLE
        }
    }

    private fun registerNetworkCallback() {
        if (networkCallbackRegistered) return
        val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                manager.registerDefaultNetworkCallback(networkCallback)
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                manager.registerNetworkCallback(request, networkCallback)
            }
            networkCallbackRegistered = true
        } catch (_: Exception) {
            networkCallbackRegistered = false
        }
    }

    private fun unregisterNetworkCallback() {
        if (!networkCallbackRegistered) return
        val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        runCatching { manager.unregisterNetworkCallback(networkCallback) }
        networkCallbackRegistered = false
    }

    private fun onPlaybackEnded() {
        continueWatching.remove(contentId)
        if (!isMovie) prefs.markEpisodeWatched(contentId) // وصل لنهاية الحلقة فعلياً = مشاهدة كاملة
        if (!isMovie && hasNextEpisode()) {
            showAutoNextCountdown()
        }
    }

    // ---------- الحلقة التالية/السابقة ----------

    private fun loadSeriesEpisodesForNavigation() {
        val sId = seriesId ?: return
        lifecycleScope.launch {
            val episodesBySeason = SeriesRepository(this@VodPlayerActivity).getEpisodes(sId)
            seasonEpisodes = episodesBySeason
                .toSortedMap()
                .values
                .flatMap { season -> season.sortedBy { it.episodeNumber } }
            currentEpisodeIndex = seasonEpisodes.indexOfFirst { it.id == contentId }
            updateEpisodeNavButtons()
        }
    }

    private fun hasNextEpisode(): Boolean = currentEpisodeIndex in 0 until seasonEpisodes.size - 1
    private fun hasPreviousEpisode(): Boolean = currentEpisodeIndex > 0

    private fun updateEpisodeNavButtons() {
        findViewById<ImageView>(R.id.btnNextEpisode).visibility = if (hasNextEpisode()) View.VISIBLE else View.GONE
        findViewById<ImageView>(R.id.btnPreviousEpisode).visibility = if (hasPreviousEpisode()) View.VISIBLE else View.GONE
    }

    private fun playAdjacentEpisode(direction: Int) {
        val newIndex = currentEpisodeIndex + direction
        if (newIndex !in seasonEpisodes.indices) return
        val episode = seasonEpisodes[newIndex]

        // Manual next/previous should not discard the current episode's resume point.
        saveProgressIfNeeded()
        currentEpisodeIndex = newIndex
        contentId = episode.id
        title = episode.title
        subtitle = getString(R.string.season_episode, episode.seasonNumber, episode.episodeNumber)
        streamUrl = episode.streamUrl
        posterUrl = episode.imageUrl ?: posterUrl

        findViewById<TextView>(R.id.txtContentTitle).text = title
        findViewById<TextView>(R.id.txtContentSubtitle).text = subtitle
        updateEpisodeNavButtons()
        playbackRetryAttempts = 0
        playbackRecoveryGuard.reset()
        startPlayback(continueWatching.getPosition(contentId))
    }

    private fun showAutoNextCountdown() {
        cancelAutoNext()
        var secondsLeft = 10
        val alert = findViewById<TextView>(R.id.txtFailoverAlert)
        alert.visibility = View.VISIBLE

        val countdownRunnable = object : Runnable {
            override fun run() {
                if (secondsLeft <= 0) {
                    // Clear the countdown state before advancing. Otherwise Back can
                    // incorrectly think an auto-next countdown is still active after
                    // the next episode has already started.
                    autoNextJob = null
                    alert.visibility = View.GONE
                    playAdjacentEpisode(1)
                    return
                }
                alert.text = getString(R.string.next_episode_in, secondsLeft)
                secondsLeft--
                seekIndicatorHandler.postDelayed(this, 1000L)
            }
        }
        autoNextJob = countdownRunnable
        seekIndicatorHandler.post(countdownRunnable)
    }

    private fun cancelAutoNext() {
        autoNextJob?.let { seekIndicatorHandler.removeCallbacks(it) }
        autoNextJob = null
        findViewById<TextView>(R.id.txtFailoverAlert).visibility = View.GONE
    }

    // ---------- Seek مباشر بالريموت ----------

    private fun handlePlayerBack() {
        // Back must always leave the player on TV. Cancelling auto-next is cleanup,
        // not a separate Back action; consuming the first Back trapped users in the
        // player whenever an episode had just ended or auto-next had fired.
        cancelAutoNext()
        saveProgressIfNeeded()
        finish()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            handlePlayerBack()
            return true
        }

        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(SEEK_STEP_MS); return true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-SEEK_STEP_MS); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { player?.play(); return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { player?.pause(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                player?.let { it.playWhenReady = !it.playWhenReady }
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (shouldSeekWithDpad()) {
                seekBy(SEEK_STEP_MS)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (shouldSeekWithDpad()) {
                seekBy(-SEEK_STEP_MS)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * Left/right are transport shortcuts only while the video surface itself owns
     * the interaction. When a toolbar/transport button has focus we leave D-pad
     * events to Android so the user can move predictably between controls.
     */
    private fun shouldSeekWithDpad(): Boolean {
        val focused = currentFocus ?: return true
        return focused.id == R.id.playerView || focused.id == R.id.seekBar
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val duration = p.duration.takeIf { it > 0L }
        val target = (p.currentPosition + deltaMs).coerceAtLeast(0L)
        p.seekTo(if (duration != null) target.coerceAtMost(duration) else target)
        showSeekIndicator(deltaMs)
    }

    private fun showSeekIndicator(deltaMs: Long) {
        val indicator = findViewById<TextView>(R.id.txtSeekIndicator)
        val seconds = deltaMs / 1000
        indicator.text = if (seconds > 0) "+${seconds}" else "${seconds}"
        indicator.visibility = View.VISIBLE
        seekIndicatorHideRunnable?.let(seekIndicatorHandler::removeCallbacks)
        val hide = Runnable { indicator.visibility = View.GONE }
        seekIndicatorHideRunnable = hide
        seekIndicatorHandler.postDelayed(hide, 700L)
    }

    private fun setPlayerChromeVisible(visible: Boolean) {
        val value = if (visible) View.VISIBLE else View.GONE
        findViewById<View>(R.id.topOverlay).visibility = value
        findViewById<View>(R.id.bottomOverlay).visibility = value
        if (!visible) {
            findViewById<TextView>(R.id.txtFailoverAlert).visibility = View.GONE
        }
    }

    /** يظهر الشريط ويجدول إخفاءه بعد فترة خمول، تُستدعى عند أي تفاعل من المستخدم. */
    private fun showControlsTemporarily() {
        setPlayerChromeVisible(true)
        chromeHandler.removeCallbacks(hideChromeRunnable)
        chromeHandler.postDelayed(hideChromeRunnable, CHROME_HIDE_TIMEOUT_MS)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) showControlsTemporarily()
        return super.dispatchKeyEvent(event)
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action == android.view.MotionEvent.ACTION_DOWN) showControlsTemporarily()
        return super.onTouchEvent(event)
    }

    private fun cycleAspectRatio() {
        resizeModeIndex = (resizeModeIndex + 1) % resizeModes.size
        findViewById<PlayerView>(R.id.playerView).resizeMode = resizeModes[resizeModeIndex]
    }

    // ---------- التقدم والحفظ ----------

    private fun updateProgressUi() {
        val p = player ?: return
        val duration = p.duration.coerceAtLeast(0)
        val position = p.currentPosition.coerceAtLeast(0)

        val seekBar = findViewById<SeekBar>(R.id.seekBar)
        if (duration > 0) {
            seekBar.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            seekBar.progress = position.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }
        findViewById<TextView>(R.id.txtCurrentTime).text = formatTime(position)
        findViewById<TextView>(R.id.txtTotalTime).text = formatTime(duration)
    }

    private fun saveProgressIfNeeded() {
        val p = player ?: return
        if (p.duration <= 0) return

        continueWatching.savePosition(
            ContinueWatchingItem(
                contentId = contentId,
                type = if (isMovie) ContinueWatchingType.MOVIE else ContinueWatchingType.EPISODE,
                title = title,
                subtitle = subtitle,
                posterUrl = posterUrl,
                streamUrl = streamUrl,
                positionMs = p.currentPosition,
                durationMs = p.duration,
                updatedAt = System.currentTimeMillis(),
                seriesId = seriesId
            )
        )

        // نعلّم الحلقة "تمت مشاهدتها" بس لما يتعدى نسبة حقيقية من مدتها، مو مجرد ما يفتحها
        if (!isMovie) {
            val progress = p.currentPosition.toFloat() / p.duration
            if (progress >= WATCHED_THRESHOLD) {
                prefs.markEpisodeWatched(contentId)
            }
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000
        return String.format(Locale.US, "%02d:%02d", totalSeconds / 60, totalSeconds % 60)
    }

    override fun onResume() {
        super.onResume()
        if (player != null) {
            progressHandler.removeCallbacks(progressRunnable)
            progressHandler.post(progressRunnable)
        }
    }

    override fun onPause() {
        progressHandler.removeCallbacks(progressRunnable)
        chromeHandler.removeCallbacks(hideChromeRunnable)
        saveProgressIfNeeded()
        super.onPause()
    }

    override fun onDestroy() {
        resourceRequestToken++
        saveProgressIfNeeded()
        progressHandler.removeCallbacks(progressRunnable)
        chromeHandler.removeCallbacksAndMessages(null)
        seekIndicatorHandler.removeCallbacksAndMessages(null)
        sleepTimerHandler.removeCallbacksAndMessages(null)
        player?.release()
        DisplayModeSwitcher.resetDisplayMode(this)
        resourceLease?.release()
        resourceLease = null
        unregisterNetworkCallback()
        super.onDestroy()
    }

    companion object {
        private const val UHD_MIN_WIDTH = 3840
        private const val UHD_MIN_HEIGHT = 2160
        const val EXTRA_CONTENT_ID = "extra_content_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_SUBTITLE = "extra_subtitle"
        const val EXTRA_STREAM_URL = "extra_stream_url"
        const val EXTRA_POSTER_URL = "extra_poster_url"
        const val EXTRA_IS_MOVIE = "extra_is_movie"
        const val EXTRA_SERIES_ID = "extra_series_id"
        const val EXTRA_PARENTAL_CATEGORY = "extra_parental_category"
        const val EXTRA_PARENTAL_SCOPE = "extra_parental_scope"
        const val PARENTAL_SCOPE_LIVE = "live"
        const val PARENTAL_SCOPE_SERIES = "series"
        private const val WATCHED_THRESHOLD = 0.85f // 85% من مدة الحلقة = تعتبر متشاهَدة
        private const val SEEK_STEP_MS = 15_000L
        private const val CHROME_HIDE_TIMEOUT_MS = 5_000L
        private const val PROGRESS_UI_INTERVAL_MS = 1_000L
        private const val PROGRESS_SAVE_INTERVAL_MS = 10_000L
        private const val MAX_PLAYBACK_RETRIES = 4
        private const val BASE_RETRY_DELAY_MS = 750L
        private const val MAX_RETRY_DELAY_MS = 12_000L
    }
}
