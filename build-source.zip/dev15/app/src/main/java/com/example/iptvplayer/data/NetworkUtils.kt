package com.brotv.player.data

import android.content.Context
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Locale

object NetworkUtils {

    /**
     * يحاول يجيب عنوان IP المحلي للجهاز بالشبكة (واي فاي غالباً)،
     * مفيد لبناء رابط QR يفتحه الجوال على نفس الشبكة.
     */
    fun getLocalIpAddress(@Suppress("UNUSED_PARAMETER") context: Context): String? {
        return try {
            val candidates = mutableListOf<java.net.InetAddress>()
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is java.net.Inet4Address && !addr.isLoopbackAddress) candidates += addr
                }
            }
            // QR pairing يحتاج عنواناً يمكن للجوال الوصول له غالباً؛ نفضّل LAN private address.
            (candidates.firstOrNull { it.isSiteLocalAddress } ?: candidates.firstOrNull())?.hostAddress
        } catch (_: Exception) {
            null
        }
    }

    /** يولّد رمز ربط مؤقت قوي التشفير ويتغير كل 5 دقائق. */
    fun generateToken(): String = PairingTokenGenerator.generate()

    fun currentTimeFormatted(context: Context): String {
        val use24h = PrefsManager(context).use24HourTime
        val pattern = if (use24h) "HH:mm" else "hh:mm a"
        return SimpleDateFormat(pattern, Locale.getDefault()).format(java.util.Date())
    }

    /** يرجّع التاريخ الطويل باستخدام لغة التطبيق/الجهاز الحالية. */
    fun currentDateFormatted(): String {
        val sdf = SimpleDateFormat("EEEE d MMMM yyyy", Locale.getDefault())
        return sdf.format(java.util.Date())
    }

}
