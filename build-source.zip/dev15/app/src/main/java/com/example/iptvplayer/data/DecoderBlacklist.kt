package com.brotv.player.data

import android.content.Context
import android.os.Build

/**
 * يسجل Decoder غير الموثوق على مستوى Device Model + Codec + Decoder.
 * لا يفرض Decoder بعينه؛ Media3 يظل مسؤولاً عن الاختيار، لكن التسجيل يمنع
 * تكرار اعتبار الفشل عشوائياً ويظهر سبب الـFallback في التشخيص.
 */
object DecoderBlacklist {
    private const val PREFS = "decoder_blacklist"

    private fun key(codec: String, decoder: String): String =
        "${Build.MANUFACTURER}:${Build.MODEL}:$codec:$decoder"

    fun isUnreliable(context: Context, codec: String, decoder: String): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(key(codec, decoder), 0) >= 2

    fun recordFailure(context: Context, codec: String, decoder: String) {
        if (codec.isBlank() || decoder.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val k = key(codec, decoder)
        prefs.edit().putInt(k, prefs.getInt(k, 0) + 1).apply()
    }
}