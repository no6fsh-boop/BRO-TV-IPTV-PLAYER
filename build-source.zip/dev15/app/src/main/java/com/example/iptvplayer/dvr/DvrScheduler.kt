package com.brotv.player.dvr

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.net.Uri

object DvrScheduler {

    fun needsExactAlarmPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return !alarmManager.canScheduleExactAlarms()
    }

    fun exactAlarmPermissionIntent(context: Context): Intent? {
        if (!needsExactAlarmPermission(context)) return null
        return Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = Uri.parse("package:${context.packageName}")
        }
    }
    fun schedule(context: Context, recordingId: String, startAtMs: Long, endAtMs: Long) {
        if (endAtMs > 0 && endAtMs <= System.currentTimeMillis()) return
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pendingIntent(context, recordingId, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        val trigger = startAtMs.coerceAtLeast(System.currentTimeMillis() + 250L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            }
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, trigger, pending)
        }
    }

    fun cancel(context: Context, recordingId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pendingIntent(context, recordingId, PendingIntent.FLAG_NO_CREATE)
        if (pending != null) {
            alarmManager.cancel(pending)
            pending.cancel()
        }
    }

    suspend fun restore(context: Context) {
        val repository = DvrRepository(context)
        val now = System.currentTimeMillis()
        repository.getFutureScheduled(now).forEach { row ->
            if (row.scheduledStartMs <= now && row.scheduledEndMs > now) {
                DvrRecordingService.start(context, row.id)
            } else {
                schedule(context, row.id, row.scheduledStartMs, row.scheduledEndMs)
            }
        }
        repository.getRecoverable(now).forEach { row ->
            // Safe to call repeatedly: the running service de-duplicates jobs by recording id.
            DvrRecordingService.start(context, row.id)
        }
    }

    private fun pendingIntent(context: Context, recordingId: String, extraFlag: Int): PendingIntent? {
        val intent = Intent(context, DvrAlarmReceiver::class.java).apply {
            action = DvrAlarmReceiver.ACTION_START_RECORDING
            putExtra(DvrAlarmReceiver.EXTRA_RECORDING_ID, recordingId)
        }
        val immutable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        val flags = extraFlag or immutable
        return PendingIntent.getBroadcast(context, requestCode(recordingId), intent, flags)
    }

    private fun requestCode(id: String): Int = id.hashCode() and 0x7fffffff
}
