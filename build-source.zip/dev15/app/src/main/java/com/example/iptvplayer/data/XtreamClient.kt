package com.brotv.player.data

import com.brotv.player.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLDecoder

/**
 * عميل بسيط للتعامل مع Xtream Codes API (المستخدم من مزوّدي IPTV كثيرين).
 * يعتمد على player_api.php لجلب فئات وقنوات البث الحي.
 */
class XtreamClient(
    private val server: String,   // مثال: http://example.com:8080
    private val username: String,
    private val password: String
) {

    private fun cleanServer(): String = XtreamUrlCodec.cleanServer(server)

    private fun apiUrl(action: String, extraQuery: String = ""): String {
        val suffix = if (extraQuery.isBlank()) "" else "&$extraQuery"
        return XtreamUrlCodec.playerApiUrl(server, username, password, action) + suffix
    }

    private fun liveStreamUrl(streamId: String, extension: String = "m3u8"): String =
        "${cleanServer()}/live/${encodePathSegment(username)}/${encodePathSegment(password)}/${encodePathSegment(streamId)}.${sanitizeExtension(extension)}"

    private fun movieStreamUrl(streamId: String, extension: String): String =
        "${cleanServer()}/movie/${encodePathSegment(username)}/${encodePathSegment(password)}/${encodePathSegment(streamId)}.${sanitizeExtension(extension)}"

    private fun seriesStreamUrl(streamId: String, extension: String): String =
        "${cleanServer()}/series/${encodePathSegment(username)}/${encodePathSegment(password)}/${encodePathSegment(streamId)}.${sanitizeExtension(extension)}"

    suspend fun getLiveChannels(): List<Channel> = withContext(Dispatchers.IO) {
        val categories = fetchCategories()
        val streamsJson = fetchJsonArray(
            apiUrl("get_live_streams")
        )

        val channels = mutableListOf<Channel>()
        for (i in 0 until streamsJson.length()) {
            val obj = streamsJson.getJSONObject(i)
            val streamId = obj.optInt("stream_id", -1)
            if (streamId == -1) continue

            val name = obj.optString("name", "قناة $streamId")
            val icon = obj.optString("stream_icon", "").takeIf { it.isNotBlank() }
            val categoryId = obj.optString("category_id", "")
            val groupTitle = categories[categoryId] ?: "عام"

            // صيغة رابط البث المعتادة في Xtream Codes
            val streamUrl = liveStreamUrl(streamId.toString())
            val hasArchive = obj.optInt("tv_archive", 0) == 1
            val archiveDays = obj.optInt("tv_archive_duration", 0)
            val epgId = obj.optString("epg_channel_id", "").trim().takeIf { it.isNotEmpty() }

            channels.add(
                Channel(
                    id = "xtream_$streamId",
                    name = name,
                    streamUrl = streamUrl,
                    logoUrl = icon,
                    groupTitle = groupTitle,
                    epgId = epgId,
                    hasArchive = hasArchive,
                    archiveDurationDays = archiveDays
                )
            )
        }
        channels
    }

    // ---------- دليل البرامج (EPG) ----------

    /** يجيب البرنامج الحالي لقناة معيّنة (لو المصدر يوفر EPG). */
    suspend fun getCurrentProgram(streamId: String): com.brotv.player.model.EpgProgram? =
        withContext(Dispatchers.IO) {
            try {
                val json = fetchJsonObject(
                    apiUrl("get_short_epg", "stream_id=${encodeQuery(streamId)}&limit=2")
                )
                val listings = json.optJSONArray("epg_listings") ?: return@withContext null
                if (listings.length() == 0) return@withContext null

                val nowSeconds = System.currentTimeMillis() / 1000
                for (i in 0 until listings.length()) {
                    val item = listings.getJSONObject(i)
                    val start = item.optLong("start_timestamp", 0)
                    val end = item.optLong("stop_timestamp", 0)
                    if (nowSeconds in start..end) {
                        val title = decodeBase64(item.optString("title", ""))
                        val progress = if (end > start) (((nowSeconds - start) * 100) / (end - start)).toInt() else 0
                        return@withContext com.brotv.player.model.EpgProgram(
                            title = title,
                            startTime = formatEpgTime(start),
                            endTime = formatEpgTime(end),
                            progressPercent = progress.coerceIn(0, 100),
                            startTimeMs = start * 1000L,
                            endTimeMs = end * 1000L,
                            description = decodeBase64(item.optString("description", ""))
                        )
                    }
                }
                null
            } catch (e: Exception) {
                null
            }
        }

    /** Current/future short EPG entries used by scheduled DVR. */
    suspend fun getUpcomingPrograms(streamId: String, limit: Int = 30): List<com.brotv.player.model.EpgProgram> =
        withContext(Dispatchers.IO) {
            try {
                val safeLimit = limit.coerceIn(2, 100)
                val json = fetchJsonObject(
                    apiUrl("get_short_epg", "stream_id=${encodeQuery(streamId)}&limit=$safeLimit")
                )
                val listings = json.optJSONArray("epg_listings") ?: return@withContext emptyList()
                val nowMs = System.currentTimeMillis()
                val result = mutableListOf<com.brotv.player.model.EpgProgram>()
                for (i in 0 until listings.length()) {
                    val item = listings.getJSONObject(i)
                    val start = item.optLong("start_timestamp", 0L)
                    val end = item.optLong("stop_timestamp", 0L)
                    if (start <= 0L || end <= start || end * 1000L <= nowMs) continue
                    val duration = (end - start).coerceAtLeast(1L)
                    val progress = if (nowMs / 1000L in start until end) {
                        (((nowMs / 1000L - start) * 100L) / duration).toInt().coerceIn(0, 100)
                    } else 0
                    result += com.brotv.player.model.EpgProgram(
                        title = decodeBase64(item.optString("title", "")),
                        startTime = formatEpgTime(start),
                        endTime = formatEpgTime(end),
                        progressPercent = progress,
                        startTimeMs = start * 1000L,
                        endTimeMs = end * 1000L,
                        description = decodeBase64(item.optString("description", ""))
                    )
                }
                result.sortedBy { it.startTimeMs }
            } catch (_: Exception) {
                emptyList()
            }
        }

    private fun decodeBase64(value: String): String {
        return try {
            String(android.util.Base64.decode(value, android.util.Base64.DEFAULT), Charsets.UTF_8)
        } catch (e: Exception) {
            value
        }
    }

    private fun formatEpgTime(unixSeconds: Long): String {
        val sdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(unixSeconds * 1000))
    }

    /** يحاول يستخرج stream_id من رابط بث بصيغة Xtream (…/live/user/pass/ID.ext). */
    fun extractStreamId(streamUrl: String): String? = parseLiveStreamUrl(streamUrl)?.streamId

    companion object {
        private val SAFE_EXTENSION = Regex("^[A-Za-z0-9]{1,10}$")

        internal data class ParsedLiveUrl(
            val server: String,
            val username: String,
            val password: String,
            val streamId: String
        )

        internal fun encodeQuery(value: String): String = XtreamUrlCodec.encodeQuery(value)

        internal fun encodePathSegment(value: String): String = XtreamUrlCodec.encodePathSegment(value)

        internal fun sanitizeExtension(value: String): String =
            value.trim().removePrefix(".").takeIf { SAFE_EXTENSION.matches(it) } ?: "mp4"

        internal fun parseLiveStreamUrl(streamUrl: String): ParsedLiveUrl? {
            return try {
                val uri = URI(streamUrl.trim())
                if (uri.scheme != "http" && uri.scheme != "https") return null
                val authority = uri.rawAuthority ?: return null
                val segments = uri.rawPath.orEmpty().split('/').filter { it.isNotEmpty() }
                val liveIndex = segments.indexOf("live")
                if (liveIndex < 0 || segments.size <= liveIndex + 3) return null
                val streamFile = segments[liveIndex + 3]
                val streamId = streamFile.substringBefore('.').takeIf { it.isNotEmpty() && it.all(Char::isDigit) } ?: return null
                ParsedLiveUrl(
                    server = "${uri.scheme}://$authority",
                    username = URLDecoder.decode(segments[liveIndex + 1], Charsets.UTF_8.name()),
                    password = URLDecoder.decode(segments[liveIndex + 2], Charsets.UTF_8.name()),
                    streamId = streamId
                )
            } catch (_: Exception) {
                null
            }
        }

        /**
         * يبني XtreamClient مباشرة من رابط بث (…/live/user/pass/id.ext) بدون الحاجة لمعرفة
         * أي حساب محفوظ بالضبط جاء منه — مفيد لما يكون عندنا أكثر من حساب Xtream محفوظ.
         */
        fun fromLiveStreamUrl(streamUrl: String): XtreamClient? {
            val parsed = parseLiveStreamUrl(streamUrl) ?: return null
            return XtreamClient(parsed.server, parsed.username, parsed.password)
        }
    }

    /**
     * يجيب قائمة أوسع من برامج EPG (ماضية وحالية) لقناة معيّنة، تُستخدم لعرض قائمة
     * "إعادة البث". يعتمد على get_simple_data_table اللي يرجّع مدى زمني أوسع من get_short_epg.
     */
    suspend fun getEpgHistory(streamId: String): List<com.brotv.player.model.CatchupProgram> =
        withContext(Dispatchers.IO) {
            try {
                val json = fetchJsonObject(
                    apiUrl("get_simple_data_table", "stream_id=${encodeQuery(streamId)}")
                )
                val listings = json.optJSONArray("epg_listings") ?: return@withContext emptyList()
                val nowSeconds = System.currentTimeMillis() / 1000
                val result = mutableListOf<com.brotv.player.model.CatchupProgram>()

                for (i in 0 until listings.length()) {
                    val item = listings.getJSONObject(i)
                    val start = item.optLong("start_timestamp", 0)
                    val end = item.optLong("stop_timestamp", 0)
                    if (start == 0L || end == 0L || end > nowSeconds) continue // نعرض بس البرامج اللي خلصت فعلاً

                    result.add(
                        com.brotv.player.model.CatchupProgram(
                            title = decodeBase64(item.optString("title", "")),
                            startUnix = start,
                            endUnix = end,
                            startLabel = formatEpgTime(start),
                            endLabel = formatEpgTime(end)
                        )
                    )
                }
                result.sortedByDescending { it.startUnix }
            } catch (e: Exception) {
                emptyList()
            }
        }

    /**
     * يبني رابط تشغيل الأرشيف (Timeshift) بصيغة Xtream القياسية، يشتغل بس لو القناة
     * تدعم tv_archive والبرنامج لسا داخل مدة الاحتفاظ بالأرشيف.
     */
    fun buildCatchupUrl(streamId: String, startUnix: Long, durationMinutes: Int): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd:HH-mm", java.util.Locale.US)
        sdf.timeZone = java.util.TimeZone.getDefault()
        val startLabel = sdf.format(java.util.Date(startUnix * 1000))
        return "${cleanServer()}/streaming/timeshift.php?username=${encodeQuery(username)}&password=${encodeQuery(password)}&stream=${encodeQuery(streamId)}&start=${encodeQuery(startLabel)}&duration=${durationMinutes.coerceAtLeast(1)}"
    }

    private fun fetchCategories(): Map<String, String> {
        return try {
            val json = fetchJsonArray(
                apiUrl("get_live_categories")
            )
            val map = mutableMapOf<String, String>()
            for (i in 0 until json.length()) {
                val obj = json.getJSONObject(i)
                map[obj.optString("category_id")] = obj.optString("category_name", "عام")
            }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    // ---------- الأفلام (VOD) ----------

    private data class OrderedProviderCategory(val name: String, val order: Int)

    private fun fetchOrderedCategories(action: String): Map<String, OrderedProviderCategory> {
        return try {
            val json = fetchJsonArray(apiUrl(action))
            val out = linkedMapOf<String, OrderedProviderCategory>()
            for (i in 0 until json.length()) {
                val obj = json.getJSONObject(i)
                val id = obj.optString("category_id", "").trim()
                if (id.isBlank()) continue
                out[id] = OrderedProviderCategory(
                    name = obj.optString("category_name", "").ifBlank { "غير مصنف" },
                    order = i
                )
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }

    suspend fun getMovies(sourceTag: String): List<com.brotv.player.model.Movie> = withContext(Dispatchers.IO) {
        val categories = fetchOrderedCategories("get_vod_categories")
        val streamsJson = fetchJsonArray(
            apiUrl("get_vod_streams")
        )
        val movies = mutableListOf<com.brotv.player.model.Movie>()
        for (i in 0 until streamsJson.length()) {
            val obj = streamsJson.getJSONObject(i)
            val vodId = obj.optInt("stream_id", -1)
            if (vodId == -1) continue
            val ext = obj.optString("container_extension", "mp4")
            val streamUrl = movieStreamUrl(vodId.toString(), ext)

            val categoryId = obj.optString("category_id", "").trim()
            val providerCategory = categories[categoryId]
            val providerCategoryName = providerCategory?.name
                ?: obj.optString("category_name", "").ifBlank { obj.optString("genre", "") }
                .ifBlank { "غير مصنف" }
            movies.add(
                com.brotv.player.model.Movie(
                    id = "movie::$sourceTag::$vodId",
                    name = obj.optString("name", "فيلم $vodId"),
                    streamUrl = streamUrl,
                    posterUrl = obj.optString("stream_icon", "").takeIf { it.isNotBlank() },
                    year = obj.optString("release_date", "").take(4).ifBlank { "" },
                    rating = obj.optString("rating", ""),
                    genre = obj.optString("genre", ""),
                    plot = "",
                    providerCategoryKey = "$sourceTag::$categoryId",
                    providerCategoryName = providerCategoryName,
                    providerCategoryOrder = providerCategory?.order ?: Int.MAX_VALUE
                )
            )
        }
        movies
    }

    /** يجيب تفاصيل إضافية (وصف، مدة) لفيلم معيّن، يُستخدم بشاشة التفاصيل. vodId رقمي مباشر (بدون بادئة المصدر). */
    suspend fun getMovieDetails(vodId: String): String = withContext(Dispatchers.IO) {
        try {
            val obj = fetchJsonObject(
                apiUrl("get_vod_info", "vod_id=${encodeQuery(vodId)}")
            )
            obj.optJSONObject("info")?.optString("plot", "") ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    // ---------- المسلسلات ----------

    suspend fun getSeriesList(sourceTag: String): List<com.brotv.player.model.Series> = withContext(Dispatchers.IO) {
        val categories = fetchOrderedCategories("get_series_categories")
        val json = fetchJsonArray(
            apiUrl("get_series")
        )
        val list = mutableListOf<com.brotv.player.model.Series>()
        for (i in 0 until json.length()) {
            val obj = json.getJSONObject(i)
            val seriesId = obj.optInt("series_id", -1)
            if (seriesId == -1) continue

            val categoryId = obj.optString("category_id", "").trim()
            val providerCategory = categories[categoryId]
            val providerCategoryName = providerCategory?.name
                ?: obj.optString("category_name", "").ifBlank { obj.optString("genre", "") }
                .ifBlank { "غير مصنف" }
            list.add(
                com.brotv.player.model.Series(
                    id = "series::$sourceTag::$seriesId",
                    name = obj.optString("name", "مسلسل $seriesId"),
                    posterUrl = obj.optString("cover", "").takeIf { it.isNotBlank() },
                    year = obj.optString("releaseDate", "").take(4).ifBlank { "" },
                    rating = obj.optString("rating", ""),
                    genre = obj.optString("genre", ""),
                    plot = obj.optString("plot", ""),
                    seasonCount = 0, // يُحدَّث لاحقاً عند فتح التفاصيل (get_series_info)
                    providerCategoryKey = "$sourceTag::$categoryId",
                    providerCategoryName = providerCategoryName,
                    providerCategoryOrder = providerCategory?.order ?: Int.MAX_VALUE
                )
            )
        }
        list
    }

    /** يجيب كل حلقات المسلسل مقسّمة حسب الموسم. seriesId هنا بالصيغة series::sourceTag::numericId. */
    suspend fun getSeriesEpisodes(seriesId: String): Map<Int, List<com.brotv.player.model.Episode>> =
        withContext(Dispatchers.IO) {
            val numericId = seriesId.substringAfterLast("::")
            val obj = fetchJsonObject(
                apiUrl("get_series_info", "series_id=${encodeQuery(numericId)}")
            )
            val seriesName = obj.optJSONObject("info")?.optString("name", "") ?: ""
            val episodesJson = obj.optJSONObject("episodes") ?: return@withContext emptyMap()

            val result = mutableMapOf<Int, List<com.brotv.player.model.Episode>>()
            episodesJson.keys().forEach { seasonKey ->
                val seasonNumber = seasonKey.toIntOrNull() ?: 0
                val episodesArray = episodesJson.optJSONArray(seasonKey) ?: return@forEach
                val episodeList = mutableListOf<com.brotv.player.model.Episode>()

                for (i in 0 until episodesArray.length()) {
                    val epObj = episodesArray.getJSONObject(i)
                    val epId = epObj.optString("id", "")
                    val ext = epObj.optString("container_extension", "mp4")
                    val info = epObj.optJSONObject("info")
                    val durationSeconds = info?.optInt("duration_secs", 0) ?: 0

                    episodeList.add(
                        com.brotv.player.model.Episode(
                            id = "ep::$seriesId::$epId",
                            seriesId = seriesId,
                            seriesName = seriesName,
                            seasonNumber = seasonNumber,
                            episodeNumber = epObj.optInt("episode_num", i + 1),
                            title = epObj.optString("title", "الحلقة ${i + 1}"),
                            plot = info?.optString("plot", "") ?: "",
                            durationLabel = formatDuration(durationSeconds),
                            streamUrl = seriesStreamUrl(epId, ext),
                            imageUrl = info?.optString("movie_image", "")
                                ?.takeIf { it.isNotBlank() }
                                ?: info?.optString("cover_big", "")?.takeIf { it.isNotBlank() }
                                ?: info?.optString("cover", "")?.takeIf { it.isNotBlank() }
                        )
                    )
                }
                result[seasonNumber] = episodeList
            }
            result
        }

    private fun formatDuration(totalSeconds: Int): String {
        if (totalSeconds <= 0) return ""
        // Store a language-neutral minute count. UI code localizes it using resources.
        return (totalSeconds / 60).toString()
    }

    private fun fetchJsonObject(urlString: String): JSONObject = JSONObject(fetchText(urlString))

    private fun fetchJsonArray(urlString: String): JSONArray = JSONArray(fetchText(urlString))

    private fun fetchText(urlString: String): String {
        var connection: HttpURLConnection? = null
        try {
            connection = URL(urlString).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.connectTimeout = 15_000
            connection.readTimeout = 15_000
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/json, text/plain;q=0.9, */*;q=0.8")
            connection.setRequestProperty("User-Agent", "BRO-TV/1.2")

            val status = connection.responseCode
            if (status !in 200..299) {
                val message = connection.errorStream
                    ?.bufferedReader(Charsets.UTF_8)
                    ?.use { it.readText().take(256) }
                    .orEmpty()
                throw IOException("Xtream request failed with HTTP $status${if (message.isBlank()) "" else ": $message"}")
            }

            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            connection?.disconnect()
        }
    }
}
