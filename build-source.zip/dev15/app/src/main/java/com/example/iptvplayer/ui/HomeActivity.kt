package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.brotv.player.R
import com.brotv.player.data.SourcesManager
import com.brotv.player.data.XtreamAccountInfoRepository
import com.brotv.player.model.HomeCard
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * BRO TV home screen. The layout mirrors the approved cinematic black/gold
 * concept: logo + subscription/clock header, one hero, then the content cards.
 */
class HomeActivity : AppCompatActivity() {

    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockTicker = object : Runnable {
        override fun run() {
            updateClock()
            clockHandler.postDelayed(this, CLOCK_TICK_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        setupHeader()
        buildHomeCards()
        loadSubscriptionInfo()
    }

    override fun onResume() {
        super.onResume()
        clockHandler.post(clockTicker)
        loadSubscriptionInfo()
    }

    override fun onPause() {
        super.onPause()
        clockHandler.removeCallbacks(clockTicker)
    }

    private fun setupHeader() {
        findViewById<ImageView>(R.id.btnSearch).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java).apply {
                putExtra(SearchActivity.EXTRA_SCOPE, SearchActivity.Scope.ALL.name)
            })
        }
        findViewById<LinearLayout>(R.id.btnSettings).setOnClickListener { open(SettingsActivity::class.java) }
        findViewById<TextView>(R.id.btnHeroWatchNow).setOnClickListener { open(SeriesActivity::class.java) }
        findViewById<TextView>(R.id.navFavorites).setOnClickListener { open(FavoritesActivity::class.java) }
        findViewById<TextView>(R.id.navChannels).setOnClickListener { open(SeriesActivity::class.java) }
        findViewById<TextView>(R.id.navMovies).setOnClickListener { open(MoviesActivity::class.java) }
        findViewById<TextView>(R.id.navSeries).setOnClickListener { open(ChannelBrowseActivity::class.java) }
        findViewById<TextView>(R.id.navHome).setOnClickListener { findViewById<TextView>(R.id.btnHeroWatchNow).requestFocus() }
    }

    private fun updateClock() {
        val now = Date()
        findViewById<TextView>(R.id.txtClock).text = clockFormat.format(now)
        findViewById<TextView>(R.id.txtDate).text = dateFormat.format(now)
    }

    private fun loadSubscriptionInfo() {
        val pill = findViewById<LinearLayout>(R.id.subscriptionPill)
        val value = findViewById<TextView>(R.id.txtSubscriptionValue)
        lifecycleScope.launch {
            val source = SourcesManager(this@HomeActivity).getXtreamSources().firstOrNull { it.enabled }
            if (source == null) {
                pill.visibility = LinearLayout.GONE
                return@launch
            }
            val info = XtreamAccountInfoRepository.load(source)
            if (info == null) {
                pill.visibility = LinearLayout.GONE
                return@launch
            }
            pill.visibility = LinearLayout.VISIBLE
            value.text = when {
                info.isExpired -> getString(R.string.home_subscription_expired)
                info.expiresAtMs != null -> {
                    val daysLeft = ((info.expiresAtMs - System.currentTimeMillis()) / MS_PER_DAY).toInt().coerceAtLeast(0)
                    getString(R.string.home_subscription_days_dynamic, daysLeft)
                }
                else -> getString(R.string.home_subscription_active)
            }
        }
    }

    private fun open(target: Class<out AppCompatActivity>) {
        startActivity(Intent(this, target))
    }

    private fun buildHomeCards() {
        val cards = listOf(
            HomeCard(getString(R.string.home_live), R.drawable.reference_card_live) { open(ChannelBrowseActivity::class.java) },
            HomeCard(getString(R.string.home_movies), R.drawable.reference_card_movies) { open(MoviesActivity::class.java) },
            HomeCard(getString(R.string.home_series), R.drawable.reference_card_series) { open(SeriesActivity::class.java) },
            HomeCard(getString(R.string.home_favorites), R.drawable.reference_card_favorites) { open(FavoritesActivity::class.java) }
        )
        val row = findViewById<LinearLayout>(R.id.cardsRow)
        val inflater = LayoutInflater.from(this)
        cards.forEachIndexed { index, card ->
            val cardView = inflater.inflate(R.layout.item_home_card, row, false)
            cardView.findViewById<ImageView>(R.id.imgCardBackground).setImageResource(card.backgroundRes)
            cardView.findViewById<TextView>(R.id.txtCardTitle).text = card.title
            cardView.setOnClickListener { card.action() }
            cardView.clipToOutline = true
            cardView.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            cardView.setOnFocusChangeListener { view, focused ->
                val scale = if (focused) 1.025f else 1f
                view.scaleX = scale
                view.scaleY = scale
                view.translationZ = if (focused) 8f else 0f
            }
            row.addView(cardView)
            if (index == 0) {
                cardView.isFocusableInTouchMode = true
                cardView.post { cardView.requestFocus() }
            }
        }
    }

    companion object {
        private const val CLOCK_TICK_MS = 30_000L
        private const val MS_PER_DAY = 86_400_000L
        private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        private val dateFormat = SimpleDateFormat("EEE d MMM", Locale.getDefault())
    }
}
