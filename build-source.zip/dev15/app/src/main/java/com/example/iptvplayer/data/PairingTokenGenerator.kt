package com.brotv.player.data

import java.security.SecureRandom

/** Cryptographically strong, QR-friendly short-lived pairing tokens. */
object PairingTokenGenerator {
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    const val LENGTH = 12
    private val secureRandom = SecureRandom()

    fun generate(): String = buildString(LENGTH) {
        repeat(LENGTH) {
            append(ALPHABET[secureRandom.nextInt(ALPHABET.length)])
        }
    }

    internal fun isValidFormat(token: String): Boolean =
        token.length == LENGTH && token.all { it in ALPHABET }
}
