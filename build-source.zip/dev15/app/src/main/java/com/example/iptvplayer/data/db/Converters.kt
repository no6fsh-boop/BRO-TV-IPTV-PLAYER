package com.brotv.player.data.db

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromProviderType(value: ProviderType): String = value.name

    @TypeConverter
    fun toProviderType(value: String): ProviderType =
        try { ProviderType.valueOf(value) } catch (e: Exception) { ProviderType.M3U }

    @TypeConverter
    fun fromProviderStatus(value: ProviderStatus): String = value.name

    @TypeConverter
    fun toProviderStatus(value: String): ProviderStatus =
        try { ProviderStatus.valueOf(value) } catch (e: Exception) { ProviderStatus.UNKNOWN }
}
