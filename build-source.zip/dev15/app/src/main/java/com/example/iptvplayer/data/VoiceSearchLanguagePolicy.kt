package com.brotv.player.data

/** Keeps external speech recognition aligned with BRO TV's selected UI language. */
object VoiceSearchLanguagePolicy {
    fun languageTag(appLanguage: String): String =
        if (appLanguage.equals("en", ignoreCase = true)) "en-US" else "ar-SA"
}
