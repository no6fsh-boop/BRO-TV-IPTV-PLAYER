package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.LocalPairingServer
import com.brotv.player.data.LocaleManager
import com.brotv.player.data.MovieRepository
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.NetworkUtils
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.QrCodeGenerator
import com.brotv.player.data.SearchMatcher
import com.brotv.player.data.SeriesRepository
import com.brotv.player.data.VoiceSearchLanguagePolicy
import com.brotv.player.model.Movie
import com.brotv.player.model.MergedChannel
import com.brotv.player.model.SearchResultItem
import com.brotv.player.model.SearchResultType
import com.brotv.player.model.Series
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.core.content.ContextCompat

/**
 * بحث موحّد وسريع للقنوات الحية والأفلام والمسلسلات.
 * البحث يعمل على فهرس مطبّع في الخلفية حتى لا يعلّق ريموت/كيبورد Android TV.
 */
class SearchActivity : AppCompatActivity() {

    enum class Scope { ALL, LIVE, MOVIES, SERIES }

    private data class ChannelEntry(
        val channel: MergedChannel,
        val displayNumber: Int,
        val haystack: String,
        val codes: Set<String>
    )

    private data class MovieEntry(val movie: Movie, val haystack: String)
    private data class SeriesEntry(val series: Series, val haystack: String)

    private var scope = Scope.ALL
    private var channels: List<MergedChannel> = emptyList()
    private var movies: List<Movie> = emptyList()
    private var seriesList: List<Series> = emptyList()
    private var channelIndex: List<ChannelEntry> = emptyList()
    private var movieIndex: List<MovieEntry> = emptyList()
    private var seriesIndex: List<SeriesEntry> = emptyList()
    private var dataReady = false

    private lateinit var editSearch: EditText
    private lateinit var recyclerResults: RecyclerView
    private lateinit var resultsAdapter: SearchResultAdapter
    private var searchJob: Job? = null
    private var searchGeneration = 0

    private var pairingServer: LocalPairingServer? = null
    private var currentToken = NetworkUtils.generateToken()
    private val tokenHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val tokenRotationRunnable = object : Runnable {
        override fun run() {
            currentToken = NetworkUtils.generateToken()
            pairingServer?.updateToken(currentToken)
            refreshQrCode()
            tokenHandler.postDelayed(this, TOKEN_ROTATION_MS)
        }
    }

    private val voiceSearchLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val spokenText = result.data
            ?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spokenText.isNotBlank()) applyExternalQuery(spokenText, focusResults = true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        setContentView(R.layout.activity_search)

        scope = runCatching {
            Scope.valueOf(intent.getStringExtra(EXTRA_SCOPE) ?: Scope.ALL.name)
        }.getOrDefault(Scope.ALL)

        editSearch = findViewById(R.id.editSearch)
        recyclerResults = findViewById(R.id.recyclerResults)
        recyclerResults.apply {
            layoutManager = LinearLayoutManager(this@SearchActivity)
            setHasFixedSize(true)
            itemAnimator = null
        }
        resultsAdapter = SearchResultAdapter(
            onClick = ::onResultClick,
            onFirstItemUp = { focusSelectedScopeButton() }
        )
        recyclerResults.adapter = resultsAdapter

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.btnMic).setOnClickListener { startVoiceSearch() }
        findViewById<ImageView>(R.id.btnQrSearch).setOnClickListener { toggleQrPanel() }

        setupScopeButtons()
        setupSearchInput()
        buildTvKeyboard()
        updateScopeUi()
        loadAllSearchData()

        editSearch.requestFocus()
        editSearch.post { suppressSystemKeyboard() }
    }

    private fun buildTvKeyboard() {
        editSearch.showSoftInputOnFocus = false
        val container = findViewById<LinearLayout>(R.id.keyboardRows)
        container.removeAllViews()
        val rows = if (LocaleManager.isEnglish()) {
            listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM", "1234567890")
        } else {
            listOf("ضصثقفغعهخحج", "شسيبلاتنمك", "ظطذدزرؤءئى", "١٢٣٤٥٦٧٨٩٠")
        }
        rows.forEach { chars ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            chars.forEach { ch -> row.addView(makeKeyboardKey(ch.toString())) }
            container.addView(row)
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        actions.addView(makeKeyboardKey("⌫", 1f) { deleteLastSearchChar() })
        actions.addView(makeKeyboardKey(getString(R.string.keyboard_space), 3f) { appendSearchText(" ") })
        actions.addView(makeKeyboardKey("123", 1f) { appendSearchText("123") })
        container.addView(actions)
    }

    private fun makeKeyboardKey(label: String, weight: Float = 1f, action: (() -> Unit)? = null): TextView =
        TextView(this).apply {
            text = label
            gravity = android.view.Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@SearchActivity, R.color.brand_white))
            textSize = 14f
            isFocusable = true
            isClickable = true
            setBackgroundResource(R.drawable.keyboard_key_selector)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(3.dp, 3.dp, 3.dp, 3.dp)
            }
            setOnClickListener { action?.invoke() ?: appendSearchText(label) }
        }

    private fun appendSearchText(value: String) {
        editSearch.append(value)
        scheduleSearch(editSearch.text.toString(), immediate = false, focusResults = false)
    }

    private fun deleteLastSearchChar() {
        val text = editSearch.text
        if (text.isNotEmpty()) text.delete(text.length - 1, text.length)
    }

    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()

    private fun setupSearchInput() {
        editSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                scheduleSearch(s?.toString().orEmpty(), immediate = false, focusResults = false)
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        editSearch.setOnEditorActionListener { _, actionId, event ->
            val submit = actionId == EditorInfo.IME_ACTION_SEARCH ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            if (submit) {
                scheduleSearch(editSearch.text.toString(), immediate = true, focusResults = true)
                true
            } else false
        }

        editSearch.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN && resultsAdapter.itemCount > 0) {
                focusFirstResult()
                true
            } else false
        }
    }

    private fun setupScopeButtons() {
        val mapping = mapOf(
            R.id.btnScopeAll to Scope.ALL,
            R.id.btnScopeLive to Scope.LIVE,
            R.id.btnScopeMovies to Scope.MOVIES,
            R.id.btnScopeSeries to Scope.SERIES
        )
        mapping.forEach { (id, value) ->
            findViewById<TextView>(id).apply {
                setOnClickListener {
                    scope = value
                    updateScopeUi()
                    scheduleSearch(editSearch.text.toString(), immediate = true, focusResults = false)
                }
                setOnKeyListener { _, keyCode, event ->
                    if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN && resultsAdapter.itemCount > 0) {
                        focusFirstResult()
                        true
                    } else false
                }
            }
        }
    }

    private fun updateScopeUi() {
        editSearch.hint = hintForScope()
        mapOf(
            R.id.btnScopeAll to Scope.ALL,
            R.id.btnScopeLive to Scope.LIVE,
            R.id.btnScopeMovies to Scope.MOVIES,
            R.id.btnScopeSeries to Scope.SERIES
        ).forEach { (id, value) -> findViewById<TextView>(id).isSelected = scope == value }
    }

    private fun focusSelectedScopeButton() {
        val id = when (scope) {
            Scope.ALL -> R.id.btnScopeAll
            Scope.LIVE -> R.id.btnScopeLive
            Scope.MOVIES -> R.id.btnScopeMovies
            Scope.SERIES -> R.id.btnScopeSeries
        }
        findViewById<View>(id).requestFocus()
    }

    private fun hintForScope(): String = getString(when (scope) {
        Scope.ALL -> R.string.search_hint_all
        Scope.LIVE -> R.string.search_hint_live
        Scope.MOVIES -> R.string.search_hint_movies
        Scope.SERIES -> R.string.search_hint_series
    })

    /** نحمّل كل الأنواع مرة واحدة حتى يقدر المستخدم يغيّر نطاق البحث بالريموت فوراً. */
    private fun loadAllSearchData() {
        lifecycleScope.launch {
            val prefs = PrefsManager(this@SearchActivity)
            val loaded = coroutineScope {
                val channelsDeferred = async {
                    MergedChannelRepository(this@SearchActivity).loadMergedChannels()
                        .filter { it.id !in prefs.hiddenChannelIds && it.groupTitle !in prefs.hiddenLiveCategories }
                }
                val moviesDeferred = async {
                    MovieRepository(this@SearchActivity).getMovies()
                        .filter { it.providerCategoryName !in prefs.hiddenVodCategories && it.genre !in prefs.hiddenVodCategories }
                }
                val seriesDeferred = async {
                    SeriesRepository(this@SearchActivity).getSeriesList()
                        .filter { it.providerCategoryName !in prefs.hiddenSeriesCategories && it.genre !in prefs.hiddenSeriesCategories }
                }
                Triple(channelsDeferred.await(), moviesDeferred.await(), seriesDeferred.await())
            }

            channels = loaded.first
            movies = loaded.second
            seriesList = loaded.third

            withContext(Dispatchers.Default) {
                channelIndex = channels.mapIndexed { index, channel ->
                    ChannelEntry(
                        channel = channel,
                        displayNumber = index + 1,
                        haystack = SearchMatcher.normalize("${channel.name} ${channel.groupTitle}"),
                        codes = SearchMatcher.channelCodes(index + 1, channel.sourceUrls)
                    )
                }
                movieIndex = movies.map { movie ->
                    MovieEntry(
                        movie,
                        SearchMatcher.normalize("${movie.name} ${movie.genre} ${movie.providerCategoryName} ${movie.year}")
                    )
                }
                seriesIndex = seriesList.map { series ->
                    SeriesEntry(
                        series,
                        SearchMatcher.normalize("${series.name} ${series.genre} ${series.providerCategoryName} ${series.year}")
                    )
                }
            }
            dataReady = true

            // إذا المستخدم كتب أو تكلم قبل اكتمال البيانات، نفّذ نفس البحث الآن تلقائياً.
            val currentQuery = editSearch.text.toString()
            if (currentQuery.isNotBlank()) scheduleSearch(currentQuery, immediate = true, focusResults = false)
        }
    }

    private fun scheduleSearch(query: String, immediate: Boolean, focusResults: Boolean) {
        searchJob?.cancel()
        val generation = ++searchGeneration
        val trimmed = query.trim()

        if (trimmed.isBlank()) {
            showResults(emptyList(), hasQuery = false, focusResults = false)
            return
        }
        if (!dataReady) {
            showLoadingState()
            return
        }

        // لا نترك نتائج الاستعلام السابق (خصوصاً شريط الأفلام) ظاهرة أثناء كتابة استعلام جديد.
        if (!immediate) {
            findViewById<TextView>(R.id.txtEmpty).visibility = View.GONE
            recyclerResults.visibility = View.GONE
            resultsAdapter.submitList(emptyList())
        }

        searchJob = lifecycleScope.launch {
            if (!immediate) delay(SEARCH_DEBOUNCE_MS)
            val results = withContext(Dispatchers.Default) { buildResults(trimmed) }
            if (generation == searchGeneration) {
                showResults(results, hasQuery = true, focusResults = focusResults)
            }
        }
    }

    private fun buildResults(query: String): List<SearchResultItem> {
        val normalized = SearchMatcher.normalize(query)
        if (normalized.isBlank()) return emptyList()
        val results = ArrayList<SearchResultItem>(MAX_RESULTS_PER_TYPE * 2)

        if (scope == Scope.ALL || scope == Scope.LIVE) {
            // الكود/رقم القناة له أولوية حتى الوصول للبث يكون مباشر وواضح.
            val exactCodeMatches = channelIndex.asSequence()
                .filter { SearchMatcher.matchesChannelCode(normalized, it.codes) }
                .take(MAX_RESULTS_PER_TYPE)
                .toList()
            val textMatches = channelIndex.asSequence()
                .filter { it.haystack.contains(normalized) }
                .filterNot { candidate -> exactCodeMatches.any { it.channel.id == candidate.channel.id } }
                .take((MAX_RESULTS_PER_TYPE - exactCodeMatches.size).coerceAtLeast(0))
                .toList()

            (exactCodeMatches + textMatches).forEach { entry ->
                val matchedCode = normalized.takeIf { SearchMatcher.matchesChannelCode(normalized, entry.codes) }
                val subtitle = buildString {
                    append("#").append(entry.displayNumber)
                    if (matchedCode != null && matchedCode != entry.displayNumber.toString()) {
                        append("  •  ").append(getString(R.string.search_code_label)).append(' ').append(matchedCode)
                    }
                    append("  •  ")
                    append(entry.channel.groupTitle)
                }
                results += SearchResultItem(SearchResultType.CHANNEL, entry.channel.name, subtitle, channel = entry.channel)
            }
        }

        if (scope == Scope.ALL || scope == Scope.MOVIES) {
            movieIndex.asSequence()
                .filter { it.haystack.contains(normalized) }
                .take(MAX_RESULTS_PER_TYPE)
                .forEach { entry ->
                    results += SearchResultItem(
                        SearchResultType.MOVIE,
                        entry.movie.name,
                        entry.movie.year.ifBlank { entry.movie.providerCategoryName },
                        movie = entry.movie
                    )
                }
        }

        if (scope == Scope.ALL || scope == Scope.SERIES) {
            seriesIndex.asSequence()
                .filter { it.haystack.contains(normalized) }
                .take(MAX_RESULTS_PER_TYPE)
                .forEach { entry ->
                    results += SearchResultItem(
                        SearchResultType.SERIES,
                        entry.series.name,
                        entry.series.year.ifBlank { entry.series.providerCategoryName },
                        series = entry.series
                    )
                }
        }

        return results
    }

    private fun showLoadingState() {
        findViewById<TextView>(R.id.txtEmpty).apply {
            text = getString(R.string.search_loading)
            visibility = View.VISIBLE
        }
        recyclerResults.visibility = View.GONE
        resultsAdapter.submitList(emptyList())
    }

    private fun showResults(results: List<SearchResultItem>, hasQuery: Boolean, focusResults: Boolean) {
        val emptyView = findViewById<TextView>(R.id.txtEmpty)
        when {
            !hasQuery -> {
                emptyView.visibility = View.GONE
                recyclerResults.visibility = View.GONE
                resultsAdapter.submitList(emptyList())
            }
            results.isEmpty() -> {
                recyclerResults.visibility = View.GONE
                emptyView.text = getString(R.string.search_no_results)
                emptyView.visibility = View.VISIBLE
                resultsAdapter.submitList(emptyList())
            }
            else -> {
                emptyView.visibility = View.GONE
                recyclerResults.visibility = View.VISIBLE
                resultsAdapter.submitList(results) {
                    if (focusResults) focusFirstResult()
                }
            }
        }
    }

    private fun focusFirstResult() {
        if (resultsAdapter.itemCount == 0) return
        hideKeyboard()
        recyclerResults.visibility = View.VISIBLE
        recyclerResults.scrollToPosition(0)
        recyclerResults.post {
            recyclerResults.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                ?: recyclerResults.requestFocus()
        }
    }

    private fun suppressSystemKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(editSearch.windowToken, 0)
    }

    private fun hideKeyboard() {
        suppressSystemKeyboard()
        editSearch.clearFocus()
    }

    private fun applyExternalQuery(query: String, focusResults: Boolean) {
        val cleaned = query.trim()
        if (cleaned.isBlank()) return
        editSearch.setText(cleaned)
        editSearch.setSelection(editSearch.text.length)
        scheduleSearch(cleaned, immediate = true, focusResults = focusResults)
    }

    private fun onResultClick(item: SearchResultItem) {
        when (item.type) {
            SearchResultType.MOVIE -> item.movie?.let {
                startActivity(Intent(this, VodPlayerActivity::class.java).apply {
                    putExtra(VodPlayerActivity.EXTRA_CONTENT_ID, it.id)
                    putExtra(VodPlayerActivity.EXTRA_TITLE, it.name)
                    putExtra(VodPlayerActivity.EXTRA_SUBTITLE, it.providerCategoryName.ifBlank { it.genre })
                    putExtra(VodPlayerActivity.EXTRA_STREAM_URL, it.streamUrl)
                    putExtra(VodPlayerActivity.EXTRA_POSTER_URL, it.posterUrl)
                    putExtra(VodPlayerActivity.EXTRA_IS_MOVIE, true)
                    putExtra(VodPlayerActivity.EXTRA_PARENTAL_CATEGORY, it.providerCategoryName.ifBlank { it.genre })
                })
            }
            SearchResultType.SERIES -> item.series?.let {
                startActivity(Intent(this, SeriesDetailActivity::class.java).apply {
                    putExtra(SeriesDetailActivity.EXTRA_SERIES, it)
                })
            }
            SearchResultType.CHANNEL -> item.channel?.let {
                startActivity(Intent(this, FullPlayerActivity::class.java).apply {
                    putExtra(FullPlayerActivity.EXTRA_CHANNEL, it)
                    putExtra(FullPlayerActivity.EXTRA_IS_LIVE, true)
                    putExtra(FullPlayerActivity.EXTRA_SURF_SCOPE, it.groupTitle)
                })
            }
        }
    }

    private fun startVoiceSearch() {
        val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, VoiceSearchLanguagePolicy.languageTag(LocaleManager.getCurrentLanguage()))
        }
        runCatching { voiceSearchLauncher.launch(intent) }
            .onFailure { Toast.makeText(this, R.string.voice_search_unavailable, Toast.LENGTH_SHORT).show() }
    }

    private fun toggleQrPanel() {
        val panel = findViewById<View>(R.id.qrPanel)
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
            stopPairingServer()
            editSearch.requestFocus()
        } else {
            panel.visibility = View.VISIBLE
            startSearchPairingServer()
        }
    }

    private fun startSearchPairingServer() {
        stopPairingServer()
        try {
            currentToken = NetworkUtils.generateToken()
            pairingServer = LocalPairingServer(
                port = SEARCH_PAIRING_PORT,
                mode = LocalPairingServer.Mode.SEARCH,
                currentToken = currentToken,
                languageCode = LocaleManager.getCurrentLanguage()
            ) { data ->
                val query = data["query"] ?: return@LocalPairingServer
                val submit = data["submit"].equals("true", ignoreCase = true)
                runOnUiThread {
                    applyExternalQuery(query, focusResults = submit)
                    if (submit) findViewById<View>(R.id.qrPanel).visibility = View.GONE
                }
            }
            pairingServer?.start()
            refreshQrCode()
            tokenHandler.postDelayed(tokenRotationRunnable, TOKEN_ROTATION_MS)
        } catch (_: Exception) {
            Toast.makeText(this, R.string.mobile_typing_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshQrCode() {
        val ip = NetworkUtils.getLocalIpAddress(this) ?: return
        val url = "http://$ip:$SEARCH_PAIRING_PORT/pair?token=$currentToken"
        findViewById<ImageView>(R.id.imgSearchQr).setImageBitmap(QrCodeGenerator.generate(url))
    }

    private fun stopPairingServer() {
        tokenHandler.removeCallbacks(tokenRotationRunnable)
        pairingServer?.stop()
        pairingServer = null
    }

    override fun onDestroy() {
        searchJob?.cancel()
        stopPairingServer()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SCOPE = "extra_scope"
        private const val SEARCH_PAIRING_PORT = 8099
        private const val TOKEN_ROTATION_MS = 5 * 60 * 1000L
        private const val SEARCH_DEBOUNCE_MS = 180L
        private const val MAX_RESULTS_PER_TYPE = 60
    }
}
