package com.brotv.player.player

/**
 * حارس جودة متدرج يحافظ على جودة المستخدم ما دام التشغيل مستقراً، ويخفض سقف الفيديو
 * خطوة واحدة فقط عند وجود دليل فعلي على ضغط Decoder/Network. يعيد الجودة تدريجياً بعد
 * فترة استقرار طويلة لتجنب التذبذب بين الجودات.
 *
 * لا يعتمد على Android حتى يمكن اختباره كوحدة مستقلة.
 */
class SmartQualityGuard(
    private val warmupMs: Long = 12_000L,
    private val changeCooldownMs: Long = 20_000L,
    private val restoreStableMs: Long = 60_000L
) {
    enum class Ceiling(val label: String) {
        USER_MAX("User max"),
        FHD_1080P("1080p"),
        HD_720P("720p"),
        SD_540P("540p")
    }

    data class Decision(
        val ceiling: Ceiling,
        val changed: Boolean,
        val reason: String = ""
    )

    private var currentCeiling = Ceiling.USER_MAX
    private var lastChangeAtMs = Long.MIN_VALUE / 4
    private var stableSinceMs = 0L
    private var lastDroppedFrames = 0
    private var lastRebufferCount = 0
    private var lastRebufferDurationMs = 0L

    fun reset() {
        currentCeiling = Ceiling.USER_MAX
        lastChangeAtMs = Long.MIN_VALUE / 4
        stableSinceMs = 0L
        lastDroppedFrames = 0
        lastRebufferCount = 0
        lastRebufferDurationMs = 0L
    }

    fun currentCeiling(): Ceiling = currentCeiling

    /**
     * @param baseMaxHeight أقصى ارتفاع يسمح به اختيار المستخدم. Int.MAX_VALUE يعني SOURCE/AUTO.
     * @param playbackAgeMs الوقت منذ أول Video Frame، وليس منذ الضغط على القناة.
     */
    fun observe(
        nowMs: Long,
        playbackAgeMs: Long,
        baseMaxHeight: Int,
        droppedFrames: Int,
        rebufferCount: Int,
        rebufferDurationMs: Long,
        estimatedBandwidth: Long,
        videoBitrate: Long,
        currentBufferMs: Long
    ): Decision {
        val droppedDelta = (droppedFrames - lastDroppedFrames).coerceAtLeast(0)
        val rebufferDelta = (rebufferCount - lastRebufferCount).coerceAtLeast(0)
        val rebufferDurationDelta = (rebufferDurationMs - lastRebufferDurationMs).coerceAtLeast(0L)
        lastDroppedFrames = droppedFrames
        lastRebufferCount = rebufferCount
        lastRebufferDurationMs = rebufferDurationMs

        if (playbackAgeMs < warmupMs) {
            stableSinceMs = 0L
            return Decision(currentCeiling, false)
        }

        var pressureScore = 0
        if (rebufferDelta > 0) pressureScore += 3
        if (rebufferDurationDelta >= 1_500L) pressureScore += 2
        pressureScore += when {
            droppedDelta >= 30 -> 3
            droppedDelta >= 12 -> 2
            droppedDelta >= 5 -> 1
            else -> 0
        }

        val bandwidthKnown = estimatedBandwidth > 0L && videoBitrate > 0L
        val bandwidthRatio = if (bandwidthKnown) estimatedBandwidth.toDouble() / videoBitrate.toDouble() else Double.POSITIVE_INFINITY
        if (bandwidthKnown) {
            pressureScore += when {
                bandwidthRatio < 1.05 -> 3
                bandwidthRatio < 1.20 -> 2
                bandwidthRatio < 1.35 -> 1
                else -> 0
            }
        }
        if (currentBufferMs in 1..749 && bandwidthKnown && bandwidthRatio < 1.35) pressureScore += 1

        val canChange = nowMs - lastChangeAtMs >= changeCooldownMs
        if (pressureScore >= 3) {
            stableSinceMs = 0L
            if (canChange) {
                val lower = nextLower(currentCeiling, baseMaxHeight)
                if (lower != currentCeiling) {
                    currentCeiling = lower
                    lastChangeAtMs = nowMs
                    return Decision(currentCeiling, true, "pressure:$pressureScore")
                }
            }
            return Decision(currentCeiling, false)
        }

        val comfortablyStable = rebufferDelta == 0 &&
            droppedDelta <= 2 &&
            currentBufferMs >= 2_000L &&
            (!bandwidthKnown || bandwidthRatio >= 1.50)

        if (!comfortablyStable) {
            stableSinceMs = 0L
            return Decision(currentCeiling, false)
        }

        if (currentCeiling == Ceiling.USER_MAX) {
            stableSinceMs = nowMs
            return Decision(currentCeiling, false)
        }

        if (stableSinceMs == 0L) stableSinceMs = nowMs
        if (canChange && nowMs - stableSinceMs >= restoreStableMs) {
            val higher = nextHigher(currentCeiling, baseMaxHeight)
            if (higher != currentCeiling) {
                currentCeiling = higher
                lastChangeAtMs = nowMs
                stableSinceMs = nowMs
                return Decision(currentCeiling, true, "stable")
            }
        }
        return Decision(currentCeiling, false)
    }

    private fun nextLower(current: Ceiling, baseMaxHeight: Int): Ceiling = when (current) {
        Ceiling.USER_MAX -> when {
            baseMaxHeight > 1080 -> Ceiling.FHD_1080P
            baseMaxHeight > 720 -> Ceiling.HD_720P
            else -> Ceiling.SD_540P
        }
        Ceiling.FHD_1080P -> Ceiling.HD_720P
        Ceiling.HD_720P -> Ceiling.SD_540P
        Ceiling.SD_540P -> Ceiling.SD_540P
    }

    private fun nextHigher(current: Ceiling, baseMaxHeight: Int): Ceiling = when (current) {
        Ceiling.SD_540P -> if (baseMaxHeight <= 720) Ceiling.USER_MAX else Ceiling.HD_720P
        Ceiling.HD_720P -> if (baseMaxHeight <= 1080) Ceiling.USER_MAX else Ceiling.FHD_1080P
        Ceiling.FHD_1080P -> Ceiling.USER_MAX
        Ceiling.USER_MAX -> Ceiling.USER_MAX
    }
}
