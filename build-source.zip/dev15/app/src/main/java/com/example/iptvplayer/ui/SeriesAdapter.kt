package com.brotv.player.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load
import com.brotv.player.R
import com.brotv.player.model.Series

/**
 * محول شبكة المسلسلات. لا يستدعي get_series_info لأي مسلسل هنا إطلاقاً — هذا كان يسبب
 * مئات الطلبات لسيرفر IPTV لمجرد عرض القائمة (بطء + Rate Limit). عدد المواسم يظهر
 * فقط داخل شاشة تفاصيل المسلسل بعد فتحه فعلياً، مو أثناء التصفح.
 */
class SeriesAdapter(
    seriesList: List<Series>,
    private val onFocus: (Series) -> Unit = {},
    private val onLeftEdge: () -> Unit = {},
    private val onClick: (Series) -> Unit
) : ListAdapter<Series, SeriesAdapter.SeriesViewHolder>(DIFF) {

    init {
        setHasStableIds(true)
        submitList(seriesList)
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Series>() {
            override fun areItemsTheSame(oldItem: Series, newItem: Series) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Series, newItem: Series) = oldItem == newItem
        }
    }

    class SeriesViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val poster: ImageView = view.findViewById(R.id.imgPoster)
        val placeholder: ImageView = view.findViewById(R.id.imgPosterPlaceholder)
        val title: TextView = view.findViewById(R.id.txtPosterTitle)
        val subtitle: TextView = view.findViewById(R.id.txtPosterSubtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeriesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_poster, parent, false)
        return SeriesViewHolder(view)
    }

    override fun getItemId(position: Int): Long = getItem(position).id.hashCode().toLong()

    override fun onBindViewHolder(holder: SeriesViewHolder, position: Int) {
        val series = getItem(position)
        holder.title.text = series.name
        holder.subtitle.text = series.year // بدون عدد المواسم هنا عمداً (يحتاج طلب إضافي لكل مسلسل)
        holder.itemView.setOnFocusChangeListener { _, hasFocus ->
            holder.itemView.scaleX = if (hasFocus) 1.035f else 1f
            holder.itemView.scaleY = if (hasFocus) 1.035f else 1f
            holder.itemView.elevation = if (hasFocus) 8f * holder.itemView.resources.displayMetrics.density else 0f
            if (hasFocus) onFocus(series)
        }
        holder.itemView.nextFocusUpId = if (position < 4) R.id.btnSortDefault else View.NO_ID
        holder.itemView.setOnKeyListener { _, keyCode, event ->
            val adapterPosition = holder.bindingAdapterPosition
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_LEFT &&
                adapterPosition != RecyclerView.NO_POSITION && adapterPosition % 4 == 0
            ) {
                onLeftEdge()
                true
            } else {
                false
            }
        }
        holder.itemView.setOnClickListener { onClick(series) }

        holder.poster.dispose()
        holder.poster.tag = series.id
        holder.placeholder.setImageResource(R.drawable.ic_series)
        holder.placeholder.visibility = View.VISIBLE
        if (series.posterUrl.isNullOrBlank()) {
            holder.poster.setImageDrawable(null)
        } else {
            holder.poster.load(series.posterUrl) {
                crossfade(false)
                listener(
                    onSuccess = { _, _ ->
                        if (holder.poster.tag == series.id) holder.placeholder.visibility = View.GONE
                    },
                    onError = { _, _ ->
                        if (holder.poster.tag == series.id) holder.placeholder.visibility = View.VISIBLE
                    }
                )
            }
        }
    }

    override fun onViewRecycled(holder: SeriesViewHolder) {
        holder.poster.dispose()
        holder.poster.tag = null
        holder.poster.setImageDrawable(null)
        holder.placeholder.visibility = View.VISIBLE
        holder.itemView.setOnFocusChangeListener(null)
        holder.itemView.setOnKeyListener(null)
        holder.itemView.setOnClickListener(null)
        holder.itemView.scaleX = 1f
        holder.itemView.scaleY = 1f
        holder.itemView.elevation = 0f
        super.onViewRecycled(holder)
    }

}
