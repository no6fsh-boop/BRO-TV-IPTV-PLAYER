package com.brotv.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLDecoder

/** قياس أولي خفيف للمصدر قبل وجود إحصاءات تشغيل فعلية. */
object ConnectionQualityChecker {

    enum class Quality { GOOD, MEDIUM, WEAK, UNREACHABLE }

    data class Measurement(
        val quality: Quality,
        val latencyMs: Long = -1L
    )

    suspend fun check(streamUrl: String): Quality = measure(streamUrl).quality

    suspend fun measure(streamUrl: String): Measurement = withContext(Dispatchers.IO) {
        // Xtream stream URLs are never probed directly: a GET/Range to /live/... can itself
        // consume one of the provider's allowed streaming connections. Probe player_api.php
        // instead, which gives server latency without opening a second media session.
        val probeUrl = safeProbeUrl(streamUrl)
        val head = tryRequest(probeUrl, "HEAD")
        if (head != null) return@withContext head
        tryRequest(probeUrl, "GET", useRange = true)
            ?: Measurement(Quality.UNREACHABLE, -1L)
    }

    /** Score أولي للمصدر غير المجرب حتى لا يخسر تلقائياً أمام مصدر مجرب ضعيف. */
    suspend fun initialHealthScore(streamUrl: String): Int {
        val measurement = measure(streamUrl)
        return when (measurement.quality) {
            Quality.GOOD -> 75
            Quality.MEDIUM -> 62
            Quality.WEAK -> 48
            Quality.UNREACHABLE -> 0
        }
    }

    private fun tryRequest(
        streamUrl: String,
        method: String,
        useRange: Boolean = false
    ): Measurement? {
        return try {
            val start = System.currentTimeMillis()
            val connection = URL(streamUrl).openConnection() as HttpURLConnection
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.instanceFollowRedirects = true
            connection.useCaches = false
            connection.requestMethod = method
            connection.setRequestProperty("User-Agent", "BROTV/1.2")
            if (useRange) connection.setRequestProperty("Range", "bytes=0-2048")

            val responseCode: Int
            val elapsed: Long
            try {
                responseCode = connection.responseCode
                elapsed = System.currentTimeMillis() - start

                if (method == "GET" && responseCode in 200..299) {
                    try {
                        connection.inputStream.use { it.read(ByteArray(1024)) }
                    } catch (_: Exception) {
                        // يكفينا نجاح الاستجابة؛ بعض خوادم IPTV تغلق GET الجزئي بسرعة.
                    }
                }
            } finally {
                connection.disconnect()
            }

            if (method == "HEAD" && responseCode in setOf(405, 501)) return null
            if (responseCode !in 200..299) {
                return if (method == "HEAD") null
                else Measurement(Quality.UNREACHABLE, elapsed)
            }

            val quality = when {
                elapsed < 800 -> Quality.GOOD
                elapsed < 2000 -> Quality.MEDIUM
                else -> Quality.WEAK
            }
            Measurement(quality, elapsed)
        } catch (_: Exception) {
            if (method == "HEAD") null else Measurement(Quality.UNREACHABLE, -1L)
        }
    }

    internal fun safeProbeUrl(streamUrl: String): String {
        return try {
            val uri = URI(streamUrl)
            val scheme = uri.scheme ?: return streamUrl
            val host = uri.host ?: return streamUrl
            val port = if (uri.port >= 0) ":${uri.port}" else ""
            val server = "$scheme://$host$port"
            val parts = uri.rawPath.orEmpty().split('/').filter { it.isNotBlank() }
            val typeIndex = parts.indexOfFirst { it == "live" || it == "movie" || it == "series" }

            var username: String? = null
            var password: String? = null
            if (typeIndex >= 0 && parts.size > typeIndex + 3) {
                username = URLDecoder.decode(parts[typeIndex + 1], Charsets.UTF_8.name())
                password = URLDecoder.decode(parts[typeIndex + 2], Charsets.UTF_8.name())
            } else if (uri.rawPath.orEmpty().endsWith("timeshift.php")) {
                uri.rawQuery.orEmpty().split('&').forEach { pair ->
                    val eq = pair.indexOf('=')
                    if (eq <= 0) return@forEach
                    val key = URLDecoder.decode(pair.substring(0, eq), Charsets.UTF_8.name())
                    val value = URLDecoder.decode(pair.substring(eq + 1), Charsets.UTF_8.name())
                    if (key == "username") username = value
                    if (key == "password") password = value
                }
            }

            val user = username?.takeIf { it.isNotBlank() } ?: return streamUrl
            val pass = password ?: return streamUrl
            XtreamUrlCodec.playerApiUrl(server, user, pass)
        } catch (_: Exception) {
            streamUrl
        }
    }

    suspend fun findBestSource(urls: List<String>): String? = coroutineScope {
        if (urls.isEmpty()) return@coroutineScope null
        val results = urls.map { url -> async { url to measure(url) } }.awaitAll()
        results
            .filter { it.second.quality != Quality.UNREACHABLE }
            .minWithOrNull(
                compareBy<Pair<String, Measurement>> { it.second.quality.ordinal }
                    .thenBy { it.second.latencyMs.takeIf { ms -> ms >= 0 } ?: Long.MAX_VALUE }
            )
            ?.first
    }
}
