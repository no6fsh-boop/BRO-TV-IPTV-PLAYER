package com.brotv.player.data.db

import androidx.room.Entity
import androidx.room.Index

@Entity(
    tableName = "epg_programs",
    primaryKeys = ["sourceId", "channelId", "startTimeMs"],
    indices = [
        Index(value = ["sourceId", "channelId", "startTimeMs", "endTimeMs"]),
        Index(value = ["sourceId", "normalizedChannelName", "startTimeMs", "endTimeMs"]),
        Index(value = ["updatedAt"])
    ]
)
data class EpgProgramEntity(
    val sourceId: String,
    val channelId: String,
    val channelName: String,
    val normalizedChannelName: String,
    val title: String,
    val description: String = "",
    val startTimeMs: Long,
    val endTimeMs: Long,
    val updatedAt: Long = System.currentTimeMillis()
)
