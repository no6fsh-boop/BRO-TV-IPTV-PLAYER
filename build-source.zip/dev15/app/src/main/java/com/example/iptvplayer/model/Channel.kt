package com.brotv.player.model

import android.os.Parcel
import android.os.Parcelable

/**
 * يمثل قناة IPTV واحدة، سواء أتت من ملف M3U أو من Xtream Codes API.
 */
data class Channel(
    val id: String,
    val name: String,
    val streamUrl: String,
    val logoUrl: String? = null,
    val groupTitle: String = "عام",
    val epgId: String? = null,
    val hasArchive: Boolean = false,
    val archiveDurationDays: Int = 0
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString(),
        parcel.readString() ?: "عام",
        parcel.readString(),
        parcel.readByte() != 0.toByte(),
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(name)
        parcel.writeString(streamUrl)
        parcel.writeString(logoUrl)
        parcel.writeString(groupTitle)
        parcel.writeString(epgId)
        parcel.writeByte(if (hasArchive) 1 else 0)
        parcel.writeInt(archiveDurationDays)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Channel> {
        override fun createFromParcel(parcel: Parcel): Channel = Channel(parcel)
        override fun newArray(size: Int): Array<Channel?> = arrayOfNulls(size)
    }
}
