package com.brotv.player.dvr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.brotv.player.R
import com.brotv.player.data.db.RecordingStatus
import com.brotv.player.player.ResourceBudget
import com.brotv.player.player.ResourceGuard
import com.brotv.player.ui.RecordingsActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Foreground DVR service. One service can own multiple independent recording jobs. */
class DvrRecordingService : Service() {
    private val serviceJob = SupervisorJob()
    private val scope = CoroutineScope(serviceJob + Dispatchers.IO)
    private lateinit var repository: DvrRepository
    private val jobs = ConcurrentHashMap<String, Job>()
    private val jobLaunchLock = Any()
    private val recorders = ConcurrentHashMap<String, DvrStreamRecorder>()
    private val stopRequested = ConcurrentHashMap<String, AtomicBoolean>()
    private val forcedFailureReason = ConcurrentHashMap<String, String>()
    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeLockRenewJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        repository = DvrRepository(this)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureForeground()
        when (intent?.action) {
            ACTION_STOP -> intent.getStringExtra(EXTRA_ID)?.let(::requestStop)
            ACTION_START -> intent.getStringExtra(EXTRA_ID)?.let(::launchRecording)
            else -> recoverRunningJobs()
        }
        return START_STICKY
    }

    private fun launchRecording(id: String) {
        lateinit var job: Job
        synchronized(jobLaunchLock) {
            if (jobs[id]?.isActive == true) return
            stopRequested[id] = AtomicBoolean(false)
            acquireWakeLock()
            job = scope.launch(start = CoroutineStart.LAZY) {
                try {
                    runRecording(id)
                } catch (_: CancellationException) {
                    // Process/service teardown leaves the DB state recoverable on the next start.
                } catch (e: Exception) {
                    val row = repository.getById(id)
                    val bytes = row?.filePath?.takeIf(String::isNotBlank)?.let { File(it).takeIf(File::exists)?.length() } ?: 0L
                    repository.updateStatus(
                        id,
                        if (bytes > 0) RecordingStatus.PARTIAL else RecordingStatus.FAILED,
                        safeError(e),
                        actualEndMs = System.currentTimeMillis()
                    )
                    row?.filePath?.takeIf(String::isNotBlank)?.let { DvrStreamRecorder.cleanupCheckpoint(File(it)) }
                } finally {
                    recorders.remove(id)?.abortCurrentNetworkCall()
                    stopRequested.remove(id)
                    forcedFailureReason.remove(id)
                    jobs.remove(id, job)
                    refreshForegroundOrStop()
                }
            }
            jobs[id] = job
        }
        job.start()
        updateNotification()
    }

    private suspend fun runRecording(id: String) {
        var row = repository.getById(id) ?: return
        val initialStatus = RecordingStatus.from(row.status)
        if (initialStatus in setOf(RecordingStatus.COMPLETED, RecordingStatus.CANCELLED, RecordingStatus.MISSED)) return

        val now = System.currentTimeMillis()
        if (row.scheduledEndMs > 0 && row.scheduledEndMs <= now) {
            repository.updateStatus(id, RecordingStatus.MISSED, actualEndMs = now)
            return
        }
        if (row.scheduledStartMs > now + START_EARLY_TOLERANCE_MS) {
            repository.updateStatus(id, RecordingStatus.SCHEDULED)
            DvrScheduler.schedule(this, id, row.scheduledStartMs, row.scheduledEndMs)
            return
        }

        val urls = repository.decryptSourceUrls(row)
        if (urls.isEmpty()) {
            repository.updateStatus(id, RecordingStatus.FAILED, "Unable to decrypt recording source", actualEndMs = now)
            return
        }
        val output = File(row.filePath)
        output.parentFile?.mkdirs()
        if (!hasEnoughStorage(output)) {
            repository.updateStatus(id, RecordingStatus.FAILED, "Not enough free storage", actualEndMs = System.currentTimeMillis())
            return
        }
        val actualStart = row.actualStartMs.takeIf { it > 0 } ?: now
        repository.updateStatus(id, RecordingStatus.WAITING_RESOURCE, actualStartMs = actualStart)

        var retryDelay = MIN_RETRY_MS
        var lastError = ""
        while (scope.isActive && !isStopRequested(id) && !hasReachedEnd(row)) {
            var openedAnySource = false
            var preemptedThisRound = false

            for (url in urls) {
                if (isStopRequested(id) || hasReachedEnd(row)) break
                val recorder = DvrStreamRecorder()
                recorders[id] = recorder
                val result = ResourceGuard.acquire(
                    context = this,
                    streamUrl = url,
                    kind = ResourceBudget.SessionKind.RECORDING,
                    onPreempt = { recorder.abortCurrentNetworkCall() }
                )
                if (result is ResourceGuard.AcquireResult.Denied) {
                    recorders.remove(id, recorder)
                    lastError = when (result.reason) {
                        ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT -> "Waiting for a free provider connection"
                        ResourceBudget.DenialReason.DEVICE_MEMORY_PRESSURE -> "Waiting for device resources"
                        ResourceBudget.DenialReason.DEVICE_DECODER_LIMIT -> "Waiting for device resources"
                    }
                    continue
                }

                openedAnySource = true
                val lease = (result as ResourceGuard.AcquireResult.Granted).lease
                repository.updateStatus(id, RecordingStatus.RECORDING, actualStartMs = actualStart)
                updateNotification()
                val lastDbProgress = AtomicLong(0L)
                try {
                    val recResult = recorder.record(
                        sourceUrl = url,
                        destination = output,
                        stopAtMs = row.scheduledEndMs,
                        shouldStop = { isStopRequested(id) },
                        onProgress = { bytes, mime ->
                            val current = System.currentTimeMillis()
                            val previous = lastDbProgress.get()
                            if (current - previous >= PROGRESS_UPDATE_MS && lastDbProgress.compareAndSet(previous, current)) {
                                scope.launch { repository.updateProgress(id, output, mime, bytes) }
                            }
                            if (!hasEnoughStorage(output, MIN_FREE_SPACE_DURING_RECORDING_BYTES)) {
                                forcedFailureReason[id] = "Recording stopped because device storage is low"
                                stopRequested[id]?.set(true)
                                recorder.abortCurrentNetworkCall()
                            }
                        }
                    )
                    repository.updateProgress(id, output, recResult.mimeType, recResult.bytesWritten)
                    if (recResult.endedNaturally && row.scheduledEndMs == 0L) {
                        finishRecording(id, output, RecordingStatus.COMPLETED, "")
                        return
                    }
                    if (hasReachedEnd(row) || isStopRequested(id)) break
                    // Finite source ended before the requested window. Fail over/retry instead of silently stopping.
                    lastError = "Source ended before recording window"
                } catch (_: RecordingPreemptedException) {
                    preemptedThisRound = true
                    lastError = "Paused for primary playback"
                    repository.updateStatus(id, RecordingStatus.WAITING_RESOURCE, lastError)
                    break
                } catch (e: Exception) {
                    lastError = safeError(e)
                    // Try the next merged source immediately.
                } finally {
                    recorders.remove(id, recorder)
                    lease.release()
                }
            }

            if (isStopRequested(id) || hasReachedEnd(row)) break
            repository.updateStatus(id, RecordingStatus.WAITING_RESOURCE, lastError)
            val waitMs = if (preemptedThisRound || !openedAnySource) RESOURCE_RETRY_MS else retryDelay
            delayUntilNeeded(waitMs, row.scheduledEndMs, id)
            retryDelay = (retryDelay * 2).coerceAtMost(MAX_RETRY_MS)
            row = repository.getById(id) ?: return
        }

        val forcedFailure = forcedFailureReason[id]
        val finalStatus = when {
            forcedFailure != null -> if (output.exists() && output.length() > 0L) RecordingStatus.PARTIAL else RecordingStatus.FAILED
            isStopRequested(id) -> if (output.exists() && output.length() > 0L) RecordingStatus.COMPLETED else RecordingStatus.CANCELLED
            hasReachedEnd(row) -> if (output.exists() && output.length() > 0L) RecordingStatus.COMPLETED else RecordingStatus.MISSED
            output.exists() && output.length() > 0L -> RecordingStatus.PARTIAL
            else -> RecordingStatus.FAILED
        }
        val finalError = forcedFailure ?: if (finalStatus == RecordingStatus.FAILED) lastError else ""
        finishRecording(id, output, finalStatus, finalError)
    }

    private suspend fun finishRecording(id: String, output: File, status: RecordingStatus, error: String) {
        val row = repository.getById(id)
        val mime = row?.mimeType ?: "video/mp2t"
        if (output.exists()) repository.updateProgress(id, output, mime, output.length())
        repository.updateStatus(id, status, error, actualEndMs = System.currentTimeMillis())
        DvrStreamRecorder.cleanupCheckpoint(output)
        DvrScheduler.cancel(this, id)
    }

    private fun requestStop(id: String) {
        stopRequested.getOrPut(id) { AtomicBoolean(false) }.set(true)
        recorders[id]?.abortCurrentNetworkCall()
        if (jobs[id]?.isActive != true) {
            scope.launch {
                val row = repository.getById(id) ?: return@launch
                val file = row.filePath.takeIf(String::isNotBlank)?.let(::File)
                repository.updateStatus(
                    id,
                    if (file?.exists() == true && file.length() > 0) RecordingStatus.COMPLETED else RecordingStatus.CANCELLED,
                    actualEndMs = System.currentTimeMillis()
                )
                file?.let(DvrStreamRecorder::cleanupCheckpoint)
                DvrScheduler.cancel(this@DvrRecordingService, id)
                refreshForegroundOrStop()
            }
        }
    }

    private fun recoverRunningJobs() {
        scope.launch {
            repository.getRecoverable().forEach { row ->
                if (jobs[row.id]?.isActive != true) launchRecording(row.id)
            }
            refreshForegroundOrStop()
        }
    }

    private suspend fun delayUntilNeeded(delayMs: Long, endMs: Long, id: String) {
        var remaining = delayMs
        while (remaining > 0 && !isStopRequested(id)) {
            if (endMs > 0 && System.currentTimeMillis() >= endMs) return
            val step = minOf(1_000L, remaining)
            delay(step)
            remaining -= step
        }
    }

    private fun hasEnoughStorage(output: File, minimumBytes: Long = MIN_FREE_SPACE_BEFORE_RECORDING_BYTES): Boolean {
        val parent = output.parentFile ?: return false
        return runCatching { parent.usableSpace >= minimumBytes }.getOrDefault(false)
    }

    private fun hasReachedEnd(row: com.brotv.player.data.db.RecordingEntity): Boolean =
        row.scheduledEndMs > 0 && System.currentTimeMillis() >= row.scheduledEndMs

    private fun isStopRequested(id: String): Boolean = stopRequested[id]?.get() == true

    private fun safeError(error: Throwable): String = when (error) {
        is RecorderHttpException -> "HTTP ${error.statusCode}"
        is UnsupportedOperationException -> error.message ?: "Unsupported stream format"
        else -> error.javaClass.simpleName.takeIf { it.isNotBlank() } ?: "Recording error"
    }

    private fun ensureForeground() {
        try {
            startForeground(NOTIFICATION_ID, buildNotification())
        } catch (_: Exception) {
            // System may temporarily reject foreground promotion; the job still has persisted state.
        }
    }

    private fun updateNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        runCatching { manager.notify(NOTIFICATION_ID, buildNotification()) }
    }

    private fun refreshForegroundOrStop() {
        if (jobs.values.any { it.isActive }) {
            updateNotification()
        } else {
            releaseWakeLock()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else {
                @Suppress("DEPRECATION") stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun buildNotification(): Notification {
        val active = jobs.values.count { it.isActive }
        val openIntent = Intent(this, RecordingsActivity::class.java)
        val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val contentIntent = PendingIntent.getActivity(this, 7120, openIntent, pendingFlags)
        val text = if (active > 0) getString(R.string.dvr_notification_active, active) else getString(R.string.dvr_notification_preparing)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.dvr_notification_title))
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setOngoing(active > 0)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.dvr_notification_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = getString(R.string.dvr_notification_channel_description) }
        manager.createNotificationChannel(channel)
    }

    private fun acquireWakeLock() {
        val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val lock = wakeLock ?: manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BROTV:DVR").apply {
            setReferenceCounted(false)
        }.also { wakeLock = it }
        if (!lock.isHeld) runCatching { lock.acquire(WAKE_LOCK_TIMEOUT_MS) }
        if (wakeLockRenewJob?.isActive != true) {
            wakeLockRenewJob = scope.launch {
                while (isActive) {
                    delay(WAKE_LOCK_RENEW_INTERVAL_MS)
                    if (jobs.values.none { it.isActive }) break
                    val activeLock = wakeLock ?: break
                    runCatching {
                        if (activeLock.isHeld) activeLock.release()
                        activeLock.acquire(WAKE_LOCK_TIMEOUT_MS)
                    }
                }
            }
        }
    }

    private fun releaseWakeLock() {
        wakeLockRenewJob?.cancel()
        wakeLockRenewJob = null
        val lock = wakeLock ?: return
        if (lock.isHeld) runCatching { lock.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        recorders.values.forEach(DvrStreamRecorder::abortCurrentNetworkCall)
        serviceJob.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        private const val ACTION_START = "com.brotv.player.action.DVR_SERVICE_START"
        private const val ACTION_STOP = "com.brotv.player.action.DVR_SERVICE_STOP"
        private const val EXTRA_ID = "recording_id"
        private const val CHANNEL_ID = "brotv_dvr"
        private const val NOTIFICATION_ID = 7121
        private const val START_EARLY_TOLERANCE_MS = 2_000L
        private const val RESOURCE_RETRY_MS = 12_000L
        private const val MIN_RETRY_MS = 3_000L
        private const val MAX_RETRY_MS = 30_000L
        private const val PROGRESS_UPDATE_MS = 2_000L
        private const val WAKE_LOCK_TIMEOUT_MS = 12L * 60L * 60L * 1000L
        private const val WAKE_LOCK_RENEW_INTERVAL_MS = 6L * 60L * 60L * 1000L
        private const val MIN_FREE_SPACE_BEFORE_RECORDING_BYTES = 256L * 1024L * 1024L
        private const val MIN_FREE_SPACE_DURING_RECORDING_BYTES = 96L * 1024L * 1024L

        fun start(context: Context, recordingId: String) {
            val intent = Intent(context, DvrRecordingService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_ID, recordingId)
            }
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Exception) {
                runCatching { context.startService(intent) }
            }
        }

        fun stop(context: Context, recordingId: String) {
            val intent = Intent(context, DvrRecordingService::class.java).apply {
                action = ACTION_STOP
                putExtra(EXTRA_ID, recordingId)
            }
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Exception) {
                runCatching { context.startService(intent) }
            }
        }
    }
}
