package com.brotv.player.security

import android.content.Context
import android.os.Build
import android.security.KeyPairGeneratorSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.annotation.RequiresApi
import java.math.BigInteger
import java.nio.ByteBuffer
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.util.Calendar
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.security.auth.x500.X500Principal

/**
 * تشفير بيانات الحسابات الحساسة بدون تخزين مفاتيح خام داخل التطبيق.
 *
 * Android 6.0+ (API 23): AES/GCM بمفتاح AES دائم داخل Android Keystore (enc:v1:).
 * Android 5.0/5.1 (API 21-22): Hybrid encryption (enc:v0:):
 *  - مفتاح RSA دائم داخل Android Keystore.
 *  - مفتاح AES عشوائي جديد لكل قيمة.
 *  - مفتاح AES يُغلّف بـRSA ويُحفظ داخل الحمولة المشفرة، وليس كنص خام.
 *
 * هذا يحافظ على minSdk 21 بدون تخزين كلمات المرور/روابط M3U كنص واضح.
 */
object CredentialCipher {

    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val MODERN_AES_ALIAS = "brotv_credentials_key"
    private const val LEGACY_RSA_ALIAS = "brotv_credentials_rsa_key"
    private const val AES_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val RSA_TRANSFORMATION = "RSA/ECB/PKCS1Padding"
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val MODERN_PREFIX = "enc:v1:"
    private const val LEGACY_PREFIX = "enc:v0:"
    private const val MODERN_IV_BYTES = 12
    private const val MAX_WRAPPED_KEY_BYTES = 1024
    private val secureRandom = SecureRandom()

    fun isEncrypted(value: String): Boolean =
        value.startsWith(MODERN_PREFIX) || value.startsWith(LEGACY_PREFIX)

    fun encryptOrNull(context: Context, plainText: String): String? {
        if (plainText.isEmpty()) return ""
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                encryptModern(plainText)
            } else {
                encryptLegacy(context.applicationContext, plainText)
            }
        } catch (_: Exception) {
            null
        }
    }

    fun encryptOrThrow(context: Context, plainText: String): String =
        encryptOrNull(context, plainText)
            ?: throw IllegalStateException("تعذر تشفير بيانات النسخة الاحتياطية")

    /**
     * القيمة غير المشفرة تُعامل كبيانات قديمة من إصدارات ما قبل التشفير ولا تُفقد.
     * أما الحمولة ذات بادئة تشفير صحيحة ولكنها تالفة/بمفتاح مختلف فترجع null صريح.
     */
    fun decryptOrNull(context: Context, value: String): String? {
        if (value.isEmpty()) return ""
        if (!isEncrypted(value)) return value

        return try {
            when {
                value.startsWith(MODERN_PREFIX) -> {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null
                    decryptModern(value)
                }
                value.startsWith(LEGACY_PREFIX) -> decryptLegacy(context.applicationContext, value)
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun getOrCreateModernKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        (keyStore.getKey(MODERN_AES_ALIAS, null) as? SecretKey)?.let { return it }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            MODERN_AES_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun encryptModern(plainText: String): String {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateModernKey())
        val iv = cipher.iv
        require(iv.size == MODERN_IV_BYTES) { "Unexpected GCM IV size" }
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return MODERN_PREFIX + Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun decryptModern(value: String): String {
        val combined = Base64.decode(value.removePrefix(MODERN_PREFIX), Base64.NO_WRAP)
        require(combined.size > MODERN_IV_BYTES) { "Encrypted payload is too short" }
        val iv = combined.copyOfRange(0, MODERN_IV_BYTES)
        val cipherBytes = combined.copyOfRange(MODERN_IV_BYTES, combined.size)
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(
            Cipher.DECRYPT_MODE,
            getOrCreateModernKey(),
            GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        )
        return String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
    }

    /** API 21-22: RSA داخل Keystore يغلّف مفتاح AES عشوائي لكل قيمة. */
    @Suppress("DEPRECATION")
    private fun getOrCreateLegacyKeyPair(context: Context): KeyPair {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existingPrivate = keyStore.getKey(LEGACY_RSA_ALIAS, null) as? PrivateKey
        val existingPublic = keyStore.getCertificate(LEGACY_RSA_ALIAS)?.publicKey
        if (existingPrivate != null && existingPublic != null) {
            return KeyPair(existingPublic, existingPrivate)
        }

        val start = Calendar.getInstance()
        val end = Calendar.getInstance().apply { add(Calendar.YEAR, 30) }
        val spec = KeyPairGeneratorSpec.Builder(context)
            .setAlias(LEGACY_RSA_ALIAS)
            .setSubject(X500Principal("CN=BRO TV Credential Key"))
            .setSerialNumber(BigInteger.ONE)
            .setStartDate(start.time)
            .setEndDate(end.time)
            .setKeySize(2048)
            .build()
        val generator = KeyPairGenerator.getInstance("RSA", KEYSTORE_PROVIDER)
        generator.initialize(spec)
        return generator.generateKeyPair()
    }

    private fun encryptLegacy(context: Context, plainText: String): String {
        val pair = getOrCreateLegacyKeyPair(context)
        val dataKey = KeyGenerator.getInstance("AES").apply { init(128, secureRandom) }.generateKey()

        val dataCipher = Cipher.getInstance(AES_TRANSFORMATION)
        dataCipher.init(Cipher.ENCRYPT_MODE, dataKey)
        val iv = dataCipher.iv
        val encryptedData = dataCipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        val rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION)
        rsaCipher.init(Cipher.ENCRYPT_MODE, pair.public)
        val wrappedKey = rsaCipher.doFinal(dataKey.encoded)

        val payload = ByteBuffer.allocate(4 + wrappedKey.size + 4 + iv.size + encryptedData.size)
            .putInt(wrappedKey.size)
            .put(wrappedKey)
            .putInt(iv.size)
            .put(iv)
            .put(encryptedData)
            .array()
        return LEGACY_PREFIX + Base64.encodeToString(payload, Base64.NO_WRAP)
    }

    private fun decryptLegacy(context: Context, value: String): String {
        val payload = Base64.decode(value.removePrefix(LEGACY_PREFIX), Base64.NO_WRAP)
        val buffer = ByteBuffer.wrap(payload)

        require(buffer.remaining() >= 8) { "Encrypted payload is too short" }
        val wrappedKeySize = buffer.int
        require(wrappedKeySize in 1..MAX_WRAPPED_KEY_BYTES && buffer.remaining() >= wrappedKeySize + 4) {
            "Invalid wrapped key size"
        }
        val wrappedKey = ByteArray(wrappedKeySize).also(buffer::get)
        val ivSize = buffer.int
        require(ivSize in 12..32 && buffer.remaining() > ivSize) { "Invalid IV size" }
        val iv = ByteArray(ivSize).also(buffer::get)
        val encryptedData = ByteArray(buffer.remaining()).also(buffer::get)

        val pair = getOrCreateLegacyKeyPair(context)
        val rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION)
        rsaCipher.init(Cipher.DECRYPT_MODE, pair.private)
        val rawAesKey = rsaCipher.doFinal(wrappedKey)
        val dataKey = SecretKeySpec(rawAesKey, "AES")

        val dataCipher = Cipher.getInstance(AES_TRANSFORMATION)
        dataCipher.init(Cipher.DECRYPT_MODE, dataKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        return String(dataCipher.doFinal(encryptedData), Charsets.UTF_8)
    }
}
