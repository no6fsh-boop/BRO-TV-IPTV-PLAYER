package com.brotv.player.ui

import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.brotv.player.R
import com.brotv.player.security.ParentalControlManager

/** UI gate shared by live/VOD surfaces. */
object ParentalGate {
    fun requirePinIfNeeded(
        activity: AppCompatActivity,
        category: String?,
        lockedCategories: Set<String>,
        onGranted: () -> Unit,
        onDenied: (() -> Unit)? = null
    ) {
        val manager = ParentalControlManager(activity)
        if (!manager.requiresPin(category, lockedCategories)) {
            onGranted()
            return
        }

        val input = EditText(activity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            isSingleLine = true
        }
        val dialog = AlertDialog.Builder(activity, R.style.BroTvDialog)
            .setTitle(activity.getString(R.string.parental_locked_content))
            .setMessage(activity.getString(R.string.parental_enter_pin))
            .setView(input)
            .setPositiveButton(android.R.string.ok, null)
            .setNegativeButton(activity.getString(R.string.cancel)) { _, _ -> onDenied?.invoke() }
            .setOnCancelListener { onDenied?.invoke() }
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (manager.verify(input.text.toString())) {
                    dialog.dismiss()
                    onGranted()
                } else {
                    input.text?.clear()
                    Toast.makeText(activity, R.string.parental_wrong_pin, Toast.LENGTH_SHORT).show()
                }
            }
        }
        dialog.show()
    }
}
