package com.brotv.player.data

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

/**
 * يبدّل لغة التطبيق فعلياً باستخدام AppCompatDelegate (نفس آلية "Per-app language"
 * الرسمية بأندرويد). ما يحتاج إعادة تشغيل التطبيق يدوياً — النظام يعيد إنشاء
 * الشاشات المفتوحة تلقائياً بمجرد استدعاء setLocale.
 */
object LocaleManager {

    const val LANGUAGE_ARABIC = "ar"
    const val LANGUAGE_ENGLISH = "en"

    fun setLocale(languageCode: String) {
        val localeList = LocaleListCompat.forLanguageTags(languageCode)
        AppCompatDelegate.setApplicationLocales(localeList)
    }

    fun getCurrentLanguage(): String {
        val locales = AppCompatDelegate.getApplicationLocales()
        if (!locales.isEmpty) {
            return if (locales[0]?.language == LANGUAGE_ENGLISH) LANGUAGE_ENGLISH else LANGUAGE_ARABIC
        }

        // Before the user explicitly chooses a language, the resources follow the device locale.
        // Keep language-dependent features (QR pairing, voice search, settings selection) in sync
        // with what the TV is actually displaying instead of assuming Arabic on an English TV.
        return if (Locale.getDefault().language == LANGUAGE_ARABIC) LANGUAGE_ARABIC else LANGUAGE_ENGLISH
    }

    fun isEnglish(): Boolean = getCurrentLanguage() == LANGUAGE_ENGLISH
}
