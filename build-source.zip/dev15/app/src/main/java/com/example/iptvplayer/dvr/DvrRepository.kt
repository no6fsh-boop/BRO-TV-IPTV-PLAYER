package com.brotv.player.dvr

import android.content.Context
import android.os.Environment
import com.brotv.player.data.db.AppDatabase
import com.brotv.player.data.db.RecordingEntity
import com.brotv.player.data.db.RecordingStatus
import com.brotv.player.model.MergedChannel
import com.brotv.player.security.CredentialCipher
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class DvrRepository(context: Context) {
    private val appContext = context.applicationContext
    private val dao = AppDatabase.getInstance(appContext).recordingDao()

    fun observeAll(): Flow<List<RecordingEntity>> = dao.observeAll()
    suspend fun getAll(): List<RecordingEntity> = dao.getAll()
    suspend fun getById(id: String): RecordingEntity? = dao.getById(id)
    suspend fun getActiveForChannel(channelId: String): RecordingEntity? = dao.getActiveForChannel(channelId)
    suspend fun getFutureScheduled(nowMs: Long = System.currentTimeMillis()): List<RecordingEntity> = dao.getFutureScheduled(nowMs)
    suspend fun getRecoverable(nowMs: Long = System.currentTimeMillis()): List<RecordingEntity> = dao.getRecoverable(nowMs)

    suspend fun createImmediate(
        channel: MergedChannel,
        title: String,
        stopAtMs: Long = 0L
    ): RecordingEntity {
        // Prevent accidental double recordings from repeated remote-control clicks.
        dao.getActiveForChannel(channel.id)?.let { return it }
        return create(channel, title, System.currentTimeMillis(), stopAtMs, RecordingStatus.WAITING_RESOURCE)
    }

    suspend fun createScheduled(
        channel: MergedChannel,
        title: String,
        startAtMs: Long,
        endAtMs: Long
    ): RecordingEntity {
        require(endAtMs > startAtMs) { "Recording end must be after start" }
        // EPG dialogs can receive duplicate key events on some TV remotes. Reuse the existing job.
        dao.getMatchingScheduled(channel.id, startAtMs, endAtMs)?.let { return it }
        return create(channel, title, startAtMs, endAtMs, RecordingStatus.SCHEDULED)
    }

    private suspend fun create(
        channel: MergedChannel,
        title: String,
        startAtMs: Long,
        endAtMs: Long,
        status: RecordingStatus
    ): RecordingEntity {
        require(channel.sourceUrls.isNotEmpty()) { "Channel has no stream URLs" }
        val rawUrls = JSONArray().apply { channel.sourceUrls.forEach(::put) }.toString()
        val encrypted = CredentialCipher.encryptOrThrow(appContext, rawUrls)
        val id = UUID.randomUUID().toString()
        val entity = RecordingEntity(
            id = id,
            channelId = channel.id,
            channelName = channel.name,
            title = title.ifBlank { channel.name },
            encryptedSourceUrls = encrypted,
            scheduledStartMs = startAtMs,
            scheduledEndMs = endAtMs,
            filePath = recordingFile(id, channel.name, title).absolutePath,
            status = status.name
        )
        dao.upsert(entity)
        return entity
    }

    fun decryptSourceUrls(recording: RecordingEntity): List<String> {
        val raw = CredentialCipher.decryptOrNull(appContext, recording.encryptedSourceUrls) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    array.optString(i).takeIf { it.startsWith("http://") || it.startsWith("https://") }?.let(::add)
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun updateStatus(
        id: String,
        status: RecordingStatus,
        error: String = "",
        actualStartMs: Long = 0L,
        actualEndMs: Long = 0L
    ) = dao.updateStatus(id, status.name, error.take(500), actualStartMs, actualEndMs)

    suspend fun updateProgress(id: String, file: File, mimeType: String, bytes: Long) =
        dao.updateProgress(id, file.absolutePath, mimeType, bytes)

    suspend fun cancel(id: String) {
        dao.updateStatus(id, RecordingStatus.CANCELLED.name, "", actualEndMs = System.currentTimeMillis())
        DvrScheduler.cancel(appContext, id)
    }

    suspend fun delete(id: String): Boolean {
        val row = dao.getById(id) ?: return true
        if (RecordingStatus.from(row.status) in setOf(RecordingStatus.RECORDING, RecordingStatus.WAITING_RESOURCE)) {
            return false
        }
        if (row.filePath.isNotBlank()) {
            val file = File(row.filePath)
            runCatching { file.delete() }
            DvrStreamRecorder.cleanupCheckpoint(file)
        }
        dao.deleteById(id)
        DvrScheduler.cancel(appContext, id)
        return true
    }

    private fun recordingFile(id: String, channel: String, title: String): File {
        val base = appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: File(appContext.filesDir, "recordings")
        val dir = File(base, "BROTV_Recordings").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safe = sanitize("${channel}_${title}").take(70).ifBlank { "recording" }
        return File(dir, "${stamp}_${safe}_${id.take(8)}.ts")
    }

    private fun sanitize(value: String): String = value
        .replace(Regex("[^A-Za-z0-9\\u0600-\\u06FF._ -]+"), "_")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '.', '_')
}
