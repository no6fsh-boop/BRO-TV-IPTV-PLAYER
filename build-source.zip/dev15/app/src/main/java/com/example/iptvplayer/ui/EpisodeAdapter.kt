package com.brotv.player.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load
import com.brotv.player.R
import com.brotv.player.data.LocaleManager
import com.brotv.player.model.Episode

/**
 * Episode rows use DiffUtil so changing season/sort/watched state does not rebuild the whole
 * RecyclerView tree or lose TV focus unnecessarily.
 */
class EpisodeAdapter(
    private val onFocus: (Episode) -> Unit = {},
    private val onClick: (Episode) -> Unit
) : ListAdapter<Episode, EpisodeAdapter.EpisodeViewHolder>(DIFF) {

    private var watchedIds: Set<String> = emptySet()

    init {
        setHasStableIds(true)
    }

    companion object {
        private const val PAYLOAD_STATUS = "episode_status"
        private val DIFF = object : DiffUtil.ItemCallback<Episode>() {
            override fun areItemsTheSame(oldItem: Episode, newItem: Episode) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Episode, newItem: Episode) = oldItem == newItem
        }
    }

    fun submitEpisodes(episodes: List<Episode>, watched: Set<String>, onCommitted: () -> Unit = {}) {
        val watchedChanged = watchedIds != watched
        watchedIds = watched
        if (currentList == episodes) {
            if (watchedChanged && itemCount > 0) notifyItemRangeChanged(0, itemCount, PAYLOAD_STATUS)
            onCommitted()
            return
        }
        submitList(episodes.toList(), onCommitted)
    }

    class EpisodeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.imgEpisode)
        val title: TextView = view.findViewById(R.id.txtEpisodeTitle)
        val plot: TextView = view.findViewById(R.id.txtEpisodePlot)
        val duration: TextView = view.findViewById(R.id.txtEpisodeDuration)
        val status: TextView = view.findViewById(R.id.txtEpisodeStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EpisodeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_episode, parent, false)
        return EpisodeViewHolder(view)
    }

    override fun getItemId(position: Int): Long = getItem(position).id.hashCode().toLong()

    override fun onBindViewHolder(holder: EpisodeViewHolder, position: Int) {
        bind(holder, getItem(position), includeArtwork = true)
    }

    override fun onBindViewHolder(holder: EpisodeViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.contains(PAYLOAD_STATUS)) {
            bindStatus(holder, getItem(position))
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    private fun bind(holder: EpisodeViewHolder, episode: Episode, includeArtwork: Boolean) {
        val context = holder.itemView.context
        val providerTitle = episode.title.trim()
        val englishGeneric = "Episode ${episode.episodeNumber}"
        val arabicGeneric = "الحلقة ${episode.episodeNumber}"
        holder.title.text = if (
            providerTitle.isBlank() ||
            providerTitle.equals(englishGeneric, ignoreCase = true) ||
            providerTitle == arabicGeneric
        ) {
            context.getString(R.string.episode_number_only, episode.episodeNumber)
        } else {
            context.getString(R.string.episode_item_title, episode.episodeNumber, providerTitle)
        }
        holder.plot.text = episode.plot
        val minutes = episode.durationLabel.trim()
            .substringBefore(' ')
            .toIntOrNull()
        // Explicit text direction avoids Android's bidi resolver visually swapping
        // compact mixed number/unit badges (for example rendering "53 min" as "min 53").
        holder.duration.textDirection = if (LocaleManager.isEnglish()) {
            View.TEXT_DIRECTION_LTR
        } else {
            View.TEXT_DIRECTION_RTL
        }
        holder.duration.text = if (minutes != null && minutes > 0) {
            context.getString(R.string.episode_duration_minutes, minutes)
        } else {
            episode.durationLabel
        }
        bindStatus(holder, episode)
        holder.itemView.setOnFocusChangeListener { _, hasFocus ->
            holder.itemView.scaleX = if (hasFocus) 1.015f else 1f
            holder.itemView.scaleY = if (hasFocus) 1.015f else 1f
            holder.itemView.elevation = if (hasFocus) 6f * holder.itemView.resources.displayMetrics.density else 0f
            if (hasFocus) onFocus(episode)
        }
        holder.itemView.setOnClickListener { onClick(episode) }

        if (!includeArtwork) return
        holder.image.dispose()
        if (episode.imageUrl.isNullOrBlank()) {
            holder.image.setImageDrawable(null)
        } else {
            holder.image.load(episode.imageUrl) { crossfade(false) }
        }
    }

    private fun bindStatus(holder: EpisodeViewHolder, episode: Episode) {
        val watched = episode.id in watchedIds
        holder.status.text = holder.itemView.context.getString(
            if (watched) R.string.watched_label else R.string.new_label
        )
    }

    override fun onViewRecycled(holder: EpisodeViewHolder) {
        holder.image.dispose()
        holder.image.setImageDrawable(null)
        holder.itemView.setOnFocusChangeListener(null)
        holder.itemView.setOnClickListener(null)
        holder.itemView.scaleX = 1f
        holder.itemView.scaleY = 1f
        holder.itemView.elevation = 0f
        super.onViewRecycled(holder)
    }

}
