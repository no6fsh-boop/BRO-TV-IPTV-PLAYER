package com.brotv.player.player

/**
 * Conservative recovery policy for live IPTV.
 *
 * A TV decoder/AnalyticsListener callback must never be treated as a periodic video heartbeat:
 * some devices legitimately stop emitting frame-processing callbacks while video continues.
 */
object LivePlaybackRecoveryPolicy {
    const val STARTUP_VIDEO_TIMEOUT_MS = 15_000L
    const val FREEZE_TIMEOUT_MS = 15_000L

    fun shouldRecoverMissingFirstFrame(
        hasExpectedVideoTrack: Boolean,
        hasReceivedFirstVideoFrame: Boolean,
        playbackAgeMs: Long,
        audioStarted: Boolean,
        positionMoving: Boolean
    ): Boolean {
        if (!hasExpectedVideoTrack || hasReceivedFirstVideoFrame) return false
        if (playbackAgeMs < STARTUP_VIDEO_TIMEOUT_MS) return false
        return audioStarted || positionMoving
    }

    fun shouldRecoverFreeze(
        playWhenReady: Boolean,
        playbackReady: Boolean,
        unchangedForMs: Long
    ): Boolean = playWhenReady && playbackReady && unchangedForMs >= FREEZE_TIMEOUT_MS
}
