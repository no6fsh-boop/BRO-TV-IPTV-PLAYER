package com.brotv.player.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.XmltvEpgRepository
import com.brotv.player.model.MergedChannel
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * TV guide rows use cache-only EPG reads and cancel work as soon as a row is recycled. This keeps
 * fast D-pad scrolling from building a queue of stale database/network work behind the user.
 */
class EpgGuideAdapter(
    context: Context,
    private val channels: List<MergedChannel>,
    private val currentChannelId: String?,
    private val lifecycleScope: LifecycleCoroutineScope,
    private val onClick: (MergedChannel) -> Unit
) : RecyclerView.Adapter<EpgGuideAdapter.ViewHolder>() {

    private val epgRepository = XmltvEpgRepository(context)

    init {
        setHasStableIds(true)
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.txtGuideChannelName)
        val program: TextView = view.findViewById(R.id.txtGuideProgram)
        val progress: ProgressBar = view.findViewById(R.id.progressGuide)
        var epgJob: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_guide_channel, parent, false)
        return ViewHolder(view)
    }

    override fun getItemId(position: Int): Long = channels[position].id.hashCode().toLong()

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.epgJob?.cancel()
        val channel = channels[position]
        val boundId = channel.id
        holder.name.text = channel.name
        holder.itemView.isSelected = channel.id == currentChannelId
        holder.program.text = ""
        holder.progress.visibility = View.GONE
        holder.itemView.setOnClickListener { onClick(channel) }

        holder.epgJob = lifecycleScope.launch {
            val epg = epgRepository.currentCachedProgram(channel)
            val boundPosition = holder.bindingAdapterPosition
            if (boundPosition == RecyclerView.NO_POSITION || channels[boundPosition].id != boundId) {
                return@launch
            }
            if (epg != null) {
                holder.program.text = holder.itemView.context.getString(
                    R.string.epg_program_with_time,
                    epg.title,
                    epg.startTime,
                    epg.endTime
                )
                holder.progress.visibility = View.VISIBLE
                holder.progress.progress = epg.progressPercent
            }
        }
    }

    override fun onViewRecycled(holder: ViewHolder) {
        holder.epgJob?.cancel()
        holder.epgJob = null
        super.onViewRecycled(holder)
    }

    override fun getItemCount(): Int = channels.size
}
