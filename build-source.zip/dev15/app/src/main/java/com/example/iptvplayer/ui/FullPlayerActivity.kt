package com.brotv.player.ui

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.KeyEvent
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.ui.PlayerView
import com.brotv.player.R
import com.brotv.player.data.AutoPilotEngine
import com.brotv.player.data.DecoderBlacklist
import com.brotv.player.data.NetworkUtils
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.StreamHealthRegistry
import com.brotv.player.data.StreamHealthScorer
import com.brotv.player.data.StreamHealthSnapshot
import com.brotv.player.model.MergedChannel
import com.brotv.player.model.EpgProgram
import com.brotv.player.player.AudioOutputController
import com.brotv.player.player.AudioOutputInfo
import com.brotv.player.player.AudioOutputMode
import com.brotv.player.player.ChannelSurfPolicy
import com.brotv.player.player.ChannelSurfScopePolicy
import com.brotv.player.player.DisplayModeSwitcher
import com.brotv.player.player.DynamicBufferController
import com.brotv.player.player.LivePlaybackRecoveryPolicy
import com.brotv.player.player.LiveSourceRecoveryPolicy
import com.brotv.player.player.LiveTimeshiftPolicy
import com.brotv.player.player.PlayerEngine
import com.brotv.player.player.PlaybackRecoveryGuard
import com.brotv.player.player.PictureInPicturePolicy
import com.brotv.player.player.ResourceBudget
import com.brotv.player.player.ResourceGuard
import com.brotv.player.player.SmartQualityGuard
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

/**
 * شاشة المشغل الكامل. تدعم:
 *  - Seek مباشر بأسهم الريموت (يمين/يسار = ±15 ثانية) مع مؤشر لحظي، بدون فتح شريط التحكم
 *  - Auto-Failover: تبديل تلقائي للمصدر التالي عند فشل التشغيل، مع تنبيه بصري
 *  - أزرار تتكيف حسب نوع المحتوى (تختفي التالية/السابقة للبث المباشر)
 *  - نسب عرض متعددة (احتواء / ملء / تكبير)
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class FullPlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private var resourceLease: ResourceGuard.Lease? = null
    private var playbackResourceRequestToken = 0L
    private var channel: MergedChannel? = null
    private var currentSourceIndex = 0
    private var currentSourceUrl: String? = null
    private var currentSourceLatencyMs: Long = -1L
    private var retryAttemptsForCurrentSource = 0
    private var playbackRetryGeneration = 0L
    // Hot-path background work must never pile up while the user zaps quickly.
    private var sourceProbeJob: Job? = null
    private var epgLookupJob: Job? = null
    private val failedSourceUrlsThisSession = mutableSetOf<String>()
    private var isLiveContent = true
    private var channelSurfList: List<MergedChannel> = emptyList()
    private var channelSurfScope: String? = null
    private val chromeHandler = Handler(Looper.getMainLooper())
    private val hideChromeRunnable = Runnable {
        if (findViewById<android.view.View>(R.id.epgGuideOverlay).visibility != android.view.View.VISIBLE) {
            setPlayerChromeVisible(false)
        }
    }

    // ---------- Player Diagnostics (بند "معلومات التشغيل التقنية") ----------
    private var lastVideoInfo = ""
    private var lastAudioInfo = ""
    private var droppedFrames = 0
    private var lastBitrateEstimate = 0L
    private var lastTtffMs: Long = -1
    private var playbackStartRequestedAt: Long = 0
    private var videoBitrate = 0L
    private var videoWidth = 0
    private var videoHeight = 0
    private var lastAppliedDisplayModeWidth = 0
    private var lastAppliedDisplayModeHeight = 0
    private var actualFps = 0f
    private var hdrType = "SDR"
    private var videoDecoderName = ""
    private var decoderIsHardware = false
    private var currentVideoCodec = ""
    private var currentBufferDurationMs = 0L
    private var rebufferCount = 0
    private var totalRebufferDurationMs = 0L
    private var rebufferStartedAtMs = 0L
    private var averageRebufferDurationMs = 0L
    private var successfulStarts = 0
    private var playbackErrors = 0
    private var failoverCount = 0
    // Live TV is allowed to jump automatically to only one alternative source per channel session.
    // This flag is also set after a manual source choice so the app never overrides that choice.
    private var liveAutomaticAlternativeUsed = false
    private var lastRenderedVideoFrameAtMs = 0L
    private var firstVideoFrameAtMs = 0L
    private var hasReceivedFirstVideoFrame = false
    private var hasExpectedVideoTrack = false
    private var audioStarted = false
    private var audioOutputInfo = AudioOutputInfo(
        AudioOutputMode.AUTO,
        "unknown",
        false,
        "unknown"
    )
    private var blackScreenRecoveryAttempts = 0
    private var blackScreenRecoveryTriggered = false
    private var channelSwitchStartMs = 0L
    private var lastChannelSwitchTimeMs = -1L
    private val channelSwitchSamplesMs = ArrayDeque<Long>()
    private var forceStatsResetOnNextStart = true
    private var lastDynamicBufferApplyAtMs = 0L
    private var dynamicBufferApplyScheduled = false
    private val dynamicBufferController = DynamicBufferController()
    private val smartQualityGuard = SmartQualityGuard()
    private var liveTimeshiftState = LiveTimeshiftPolicy.evaluate(false, false, 0L, 0L)
    // MVP: بَفر محلي مستقل لإعادة اللف حتى 30 دقيقة حتى لو المزود ما يدعم catch-up
    // (StreamVault parity). Activity-scoped عمداً، مو Service — ينتهي ويُحذف عند مغادرة
    // المشغل. غير مربوط حالياً بزر إعادة اللف نفسه (LiveTimeshiftPolicy لسه هو المتحكم
    // بالـUI)؛ هذا فقط يشغّل محرك التجميع بالخلفية ليكون جاهز/قابل للتحقق قبل ربط الـUI.
    private var rollingBufferRecorder: com.brotv.player.player.LiveRollingBufferRecorder? = null
    private var rollingBufferChannelId: String? = null
    // true فقط أثناء تشغيل ملف الإعادة المحلي (rewind.m3u8) — يوقف كل منطق استرجاع/فشل
    // البث المباشر مؤقتاً (checkForFreeze / onPlayerError) لأنه مبني لرابط شبكة حي.
    private var isPlayingFromLocalBuffer = false
    private var smartQualityCeiling = SmartQualityGuard.Ceiling.USER_MAX
    private var smartQualityLastReason = ""
    private var lastAppliedFrameRate = 0f
    private var pendingFrameRate = 0f
    private val frameRateHandler = Handler(Looper.getMainLooper())
    private val frameRateRunnable = Runnable {
        commitMatchFrameRate(pendingFrameRate)
    }

    // ---------- كشف التجمّد (بند "Freeze Detection") ----------
    private var lastKnownPositionMs: Long = -1
    private var positionUnchangedSinceMs: Long = 0
    private var freezeRecoveryTriggered = false
    private var freezeRecoveryAttempts = 0
    private val playbackRecoveryGuard = PlaybackRecoveryGuard()

    // ---------- استعادة الاتصال عند تغيّر الشبكة (بند "Network Change Recovery") ----------
    private var wasNetworkLost = false
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onLost(network: Network) {
            wasNetworkLost = true
            runOnUiThread { showFailoverAlert(getString(R.string.waiting_for_connection)) }
        }

        override fun onAvailable(network: Network) {
            if (wasNetworkLost) {
                wasNetworkLost = false
                runOnUiThread {
                    channel?.let { ch ->
                        retryAttemptsForCurrentSource = 0
                        startPlayback(ch, currentSourceIndex)
                    }
                }
            }
        }
    }

    private val seekIndicatorHandler = Handler(Looper.getMainLooper())
    private var seekIndicatorHideRunnable: Runnable? = null
    private val recoveryHandler = Handler(Looper.getMainLooper())
    private val progressHandler = Handler(Looper.getMainLooper())
    private val channelNumberHandler = Handler(Looper.getMainLooper())
    private val channelNumberBuffer = StringBuilder()
    private val channelNumberCommit = Runnable { commitChannelNumber() }
    private val sleepTimerHandler = Handler(Looper.getMainLooper())
    private var sleepTimerRunnable: Runnable? = null

    private val resizeModes = listOf(
        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT,
        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private var resizeModeIndex = 0
    private val liveClockFormatter by lazy { SimpleDateFormat("HH:mm  •  yyyy/MM/dd", Locale.getDefault()) }
    private var lastLiveClockSecond = Long.MIN_VALUE
    private var lastLiveMetadataChannelId: String? = null

    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgressUi()
            observeSmartQualityGuard()
            checkForFreeze()
            progressHandler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_player)

        channel = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_CHANNEL, MergedChannel::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_CHANNEL)
        }
        isLiveContent = intent.getBooleanExtra(EXTRA_IS_LIVE, true)
        channelSurfScope = intent.getStringExtra(EXTRA_SURF_SCOPE)

        val ch = channel ?: run { finish(); return }

        findViewById<TextView>(R.id.txtContentType).text =
            getString(if (isLiveContent) R.string.content_type_live else R.string.content_type_video)
        findViewById<TextView>(R.id.txtContentTitle).text = ch.name
        findViewById<TextView>(R.id.txtContentSubtitle).text = ch.groupTitle
        findViewById<TextView>(R.id.txtPlayerClock).text = NetworkUtils.currentTimeFormatted(this)

        configureControlsForContent(ch)

        val prefs = com.brotv.player.data.PrefsManager(this)
        ParentalGate.requirePinIfNeeded(
            activity = this,
            category = ch.groupTitle,
            lockedCategories = prefs.lockedLiveCategories,
            onGranted = { initializePlayback(ch, prefs) },
            onDenied = { finish() }
        )
    }

    private fun initializePlayback(ch: MergedChannel, prefs: com.brotv.player.data.PrefsManager) {
        setupControls()
        retryAttemptsForCurrentSource = 0
        // Startup/zapping must not wait for a network probe. AutoPilot uses real playback history
        // synchronously (in-memory only), while the selected stream is measured after prepare().
        val bestUrl = AutoPilotEngine.bestKnownSource(ch.sourceUrls)
        val bestIndex = bestUrl?.let(ch.sourceUrls::indexOf)?.takeIf { it >= 0 } ?: 0
        startPlayback(ch, bestIndex)
        progressHandler.post(progressRunnable)
        if (isLiveContent) {
            loadEpgInfo(ch)
            lifecycleScope.launch {
                channelSurfList = loadScopedLiveChannels()
                updateLiveChromeMetadata(force = true)
            }
            showPlayerChromeTemporarily()
            findViewById<TextView>(R.id.btnLiveGuide).requestFocus()
        }
        // Diagnostics are internal-only; never expose the green debug overlay in normal playback.
        prefs.playerStatsOverlayEnabled = false
        findViewById<TextView>(R.id.txtPlayerStats).visibility = android.view.View.GONE
        registerNetworkCallback()
    }

    private fun registerNetworkCallback() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(networkCallback)
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                connectivityManager.registerNetworkCallback(request, networkCallback)
            }
        } catch (_: Exception) {
            // فشل التسجيل لا يجب أن يمنع تشغيل القناة؛ الاسترداد سيعتمد على أخطاء المشغل نفسه.
        }
    }

    private fun loadEpgInfo(ch: MergedChannel) {
        // CHANNEL+/CHANNEL- should never queue multiple provider/API requests. Paint cached XMLTV
        // immediately, refresh the XMLTV cache if its TTL allows it, then make at most one Xtream
        // fallback request only when the cache still has no programme for this channel.
        epgLookupJob?.cancel()
        epgLookupJob = lifecycleScope.launch {
            val cached = xmltvEpgRepository.currentCachedProgram(ch)
            if (channel?.id == ch.id) updateLiveEpgUi(cached)

            xmltvEpgRepository.refreshIfNeeded()
            val refreshed = xmltvEpgRepository.currentCachedProgram(ch)
            if (channel?.id != ch.id) return@launch
            if (refreshed != null) {
                updateLiveEpgUi(refreshed)
            } else if (cached == null) {
                updateLiveEpgUi(xmltvEpgRepository.currentProgram(ch))
            }
        }
    }

    private fun updateLiveEpgUi(program: EpgProgram?) {
        if (!isLiveContent) return
        if (program == null) {
            findViewById<TextView>(R.id.txtLiveProgram).setText(R.string.live_no_epg)
            findViewById<TextView>(R.id.txtLiveEpgStart).text = "--:--"
            findViewById<TextView>(R.id.txtLiveEpgEnd).text = "--:--"
            findViewById<android.widget.ProgressBar>(R.id.liveEpgProgress).progress = 0
            return
        }
        val text = getString(R.string.epg_program_with_time, program.title, program.startTime, program.endTime)
        findViewById<TextView>(R.id.txtContentSubtitle).text = text
        findViewById<TextView>(R.id.txtLiveProgram).text = program.title
        findViewById<TextView>(R.id.txtLiveEpgStart).text = program.startTime
        findViewById<TextView>(R.id.txtLiveEpgEnd).text = program.endTime
        findViewById<android.widget.ProgressBar>(R.id.liveEpgProgress).progress = program.progressPercent
    }

    private fun updateLiveChromeMetadata(force: Boolean = false) {
        if (!isLiveContent) return
        val activeChannelId = channel?.id
        if (force || activeChannelId != lastLiveMetadataChannelId) {
            val number = channelSurfList.indexOfFirst { it.id == activeChannelId }
            findViewById<TextView>(R.id.txtLiveChannelNumber).text =
                if (number >= 0) (number + 1).toString() else ""
            lastLiveMetadataChannelId = activeChannelId
        }

        // updateProgressUi runs twice a second for recovery/seek accuracy; formatting the wall
        // clock twice a second is wasted work on low-end TV boxes. Update it at most once/second.
        val now = System.currentTimeMillis()
        val second = now / 1_000L
        if (force || second != lastLiveClockSecond) {
            findViewById<TextView>(R.id.txtLiveClockDate).text = liveClockFormatter.format(Date(now))
            lastLiveClockSecond = second
        }
    }

    private fun setupControls() {
        findViewById<ImageView>(R.id.btnPlayPause).setOnClickListener { togglePlayPause() }

        findViewById<android.widget.FrameLayout>(R.id.btnForward15).setOnClickListener { seekBy(15_000) }
        findViewById<android.widget.FrameLayout>(R.id.btnRewind15).setOnClickListener { seekBy(-15_000) }

        findViewById<ImageView>(R.id.btnAspectRatio).setOnClickListener { cycleAspectRatio() }

        findViewById<ImageView>(R.id.btnSubtitles).setOnClickListener {
            player?.let { com.brotv.player.data.SubtitleController.showSubtitleTracksDialog(this, it) }
        }

        findViewById<ImageView>(R.id.btnGuide).setOnClickListener { openGuide() }
        findViewById<ImageView>(R.id.btnRecord).setOnClickListener { showDvrActions() }
        findViewById<ImageView>(R.id.btnRecord).setOnLongClickListener {
            startActivity(android.content.Intent(this, RecordingsActivity::class.java))
            true
        }
        findViewById<ImageView>(R.id.btnCloseGuide).setOnClickListener { closeGuide() }
        findViewById<ImageView>(R.id.btnStats).visibility = android.view.View.GONE
        findViewById<ImageView>(R.id.btnPip).setOnClickListener { enterPictureInPicture() }
        findViewById<ImageView>(R.id.btnSleepTimer).setOnClickListener { showSleepTimerDialog() }
        findViewById<ImageView>(R.id.btnPlayerSettings).setOnClickListener {
            startActivity(android.content.Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.btnGoLive).setOnClickListener { goToLiveEdge() }
        findViewById<TextView>(R.id.btnLiveGuide).setOnClickListener { openGuide() }
        findViewById<TextView>(R.id.btnLiveSource).setOnClickListener { showLiveSourceDialog() }
        findViewById<TextView>(R.id.btnLiveQuality).setOnClickListener { showQuickLiveQualityDialog() }
        findViewById<TextView>(R.id.btnLiveFavorite).setOnClickListener { toggleCurrentLiveFavorite() }

        findViewById<SeekBar>(R.id.seekBar).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val p = player ?: return
                if (isLiveContent) {
                    val state = evaluateLiveTimeshift(p)
                    if (!state.supported) return
                    p.seekTo(LiveTimeshiftPolicy.clampSeek(progress.toLong(), state.windowDurationMs))
                } else {
                    p.seekTo(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }


    private fun configureControlsForContent(ch: MergedChannel) {
        val live = isLiveContent
        findViewById<android.view.View>(R.id.progressRow).visibility = if (live) android.view.View.GONE else android.view.View.VISIBLE
        findViewById<android.view.View>(R.id.transportControlsRow).visibility = android.view.View.VISIBLE
        findViewById<android.view.View>(R.id.liveControlsRow).visibility = if (live) android.view.View.VISIBLE else android.view.View.GONE
        findViewById<ImageView>(R.id.btnNextEpisode).visibility = if (live) android.view.View.GONE else android.view.View.VISIBLE
        findViewById<ImageView>(R.id.btnPreviousEpisode).visibility = if (live) android.view.View.GONE else android.view.View.VISIBLE
        if (live) {
            findViewById<TextView>(R.id.txtLiveChannelName).text = ch.name
            findViewById<TextView>(R.id.txtLiveProgram).text = ch.groupTitle
            updateLiveSourceLabel()
            updateLiveQualityButton()
            updateLiveFavoriteButton()
            updateLiveChromeMetadata()
        }
    }

    private suspend fun loadScopedLiveChannels(): List<MergedChannel> {
        val current = channel ?: return emptyList()
        val prefs = com.brotv.player.data.PrefsManager(this)
        val scope = ChannelSurfScopePolicy.resolve(channelSurfScope, current.groupTitle)
        channelSurfScope = scope
        val favorites = prefs.favoriteChannelIds
        val channels = com.brotv.player.data.MergedChannelRepository(this).loadMergedChannels()
            .asSequence()
            .filter { it.id !in prefs.hiddenChannelIds }
            .filter { it.groupTitle !in prefs.hiddenLiveCategories }
            .filter { ChannelSurfScopePolicy.accepts(scope, it.groupTitle, it.id in favorites) }
            .toList()
        return channels.ifEmpty { listOf(current) }
    }

    private fun showLiveSourceDialog() {
        if (!isLiveContent) return
        val ch = channel ?: return
        if (ch.sourceUrls.size <= 1) {
            Toast.makeText(this, R.string.no_alternative_sources, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = ch.sourceUrls.mapIndexed { index, _ ->
            val base = getString(R.string.source_number, index + 1)
            if (index == currentSourceIndex) "$base • ${currentLiveQualityLabel()}" else base
        }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.choose_source)
            .setSingleChoiceItems(labels, currentSourceIndex) { dialog, which ->
                if (which != currentSourceIndex) {
                    resetRecoveryStateForSelection()
                    failedSourceUrlsThisSession.clear()
                    liveAutomaticAlternativeUsed = true
                    forceStatsResetOnNextStart = true
                    startPlayback(ch, which)
                    updateLiveSourceLabel()
                }
                dialog.dismiss()
                showPlayerChromeTemporarily()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
            .enableTvListFocus(currentSourceIndex)
    }

    private fun showQuickLiveQualityDialog() {
        if (!isLiveContent) return
        val prefs = PrefsManager(this)
        val labels = arrayOf(
            getString(R.string.quality_auto),
            getString(R.string.quality_source),
            getString(R.string.quality_1080p),
            getString(R.string.quality_720p)
        )
        val values = arrayOf("AUTO", "SOURCE", "FHD_1080P", "HD_720P")
        val current = values.indexOf(prefs.qualityMode).coerceAtLeast(0)
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.quality_label)
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.qualityMode = values[which]
                player?.let { PlayerEngine.applySmartQualityCeiling(it, currentQualityMode(), SmartQualityGuard.Ceiling.USER_MAX) }
                updateLiveSourceLabel()
                updateLiveQualityButton()
                dialog.dismiss()
                showPlayerChromeTemporarily()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
            .enableTvListFocus(current)
    }

    private fun updateLiveQualityButton() {
        if (!isLiveContent) return
        val label = when (currentQualityMode()) {
            PlayerEngine.QualityMode.AUTO -> getString(R.string.quality_auto)
            PlayerEngine.QualityMode.SOURCE -> getString(R.string.quality_source)
            PlayerEngine.QualityMode.UHD_4K -> "4K"
            PlayerEngine.QualityMode.FHD_1080P -> "1080p"
            PlayerEngine.QualityMode.HD_720P -> "720p"
        }
        findViewById<TextView>(R.id.btnLiveQuality).text = label
    }

    private fun toggleCurrentLiveFavorite() {
        val ch = channel ?: return
        val prefs = PrefsManager(this)
        prefs.toggleChannelFavorite(ch.id)
        updateLiveFavoriteButton()
    }

    private fun updateLiveFavoriteButton() {
        if (!isLiveContent) return
        val ch = channel ?: return
        val button = findViewById<TextView>(R.id.btnLiveFavorite)
        val favorite = ch.id in PrefsManager(this).favoriteChannelIds
        button.isSelected = favorite
        button.setBackgroundResource(if (favorite) R.drawable.preview_action_selector_gold else R.drawable.preview_action_selector)
    }

    private fun currentLiveQualityLabel(): String = when {
        videoWidth >= 3000 || videoHeight >= 2000 -> "4K"
        videoWidth >= 1900 || videoHeight >= 1000 -> "1080p"
        videoWidth >= 1200 || videoHeight >= 700 -> "720p"
        videoWidth > 0 || videoHeight > 0 -> "SD"
        else -> getString(R.string.quality_detecting)
    }

    private fun updateLiveSourceLabel() {
        if (!isLiveContent) return
        val ch = channel ?: return
        val sourceCount = ch.sourceUrls.size.coerceAtLeast(1)
        val sourceNumber = (currentSourceIndex + 1).coerceIn(1, sourceCount)
        findViewById<TextView>(R.id.btnLiveSource).text =
            getString(R.string.live_source_status, currentLiveQualityLabel(), sourceNumber, sourceCount)
        findViewById<TextView>(R.id.txtLiveChannelName).text = ch.name
        updateLiveChromeMetadata()
    }

    private fun showPlayerChromeTemporarily() {
        if (!isLiveContent) {
            setPlayerChromeVisible(true)
            return
        }
        setPlayerChromeVisible(true)
        chromeHandler.removeCallbacks(hideChromeRunnable)
        chromeHandler.postDelayed(hideChromeRunnable, LIVE_CHROME_TIMEOUT_MS)
    }

    private fun showSleepTimerDialog() {
        val minutes = intArrayOf(0, 30, 60, 90, 120)
        val labels = minutes.map { value ->
            if (value == 0) getString(R.string.sleep_timer_off)
            else getString(R.string.sleep_timer_minutes, value)
        }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.sleep_timer)
            .setItems(labels) { _, which -> scheduleSleepTimer(minutes[which]) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun scheduleSleepTimer(minutes: Int) {
        sleepTimerRunnable?.let(sleepTimerHandler::removeCallbacks)
        sleepTimerRunnable = null
        if (minutes <= 0) {
            Toast.makeText(this, R.string.sleep_timer_cancelled, Toast.LENGTH_SHORT).show()
            return
        }
        val task = Runnable {
            player?.pause()
            Toast.makeText(this, R.string.sleep_timer_finished, Toast.LENGTH_SHORT).show()
            finish()
        }
        sleepTimerRunnable = task
        sleepTimerHandler.postDelayed(task, minutes * 60_000L)
        Toast.makeText(this, getString(R.string.sleep_timer_set, minutes), Toast.LENGTH_SHORT).show()
    }


    // ---------- DVR / scheduled recording ----------

    private val dvrRepository by lazy { com.brotv.player.dvr.DvrRepository(this) }

    private fun showDvrActions() {
        if (!isLiveContent) {
            startActivity(android.content.Intent(this, RecordingsActivity::class.java))
            return
        }
        val currentChannel = channel ?: return
        lifecycleScope.launch {
            val active = dvrRepository.getActiveForChannel(currentChannel.id)
            if (active != null) {
                androidx.appcompat.app.AlertDialog.Builder(this@FullPlayerActivity, R.style.BroTvDialog)
                    .setTitle(R.string.dvr_active_title)
                    .setMessage(R.string.dvr_active_message)
                    .setPositiveButton(R.string.dvr_stop) { _, _ ->
                        com.brotv.player.dvr.DvrRecordingService.stop(this@FullPlayerActivity, active.id)
                    }
                    .setNeutralButton(R.string.dvr_open_recordings) { _, _ ->
                        startActivity(android.content.Intent(this@FullPlayerActivity, RecordingsActivity::class.java))
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
                return@launch
            }

            val currentProgram = xmltvEpgRepository.currentProgram(currentChannel)
            val labels = mutableListOf<String>()
            val actions = mutableListOf<() -> Unit>()
            labels += getString(R.string.dvr_record_now)
            actions += { startImmediateRecording(currentChannel, null) }
            if (currentProgram != null && currentProgram.endTimeMs > System.currentTimeMillis()) {
                labels += getString(R.string.dvr_record_current_program)
                actions += { startImmediateRecording(currentChannel, currentProgram) }
            }
            labels += getString(R.string.dvr_schedule_program)
            actions += { showScheduleFromEpg(currentChannel) }
            labels += getString(R.string.dvr_open_recordings)
            actions += { startActivity(android.content.Intent(this@FullPlayerActivity, RecordingsActivity::class.java)) }

            androidx.appcompat.app.AlertDialog.Builder(this@FullPlayerActivity, R.style.BroTvDialog)
                .setTitle(R.string.dvr_recordings_title)
                .setItems(labels.toTypedArray()) { _, which -> actions[which].invoke() }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private fun startImmediateRecording(ch: MergedChannel, program: com.brotv.player.model.EpgProgram?) {
        lifecycleScope.launch {
            try {
                val title = program?.title?.takeIf(String::isNotBlank) ?: getString(R.string.dvr_manual_title, ch.name)
                val stopAt = program?.endTimeMs?.takeIf { it > System.currentTimeMillis() } ?: 0L
                val row = dvrRepository.createImmediate(ch, title, stopAt)
                com.brotv.player.dvr.DvrRecordingService.start(this@FullPlayerActivity, row.id)
                Toast.makeText(this@FullPlayerActivity, R.string.dvr_record_requested, Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this@FullPlayerActivity, R.string.primary_resource_unavailable, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showScheduleFromEpg(ch: MergedChannel) {
        lifecycleScope.launch {
            xmltvEpgRepository.refreshIfNeeded(force = true)
            val now = System.currentTimeMillis()
            val programs = xmltvEpgRepository.programs(ch, now, now + 48L * 60L * 60L * 1000L, 50)
                .filter { it.endTimeMs > now && it.startTimeMs > 0L && it.endTimeMs > it.startTimeMs }
            if (programs.isEmpty()) {
                Toast.makeText(this@FullPlayerActivity, R.string.dvr_no_epg, Toast.LENGTH_LONG).show()
                return@launch
            }
            val labels = programs.map {
                getString(R.string.dvr_schedule_time, it.startTime, it.endTime) + "  •  " + it.title
            }.toTypedArray()
            androidx.appcompat.app.AlertDialog.Builder(this@FullPlayerActivity, R.style.BroTvDialog)
                .setTitle(R.string.dvr_schedule_title)
                .setItems(labels) { _, which ->
                    val selected = programs[which]
                    lifecycleScope.launch {
                        try {
                            if (selected.startTimeMs <= System.currentTimeMillis()) {
                                startImmediateRecording(ch, selected)
                            } else {
                                val row = dvrRepository.createScheduled(
                                    ch,
                                    selected.title,
                                    selected.startTimeMs,
                                    selected.endTimeMs
                                )
                                com.brotv.player.dvr.DvrScheduler.schedule(
                                    this@FullPlayerActivity,
                                    row.id,
                                    row.scheduledStartMs,
                                    row.scheduledEndMs
                                )
                                Toast.makeText(this@FullPlayerActivity, R.string.dvr_scheduled, Toast.LENGTH_SHORT).show()
                                maybeRequestExactAlarmPermission()
                            }
                        } catch (_: Exception) {
                            Toast.makeText(this@FullPlayerActivity, R.string.backup_export_failed, Toast.LENGTH_LONG).show()
                        }
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private fun maybeRequestExactAlarmPermission() {
        val permissionIntent = com.brotv.player.dvr.DvrScheduler.exactAlarmPermissionIntent(this) ?: return
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.dvr_exact_alarm_title)
            .setMessage(R.string.dvr_exact_alarm_message)
            .setPositiveButton(R.string.dvr_open_alarm_settings) { _, _ -> runCatching { startActivity(permissionIntent) } }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------- Player Diagnostics ----------

    private fun toggleStatsOverlay() {
        val overlay = findViewById<TextView>(R.id.txtPlayerStats)
        val newState = overlay.visibility != android.view.View.VISIBLE
        overlay.visibility = if (newState) android.view.View.VISIBLE else android.view.View.GONE
        com.brotv.player.data.PrefsManager(this).playerStatsOverlayEnabled = newState
        if (newState) refreshStatsOverlay()
    }

    private fun refreshStatsOverlay() {
        val overlay = findViewById<TextView>(R.id.txtPlayerStats)
        if (overlay.visibility != android.view.View.VISIBLE) return
        val bitrateMbps = String.format(Locale.US, "%.2f", lastBitrateEstimate / 1_000_000.0)
        val resourceStatus = ResourceGuard.status(resourceLease?.providerKey)
        overlay.text = buildString {
            append("Video: $lastVideoInfo\n")
            append("Audio: $lastAudioInfo\n")
            append("Video bitrate: ${videoBitrate / 1_000_000.0} Mbps\n")
            append("Bandwidth: ${bitrateMbps} Mbps\n")
            append("HDR: $hdrType\n")
            append("Decoder: ${if (videoDecoderName.isBlank()) "..." else videoDecoderName} ")
            append(if (decoderIsHardware) "(HW)\n" else "(SW)\n")
            append("Audio output: ${audioOutputInfo.description}\n")
            append("Buffer duration: ${currentBufferDurationMs}ms\n")
            append("Rebuffer: $rebufferCount / ${totalRebufferDurationMs}ms ")
            append("(avg ${averageRebufferDurationMs}ms)\n")
            append("Dropped frames: $droppedFrames\n")
            append("TTFF: ${if (lastTtffMs >= 0) "${lastTtffMs}ms" else "..."}\n")
            append("Channel switch: ${if (lastChannelSwitchTimeMs >= 0) "${lastChannelSwitchTimeMs}ms" else "..."}\n")
            append("Switch avg/med/worst: ${channelSwitchSummary()}\n")
            append("Display refresh: ${currentDisplayRefreshRate()}Hz\n")
            append("Requested FPS: ${if (pendingFrameRate > 0) pendingFrameRate else lastAppliedFrameRate}\n")
            append("Health: ${currentHealthScore()}/100\n")
            append("Source: ${currentSourceIndex + 1}  Failovers: $failoverCount\n")
            append("Connections: ${resourceStatus.localConnections} local")
            if (resourceStatus.providerEstimatedConnections != null) {
                append(" • provider ${resourceStatus.providerEstimatedConnections}")
                resourceStatus.providerMaxConnections?.let { append("/$it") }
            }
            append(" • decoders ${resourceStatus.activeVideoDecoders}\n")
            val guardState = if (com.brotv.player.data.PrefsManager(this@FullPlayerActivity).smartQualityGuardEnabled) "ON" else "OFF"
            append("Quality guard: $guardState → ${smartQualityCeiling.label}")
            if (smartQualityLastReason.isNotBlank()) append(" (${smartQualityLastReason})")
            append("\n")
            val timeshift = if (!isLiveContent) "N/A" else if (liveTimeshiftState.supported) {
                if (liveTimeshiftState.atLiveEdge) "Native LIVE" else "Native -${formatTime(liveTimeshiftState.behindLiveMs)}"
            } else "Unavailable"
            append("Timeshift: $timeshift\n")
            append("Buffer: ${savedBufferProfileName()} → ${currentBufferProfile().name}")
        }
    }

    /**
     * Match Frame Rate (بند 4): يطلب من Surface نفسه تغيير معدل التحديث ليطابق الفيديو،
     * باستخدام Surface.setFrameRate الرسمية (متوفرة من Android 11 / API 30 فأعلى).
     * على الإصدارات الأقدم ما فيه API عام مناسب، فنتجاهلها بدل ما نكسر التشغيل.
     */
    private fun applyMatchFrameRate(videoFrameRate: Float) {
        if (videoFrameRate <= 0) return
        val mode = com.brotv.player.data.PrefsManager(this).matchFrameRateMode
        if (mode == "OFF") return

        val targetFrameRate = normalizeFrameRate(videoFrameRate) ?: return
        // AUTO يتجنب طلب تغيير مزعج لمعدل غير قياسي. ALWAYS يقبل أي معدل صالح.
        if (mode == "AUTO" && !isCommonFrameRate(targetFrameRate)) return
        if (abs(lastAppliedFrameRate - targetFrameRate) < 0.01f) return

        pendingFrameRate = targetFrameRate
        frameRateHandler.removeCallbacks(frameRateRunnable)
        frameRateHandler.postDelayed(frameRateRunnable, FRAME_RATE_DEBOUNCE_MS)
    }

    /**
     * يبدّل دقة خرج HDMI الفعلية لتطابق المحتوى الحالي (مثلاً 4K حقيقي لا مجرد تكبير
     * داخلي)، وهذا هو اللي يخلي التلفزيون (زي LG) يعرض إشعار "4K" الحقيقي على شاشته
     * لأنه إشعار مبني على إشارة HDMI الواصلة له فعلياً. يشتغل فقط من Android 6 (API 23)
     * فأعلى؛ على الأجهزة الأقدم يتجاهل الطلب بهدوء (`DisplayModeSwitcher` نفسها تتحقق).
     * مربوط بنفس إعداد "مطابقة معدل التحديث" — لو المستخدم عطّله (OFF) ما نبدّل الدقة
     * أيضاً، حتى لا نفاجئه بتبديلات HDMI ما يبيها.
     */
    private fun applyBestDisplayResolution(width: Int, height: Int, frameRate: Float) {
        if (width <= 0 || height <= 0) return
        val mode = com.brotv.player.data.PrefsManager(this).matchFrameRateMode
        if (mode == "OFF") return
        if (width == lastAppliedDisplayModeWidth && height == lastAppliedDisplayModeHeight) return
        lastAppliedDisplayModeWidth = width
        lastAppliedDisplayModeHeight = height
        val appliedMode = DisplayModeSwitcher.applyBestDisplayMode(this, width, height, frameRate)
        notifyIfRealUhdActivated(width, height, appliedMode)
    }

    /**
     * يُظهر تنبيه بسيط (Toast) فقط لما يصير المحتوى 4K فعلاً *و* خرج HDMI للجهاز انبدّل
     * فعلياً لدقة 4K حقيقية — نفس اللحظة اللي بيعرض فيها التلفزيون (زي LG) إشعار "4K"
     * الخاص فيه على شاشته. ما نعرض أي شيء لقنوات/أفلام أقل من 4K حتى لا نزعج المستخدم
     * برسالة كل قناة.
     */
    private fun notifyIfRealUhdActivated(contentWidth: Int, contentHeight: Int, appliedMode: DisplayModeSwitcher.ModeInfo?) {
        val contentIsUhd = contentWidth >= UHD_MIN_WIDTH && contentHeight >= UHD_MIN_HEIGHT
        val outputIsUhd = appliedMode != null &&
            appliedMode.width >= UHD_MIN_WIDTH && appliedMode.height >= UHD_MIN_HEIGHT
        if (!contentIsUhd || !outputIsUhd) return
        Toast.makeText(this, getString(R.string.uhd_4k_activated), Toast.LENGTH_SHORT).show()
    }

    private fun commitMatchFrameRate(frameRate: Float) {
        if (frameRate <= 0) return
        val mode = com.brotv.player.data.PrefsManager(this).matchFrameRateMode
        if (mode == "OFF") return
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val surfaceView = findViewById<PlayerView>(R.id.playerView).videoSurfaceView
            val surface = (surfaceView as? android.view.SurfaceView)?.holder?.surface ?: return
            try {
                surface.setFrameRate(frameRate, android.view.Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
                lastAppliedFrameRate = frameRate
            } catch (e: Exception) {
                // لو التلفزيون/الجهاز يرفض القيمة لأي سبب، نكمل بالتشغيل الطبيعي بدون تعديل
            }
        }
    }

    private fun normalizeFrameRate(value: Float): Float? {
        if (!value.isFinite() || value <= 0f) return null
        val commonRates = floatArrayOf(23.976f, 24f, 25f, 29.97f, 30f, 50f, 59.94f, 60f)
        val nearest = commonRates.minByOrNull { abs(it - value) } ?: return value
        return if (abs(nearest - value) <= 0.15f) nearest else value
    }

    private fun isCommonFrameRate(value: Float): Boolean =
        floatArrayOf(23.976f, 24f, 25f, 29.97f, 30f, 50f, 59.94f, 60f)
            .any { abs(it - value) <= 0.01f }

    private fun currentQualityMode(): com.brotv.player.player.PlayerEngine.QualityMode {
        val saved = com.brotv.player.data.PrefsManager(this).qualityMode
        return try {
            com.brotv.player.player.PlayerEngine.QualityMode.valueOf(saved)
        } catch (e: Exception) {
            com.brotv.player.player.PlayerEngine.QualityMode.SOURCE
        }
    }

    private fun currentAudioOutputMode(): AudioOutputMode {
        val saved = com.brotv.player.data.PrefsManager(this).audioOutputMode
        return try {
            AudioOutputMode.valueOf(saved)
        } catch (_: Exception) {
            AudioOutputMode.AUTO
        }
    }

    private fun currentBufferProfile(): com.brotv.player.player.PlayerEngine.BufferProfile {
        val saved = com.brotv.player.data.PrefsManager(this).bufferProfile
        return try {
            if (saved == "AUTO") dynamicBufferController.currentProfile
            else com.brotv.player.player.PlayerEngine.BufferProfile.valueOf(saved)
        } catch (e: Exception) {
            com.brotv.player.player.PlayerEngine.BufferProfile.BALANCED
        }
    }

    private fun savedBufferProfileName(): String =
        com.brotv.player.data.PrefsManager(this).bufferProfile

    private fun currentDisplayRefreshRate(): String {
        val refreshRate = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            display?.refreshRate ?: 0f
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.refreshRate
        }
        return if (refreshRate > 0f) String.format(Locale.US, "%.2f", refreshRate) else "?"
    }

    private fun currentHealthScore(): Int =
        StreamHealthScorer.score(
            StreamHealthSnapshot(
                width = videoWidth,
                height = videoHeight,
                fps = actualFps,
                bitrate = videoBitrate,
                ttffMs = lastTtffMs,
                rebufferCount = rebufferCount,
                rebufferDurationMs = totalRebufferDurationMs,
                playbackErrors = playbackErrors,
                droppedFrames = droppedFrames,
                successfulStarts = successfulStarts,
                serverLatencyMs = currentSourceLatencyMs
            )
        )

    private fun channelSwitchSummary(): String {
        if (channelSwitchSamplesMs.isEmpty()) return "..."
        val values = channelSwitchSamplesMs.toList().sorted()
        val average = values.average().toLong()
        val median = if (values.size % 2 == 1) {
            values[values.size / 2]
        } else {
            (values[values.size / 2 - 1] + values[values.size / 2]) / 2
        }
        return "${average}ms / ${median}ms / ${values.last()}ms"
    }

    // ---------- التشغيل (بند "Channel Zapping": نعيد استخدام نفس المشغل، ما نبنيه من الصفر كل قناة) ----------

    private fun startPlayback(ch: MergedChannel, sourceIndex: Int, forceRecreate: Boolean = false) {
        // Any explicit/new playback start invalidates older delayed retries so network/player errors
        // cannot build up a retry storm against the same provider.
        playbackRetryGeneration++
        val url = ch.sourceUrls.getOrNull(sourceIndex) ?: return
        val requestToken = ++playbackResourceRequestToken
        val providerKey = ResourceGuard.providerKeyFor(url)
        val reusableLease = resourceLease?.takeIf { it.providerKey == providerKey }

        if (reusableLease != null) {
            reusableLease.updateKind(ResourceBudget.SessionKind.PRIMARY_PLAYBACK)
            startPlaybackWithGrantedResource(ch, sourceIndex, forceRecreate)
            return
        }

        // Switching provider: close the old network stream before reserving the next slot. The
        // ExoPlayer object itself stays reusable until the new provider lease is granted.
        player?.stop()
        player?.clearMediaItems()
        resourceLease?.release()
        resourceLease = null
        findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = android.view.View.VISIBLE

        lifecycleScope.launch {
            when (val result = ResourceGuard.acquire(
                context = this@FullPlayerActivity,
                streamUrl = url,
                kind = ResourceBudget.SessionKind.PRIMARY_PLAYBACK
            )) {
                is ResourceGuard.AcquireResult.Granted -> {
                    if (requestToken != playbackResourceRequestToken || isFinishing || isDestroyed) {
                        result.lease.release()
                        return@launch
                    }
                    resourceLease = result.lease
                    startPlaybackWithGrantedResource(ch, sourceIndex, forceRecreate)
                }
                is ResourceGuard.AcquireResult.Denied -> {
                    if (requestToken != playbackResourceRequestToken) return@launch
                    findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = android.view.View.GONE
                    handleResourceGuardDenied(ch, url, result)
                }
            }
        }
    }

    private fun handleResourceGuardDenied(
        ch: MergedChannel,
        deniedUrl: String,
        result: ResourceGuard.AcquireResult.Denied
    ) {
        when (result.reason) {
            ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT -> {
                failedSourceUrlsThisSession.add(deniedUrl)
                if (isLiveContent) {
                    tryOneLiveAlternativeOrRequireManual(ch, deniedUrl)
                } else if (ch.sourceUrls.any { it !in failedSourceUrlsThisSession }) {
                    showFailoverAlert(getString(R.string.provider_connection_limit_trying_alternative))
                    tryNextSourceOnFailure(ch, deniedUrl)
                } else {
                    Toast.makeText(
                        this,
                        getString(R.string.provider_connection_limit_reached),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            ResourceBudget.DenialReason.DEVICE_DECODER_LIMIT,
            ResourceBudget.DenialReason.DEVICE_MEMORY_PRESSURE -> {
                Toast.makeText(
                    this,
                    getString(R.string.primary_resource_unavailable),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun startPlaybackWithGrantedResource(
        ch: MergedChannel,
        sourceIndex: Int,
        forceRecreate: Boolean = false
    ) {
        val url = ch.sourceUrls.getOrNull(sourceIndex) ?: return
        // أي بداية تشغيل حقيقية (تبديل قناة/مصدر/إعادة محاولة) تنهي وضع الإعادة للخلف
        // المحلي تلقائياً، حتى لو المستدعي نسي يمرّ عبر exitLocalRewindMode().
        isPlayingFromLocalBuffer = false
        playbackStartRequestedAt = System.currentTimeMillis()
        val sourceChanged = currentSourceUrl != null && currentSourceUrl != url
        val resetQualityGuardSession = forceStatsResetOnNextStart || sourceChanged
        if (forceStatsResetOnNextStart) {
            resetPlaybackStats()
            dynamicBufferController.reset()
            channelSwitchStartMs = playbackStartRequestedAt
            forceStatsResetOnNextStart = false
        } else if (sourceChanged) {
            // كل مصدر يحتفظ بإحصاءاته الخاصة؛ لا يرث أخطاء/Rebuffer المصدر السابق عند Failover.
            resetSourcePlaybackStats()
        } else {
            lastTtffMs = -1
            hasReceivedFirstVideoFrame = false
            hasExpectedVideoTrack = false
            audioStarted = false
            firstVideoFrameAtMs = 0L
            lastRenderedVideoFrameAtMs = playbackStartRequestedAt
        }
        frameRateHandler.removeCallbacks(frameRateRunnable)
        pendingFrameRate = 0f
        freezeRecoveryTriggered = false
        lastKnownPositionMs = -1
        positionUnchangedSinceMs = 0L
        currentSourceIndex = sourceIndex
        currentSourceUrl = url
        updateLiveSourceLabel()
        currentSourceLatencyMs = StreamHealthRegistry.snapshot(url)?.serverLatencyMs ?: -1L
        channel = ch
        StreamHealthRegistry.recordStart(url)
        if (isLiveContent) updateRollingBufferForChannel(ch.id, url) else stopRollingBuffer()
        // Do not open a second HTTP connection to the same live stream while ExoPlayer is
        // starting. Some IPTV providers count that probe as another active connection, and on
        // constrained servers it also competes with the real playback request. Startup health is
        // therefore learned from actual playback telemetry and the last cached measurement.
        sourceProbeJob?.cancel()
        sourceProbeJob = null

        val existingPlayer = player
        val resumePositionMs = if (forceRecreate && !isLiveContent) {
            existingPlayer?.currentPosition?.takeIf { it > 0L }
        } else null
        val exoPlayer = if (existingPlayer != null && !forceRecreate) {
            // إعادة استخدام حقيقية: نفس الـDecoder/Surface يبقوا شغالين، بدون Release كامل ولا مستمعات مكررة
            existingPlayer.stop()
            existingPlayer.clearMediaItems()
            existingPlayer
        } else {
            existingPlayer?.release()
            createFreshPlayer()
        }

        if (resetQualityGuardSession) {
            smartQualityGuard.reset()
            smartQualityCeiling = SmartQualityGuard.Ceiling.USER_MAX
            smartQualityLastReason = ""
        }
        // إذا أُعيد إنشاء ExoPlayer لنفس المصدر بسبب Recovery/Dynamic Buffer، نحافظ على
        // سقف الحارس الحالي بدل العودة فجأة إلى 4K/Source والتسبب في نفس الضغط من جديد.
        PlayerEngine.applySmartQualityCeiling(exoPlayer, currentQualityMode(), smartQualityCeiling)

        exoPlayer.setMediaItem(MediaItem.fromUri(url))
        if (resumePositionMs != null) exoPlayer.seekTo(resumePositionMs)
        exoPlayer.prepare()
        com.brotv.player.data.SubtitleController.enableAutoSubtitles(exoPlayer)
        exoPlayer.playWhenReady = true
    }

    /** ينشئ مشغّل جديد بالكامل ويعلّق كل المستمعات عليه مرة وحدة بس (يُستدعى فقط أول مرة أو عند Recovery أخير). */
    private fun createFreshPlayer(): ExoPlayer {
        val exoPlayer = PlayerEngine.buildPlayer(
            this,
            currentBufferProfile(),
            currentQualityMode(),
            currentAudioOutputMode()
        )
        player = exoPlayer
        findViewById<PlayerView>(R.id.playerView).player = exoPlayer

        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility =
                    if (state == Player.STATE_BUFFERING) android.view.View.VISIBLE else android.view.View.GONE
                when (state) {
                    Player.STATE_BUFFERING -> beginRebufferIfNeeded()
                    Player.STATE_READY -> finishRebufferIfNeeded()
                    Player.STATE_IDLE, Player.STATE_ENDED -> finishRebufferIfNeeded()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (isPlayingFromLocalBuffer) {
                    // خطأ بملف الإعادة المحلي نفسه (مو بث الشبكة الحي) — منطق الاسترجاع
                    // بالأسفل مبني بالكامل على افتراض رابط قناة مباشرة، فما نمرره له.
                    // أبسط وأسلم رد فعل: نرجع للبث المباشر مباشرة.
                    Toast.makeText(
                        this@FullPlayerActivity,
                        getString(R.string.live_rewind_playback_error),
                        Toast.LENGTH_SHORT
                    ).show()
                    exitLocalRewindMode()
                    return
                }
                // نقرأ القناة/الرابط الحاليين من المتغيّرات نفسها وقت الفشل، مو من قيمة قديمة
                // محبوسة بالـclosure — مهم لأن نفس المشغل صار يُعاد استخدامه لعدة قنوات بالتوالي.
                val ch = channel ?: return
                val url = ch.sourceUrls.getOrNull(currentSourceIndex) ?: return
                playbackErrors++
                StreamHealthRegistry.recordError(url)
                if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED) {
                    DecoderBlacklist.recordFailure(
                        this@FullPlayerActivity,
                        currentVideoCodec.substringAfterLast('.'),
                        videoDecoderName
                    )
                    // Recreate ExoPlayer so the decoder ranking/blacklist is actually re-evaluated.
                    // Reusing the same player here can select the exact decoder that just crashed.
                    val maxDecoderRetries = if (isLiveContent) 1 else MAX_DECODER_RECOVERY_RETRIES
                    if (retryAttemptsForCurrentSource < maxDecoderRetries) {
                        schedulePlaybackRetry(
                            ch,
                            currentSourceIndex,
                            QUICK_RETRY_DELAY_MS,
                            forceRecreate = true
                        )
                    } else if (isLiveContent) {
                        tryOneLiveAlternativeOrRequireManual(ch, url)
                    } else {
                        tryNextSourceOnFailure(ch, url)
                    }
                    return
                }
                if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED) {
                    DecoderBlacklist.recordFailure(
                        this@FullPlayerActivity,
                        currentVideoCodec.substringAfterLast('.'),
                        videoDecoderName
                    )
                }
                handlePlaybackError(ch, url, error)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                findViewById<ImageView>(R.id.btnPlayPause).setImageResource(
                    if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                )
                updateProgressUi()
            }

            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
                updateProgressUi()
            }
        })

        exoPlayer.addAnalyticsListener(object : AnalyticsListener {
            override fun onRenderedFirstFrame(eventTime: AnalyticsListener.EventTime, output: Any, renderTimeMs: Long) {
                lastTtffMs = System.currentTimeMillis() - playbackStartRequestedAt
                // نجاح التشغيل الحقيقي يبدأ دورة محاولات جديدة لهذا المصدر.
                retryAttemptsForCurrentSource = 0
                hasReceivedFirstVideoFrame = true
                firstVideoFrameAtMs = System.currentTimeMillis()
                lastRenderedVideoFrameAtMs = firstVideoFrameAtMs
                blackScreenRecoveryAttempts = 0
                blackScreenRecoveryTriggered = false
                successfulStarts++
                if (channelSwitchStartMs > 0L) {
                    lastChannelSwitchTimeMs = System.currentTimeMillis() - channelSwitchStartMs
                    if (channelSwitchSamplesMs.size >= MAX_SWITCH_SAMPLES) {
                        channelSwitchSamplesMs.removeFirst()
                    }
                    channelSwitchSamplesMs.addLast(lastChannelSwitchTimeMs)
                }
                val url = channel?.sourceUrls?.getOrNull(currentSourceIndex)
                if (url != null) {
                    StreamHealthRegistry.recordSuccess(url, currentSnapshot())
                }
                refreshStatsOverlay()
            }

            override fun onVideoInputFormatChanged(
                eventTime: AnalyticsListener.EventTime,
                format: androidx.media3.common.Format,
                decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?
            ) {
                videoWidth = format.width
                videoHeight = format.height
                actualFps = format.frameRate
                videoBitrate = format.bitrate.toLong().coerceAtLeast(0L)
                currentVideoCodec = format.sampleMimeType.orEmpty()
                hasExpectedVideoTrack = true
                hdrType = detectHdrType(format)
                val fps = if (format.frameRate > 0) "${formatFrameRate(format.frameRate)}fps" else ""
                lastVideoInfo = "${format.width}x${format.height} $fps  ${format.sampleMimeType?.substringAfterLast('.') ?: ""}"
                applyMatchFrameRate(format.frameRate)
                applyBestDisplayResolution(format.width, format.height, format.frameRate)
                updateLiveSourceLabel()
                refreshStatsOverlay()
            }

            override fun onAudioInputFormatChanged(
                eventTime: AnalyticsListener.EventTime,
                format: androidx.media3.common.Format,
                decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?
            ) {
                audioStarted = true
                audioOutputInfo = AudioOutputController.inspect(
                    this@FullPlayerActivity,
                    format.sampleMimeType,
                    currentAudioOutputMode()
                )
                lastAudioInfo = "${format.sampleMimeType?.substringAfterLast('.') ?: ""}  ${format.sampleRate}Hz  ${format.channelCount}ch"
                refreshStatsOverlay()
            }

            override fun onVideoFrameProcessingOffset(
                eventTime: AnalyticsListener.EventTime,
                totalVideoFrameProcessingOffsetUs: Long,
                frameCount: Int
            ) {
                if (frameCount > 0) {
                    lastRenderedVideoFrameAtMs = System.currentTimeMillis()
                }
            }

            override fun onVideoDecoderInitialized(
                eventTime: AnalyticsListener.EventTime,
                decoderName: String,
                initializedTimestampMs: Long,
                initializationDurationMs: Long
            ) {
                videoDecoderName = decoderName
                decoderIsHardware = !decoderName.startsWith("OMX.google") &&
                    !decoderName.startsWith("c2.android")
                refreshStatsOverlay()
            }

            override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
                this@FullPlayerActivity.droppedFrames += droppedFrames
                observeSmartQualityGuard()
                refreshStatsOverlay()
            }

            override fun onBandwidthEstimate(eventTime: AnalyticsListener.EventTime, totalLoadTimeMs: Int, totalBytesLoaded: Long, bitrateEstimate: Long) {
                lastBitrateEstimate = bitrateEstimate
                observeDynamicBuffer()
                observeSmartQualityGuard()
                refreshStatsOverlay()
            }
        })

        return exoPlayer
    }

    private fun resetPlaybackStats() {
        lastVideoInfo = ""
        lastAudioInfo = ""
        droppedFrames = 0
        lastBitrateEstimate = 0L
        videoBitrate = 0L
        videoWidth = 0
        videoHeight = 0
        actualFps = 0f
        hdrType = "SDR"
        videoDecoderName = ""
        decoderIsHardware = false
        currentVideoCodec = ""
        lastTtffMs = -1
        currentBufferDurationMs = 0L
        rebufferCount = 0
        totalRebufferDurationMs = 0L
        rebufferStartedAtMs = 0L
        averageRebufferDurationMs = 0L
        successfulStarts = 0
        playbackErrors = 0
        failoverCount = 0
        lastRenderedVideoFrameAtMs = System.currentTimeMillis()
        firstVideoFrameAtMs = 0L
        hasReceivedFirstVideoFrame = false
        hasExpectedVideoTrack = false
        audioStarted = false
        currentSourceLatencyMs = -1L
        audioOutputInfo = AudioOutputInfo(currentAudioOutputMode(), "unknown", false, "unknown")
        blackScreenRecoveryAttempts = 0
        blackScreenRecoveryTriggered = false
        lastChannelSwitchTimeMs = -1L
        channelSwitchSamplesMs.clear()
        smartQualityGuard.reset()
        smartQualityCeiling = SmartQualityGuard.Ceiling.USER_MAX
        smartQualityLastReason = ""
    }

    private fun resetSourcePlaybackStats() {
        lastVideoInfo = ""
        lastAudioInfo = ""
        droppedFrames = 0
        videoBitrate = 0L
        videoWidth = 0
        videoHeight = 0
        actualFps = 0f
        hdrType = "SDR"
        videoDecoderName = ""
        decoderIsHardware = false
        currentVideoCodec = ""
        lastTtffMs = -1L
        currentBufferDurationMs = 0L
        rebufferCount = 0
        totalRebufferDurationMs = 0L
        rebufferStartedAtMs = 0L
        averageRebufferDurationMs = 0L
        successfulStarts = 0
        playbackErrors = 0
        lastRenderedVideoFrameAtMs = System.currentTimeMillis()
        firstVideoFrameAtMs = 0L
        hasReceivedFirstVideoFrame = false
        hasExpectedVideoTrack = false
        audioStarted = false
        currentSourceLatencyMs = -1L
        audioOutputInfo = AudioOutputInfo(currentAudioOutputMode(), "unknown", false, "unknown")
        blackScreenRecoveryAttempts = 0
        blackScreenRecoveryTriggered = false
        dynamicBufferController.reset()
        smartQualityGuard.reset()
        smartQualityCeiling = SmartQualityGuard.Ceiling.USER_MAX
        smartQualityLastReason = ""
    }

    private fun beginRebufferIfNeeded() {
        if (!hasReceivedFirstVideoFrame || rebufferStartedAtMs != 0L) return
        rebufferStartedAtMs = System.currentTimeMillis()
    }

    private fun finishRebufferIfNeeded() {
        if (rebufferStartedAtMs == 0L) return
        val duration = (System.currentTimeMillis() - rebufferStartedAtMs).coerceAtLeast(0L)
        rebufferStartedAtMs = 0L
        rebufferCount++
        totalRebufferDurationMs += duration
        averageRebufferDurationMs = totalRebufferDurationMs / rebufferCount
        channel?.sourceUrls?.getOrNull(currentSourceIndex)?.let {
            StreamHealthRegistry.recordRebuffer(it, rebufferCount, totalRebufferDurationMs)
        }
        observeDynamicBuffer()
        observeSmartQualityGuard()
        refreshStatsOverlay()
    }

    private fun observeSmartQualityGuard() {
        val p = player ?: return
        val prefs = com.brotv.player.data.PrefsManager(this)
        val userMode = currentQualityMode()
        if (!prefs.smartQualityGuardEnabled) {
            if (smartQualityCeiling != SmartQualityGuard.Ceiling.USER_MAX) {
                smartQualityGuard.reset()
                smartQualityCeiling = SmartQualityGuard.Ceiling.USER_MAX
                smartQualityLastReason = "disabled"
                PlayerEngine.applySmartQualityCeiling(p, userMode, smartQualityCeiling)
                refreshStatsOverlay()
            }
            return
        }
        if (!hasReceivedFirstVideoFrame || firstVideoFrameAtMs <= 0L) return

        val now = System.currentTimeMillis()
        val decision = smartQualityGuard.observe(
            nowMs = now,
            playbackAgeMs = (now - firstVideoFrameAtMs).coerceAtLeast(0L),
            baseMaxHeight = PlayerEngine.userQualityMaxHeight(userMode),
            droppedFrames = droppedFrames,
            rebufferCount = rebufferCount,
            rebufferDurationMs = totalRebufferDurationMs,
            estimatedBandwidth = lastBitrateEstimate,
            videoBitrate = videoBitrate,
            currentBufferMs = currentBufferDurationMs
        )
        if (!decision.changed) return
        if (PlayerEngine.applySmartQualityCeiling(p, userMode, decision.ceiling)) {
            smartQualityCeiling = decision.ceiling
            smartQualityLastReason = decision.reason
            refreshStatsOverlay()
        }
    }

    private fun observeDynamicBuffer() {
        // Never recreate the live player automatically just to change LoadControl.
        // On real IPTV providers this creates a visible cut and may look like source failover.
        // Live playback keeps the current buffer profile for the whole channel session.
        if (isLiveContent) return
        if (savedBufferProfileName() != "AUTO") return
        val now = System.currentTimeMillis()
        // لا نحكم على Buffer=0 أثناء Startup؛ ننتظر أول Frame ثم فترة Warm-up.
        if (!hasReceivedFirstVideoFrame || firstVideoFrameAtMs <= 0L ||
            now - firstVideoFrameAtMs < DYNAMIC_BUFFER_WARMUP_MS
        ) return
        val oldProfile = dynamicBufferController.currentProfile
        val newProfile = dynamicBufferController.observe(
            nowMs = now,
            isLive = isLiveContent,
            rebufferCount = rebufferCount,
            currentBufferMs = currentBufferDurationMs,
            estimatedBandwidth = lastBitrateEstimate,
            ttffMs = lastTtffMs
        )
        if (oldProfile == newProfile || dynamicBufferApplyScheduled) return
        if (now - lastDynamicBufferApplyAtMs < DYNAMIC_BUFFER_COOLDOWN_MS) return

        // LoadControl لا يغيّر مدته بعد البناء؛ نعيد إنشاء المشغل فقط عند
        // انتقال القرار إلى بروفايل آخر، وليس عند كل عينة.
        dynamicBufferApplyScheduled = true
        val recoveryGeneration = playbackRetryGeneration
        recoveryHandler.postDelayed({
            dynamicBufferApplyScheduled = false
            if (recoveryGeneration != playbackRetryGeneration) return@postDelayed
            lastDynamicBufferApplyAtMs = System.currentTimeMillis()
            channel?.let { startPlayback(it, currentSourceIndex, forceRecreate = true) }
        }, DYNAMIC_BUFFER_APPLY_DELAY_MS)
    }

    private fun currentSnapshot(): StreamHealthSnapshot = StreamHealthSnapshot(
        width = videoWidth,
        height = videoHeight,
        fps = actualFps,
        bitrate = videoBitrate,
        ttffMs = lastTtffMs,
        rebufferCount = rebufferCount,
        rebufferDurationMs = totalRebufferDurationMs,
        playbackErrors = playbackErrors,
        droppedFrames = droppedFrames,
        successfulStarts = successfulStarts,
        serverLatencyMs = currentSourceLatencyMs
    )

    private fun detectHdrType(format: androidx.media3.common.Format): String {
        val mime = format.sampleMimeType.orEmpty()
        if (mime == androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION ||
            format.codecs?.contains("dv", ignoreCase = true) == true
        ) {
            return "Dolby Vision"
        }
        return when (format.colorInfo?.colorTransfer) {
            androidx.media3.common.C.COLOR_TRANSFER_ST2084 -> "HDR10"
            androidx.media3.common.C.COLOR_TRANSFER_HLG -> "HLG"
            else -> "SDR"
        }
    }

    private fun formatFrameRate(value: Float): String =
        String.format(Locale.US, "%.3f", value)
            .trimEnd('0')
            .trimEnd('.')

    /**
     * يصنّف نوع الخطأ بدقة قبل ما يقرر شنو يسوي (بند "HTTP Error Handling"):
     *  - 401/403 (مشكلة صلاحية/Credentials): ما فيه فايدة من إعادة المحاولة، يروح على
     *    طول لمصدر بديل بدون تكرار عبثي.
     *  - 404: يعتبرها مثل انتهاء صلاحية الرابط، يروح لمصدر بديل مباشرة.
     *  - 429 (Too Many Requests): يعيد المحاولة بس بعد تأخير أطول من المعتاد.
     *  - 500/502/503/504 أو أخطاء شبكة/timeout: إعادة محاولة سريعة على نفس الرابط أول.
     *  - Format غير مدعوم: ما فيه فايدة من إعادة المحاولة، يروح لمصدر بديل.
     */
    private fun resetRecoveryStateForSelection() {
        playbackRetryGeneration++
        recoveryHandler.removeCallbacksAndMessages(null)
        retryAttemptsForCurrentSource = 0
        blackScreenRecoveryAttempts = 0
        blackScreenRecoveryTriggered = false
        freezeRecoveryAttempts = 0
        freezeRecoveryTriggered = false
    }

    private fun requireManualLiveSource(ch: MergedChannel, failedUrl: String) {
        failedSourceUrlsThisSession.add(failedUrl)
        resetRecoveryStateForSelection()
        player?.pause()
        findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = android.view.View.GONE
        showPlayerChromeTemporarily()
        findViewById<TextView>(R.id.btnLiveSource).requestFocus()
        val message = if (ch.sourceUrls.size > 1) {
            getString(R.string.live_source_failed_choose_manual)
        } else {
            getString(R.string.live_source_failed_single)
        }
        showFailoverAlert(message)
    }

    private fun handlePlaybackError(ch: MergedChannel, failedUrl: String, error: PlaybackException) {
        val httpCode = extractHttpStatusCode(error)
        val diagnosis = com.example.iptvplayer.player.PlaybackDoctor.diagnose(
            httpCode = httpCode,
            mediaErrorCode = error.errorCode,
            decodingFailedCode = PlaybackException.ERROR_CODE_DECODING_FAILED,
            unsupportedFormatCode = PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            malformedContainerCode = PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            networkErrorCodes = setOf(
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
            )
        )
        val permanentFailure = !diagnosis.retryable

        // BRO Doctor executes the expensive decoder remedy only when the recovery guard allows it.
        // This prevents decoder rebuild storms on weak Android TV hardware.
        if (diagnosis.remedy == com.example.iptvplayer.player.PlaybackDoctor.Remedy.RECREATE_PLAYER) {
            val now = android.os.SystemClock.elapsedRealtime()
            if (playbackRecoveryGuard.canRecover(now)) {
                playbackRecoveryGuard.recordRecovery(now)
                showFailoverAlert(getString(R.string.bro_doctor_decoder_recovery))
                schedulePlaybackRetry(ch, currentSourceIndex, 350L, forceRecreate = true)
                return
            }
        }

        if (diagnosis.cause == com.example.iptvplayer.player.PlaybackDoctor.Cause.NETWORK) {
            showFailoverAlert(getString(R.string.bro_doctor_network_recovery))
        } else if (diagnosis.cause == com.example.iptvplayer.player.PlaybackDoctor.Cause.SERVER && retryAttemptsForCurrentSource == 0) {
            showFailoverAlert(getString(R.string.bro_doctor_server_recovery))
        }

        if (isLiveContent) {
            val alternativeAvailable = ch.sourceUrls.indices.any { index ->
                index != currentSourceIndex && ch.sourceUrls[index] !in failedSourceUrlsThisSession
            }
            when (
                LiveSourceRecoveryPolicy.actionFor(
                    retryAttempts = retryAttemptsForCurrentSource,
                    permanentFailure = permanentFailure,
                    alternativeAvailable = alternativeAvailable,
                    automaticAlternativeAlreadyUsed = liveAutomaticAlternativeUsed
                )
            ) {
                LiveSourceRecoveryPolicy.Action.RETRY_CURRENT_SOURCE -> {
                    val delay = when {
                        httpCode == 429 -> extractRetryAfterMillis(error)?.coerceAtMost(5_000L) ?: 2_000L
                        httpCode in TRANSIENT_HTTP_CODES -> 1_500L
                        else -> 1_000L
                    }
                    schedulePlaybackRetry(ch, currentSourceIndex, delay)
                }
                LiveSourceRecoveryPolicy.Action.TRY_ONE_ALTERNATIVE -> {
                    tryOneLiveAlternativeOrRequireManual(ch, failedUrl)
                }
                LiveSourceRecoveryPolicy.Action.REQUIRE_MANUAL_SOURCE -> {
                    requireManualLiveSource(ch, failedUrl)
                }
            }
            return
        }

        when {
            permanentFailure -> tryNextSourceOnFailure(ch, failedUrl)
            httpCode == 429 -> {
                if (retryAttemptsForCurrentSource < MAX_QUICK_RETRIES) {
                    schedulePlaybackRetry(
                        ch,
                        currentSourceIndex,
                        extractRetryAfterMillis(error) ?: exponentialRetryDelay(RATE_LIMIT_RETRY_DELAY_MS)
                    )
                } else tryNextSourceOnFailure(ch, failedUrl)
            }
            retryAttemptsForCurrentSource < MAX_QUICK_RETRIES -> {
                val delay = if (httpCode in TRANSIENT_HTTP_CODES) exponentialRetryDelay(QUICK_RETRY_DELAY_MS)
                else QUICK_RETRY_DELAY_MS
                schedulePlaybackRetry(ch, currentSourceIndex, delay)
            }
            else -> tryNextSourceOnFailure(ch, failedUrl)
        }
    }

    private fun schedulePlaybackRetry(
        ch: MergedChannel,
        sourceIndex: Int,
        delayMs: Long,
        forceRecreate: Boolean = false
    ) {
        retryAttemptsForCurrentSource++
        val retryGeneration = ++playbackRetryGeneration
        if (isLiveContent) {
            // Force the old HTTP stream to close before reconnecting. This avoids a transient
            // second active_cons on single-connection providers.
            player?.stop()
            player?.clearMediaItems()
        }
        val effectiveDelay = if (isLiveContent) {
            maxOf(delayMs, LIVE_PROVIDER_SETTLE_DELAY_MS)
        } else {
            delayMs
        }
        recoveryHandler.postDelayed({
            if (retryGeneration == playbackRetryGeneration &&
                channel?.id == ch.id &&
                currentSourceIndex == sourceIndex
            ) {
                startPlayback(ch, sourceIndex, forceRecreate = forceRecreate)
            }
        }, effectiveDelay.coerceAtMost(MAX_RETRY_DELAY_MS))
    }

    private fun exponentialRetryDelay(baseDelayMs: Long): Long {
        val attemptNumber = retryAttemptsForCurrentSource + 1
        return (baseDelayMs * 2.0.pow((attemptNumber - 1).coerceAtLeast(0)))
            .toLong()
            .coerceAtMost(MAX_RETRY_DELAY_MS)
    }

    private fun extractRetryAfterMillis(error: PlaybackException): Long? {
        var cause: Throwable? = error
        var depth = 0
        while (cause != null && depth < 6) {
            if (cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                val retryAfter = cause.headerFields.entries
                    .firstOrNull { it.key.equals("Retry-After", ignoreCase = true) }
                    ?.value
                    ?.firstOrNull()
                    ?.trim()
                    ?: return null

                retryAfter.toLongOrNull()?.let { seconds ->
                    return (seconds * 1_000L).coerceAtLeast(0L)
                }

                // دعم صيغة HTTP-date الشائعة، مع الرجوع للتأخير الأقصى عند تعذر تحليلها.
                return try {
                    val target = java.text.SimpleDateFormat(
                        "EEE, dd MMM yyyy HH:mm:ss z",
                        Locale.US
                    ).parse(retryAfter)?.time ?: return null
                    (target - System.currentTimeMillis()).coerceAtLeast(0L)
                } catch (_: Exception) {
                    return null
                }
            }
            cause = cause.cause
            depth++
        }
        return null
    }

    /** يحاول يطلع كود HTTP الفعلي من سلسلة أسباب الخطأ (لو موجود)، عشان نصنّف صح مو تخمين. */
    private fun extractHttpStatusCode(error: PlaybackException): Int? {
        var cause: Throwable? = error
        var depth = 0
        while (cause != null && depth < 6) {
            if (cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                return cause.responseCode
            }
            cause = cause.cause
            depth++
        }
        return null
    }

    private fun tryOneLiveAlternativeOrRequireManual(ch: MergedChannel, failedUrl: String) {
        if (!isLiveContent) {
            tryNextSourceOnFailure(ch, failedUrl)
            return
        }

        // Automatic switching between live sources is disabled per field feedback: it kept
        // flapping between sources on unstable providers and froze the device. The viewer now
        // always confirms the next source manually.
        requireManualLiveSource(ch, failedUrl)
    }

    private fun tryNextSourceOnFailure(ch: MergedChannel, failedUrl: String) {
        if (isLiveContent) {
            tryOneLiveAlternativeOrRequireManual(ch, failedUrl)
            return
        }

        failedSourceUrlsThisSession.add(failedUrl)
        val remaining = ch.sourceUrls.filter { it !in failedSourceUrlsThisSession }
        if (remaining.isEmpty()) {
            Toast.makeText(this, getString(R.string.all_sources_failed), Toast.LENGTH_LONG).show()
            return
        }
        val generation = playbackRetryGeneration
        val channelId = ch.id
        lifecycleScope.launch {
            val nextUrl = AutoPilotEngine.bestSource(remaining) ?: remaining.first()
            if (generation != playbackRetryGeneration || channel?.id != channelId) return@launch
            val nextIndex = ch.sourceUrls.indexOf(nextUrl)
            if (nextIndex == -1) return@launch
            showFailoverAlert()
            failoverCount++
            retryAttemptsForCurrentSource = 0
            startPlayback(ch, nextIndex)
        }
    }

    private fun showFailoverAlert(message: String = getString(R.string.failover_switched)) {
        val alert = findViewById<TextView>(R.id.txtFailoverAlert)
        alert.text = message
        alert.visibility = android.view.View.VISIBLE
        seekIndicatorHandler.postDelayed({ alert.visibility = android.view.View.GONE }, 2500L)
    }

    private fun togglePlayPause() {
        val p = player ?: return
        p.playWhenReady = !p.playWhenReady
    }

    // ---------- Picture-in-Picture + Remote Channel Surf ----------

    private fun enterPictureInPicture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            !packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            Toast.makeText(this, getString(R.string.pip_not_supported), Toast.LENGTH_SHORT).show()
            return
        }
        val ratio = PictureInPicturePolicy.safeRatio(videoWidth, videoHeight)
        val params = android.app.PictureInPictureParams.Builder()
            .setAspectRatio(Rational(ratio.width, ratio.height))
            .build()
        setPlayerChromeVisible(false)
        val entered = try {
            enterPictureInPictureMode(params)
        } catch (_: RuntimeException) {
            false
        }
        if (!entered) {
            setPlayerChromeVisible(true)
            Toast.makeText(this, getString(R.string.pip_not_supported), Toast.LENGTH_SHORT).show()
        }
    }

    private fun setPlayerChromeVisible(visible: Boolean) {
        val value = if (visible) android.view.View.VISIBLE else android.view.View.GONE
        findViewById<android.view.View>(R.id.topOverlay).visibility = value
        findViewById<android.view.View>(R.id.infoOverlay).visibility =
            if (visible && !isLiveContent) android.view.View.VISIBLE else android.view.View.GONE
        findViewById<android.view.View>(R.id.bottomOverlay).visibility = value
        findViewById<TextView>(R.id.txtPlayerStats).visibility = android.view.View.GONE
        if (!visible) {
            findViewById<android.view.View>(R.id.epgGuideOverlay).visibility = android.view.View.GONE
            findViewById<TextView>(R.id.txtFailoverAlert).visibility = android.view.View.GONE
            findViewById<TextView>(R.id.txtSeekIndicator).visibility = android.view.View.GONE
        }
    }

    private fun isPlayerChromeVisible(): Boolean =
        findViewById<android.view.View>(R.id.bottomOverlay).visibility == android.view.View.VISIBLE

    private fun surfChannel(direction: Int) {
        if (!isLiveContent) return
        lifecycleScope.launch {
            val channels = if (channelSurfList.isNotEmpty()) {
                channelSurfList
            } else {
                loadScopedLiveChannels().also { channelSurfList = it }
            }
            if (channels.isEmpty()) return@launch
            val currentIndex = channels.indexOfFirst { it.id == channel?.id }
            val target = ChannelSurfPolicy.targetIndex(currentIndex, channels.size, direction)
            channels.getOrNull(target)?.let { switchChannelFromGuide(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !isInPictureInPictureMode) {
            if (isLiveContent) showPlayerChromeTemporarily() else setPlayerChromeVisible(true)
        }
    }

    // ---------- دليل البرامج الكامل ----------

    private var guideLoaded = false
    private val xmltvEpgRepository by lazy { com.brotv.player.data.XmltvEpgRepository(this) }

    private fun openGuide() {
        chromeHandler.removeCallbacks(hideChromeRunnable)
        setPlayerChromeVisible(true)
        val overlay = findViewById<android.widget.FrameLayout>(R.id.epgGuideOverlay)
        overlay.visibility = android.view.View.VISIBLE

        val guideRecycler = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recyclerGuide)
        if (guideRecycler.layoutManager == null) {
            guideRecycler.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
            guideRecycler.setHasFixedSize(true)
            guideRecycler.setItemViewCacheSize(8)
            guideRecycler.itemAnimator = null
        }

        lifecycleScope.launch {
            val scopedChannels = if (channelSurfList.isNotEmpty()) {
                channelSurfList
            } else {
                loadScopedLiveChannels().also { channelSurfList = it }
            }
            val shouldRefreshEpg = !guideLoaded
            guideLoaded = true
            guideRecycler.adapter =
                EpgGuideAdapter(this@FullPlayerActivity, scopedChannels, channel?.id, lifecycleScope) { selected ->
                    switchChannelFromGuide(selected)
                }
            val currentIndex = scopedChannels.indexOfFirst { it.id == channel?.id }.coerceAtLeast(0)
            guideRecycler.scrollToPosition(currentIndex)
            guideRecycler.post {
                val holder = guideRecycler.findViewHolderForAdapterPosition(currentIndex)
                if (holder != null) {
                    holder.itemView.requestFocus()
                } else {
                    guideRecycler.requestFocus()
                }
            }
            if (shouldRefreshEpg) {
                val result = xmltvEpgRepository.refreshIfNeeded()
                if (result.succeeded > 0) guideRecycler.adapter?.notifyDataSetChanged()
            }
        }
    }

    private fun closeGuide() {
        findViewById<android.widget.FrameLayout>(R.id.epgGuideOverlay).visibility = android.view.View.GONE
        showPlayerChromeTemporarily()
    }

    /** يبدّل القناة من الدليل/الأرقام/التصفح مع تطبيق الرقابة الأبوية على كل انتقال. */
    private fun switchChannelFromGuide(newChannel: MergedChannel) {
        val prefs = com.brotv.player.data.PrefsManager(this)
        ParentalGate.requirePinIfNeeded(
            activity = this,
            category = newChannel.groupTitle,
            lockedCategories = prefs.lockedLiveCategories,
            onGranted = { applyChannelSwitch(newChannel) }
        )
    }

    private fun applyChannelSwitch(newChannel: MergedChannel) {
        resetRecoveryStateForSelection()
        playbackResourceRequestToken++
        channel = newChannel
        failedSourceUrlsThisSession.clear()
        liveAutomaticAlternativeUsed = false
        forceStatsResetOnNextStart = true
        findViewById<TextView>(R.id.txtContentTitle).text = newChannel.name
        findViewById<TextView>(R.id.txtContentSubtitle).text = newChannel.groupTitle
        findViewById<TextView>(R.id.txtLiveChannelName).text = newChannel.name
        findViewById<TextView>(R.id.txtLiveProgram).text = newChannel.groupTitle
        retryAttemptsForCurrentSource = 0
        // Channel zapping is a hot path: choose from real in-memory playback history only.
        // No network probe is allowed before prepare(), so remote CHANNEL+/CHANNEL- stays immediate.
        val preferredUrl = AutoPilotEngine.bestKnownSource(newChannel.sourceUrls)
        val preferredIndex = preferredUrl?.let(newChannel.sourceUrls::indexOf)?.takeIf { it >= 0 } ?: 0
        startPlayback(newChannel, preferredIndex)
        loadEpgInfo(newChannel)
        updateLiveSourceLabel()
        updateLiveChromeMetadata(force = true)
        closeGuide()
        showPlayerChromeTemporarily()
    }

    override fun onBackPressed() {
        val guide = findViewById<android.widget.FrameLayout>(R.id.epgGuideOverlay)
        if (guide.visibility == android.view.View.VISIBLE) {
            closeGuide()
            return
        }
        if (isLiveContent && isPlayerChromeVisible()) {
            chromeHandler.removeCallbacks(hideChromeRunnable)
            setPlayerChromeVisible(false)
            return
        }
        if (isLiveContent) {
            setResult(RESULT_OK, android.content.Intent().apply {
                channel?.let { putExtra(EXTRA_RETURN_CHANNEL, it) }
            })
            finish()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Seek مباشر بالريموت ----------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && isLiveContent) {
            val guideOpen = findViewById<android.view.View>(R.id.epgGuideOverlay).visibility == android.view.View.VISIBLE
            if (!guideOpen) {
                val chromeVisible = isPlayerChromeVisible()

                // OK أثناء إخفاء الشريط يفتح قائمة قنوات نفس المجلد فوق البث مباشرة.
                if (!chromeVisible && (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                    openGuide()
                    return true
                }

                if (chromeVisible) {
                    // أي تفاعل داخل الشريط يعيد مهلة الإخفاء حتى لا يختفي أثناء تحريك المؤشر.
                    chromeHandler.removeCallbacks(hideChromeRunnable)
                    chromeHandler.postDelayed(hideChromeRunnable, LIVE_CHROME_TIMEOUT_MS)
                }

                when (event.keyCode) {
                    // أعلى/أسفل يبدلان داخل نطاق المجلد فقط وبنفس ترتيب المزود.
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        surfChannel(-1)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        surfChannel(1)
                        return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val guideOpen = findViewById<android.view.View>(R.id.epgGuideOverlay).visibility == android.view.View.VISIBLE
        if (isLiveContent && !guideOpen && keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) {
            appendChannelNumber(keyCode - KeyEvent.KEYCODE_0)
            return true
        }
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (!isLiveContent) {
                seekBy(15_000)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (!isLiveContent) {
                seekBy(-15_000)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> if (isLiveContent && !guideOpen) {
                surfChannel(1)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> if (isLiveContent && !guideOpen) {
                surfChannel(-1)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun appendChannelNumber(digit: Int) {
        if (channelNumberBuffer.length >= 4) channelNumberBuffer.clear()
        channelNumberBuffer.append(digit)
        channelNumberHandler.removeCallbacks(channelNumberCommit)
        findViewById<TextView>(R.id.txtSeekIndicator).apply {
            text = channelNumberBuffer.toString()
            visibility = android.view.View.VISIBLE
        }
        channelNumberHandler.postDelayed(channelNumberCommit, CHANNEL_NUMBER_TIMEOUT_MS)
    }

    private fun commitChannelNumber() {
        val requested = channelNumberBuffer.toString().toIntOrNull()
        channelNumberBuffer.clear()
        findViewById<TextView>(R.id.txtSeekIndicator).visibility = android.view.View.GONE
        if (requested == null || requested <= 0) return
        lifecycleScope.launch {
            val channels = if (channelSurfList.isNotEmpty()) channelSurfList else
                loadScopedLiveChannels().also { channelSurfList = it }
            channels.getOrNull(requested - 1)?.let { switchChannelFromGuide(it) }
        }
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        if (isPlayingFromLocalBuffer) {
            val duration = p.duration.takeIf { it > 0L } ?: 0L
            val newPosition = (p.currentPosition + deltaMs).coerceIn(0L, duration)
            // لو التقديم وصل لآخر البَفر المحلي، نرجع تلقائياً للبث المباشر الحقيقي
            // (زي أي مشغل DVR عادي) بدل ما يوقف على نهاية ملف محلي.
            if (deltaMs > 0 && duration > 0L && newPosition >= duration - LOCAL_BUFFER_CATCHUP_THRESHOLD_MS) {
                exitLocalRewindMode()
            } else {
                p.seekTo(newPosition)
                showSeekIndicator(deltaMs)
            }
            return
        }
        if (isLiveContent) {
            val state = evaluateLiveTimeshift(p)
            if (!state.supported) {
                // ما فيه نافذة رجوع من المزود نفسه — نجرب البَفر المحلي (StreamVault parity)
                // بدل ما نوقف عند رسالة "غير مدعومة" مباشرة.
                if (deltaMs < 0 && tryEnterLocalRewindMode()) return
                showFailoverAlert(getString(R.string.timeshift_unavailable))
                return
            }
            val newPosition = LiveTimeshiftPolicy.clampSeek(
                p.currentPosition + deltaMs,
                state.windowDurationMs
            )
            p.seekTo(newPosition)
        } else {
            val newPosition = (p.currentPosition + deltaMs).coerceAtLeast(0L)
            p.seekTo(newPosition)
        }
        showSeekIndicator(deltaMs)
    }

    /**
     * يحاول الدخول لوضع الإعادة للخلف المحلي (LiveRollingBufferRecorder) لما المزود
     * نفسه ما يوفر نافذة Timeshift. يرجع true لو دخل الوضع فعلياً (حتى لو التحميل
     * لسه شغال بالخلفية)، و false لو ما فيه بَفر كافٍ إطلاقاً حتى نعرض رسالة واضحة.
     */
    private fun tryEnterLocalRewindMode(): Boolean {
        val recorder = rollingBufferRecorder ?: return false
        if (recorder.unsupported || recorder.maxRewindMs() <= 0L) return false

        showFailoverAlert(getString(R.string.live_rewind_entering_local_buffer))
        lifecycleScope.launch {
            val file = recorder.buildLocalPlaylistFile()
            if (file == null || rollingBufferRecorder !== recorder) {
                // البَفر تغيّر (تبديل قناة) أو لسه ما تجمّع شرائح كافية.
                if (!isPlayingFromLocalBuffer) {
                    showFailoverAlert(getString(R.string.timeshift_unavailable))
                }
                return@launch
            }
            val p = player ?: return@launch
            isPlayingFromLocalBuffer = true
            p.setMediaItem(androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(file)))
            p.prepare()
            p.seekTo(0L)
            p.playWhenReady = true
        }
        return true
    }

    /** يرجّع المشغل للبث المباشر الحقيقي بعد الخروج من وضع الإعادة للخلف المحلي. */
    private fun exitLocalRewindMode() {
        if (!isPlayingFromLocalBuffer) return
        isPlayingFromLocalBuffer = false
        val ch = channel ?: return
        forceStatsResetOnNextStart = true
        startPlayback(ch, currentSourceIndex, forceRecreate = true)
    }

    private fun goToLiveEdge() {
        val p = player ?: return
        if (isPlayingFromLocalBuffer) {
            exitLocalRewindMode()
            return
        }
        val state = evaluateLiveTimeshift(p)
        if (!state.supported) {
            showFailoverAlert(getString(R.string.timeshift_unavailable))
            return
        }
        p.seekToDefaultPosition()
        p.playWhenReady = true
        showFailoverAlert(getString(R.string.timeshift_back_to_live))
    }

    private fun evaluateLiveTimeshift(p: ExoPlayer): LiveTimeshiftPolicy.State {
        liveTimeshiftState = LiveTimeshiftPolicy.evaluate(
            isLive = isLiveContent,
            isSeekable = p.isCurrentMediaItemSeekable,
            durationMs = p.duration,
            positionMs = p.currentPosition
        )
        return liveTimeshiftState
    }

    private fun showSeekIndicator(deltaMs: Long) {
        val indicator = findViewById<TextView>(R.id.txtSeekIndicator)
        val seconds = deltaMs / 1000
        indicator.text = if (seconds > 0) "+${seconds}" else "${seconds}"
        indicator.visibility = android.view.View.VISIBLE
        seekIndicatorHideRunnable?.let(seekIndicatorHandler::removeCallbacks)
        val hide = Runnable { indicator.visibility = android.view.View.GONE }
        seekIndicatorHideRunnable = hide
        seekIndicatorHandler.postDelayed(hide, 700L)
    }

    // ---------- حجم الصورة ----------

    private fun cycleAspectRatio() {
        resizeModeIndex = (resizeModeIndex + 1) % resizeModes.size
        findViewById<PlayerView>(R.id.playerView).resizeMode = resizeModes[resizeModeIndex]
    }

    // ---------- شريط التقدم ----------

    private fun updateProgressUi() {
        if (isLiveContent) {
            updateLiveChromeMetadata()
        }
        val p = player ?: return
        val duration = p.duration.coerceAtLeast(0L)
        val position = p.currentPosition.coerceAtLeast(0L)
        currentBufferDurationMs = (p.bufferedPosition - p.currentPosition).coerceAtLeast(0L)
        observeDynamicBuffer()

        val seekBar = findViewById<SeekBar>(R.id.seekBar)
        val currentText = findViewById<TextView>(R.id.txtCurrentTime)
        val totalText = findViewById<TextView>(R.id.txtTotalTime)
        val goLive = findViewById<TextView>(R.id.btnGoLive)

        if (isLiveContent) {
            val state = evaluateLiveTimeshift(p)
            seekBar.isEnabled = state.supported
            goLive.visibility = if (state.supported) android.view.View.VISIBLE else android.view.View.GONE
            goLive.isEnabled = state.supported && !state.atLiveEdge
            goLive.alpha = if (goLive.isEnabled) 1f else 0.55f

            if (state.supported) {
                seekBar.max = state.windowDurationMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                seekBar.progress = state.positionMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                currentText.text = if (state.atLiveEdge) {
                    getString(R.string.timeshift_now)
                } else {
                    "-${formatTime(state.behindLiveMs)}"
                }
            } else {
                seekBar.progress = 0
                currentText.text = getString(R.string.timeshift_now)
            }
            totalText.text = getString(R.string.live_indicator)
        } else {
            liveTimeshiftState = LiveTimeshiftPolicy.evaluate(false, false, 0L, 0L)
            seekBar.isEnabled = duration > 0L
            goLive.visibility = android.view.View.GONE
            if (duration > 0L) {
                seekBar.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                seekBar.progress = position.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            }
            currentText.text = formatTime(position)
            totalText.text = formatTime(duration)
        }
        refreshStatsOverlay()
    }

    /**
     * كشف تجمّد فعلي (بند "Freeze Detection"): ما نعتمد بس على onPlayerError من Media3،
     * لأن أحياناً الصوت يشتغل والصورة متوقفة بدون أي خطأ رسمي. نراقب موضع التشغيل
     * نفسه: لو ما تحرك لمدة كافية وهو المفروض يشتغل، نعتبره Frozen ونبدأ استرجاع تلقائي.
     */
    private fun checkForFreeze() {
        // وضع الإعادة للخلف المحلي يشغّل ملف محلي عادي عبر نفس الـExoPlayer، ومنطق
        // الاسترجاع هنا مبني بالكامل على افتراض إنه بث شبكة حي (يعيد تحميل رابط القناة
        // المباشرة). نطفي الكشف مؤقتاً وقت وضع البَفر المحلي لتفادي إعادة تحميل البث
        // الحي فجأة بينما المستخدم يتفرج على الإعادة المحلية.
        if (isPlayingFromLocalBuffer) return
        val p = player ?: return
        if (!p.playWhenReady || p.playbackState != Player.STATE_READY) return
        checkForBlackScreen(p)
        if (freezeRecoveryTriggered || blackScreenRecoveryTriggered) return

        val currentPosition = p.currentPosition
        if (currentPosition == lastKnownPositionMs) {
            if (positionUnchangedSinceMs == 0L) {
                positionUnchangedSinceMs = System.currentTimeMillis()
            } else {
                val unchangedForMs = System.currentTimeMillis() - positionUnchangedSinceMs
                if (LivePlaybackRecoveryPolicy.shouldRecoverFreeze(
                        playWhenReady = p.playWhenReady,
                        playbackReady = p.playbackState == Player.STATE_READY,
                        unchangedForMs = unchangedForMs
                    )
                ) {
                    freezeRecoveryTriggered = true
                    recoverFromFreeze()
                }
            }
        } else {
            lastKnownPositionMs = currentPosition
            positionUnchangedSinceMs = 0L
        }
    }

    /**
     * يفرق بين Freeze (الموضع لا يتحرك) وBlack Screen (الموضع/الصوت يعملان
     * لكن Media3 لا يسجل Frames فيديو). يبدأ بإعادة التحضير ثم إعادة إنشاء
     * المشغل، وبعدها ينتقل للمصدر البديل.
     */
    private fun checkForBlackScreen(p: ExoPlayer) {
        if (blackScreenRecoveryTriggered) return
        val now = System.currentTimeMillis()
        if (LivePlaybackRecoveryPolicy.shouldRecoverMissingFirstFrame(
                hasExpectedVideoTrack = hasExpectedVideoTrack,
                hasReceivedFirstVideoFrame = hasReceivedFirstVideoFrame,
                playbackAgeMs = (now - playbackStartRequestedAt).coerceAtLeast(0L),
                audioStarted = audioStarted,
                positionMoving = p.currentPosition != lastKnownPositionMs
            )
        ) {
            recoverFromBlackScreen()
        }
    }

    private fun recoverFromBlackScreen() {
        val ch = channel ?: return
        val recoveryNow = android.os.SystemClock.elapsedRealtime()
        if (!playbackRecoveryGuard.canRecover(recoveryNow)) {
            blackScreenRecoveryTriggered = false
            return
        }
        playbackRecoveryGuard.recordRecovery(recoveryNow)
        val maxAttempts = if (isLiveContent) 1 else MAX_BLACK_SCREEN_RECOVERY_ATTEMPTS
        if (blackScreenRecoveryAttempts >= maxAttempts) {
            val codec = currentVideoCodec.substringAfterLast('.')
            if (codec.isNotBlank() && videoDecoderName.isNotBlank()) {
                DecoderBlacklist.recordFailure(this, codec, videoDecoderName)
            }
            blackScreenRecoveryAttempts = 0
            val failedUrl = ch.sourceUrls.getOrNull(currentSourceIndex) ?: return
            if (isLiveContent) tryOneLiveAlternativeOrRequireManual(ch, failedUrl) else tryNextSourceOnFailure(ch, failedUrl)
            return
        }

        blackScreenRecoveryAttempts++
        blackScreenRecoveryTriggered = true
        startPlayback(
            ch,
            currentSourceIndex,
            forceRecreate = isLiveContent || blackScreenRecoveryAttempts >= 2
        )
        val recoveryGeneration = playbackRetryGeneration
        recoveryHandler.postDelayed({
            if (recoveryGeneration != playbackRetryGeneration) return@postDelayed
            blackScreenRecoveryTriggered = false
            if (!hasReceivedFirstVideoFrame) recoverFromBlackScreen()
        }, BLACK_SCREEN_RECOVERY_WAIT_MS)
    }

    /** Self-Healing: نجرب Seek بسيط أول (أرخص حل)، ولو ما نفع نعيد إنشاء التشغيل بالكامل. */
    /**
     * Self-Healing (بند 24): محاولات متدرجة بحد أقصى وCooldown، بدون Loop لا نهائي.
     * Attempt 1: Seek بسيط. Attempt 2+: إعادة إنشاء المشغل بالكامل. بعد الحد الأقصى: Failover لمصدر بديل.
     */
    private fun recoverFromFreeze() {
        val p = player ?: return
        val ch = channel ?: return
        val recoveryNow = android.os.SystemClock.elapsedRealtime()
        if (!playbackRecoveryGuard.canRecover(recoveryNow)) {
            freezeRecoveryTriggered = false
            return
        }
        playbackRecoveryGuard.recordRecovery(recoveryNow)

        val maxAttempts = if (isLiveContent) 1 else MAX_FREEZE_RECOVERY_ATTEMPTS
        if (freezeRecoveryAttempts >= maxAttempts) {
            // استنفدنا المحاولات المعقولة على نفس المصدر — نروح لمصدر بديل بدل ما نكرر بلا فايدة
            freezeRecoveryAttempts = 0
            val failedUrl = ch.sourceUrls.getOrNull(currentSourceIndex) ?: return
            if (isLiveContent) tryOneLiveAlternativeOrRequireManual(ch, failedUrl) else tryNextSourceOnFailure(ch, failedUrl)
            return
        }
        freezeRecoveryAttempts++

        if (freezeRecoveryAttempts == 1) {
            p.seekTo(p.currentPosition) // أرخص محاولة أول: Seek بسيط يفك التجمّد أحياناً
        }

        val recoveryGeneration = playbackRetryGeneration
        recoveryHandler.postDelayed({
            if (recoveryGeneration != playbackRetryGeneration || channel?.id != ch.id) return@postDelayed
            if (player?.currentPosition == lastKnownPositionMs) {
                retryAttemptsForCurrentSource = 0
                startPlayback(ch, currentSourceIndex, forceRecreate = true) // إعادة إنشاء كاملة من المحاولة الثانية
            } else {
                freezeRecoveryTriggered = false
                freezeRecoveryAttempts = 0 // رجع يشتغل طبيعي، نصفّر العداد
            }
        }, 1500L)
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    private fun updateRollingBufferForChannel(channelId: String, liveUrl: String) {
        if (rollingBufferChannelId == channelId && rollingBufferRecorder != null) return
        stopRollingBuffer()
        rollingBufferChannelId = channelId
        rollingBufferRecorder = com.brotv.player.player.LiveRollingBufferRecorder(applicationContext, channelId)
            .also { it.start(liveUrl) }
    }

    private fun stopRollingBuffer() {
        rollingBufferRecorder?.stop(deleteFiles = true)
        rollingBufferRecorder = null
        rollingBufferChannelId = null
    }

    override fun onDestroy() {
        playbackResourceRequestToken++
        playbackRetryGeneration++
        sourceProbeJob?.cancel()
        epgLookupJob?.cancel()
        sourceProbeJob = null
        epgLookupJob = null
        stopRollingBuffer()
        progressHandler.removeCallbacks(progressRunnable)
        seekIndicatorHandler.removeCallbacksAndMessages(null)
        recoveryHandler.removeCallbacksAndMessages(null)
        channelNumberHandler.removeCallbacksAndMessages(null)
        sleepTimerHandler.removeCallbacksAndMessages(null)
        frameRateHandler.removeCallbacksAndMessages(null)
        chromeHandler.removeCallbacksAndMessages(null)
        player?.release()
        DisplayModeSwitcher.resetDisplayMode(this)
        resourceLease?.release()
        resourceLease = null
        try {
            val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            connectivityManager.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            // ما كان مسجّل أصلاً أو النظام رفض الإلغاء، ما يهم
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CHANNEL = "extra_channel"
        const val EXTRA_IS_LIVE = "extra_is_live"
        const val EXTRA_SURF_SCOPE = "extra_surf_scope"
        const val EXTRA_RETURN_CHANNEL = "extra_return_channel"
        private const val CHANNEL_NUMBER_TIMEOUT_MS = 1_500L
        private const val LIVE_CHROME_TIMEOUT_MS = 4_000L
        private const val LIVE_SINGLE_FALLBACK_DELAY_MS = 1_200L
        private const val LIVE_PROVIDER_SETTLE_DELAY_MS = 1_000L
        private const val MAX_QUICK_RETRIES = 4
        private const val MAX_DECODER_RECOVERY_RETRIES = 2
        private const val QUICK_RETRY_DELAY_MS = 500L
        private const val RATE_LIMIT_RETRY_DELAY_MS = 3000L
        private const val MAX_RETRY_DELAY_MS = 30_000L
        private const val FRAME_RATE_DEBOUNCE_MS = 700L
        private val TRANSIENT_HTTP_CODES = setOf(500, 502, 503, 504)
        private const val MAX_FREEZE_RECOVERY_ATTEMPTS = 3
        private const val LOCAL_BUFFER_CATCHUP_THRESHOLD_MS = 3_000L
        private const val UHD_MIN_WIDTH = 3840
        private const val UHD_MIN_HEIGHT = 2160
        private const val BLACK_SCREEN_RECOVERY_WAIT_MS = 2_500L
        private const val MAX_BLACK_SCREEN_RECOVERY_ATTEMPTS = 3
        private const val DYNAMIC_BUFFER_WARMUP_MS = 10_000L
        private const val DYNAMIC_BUFFER_COOLDOWN_MS = 30_000L
        private const val DYNAMIC_BUFFER_APPLY_DELAY_MS = 750L
        private const val MAX_SWITCH_SAMPLES = 100
    }
}
