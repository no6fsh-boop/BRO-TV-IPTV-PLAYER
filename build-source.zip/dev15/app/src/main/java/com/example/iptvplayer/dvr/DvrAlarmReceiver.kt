package com.brotv.player.dvr

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class DvrAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_START_RECORDING) return
        val id = intent.getStringExtra(EXTRA_RECORDING_ID) ?: return
        DvrRecordingService.start(context, id)
    }

    companion object {
        const val ACTION_START_RECORDING = "com.brotv.player.action.DVR_START"
        const val EXTRA_RECORDING_ID = "recording_id"
    }
}
