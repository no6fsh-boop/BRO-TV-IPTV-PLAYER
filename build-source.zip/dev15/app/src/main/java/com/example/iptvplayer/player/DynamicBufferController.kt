package com.brotv.player.player

import kotlin.math.max

/**
 * يقرر بروفايل التخزين المؤقت من قياسات التشغيل الحالية. لا يبدل الاسم فقط:
 * القرار يتغير مع Rebuffer ووقت الاستقرار وحجم الـBuffer الفعلي.
 */
class DynamicBufferController {
    var currentProfile: PlayerEngine.BufferProfile = PlayerEngine.BufferProfile.BALANCED
        private set

    private var stableSinceMs = 0L
    private var lastObservedRebufferCount = 0
    private var lastRebufferAtMs = 0L

    fun reset() {
        currentProfile = PlayerEngine.BufferProfile.BALANCED
        stableSinceMs = 0L
        lastObservedRebufferCount = 0
        lastRebufferAtMs = 0L
    }

    fun observe(
        nowMs: Long,
        isLive: Boolean,
        rebufferCount: Int,
        currentBufferMs: Long,
        estimatedBandwidth: Long,
        ttffMs: Long
    ): PlayerEngine.BufferProfile {
        if (rebufferCount > lastObservedRebufferCount) {
            lastObservedRebufferCount = rebufferCount
            lastRebufferAtMs = nowMs
        }
        val recentRebuffer = lastRebufferAtMs > 0L && nowMs - lastRebufferAtMs < 30_000L
        val unstable = (recentRebuffer && rebufferCount >= 2) || currentBufferMs < 1_500L ||
            (estimatedBandwidth in 1L..2_500_000L && currentBufferMs < 4_000L) ||
            ttffMs > 6_000L

        if (unstable) {
            stableSinceMs = 0L
            currentProfile = when (currentProfile) {
                PlayerEngine.BufferProfile.LOW_LATENCY -> PlayerEngine.BufferProfile.BALANCED
                PlayerEngine.BufferProfile.BALANCED -> PlayerEngine.BufferProfile.STABLE
                else -> PlayerEngine.BufferProfile.STABLE
            }
            return currentProfile
        }

        if (estimatedBandwidth > 8_000_000L && currentBufferMs > 4_000L && ttffMs in 0..4_000L) {
            if (stableSinceMs == 0L) stableSinceMs = nowMs
            if (nowMs - stableSinceMs >= 15_000L) {
                currentProfile = if (isLive) {
                    PlayerEngine.BufferProfile.LOW_LATENCY
                } else {
                    PlayerEngine.BufferProfile.BALANCED
                }
            }
        } else {
            stableSinceMs = 0L
        }
        return currentProfile
    }
}