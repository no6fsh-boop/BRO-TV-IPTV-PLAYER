package com.brotv.player.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.PrefsManager
import kotlinx.coroutines.launch

class ChannelReorderActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_channel_reorder)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.txtReorderTitle).setText(R.string.settings_reorder_folders)

        val prefs = PrefsManager(this)
        val repository = MergedChannelRepository(this)
        val recycler = findViewById<RecyclerView>(R.id.recyclerReorder)
        recycler.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            val providerOrder = repository.loadMergedChannels()
                .map { it.groupTitle }
                .distinct()
                .filter { it !in prefs.hiddenLiveCategories }
            val saved = prefs.liveCategoryOrder
            val folders = buildList {
                addAll(saved.filter { it in providerOrder })
                addAll(providerOrder.filter { it !in saved })
            }.toMutableList()

            recycler.adapter = ChannelReorderAdapter(
                folders = folders,
                onOrderChanged = { newOrder -> prefs.liveCategoryOrder = newOrder },
                onRequestFocusAt = { position ->
                    recycler.post {
                        recycler.scrollToPosition(position)
                        recycler.post {
                            recycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
                                ?: recycler.requestFocus()
                        }
                    }
                }
            )
            recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        }
    }
}
