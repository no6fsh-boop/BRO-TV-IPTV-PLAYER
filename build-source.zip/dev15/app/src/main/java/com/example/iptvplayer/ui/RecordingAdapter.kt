package com.brotv.player.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.db.RecordingEntity
import com.brotv.player.data.db.RecordingStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingAdapter(
    private val onPrimaryAction: (RecordingEntity) -> Unit,
    private val onDelete: (RecordingEntity) -> Unit
) : ListAdapter<RecordingEntity, RecordingAdapter.Holder>(DIFF) {

    init {
        setHasStableIds(true)
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<RecordingEntity>() {
            override fun areItemsTheSame(oldItem: RecordingEntity, newItem: RecordingEntity): Boolean = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: RecordingEntity, newItem: RecordingEntity): Boolean = oldItem == newItem
        }
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.txtRecordingTitle)
        val meta: TextView = view.findViewById(R.id.txtRecordingMeta)
        val primary: TextView = view.findViewById(R.id.btnPrimaryAction)
        val delete: TextView = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_recording, parent, false)
    )

    override fun getItemId(position: Int): Long = getItem(position).id.hashCode().toLong()

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val row = getItem(position)
        val context = holder.itemView.context
        val status = RecordingStatus.from(row.status)
        holder.title.text = if (row.title == row.channelName) row.title else "${row.channelName} • ${row.title}"
        val timeFormat = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val time = timeFormat.format(Date(row.scheduledStartMs))
        val size = formatSize(row.bytesWritten)
        holder.meta.text = context.getString(R.string.dvr_status_line, statusLabel(holder, status), time, size)

        val hasPrimaryAction = status !in setOf(
            RecordingStatus.FAILED,
            RecordingStatus.MISSED,
            RecordingStatus.CANCELLED
        )
        holder.primary.visibility = if (hasPrimaryAction) View.VISIBLE else View.GONE
        if (hasPrimaryAction) {
            holder.primary.text = when (status) {
                RecordingStatus.RECORDING, RecordingStatus.WAITING_RESOURCE, RecordingStatus.INTERRUPTED -> context.getString(R.string.dvr_stop)
                RecordingStatus.SCHEDULED -> context.getString(R.string.dvr_cancel)
                RecordingStatus.COMPLETED, RecordingStatus.PARTIAL -> context.getString(R.string.dvr_play)
                else -> ""
            }
            holder.primary.setOnClickListener { onPrimaryAction(row) }
        } else {
            holder.primary.setOnClickListener(null)
        }
        holder.delete.setOnClickListener { onDelete(row) }
        holder.itemView.setOnClickListener {
            when {
                status in setOf(RecordingStatus.COMPLETED, RecordingStatus.PARTIAL) -> onPrimaryAction(row)
                hasPrimaryAction -> holder.primary.requestFocus()
                else -> holder.delete.requestFocus()
            }
        }
    }

    override fun onViewRecycled(holder: Holder) {
        holder.primary.setOnClickListener(null)
        holder.delete.setOnClickListener(null)
        holder.itemView.setOnClickListener(null)
        super.onViewRecycled(holder)
    }

    private fun statusLabel(holder: Holder, status: RecordingStatus): String {
        val res = when (status) {
            RecordingStatus.SCHEDULED -> R.string.dvr_status_scheduled
            RecordingStatus.WAITING_RESOURCE -> R.string.dvr_status_waiting
            RecordingStatus.RECORDING -> R.string.dvr_status_recording
            RecordingStatus.COMPLETED -> R.string.dvr_status_completed
            RecordingStatus.PARTIAL -> R.string.dvr_status_partial
            RecordingStatus.MISSED -> R.string.dvr_status_missed
            RecordingStatus.FAILED -> R.string.dvr_status_failed
            RecordingStatus.CANCELLED -> R.string.dvr_status_cancelled
            RecordingStatus.INTERRUPTED -> R.string.dvr_status_interrupted
        }
        return holder.itemView.context.getString(res)
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0))
        bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }
}
