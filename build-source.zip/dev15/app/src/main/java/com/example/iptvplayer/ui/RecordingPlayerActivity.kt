package com.brotv.player.ui

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.brotv.player.R
import com.brotv.player.data.SubtitleController
import java.io.File
import java.util.Locale

class RecordingPlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recording_player)
        val path = intent.getStringExtra(EXTRA_PATH) ?: return finish()
        val file = File(path)
        if (!file.exists()) return finish()
        val mime = intent.getStringExtra(EXTRA_MIME).orEmpty().ifBlank { "video/mp2t" }
        findViewById<TextView>(R.id.txtTitle).text = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.btnPlayPause).setOnClickListener { player?.let { it.playWhenReady = !it.playWhenReady } }
        findViewById<ImageView>(R.id.btnSubtitles).setOnClickListener { player?.let { SubtitleController.showSubtitleTracksDialog(this, it) } }
        findViewById<SeekBar>(R.id.seekBar).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) player?.seekTo(progress.toLong()) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        player = ExoPlayer.Builder(this).build().also { exo ->
            findViewById<PlayerView>(R.id.playerView).player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    findViewById<ProgressBar>(R.id.progressBar).visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                }
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    findViewById<ImageView>(R.id.btnPlayPause).setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                }
            })
            exo.setMediaItem(MediaItem.Builder().setUri(Uri.fromFile(file)).setMimeType(mime).build())
            exo.prepare()
            SubtitleController.enableAutoSubtitles(exo)
            exo.playWhenReady = true
        }
        handler.post(progressRunnable)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> { seekBy(15_000L); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { seekBy(-15_000L); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun seekBy(delta: Long) {
        val p = player ?: return
        p.seekTo((p.currentPosition + delta).coerceAtLeast(0L))
        val indicator = findViewById<TextView>(R.id.txtSeekIndicator)
        indicator.text = if (delta > 0) "+15" else "-15"
        indicator.visibility = View.VISIBLE
        handler.postDelayed({ indicator.visibility = View.GONE }, 700L)
    }

    private fun updateProgress() {
        val p = player ?: return
        val duration = p.duration.coerceAtLeast(0L)
        val position = p.currentPosition.coerceAtLeast(0L)
        findViewById<SeekBar>(R.id.seekBar).apply {
            if (duration in 1..Int.MAX_VALUE.toLong()) max = duration.toInt()
            progress = position.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }
        findViewById<TextView>(R.id.txtCurrentTime).text = format(position)
        findViewById<TextView>(R.id.txtTotalTime).text = format(duration)
    }

    private fun format(ms: Long): String {
        val total = ms / 1000L
        return String.format(Locale.US, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PATH = "recording_path"
        const val EXTRA_MIME = "recording_mime"
        const val EXTRA_TITLE = "recording_title"
    }
}
