package com.brotv.player.player

import android.content.Context
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioCapabilities
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.brotv.player.data.DecoderBlacklist
import java.util.Collections
import java.util.WeakHashMap

/**
 * محرك التشغيل المركزي. يطبق إعدادات الجودة والـBuffer والصوت واختيار الـDecoder
 * فعلياً عند إنشاء ExoPlayer، وليس كخيارات واجهة فقط.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
object PlayerEngine {

    enum class BufferProfile { AUTO, LOW_LATENCY, BALANCED, STABLE }
    enum class QualityMode { AUTO, SOURCE, UHD_4K, FHD_1080P, HD_720P }

    private val trackSelectors = Collections.synchronizedMap(WeakHashMap<ExoPlayer, DefaultTrackSelector>())

    fun buildPlayer(
        context: Context,
        bufferProfile: BufferProfile = BufferProfile.BALANCED,
        qualityMode: QualityMode = QualityMode.SOURCE,
        audioOutputMode: AudioOutputMode = AudioOutputMode.AUTO
    ): ExoPlayer {
        val appContext = context.applicationContext

        val codecSelector = MediaCodecSelector { mimeType, requiresSecureDecoder, requiresTunnelingDecoder ->
            val decoders = MediaCodecSelector.DEFAULT.getDecoderInfos(
                mimeType,
                requiresSecureDecoder,
                requiresTunnelingDecoder
            )
            // لا نحذف Decoder نهائياً حتى لا نكسر أجهزة فيها Decoder واحد فقط.
            // ننقل الـDecoder الذي فشل مرتين أو أكثر إلى آخر القائمة، فيستخدمه Media3
            // فقط إذا لم يوجد بديل مناسب.
            decoders.sortedBy { info ->
                if (DecoderBlacklist.isUnreliable(appContext, mimeType, info.name)) 1 else 0
            }
        }

        val renderersFactory = object : DefaultRenderersFactory(appContext) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                val capabilities = when (audioOutputMode) {
                    AudioOutputMode.PCM -> AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES
                    AudioOutputMode.AUTO,
                    AudioOutputMode.PASSTHROUGH -> AudioCapabilities.getCapabilities(context)
                }
                return DefaultAudioSink.Builder(context)
                    .setAudioCapabilities(capabilities)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
            }
        }
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
            .setMediaCodecSelector(codecSelector)

        val trackSelector = DefaultTrackSelector(appContext).apply {
            parameters = buildQualityParameters(appContext, qualityMode)
        }

        return ExoPlayer.Builder(appContext)
            .setRenderersFactory(renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(buildLoadControl(bufferProfile))
            .build()
            .also { trackSelectors[it] = trackSelector }
    }

    /**
     * يغيّر سقف جودة الفيديو أثناء التشغيل عبر TrackSelector نفسه، بدون Release/Recreate.
     * لا يرفع الجودة أبداً فوق اختيار المستخدم الأصلي.
     */
    fun applySmartQualityCeiling(
        player: ExoPlayer,
        userMode: QualityMode,
        ceiling: SmartQualityGuard.Ceiling
    ): Boolean {
        val selector = trackSelectors[player] ?: return false
        val userCap = when (userMode) {
            QualityMode.AUTO, QualityMode.SOURCE -> Int.MAX_VALUE to Int.MAX_VALUE
            QualityMode.UHD_4K -> 3840 to 2160
            QualityMode.FHD_1080P -> 1920 to 1080
            QualityMode.HD_720P -> 1280 to 720
        }
        val guardCap = when (ceiling) {
            SmartQualityGuard.Ceiling.USER_MAX -> Int.MAX_VALUE to Int.MAX_VALUE
            SmartQualityGuard.Ceiling.FHD_1080P -> 1920 to 1080
            SmartQualityGuard.Ceiling.HD_720P -> 1280 to 720
            SmartQualityGuard.Ceiling.SD_540P -> 960 to 540
        }
        val maxWidth = minOf(userCap.first, guardCap.first)
        val maxHeight = minOf(userCap.second, guardCap.second)
        val params = selector.buildUponParameters()
            .setMaxVideoSize(maxWidth, maxHeight)
            .setForceHighestSupportedBitrate(userMode != QualityMode.AUTO)
        selector.setParameters(params)
        return true
    }

    fun userQualityMaxHeight(mode: QualityMode): Int = when (mode) {
        QualityMode.AUTO, QualityMode.SOURCE -> Int.MAX_VALUE
        QualityMode.UHD_4K -> 2160
        QualityMode.FHD_1080P -> 1080
        QualityMode.HD_720P -> 720
    }

    fun buildQualityParameters(context: Context, mode: QualityMode): DefaultTrackSelector.Parameters {
        // مهم: `DefaultTrackSelector.Parameters.Builder(context)` يقيّد تلقائياً اختيار
        // الجودة من أي بث تكيفي (HLS/DASH Adaptive) بحسب دقة خرج HDMI *الحالية* للجهاز
        // (viewport = physical display size وقت الإنشاء). يعني لو الجهاز شغّال حالياً
        // على 1080p (شائع قبل ما يبدّل أول قناة 4K)، بيتم استبعاد أي نسخة 4K من البث
        // نهائياً حتى لو "المصدر"/SOURCE مفعّلة — وهذا هو السبب الحقيقي خلف عدم وصول
        // الجودة الكاملة، مو مشكلة Decoder أو Bandwidth. نلغي هذا القيد الضمني هنا
        // لكل الأوضاع ونترك التحكم الفعلي بالسقف لـsetMaxVideoSize صراحة (زي المنافس
        // الذي يعرض 4K كامل ويجعل التلفزيون نفسه يعرض إشعار 4K حقيقي).
        val builder = DefaultTrackSelector.Parameters.Builder(context)
            .setViewportSize(Int.MAX_VALUE, Int.MAX_VALUE, true)
        return when (mode) {
            QualityMode.AUTO -> builder.build()
            QualityMode.SOURCE -> builder.setForceHighestSupportedBitrate(true).build()
            QualityMode.UHD_4K -> builder.setForceHighestSupportedBitrate(true)
                .setMaxVideoSize(3840, 2160).build()
            QualityMode.FHD_1080P -> builder.setForceHighestSupportedBitrate(true)
                .setMaxVideoSize(1920, 1080).build()
            QualityMode.HD_720P -> builder.setForceHighestSupportedBitrate(true)
                .setMaxVideoSize(1280, 720).build()
        }
    }

    private fun buildLoadControl(profile: BufferProfile): DefaultLoadControl {
        val builder = DefaultLoadControl.Builder()
        when (profile) {
            BufferProfile.LOW_LATENCY -> builder.setBufferDurationsMs(
                3_000, 10_000, 500, 1_000
            )
            BufferProfile.BALANCED -> builder.setBufferDurationsMs(
                8_000, 30_000, 1_500, 2_500
            )
            BufferProfile.STABLE -> builder.setBufferDurationsMs(
                15_000, 60_000, 3_000, 5_000
            )
            BufferProfile.AUTO -> builder.setBufferDurationsMs(
                8_000, 30_000, 1_500, 2_500
            )
        }
        return builder.build()
    }
}
