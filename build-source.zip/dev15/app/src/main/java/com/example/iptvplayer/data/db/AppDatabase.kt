package com.brotv.player.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * قاعدة البيانات المركزية للتطبيق. تحتوي المصادر، كاش EPG، ووظائف DVR/الجدولة.
 * بقية الحالة الخفيفة (المفضلة/التفضيلات/المشاهدة) ما زالت تُدار عبر مخازنها الحالية.
 */
@Database(
    entities = [ProviderEntity::class, EpgProgramEntity::class, RecordingEntity::class],
    version = 3,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun providerDao(): ProviderDao
    abstract fun epgDao(): EpgDao
    abstract fun recordingDao(): RecordingDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE providers ADD COLUMN epgUrl TEXT NOT NULL DEFAULT ''")
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS epg_programs (
                        sourceId TEXT NOT NULL,
                        channelId TEXT NOT NULL,
                        channelName TEXT NOT NULL,
                        normalizedChannelName TEXT NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT NOT NULL,
                        startTimeMs INTEGER NOT NULL,
                        endTimeMs INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        PRIMARY KEY(sourceId, channelId, startTimeMs)
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_epg_programs_sourceId_channelId_startTimeMs_endTimeMs ON epg_programs(sourceId, channelId, startTimeMs, endTimeMs)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_epg_programs_sourceId_normalizedChannelName_startTimeMs_endTimeMs ON epg_programs(sourceId, normalizedChannelName, startTimeMs, endTimeMs)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_epg_programs_updatedAt ON epg_programs(updatedAt)")
            }
        }


        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS recordings (
                        id TEXT NOT NULL PRIMARY KEY,
                        channelId TEXT NOT NULL,
                        channelName TEXT NOT NULL,
                        title TEXT NOT NULL,
                        encryptedSourceUrls TEXT NOT NULL,
                        scheduledStartMs INTEGER NOT NULL,
                        scheduledEndMs INTEGER NOT NULL,
                        actualStartMs INTEGER NOT NULL,
                        actualEndMs INTEGER NOT NULL,
                        filePath TEXT NOT NULL,
                        mimeType TEXT NOT NULL,
                        status TEXT NOT NULL,
                        bytesWritten INTEGER NOT NULL,
                        errorMessage TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recordings_status ON recordings(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recordings_scheduledStartMs ON recordings(scheduledStartMs)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recordings_scheduledEndMs ON recordings(scheduledEndMs)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recordings_channelId ON recordings(channelId)")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "brotv_database"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
