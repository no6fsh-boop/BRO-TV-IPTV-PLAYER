package com.brotv.player.model

/**
 * يحول القناة الخام إلى نموذج التشغيل الكامل حتى تمر كل مسارات البث الحي عبر
 * FullPlayerActivity ونفس طبقات الحماية/الاسترداد/الجودة بدلاً من المشغل القديم.
 */
fun Channel.toMergedChannel(): MergedChannel = MergedChannel(
    id = id,
    name = name,
    groupTitle = groupTitle,
    logoUrl = logoUrl,
    sourceUrls = listOf(streamUrl),
    epgIds = listOfNotNull(epgId?.takeIf { it.isNotBlank() }),
    hasArchive = hasArchive,
    archiveDurationDays = archiveDurationDays
)
