package com.brotv.player.data

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import javax.xml.parsers.SAXParserFactory

/** Streaming XMLTV parser: لا يحمّل ملف XML الكامل بالذاكرة. */
object XmltvParser {
    data class Programme(
        val channelId: String,
        val channelName: String,
        val title: String,
        val description: String,
        val startTimeMs: Long,
        val endTimeMs: Long
    )

    fun parse(
        input: InputStream,
        windowStartMs: Long = Long.MIN_VALUE,
        windowEndMs: Long = Long.MAX_VALUE,
        maxProgrammes: Int = 100_000
    ): List<Programme> {
        val channels = LinkedHashMap<String, String>()
        val raw = ArrayList<RawProgramme>()
        val factory = SAXParserFactory.newInstance().apply {
            isNamespaceAware = false
            try { setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Exception) {}
            try { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Exception) {}
            try { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) {}
        }
        factory.newSAXParser().parse(input, object : DefaultHandler() {
            private var channelId: String? = null
            private var programme: RawProgramme? = null
            private var activeTag: String? = null
            private val text = StringBuilder()

            override fun startElement(uri: String?, localName: String?, qName: String, attributes: Attributes) {
                when (qName.lowercase(Locale.US)) {
                    "channel" -> channelId = attributes.getValue("id")?.trim()
                    "programme" -> {
                        if (raw.size >= maxProgrammes) return
                        val id = attributes.getValue("channel")?.trim().orEmpty()
                        val start = parseXmltvTime(attributes.getValue("start")) ?: return
                        val stop = parseXmltvTime(attributes.getValue("stop")) ?: return
                        if (stop <= windowStartMs || start >= windowEndMs || stop <= start) return
                        programme = RawProgramme(id, start, stop)
                    }
                    "display-name", "title", "desc" -> {
                        activeTag = qName.lowercase(Locale.US)
                        text.setLength(0)
                    }
                }
            }

            override fun characters(ch: CharArray, start: Int, length: Int) {
                if (activeTag != null) text.append(ch, start, length)
            }

            override fun endElement(uri: String?, localName: String?, qName: String) {
                when (qName.lowercase(Locale.US)) {
                    "display-name" -> {
                        val id = channelId
                        val value = text.toString().trim()
                        if (!id.isNullOrBlank() && value.isNotBlank() && channels[id].isNullOrBlank()) channels[id] = value
                        activeTag = null
                    }
                    "title" -> {
                        programme?.title = text.toString().trim()
                        activeTag = null
                    }
                    "desc" -> {
                        programme?.description = text.toString().trim()
                        activeTag = null
                    }
                    "programme" -> {
                        programme?.takeIf { it.channelId.isNotBlank() && it.title.isNotBlank() }?.let(raw::add)
                        programme = null
                    }
                    "channel" -> channelId = null
                }
            }
        })
        return raw.map {
            Programme(
                channelId = it.channelId,
                channelName = channels[it.channelId].orEmpty(),
                title = it.title,
                description = it.description,
                startTimeMs = it.startTimeMs,
                endTimeMs = it.endTimeMs
            )
        }
    }

    internal fun parseXmltvTime(value: String?): Long? {
        val raw = value?.trim()?.takeIf { it.length >= 12 } ?: return null
        val parts = raw.split(Regex("\\s+"), limit = 2)
        var stamp = parts[0]
        var zone = parts.getOrNull(1)?.trim().orEmpty()
        if (zone.isEmpty() && stamp.length > 14) {
            zone = stamp.substring(14)
            stamp = stamp.substring(0, 14)
        }
        zone = zone.replace(Regex("([+-]\\d{2}):(\\d{2})"), "$1$2")
        val base = when (stamp.length) {
            12 -> "yyyyMMddHHmm"
            else -> {
                stamp = stamp.take(14)
                "yyyyMMddHHmmss"
            }
        }
        val pattern = if (zone.isNotBlank()) "$base Z" else base
        val valueToParse = if (zone.isNotBlank()) "$stamp $zone" else stamp
        return try {
            SimpleDateFormat(pattern, Locale.US).apply {
                isLenient = false
                if (zone.isBlank()) timeZone = TimeZone.getDefault()
            }.parse(valueToParse)?.time
        } catch (_: Exception) {
            null
        }
    }

    private data class RawProgramme(
        val channelId: String,
        val startTimeMs: Long,
        val endTimeMs: Long,
        var title: String = "",
        var description: String = ""
    )
}
