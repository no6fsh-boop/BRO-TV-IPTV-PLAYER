package com.brotv.player.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load
import com.brotv.player.R
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.StreamHealthRegistry
import com.brotv.player.model.MergedChannel

/**
 * Live-channel rows stay deliberately cheap to bind. Health indicators come only from cached
 * playback telemetry; scrolling never launches network probes. ListAdapter also prevents a full
 * RecyclerView rebuild when the user changes category or returns from the player.
 */
class MergedChannelAdapter(
    private val gridSpanCount: Int = 1,
    private val onLeftEdge: () -> Unit = {},
    private val onClick: (MergedChannel) -> Unit
) : ListAdapter<MergedChannel, MergedChannelAdapter.ChannelViewHolder>(DIFF) {

    private var prefs: PrefsManager? = null

    init {
        setHasStableIds(true)
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<MergedChannel>() {
            override fun areItemsTheSame(oldItem: MergedChannel, newItem: MergedChannel) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: MergedChannel, newItem: MergedChannel) = oldItem == newItem
        }
    }

    class ChannelViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val index: TextView = view.findViewById(R.id.txtIndex)
        val name: TextView = view.findViewById(R.id.txtName)
        val signal: ImageView = view.findViewById(R.id.imgSignal)
        val sourceCount: TextView = view.findViewById(R.id.txtSourceCount)
        val logo: ImageView = view.findViewById(R.id.imgLogo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_merged_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun getItemId(position: Int): Long = getItem(position).id.hashCode().toLong()

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = getItem(position)
        val context = holder.itemView.context
        val localPrefs = prefs ?: PrefsManager(context).also { prefs = it }

        holder.index.text = if (localPrefs.showChannelNumbers) (position + 1).toString() else ""
        holder.name.text = channel.name
        holder.signal.setImageResource(signalIconFor(channel))

        holder.logo.dispose()
        holder.logo.tag = channel.id
        if (channel.logoUrl.isNullOrBlank()) {
            holder.logo.setImageResource(R.drawable.ic_tv)
        } else {
            holder.logo.load(channel.logoUrl) {
                crossfade(false)
                placeholder(R.drawable.ic_tv)
                error(R.drawable.ic_tv)
            }
        }

        holder.sourceCount.text = if (channel.sourceUrls.size > 1) {
            context.getString(R.string.source_count, channel.sourceUrls.size)
        } else {
            ""
        }
        holder.sourceCount.visibility = if (channel.sourceUrls.size > 1) View.VISIBLE else View.GONE
        holder.itemView.setOnKeyListener { _, keyCode, event ->
            val adapterPosition = holder.bindingAdapterPosition
            val atGridLeftEdge = adapterPosition != RecyclerView.NO_POSITION &&
                adapterPosition % gridSpanCount == 0
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_LEFT && atGridLeftEdge) {
                onLeftEdge()
                true
            } else {
                false
            }
        }
        holder.itemView.setOnClickListener { onClick(channel) }
    }

    override fun onViewRecycled(holder: ChannelViewHolder) {
        holder.itemView.setOnKeyListener(null)
        holder.itemView.setOnClickListener(null)
        holder.logo.dispose()
        holder.logo.tag = null
        super.onViewRecycled(holder)
    }

    private fun signalIconFor(channel: MergedChannel): Int {
        val scores = channel.sourceUrls.mapNotNull(StreamHealthRegistry::score)
        val bestScore = scores.maxOrNull() ?: return R.drawable.ic_signal_unknown
        return when {
            bestScore >= 80 -> R.drawable.ic_signal_good
            bestScore >= 55 -> R.drawable.ic_signal_medium
            else -> R.drawable.ic_signal_weak
        }
    }
}
