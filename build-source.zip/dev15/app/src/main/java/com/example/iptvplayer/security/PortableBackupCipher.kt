package com.brotv.player.security

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * تشفير نسخة احتياطية قابلة للنقل بين الأجهزة باستخدام كلمة مرور المستخدم.
 * التنسيق ثابت ومستقل عن Android Keystore حتى يستطيع جهاز آخر فك الملف.
 */
object PortableBackupCipher {
    private const val PREFIX = "brotv:portable:v1:"
    private const val ITERATIONS = 300_000
    private const val KEY_BITS = 256
    private const val SALT_BYTES = 16
    private const val IV_BYTES = 12
    private val secureRandom = SecureRandom()

    fun isPortable(text: String): Boolean = text.startsWith(PREFIX)

    fun encrypt(plainText: String, password: CharArray): String {
        require(password.isNotEmpty()) { "كلمة مرور النسخة الاحتياطية مطلوبة" }
        val salt = ByteArray(SALT_BYTES).also(secureRandom::nextBytes)
        val iv = ByteArray(IV_BYTES).also(secureRandom::nextBytes)
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        cipher.updateAAD(PREFIX.toByteArray(Charsets.UTF_8))
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val payload = ByteArray(salt.size + iv.size + encrypted.size)
        System.arraycopy(salt, 0, payload, 0, salt.size)
        System.arraycopy(iv, 0, payload, salt.size, iv.size)
        System.arraycopy(encrypted, 0, payload, salt.size + iv.size, encrypted.size)
        return PREFIX + Base64.encodeToString(payload, Base64.NO_WRAP)
    }

    fun decrypt(text: String, password: CharArray): String? {
        if (!isPortable(text) || password.isEmpty()) return null
        return try {
            val payload = Base64.decode(text.removePrefix(PREFIX), Base64.NO_WRAP)
            if (payload.size <= SALT_BYTES + IV_BYTES) return null
            val salt = payload.copyOfRange(0, SALT_BYTES)
            val iv = payload.copyOfRange(SALT_BYTES, SALT_BYTES + IV_BYTES)
            val encrypted = payload.copyOfRange(SALT_BYTES + IV_BYTES, payload.size)
            val key = deriveKey(password, salt)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            cipher.updateAAD(PREFIX.toByteArray(Charsets.UTF_8))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    private fun deriveKey(password: CharArray, salt: ByteArray): SecretKeySpec {
        // HMAC-SHA1 مستخدم هنا ليتوافق مع minSdk 21 عبر جميع الأجهزة؛ أمان PBKDF2 هنا
        // يعتمد على كلمة مرور قوية + Salt عشوائي + عدد دورات مرتفع، وليس مقاومة تصادم SHA1.
        val spec = PBEKeySpec(password, salt, ITERATIONS, KEY_BITS)
        return try {
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }
}
