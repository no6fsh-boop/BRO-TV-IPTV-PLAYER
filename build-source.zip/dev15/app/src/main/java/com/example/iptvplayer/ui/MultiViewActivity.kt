package com.brotv.player.ui

import android.app.ActivityManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.PrefsManager
import com.brotv.player.model.MergedChannel
import com.brotv.player.player.AudioOutputMode
import com.brotv.player.player.MultiViewPolicy
import com.brotv.player.player.PlayerEngine
import com.brotv.player.player.ResourceBudget
import com.brotv.player.player.ResourceGuard
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Multiview محافظ على Android TV: حتى 4 قنوات حسب قدرة الجهاز، صوت نافذة واحدة فقط،
 * سقف جودة ديناميكي، Failover مستقل، وResourceGuard يمنع تجاوز اتصالات المزود/قدرة الجهاز.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class MultiViewActivity : AppCompatActivity() {

    private data class PaneState(
        var channel: MergedChannel? = null,
        var player: ExoPlayer? = null,
        var resourceLease: ResourceGuard.Lease? = null,
        var sourceIndex: Int = 0,
        var currentUrl: String? = null,
        var requestToken: Long = 0L,
        val failedUrls: MutableSet<String> = mutableSetOf()
    )

    private lateinit var prefs: PrefsManager
    private val panes = Array(4) { PaneState() }
    private lateinit var paneContainers: List<FrameLayout>
    private lateinit var playerViews: List<PlayerView>
    private lateinit var nameViews: List<TextView>
    private lateinit var stateViews: List<TextView>
    private var selectedPane = 0
    private var maxPanes = 2
    private var returningFromBackground = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multiview)
        prefs = PrefsManager(this)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        paneContainers = listOf(
            findViewById(R.id.pane0), findViewById(R.id.pane1),
            findViewById(R.id.pane2), findViewById(R.id.pane3)
        )
        playerViews = listOf(
            findViewById(R.id.player0), findViewById(R.id.player1),
            findViewById(R.id.player2), findViewById(R.id.player3)
        )
        nameViews = listOf(
            findViewById(R.id.txtPane0Name), findViewById(R.id.txtPane1Name),
            findViewById(R.id.txtPane2Name), findViewById(R.id.txtPane3Name)
        )
        stateViews = listOf(
            findViewById(R.id.txtPane0State), findViewById(R.id.txtPane1State),
            findViewById(R.id.txtPane2State), findViewById(R.id.txtPane3State)
        )

        maxPanes = calculateDeviceCapacity()
        configurePanes()
        findViewById<ImageView>(R.id.btnMultiBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.txtMultiCapacity).text =
            getString(R.string.multiview_capacity, maxPanes)

        loadChannels()
        readInitialChannel()?.let { assignChannel(0, it) }
    }

    private fun calculateDeviceCapacity(): Int {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        return MultiViewPolicy.maxPanes(
            MultiViewPolicy.DeviceProfile(
                lowRamDevice = am.isLowRamDevice,
                memoryClassMb = am.memoryClass,
                sdkInt = Build.VERSION.SDK_INT
            )
        )
    }

    private fun configurePanes() {
        paneContainers.forEachIndexed { index, pane ->
            pane.visibility = if (index < maxPanes) View.VISIBLE else View.GONE
            pane.isFocusable = index < maxPanes
            pane.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) selectPane(index)
            }
            pane.setOnClickListener {
                panes[index].channel?.let { openFullScreen(it) }
                    ?: selectPane(index)
            }
            pane.setOnLongClickListener {
                clearPane(index)
                true
            }
        }
        selectPane(0)
    }

    private fun loadChannels() {
        val recycler = findViewById<RecyclerView>(R.id.recyclerMultiChannels)
        recycler.layoutManager = LinearLayoutManager(this)
        lifecycleScope.launch {
            val hiddenIds = prefs.hiddenChannelIds
            val hiddenGroups = prefs.hiddenLiveCategories
            val channels = MergedChannelRepository(this@MultiViewActivity).loadMergedChannels()
                .filter { it.id !in hiddenIds && it.groupTitle !in hiddenGroups }
            recycler.adapter = MultiViewChannelAdapter(channels) { channel ->
                assignChannel(selectedPane, channel)
                selectedPane = nextEmptyPaneAfter(selectedPane) ?: selectedPane
                updateSelectionVisuals()
                updateLeasePriorities()
            }
        }
    }

    private fun selectPane(index: Int) {
        if (index !in 0 until maxPanes) return
        selectedPane = index
        updateSelectionVisuals()
        updateAudioFocus()
        updateLeasePriorities()
        applyQualityCaps()
    }

    private fun updateSelectionVisuals() {
        paneContainers.forEachIndexed { index, pane -> pane.isActivated = index == selectedPane }
        findViewById<TextView>(R.id.txtMultiSelected).text =
            getString(R.string.multiview_selected_pane, selectedPane + 1)
    }

    private fun updateLeasePriorities() {
        panes.take(maxPanes).forEachIndexed { index, state ->
            state.resourceLease?.updateKind(multiviewKind(index))
        }
    }

    private fun multiviewKind(index: Int): ResourceBudget.SessionKind =
        if (index == selectedPane) ResourceBudget.SessionKind.MULTIVIEW_FOCUSED
        else ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND

    private fun assignChannel(index: Int, channel: MergedChannel) {
        if (index !in 0 until maxPanes) return
        val state = panes[index]
        state.requestToken++
        releasePlayer(index, releaseLease = true)
        state.channel = channel
        state.sourceIndex = 0
        state.failedUrls.clear()
        nameViews[index].text = channel.name
        stateViews[index].text = getString(R.string.multiview_connecting)
        startSource(index, 0)
    }

    /**
     * Starts only after ResourceGuard grants a provider/device lease. A monotonically increasing
     * request token prevents a slow account-info probe from resurrecting an old pane selection.
     */
    private fun startSource(index: Int, sourceIndex: Int) {
        if (index !in 0 until maxPanes) return
        val state = panes[index]
        val channel = state.channel ?: return
        val url = channel.sourceUrls.getOrNull(sourceIndex) ?: run {
            stateViews[index].text = getString(R.string.multiview_all_sources_failed)
            return
        }

        val targetProviderKey = ResourceGuard.providerKeyFor(url)
        val reusableLease = state.resourceLease?.takeIf { it.providerKey == targetProviderKey }

        state.requestToken++
        val token = state.requestToken
        releasePlayer(index, releaseLease = reusableLease == null)
        state.sourceIndex = sourceIndex
        state.currentUrl = url
        stateViews[index].text = getString(R.string.multiview_checking_capacity)

        lifecycleScope.launch {
            val lease: ResourceGuard.Lease = if (reusableLease != null) {
                reusableLease.updateKind(multiviewKind(index))
                reusableLease
            } else {
                when (val result = ResourceGuard.acquire(
                    context = this@MultiViewActivity,
                    streamUrl = url,
                    kind = multiviewKind(index),
                    onPreempt = { leaseId ->
                        runOnUiThread { handleResourcePreempted(index, leaseId) }
                    }
                )) {
                    is ResourceGuard.AcquireResult.Granted -> result.lease
                    is ResourceGuard.AcquireResult.Denied -> {
                        if (token == panes[index].requestToken) {
                            handleResourceDenied(index, url, result)
                        }
                        return@launch
                    }
                }
            }

            val latest = panes[index]
            if (token != latest.requestToken || latest.channel !== channel || latest.currentUrl != url || isFinishing) {
                if (lease !== reusableLease) lease.release()
                return@launch
            }

            latest.resourceLease = lease
            val player = PlayerEngine.buildPlayer(
                context = this@MultiViewActivity,
                bufferProfile = PlayerEngine.BufferProfile.BALANCED,
                qualityMode = currentQualityMode(),
                // Multiview uses PCM to avoid competing passthrough sessions; full-screen keeps the user's audio setting.
                audioOutputMode = AudioOutputMode.PCM
            )
            latest.player = player
            playerViews[index].player = player
            player.volume = if (index == selectedPane) 1f else 0f

            player.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (panes[index].player !== player) return
                    stateViews[index].text = when (playbackState) {
                        Player.STATE_BUFFERING -> getString(R.string.multiview_buffering)
                        Player.STATE_READY -> getString(R.string.multiview_live)
                        Player.STATE_ENDED -> getString(R.string.multiview_ended)
                        else -> getString(R.string.multiview_connecting)
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (panes[index].player !== player) return
                    if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED &&
                        handleDecoderPressure(index)
                    ) {
                        return
                    }
                    tryNextSource(index, url)
                }
            })

            player.setMediaItem(MediaItem.fromUri(url))
            player.prepare()
            player.playWhenReady = true
            applyQualityCaps()
        }
    }

    private fun handleResourceDenied(
        index: Int,
        deniedUrl: String,
        result: ResourceGuard.AcquireResult.Denied
    ) {
        when (result.reason) {
            ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT -> {
                val state = panes[index]
                val channel = state.channel ?: return
                state.failedUrls.add(deniedUrl)
                val next = channel.sourceUrls.indexOfFirst { it !in state.failedUrls }
                if (next >= 0) {
                    stateViews[index].text = getString(R.string.multiview_failover)
                    startSource(index, next)
                } else {
                    stateViews[index].text = getString(R.string.multiview_provider_limit)
                }
            }
            ResourceBudget.DenialReason.DEVICE_DECODER_LIMIT,
            ResourceBudget.DenialReason.DEVICE_MEMORY_PRESSURE -> {
                stateViews[index].text = getString(R.string.multiview_device_limit)
            }
        }
    }

    private fun handleResourcePreempted(index: Int, leaseId: Long) {
        if (index !in panes.indices) return
        val state = panes[index]
        if (state.resourceLease?.id != leaseId) return
        state.requestToken++
        releasePlayer(index, releaseLease = true)
        stateViews[index].text = getString(R.string.multiview_resource_preempted)
        applyQualityCaps()
    }

    private fun tryNextSource(index: Int, failedUrl: String) {
        val state = panes[index]
        val channel = state.channel ?: return
        state.failedUrls.add(failedUrl)
        val next = channel.sourceUrls.indexOfFirst { it !in state.failedUrls }
        if (next >= 0) {
            stateViews[index].text = getString(R.string.multiview_failover)
            startSource(index, next)
        } else {
            state.requestToken++
            releasePlayer(index, releaseLease = true)
            stateViews[index].text = getString(R.string.multiview_all_sources_failed)
        }
    }

    private fun applyQualityCaps() {
        val active = panes.take(maxPanes).count { it.player != null }
        val userMode = currentQualityMode()
        panes.take(maxPanes).forEachIndexed { index, state ->
            val player = state.player ?: return@forEachIndexed
            PlayerEngine.applySmartQualityCeiling(
                player = player,
                userMode = userMode,
                ceiling = MultiViewPolicy.ceiling(active, index == selectedPane)
            )
        }
    }

    private fun updateAudioFocus() {
        panes.take(maxPanes).forEachIndexed { index, state ->
            state.player?.volume = if (index == selectedPane) 1f else 0f
        }
    }

    private fun clearPane(index: Int) {
        if (index !in 0 until maxPanes) return
        val state = panes[index]
        state.requestToken++
        releasePlayer(index, releaseLease = true)
        state.channel = null
        state.sourceIndex = 0
        state.currentUrl = null
        state.failedUrls.clear()
        nameViews[index].text = getString(R.string.multiview_empty)
        stateViews[index].text = getString(R.string.multiview_choose_channel)
        applyQualityCaps()
    }

    private fun nextEmptyPaneAfter(index: Int): Int? {
        for (offset in 1..maxPanes) {
            val candidate = (index + offset) % maxPanes
            if (panes[candidate].channel == null) return candidate
        }
        return null
    }

    private fun openFullScreen(channel: MergedChannel) {
        startActivity(Intent(this, FullPlayerActivity::class.java).apply {
            putExtra(FullPlayerActivity.EXTRA_CHANNEL, channel)
            putExtra(FullPlayerActivity.EXTRA_IS_LIVE, true)
        })
    }

    private fun currentQualityMode(): PlayerEngine.QualityMode = runCatching {
        PlayerEngine.QualityMode.valueOf(prefs.qualityMode)
    }.getOrDefault(PlayerEngine.QualityMode.SOURCE)

    @Suppress("DEPRECATION")
    private fun readInitialChannel(): MergedChannel? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_CHANNEL, MergedChannel::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_CHANNEL)
        }

    private fun releasePlayer(index: Int, releaseLease: Boolean) {
        val state = panes[index]
        state.player?.let { player ->
            playerViews[index].player = null
            player.release()
        }
        state.player = null
        state.currentUrl = null
        if (releaseLease) {
            state.resourceLease?.release()
            state.resourceLease = null
        }
    }

    /**
     * Some TV SoCs advertise more decoder capability than they can sustain concurrently. If a
     * decoder fails while Multiview is active, reduce secondary load instead of repeatedly opening
     * new streams. The focused pane always wins.
     */
    private fun handleDecoderPressure(failedIndex: Int): Boolean {
        val activePlayers = panes.take(maxPanes).count { it.player != null }
        if (activePlayers <= 1) return false

        if (failedIndex != selectedPane) {
            panes[failedIndex].requestToken++
            releasePlayer(failedIndex, releaseLease = true)
            stateViews[failedIndex].text = getString(R.string.multiview_decoder_pressure)
            applyQualityCaps()
            return true
        }

        val background = panes.indices
            .asSequence()
            .filter { it < maxPanes && it != selectedPane }
            .firstOrNull { panes[it].player != null } ?: return false
        panes[background].requestToken++
        releasePlayer(background, releaseLease = true)
        stateViews[background].text = getString(R.string.multiview_decoder_pressure)

        val sourceIndex = panes[failedIndex].sourceIndex
        stateViews[failedIndex].text = getString(R.string.multiview_connecting)
        startSource(failedIndex, sourceIndex)
        applyQualityCaps()
        return true
    }

    private fun shedOneSecondaryPaneForMemoryPressure() {
        val candidate = panes.indices
            .asSequence()
            .filter { it < maxPanes && it != selectedPane }
            .firstOrNull { panes[it].player != null } ?: return
        panes[candidate].requestToken++
        releasePlayer(candidate, releaseLease = true)
        stateViews[candidate].text = getString(R.string.multiview_resource_shed)
        applyQualityCaps()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
        ) {
            // Keep the focused/main pane and shed one background decoder at a time.
            shedOneSecondaryPaneForMemoryPressure()
        }
    }

    override fun onStop() {
        super.onStop()
        // Full screen/main playback gets priority: release every secondary Decoder + connection first.
        panes.indices.forEach { index ->
            panes[index].requestToken++
            releasePlayer(index, releaseLease = true)
        }
        returningFromBackground = true
    }

    override fun onStart() {
        super.onStart()
        if (!returningFromBackground) return
        returningFromBackground = false
        lifecycleScope.launch {
            panes.take(maxPanes).forEachIndexed { index, state ->
                if (state.channel != null && state.player == null) {
                    delay(MultiViewPolicy.startupStaggerMs(index))
                    startSource(index, state.sourceIndex)
                }
            }
        }
    }

    override fun onDestroy() {
        panes.indices.forEach { index ->
            panes[index].requestToken++
            releasePlayer(index, releaseLease = true)
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CHANNEL = "extra_multiview_channel"
    }
}
