package com.brotv.player.data

import com.brotv.player.data.db.ProviderStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * يفحص صحة مصدر معيّن فعلياً: لو Xtream يتأكد من صلاحية الحساب نفسه (منتهي أو لا)
 * مو بس إنه يرد، ولو M3U يتأكد إن الرابط يرد بوقت معقول.
 */
object ProviderHealthChecker {

    suspend fun check(source: SourceConfig): ProviderStatus = withContext(Dispatchers.IO) {
        try {
            when (source.type) {
                PrefsManager.SourceType.XTREAM -> checkXtream(source)
                PrefsManager.SourceType.M3U -> checkM3u(source)
                PrefsManager.SourceType.NONE -> ProviderStatus.UNKNOWN
            }
        } catch (e: Exception) {
            ProviderStatus.OFFLINE
        }
    }

    private fun checkXtream(source: SourceConfig): ProviderStatus {
        val start = System.currentTimeMillis()
        val url = XtreamUrlCodec.playerApiUrl(
            source.xtreamServer,
            source.xtreamUsername,
            source.xtreamPassword
        )
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = 6_000
            connection.readTimeout = 6_000
            connection.instanceFollowRedirects = true
            connection.useCaches = false
            connection.requestMethod = "GET"
            connection.setRequestProperty("User-Agent", "BROTV/1.2")

            val responseCode = connection.responseCode
            val elapsed = System.currentTimeMillis() - start
            if (responseCode !in 200..299) return ProviderStatus.OFFLINE

            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val userInfo = try { JSONObject(body).optJSONObject("user_info") } catch (_: Exception) { null }
                ?: return ProviderStatus.OFFLINE
            val authOk = userInfo.optString("auth", "1").toIntOrNull()?.let { it != 0 }
                ?: (userInfo.optInt("auth", 1) != 0)
            val accountStatus = userInfo.optString("status", "Active")

            if (!authOk || accountStatus.equals("Expired", true) || accountStatus.equals("Disabled", true)) {
                ProviderStatus.EXPIRED
            } else if (elapsed < 1_500) {
                ProviderStatus.CONNECTED
            } else {
                ProviderStatus.SLOW
            }
        } finally {
            connection?.disconnect()
        }
    }

    private fun checkM3u(source: SourceConfig): ProviderStatus {
        val start = System.currentTimeMillis()
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(source.m3uUrl).openConnection() as HttpURLConnection
            connection.connectTimeout = 6_000
            connection.readTimeout = 6_000
            connection.instanceFollowRedirects = true
            connection.useCaches = false
            connection.requestMethod = "GET"
            connection.setRequestProperty("User-Agent", "BROTV/1.2")
            val responseCode = connection.responseCode
            val elapsed = System.currentTimeMillis() - start
            if (responseCode !in 200..299) ProviderStatus.OFFLINE
            else if (elapsed < 1_500) ProviderStatus.CONNECTED
            else ProviderStatus.SLOW
        } finally {
            connection?.disconnect()
        }
    }
}
