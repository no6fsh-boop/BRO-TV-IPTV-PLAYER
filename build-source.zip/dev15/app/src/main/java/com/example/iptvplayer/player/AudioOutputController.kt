package com.brotv.player.player

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.audio.AudioCapabilities

enum class AudioOutputMode { AUTO, PCM, PASSTHROUGH }

data class AudioOutputInfo(
    val mode: AudioOutputMode,
    val codec: String,
    val passthroughSupported: Boolean,
    val description: String
)

/**
 * يعرض حالة خرج الصوت بدون ادعاء أن Passthrough يعمل فعلياً لمجرد أن الجهاز قادر عليه.
 * القرار الفعلي لتهيئة AudioSink يتم داخل PlayerEngine.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
object AudioOutputController {
    fun inspect(context: Context, mimeType: String?, mode: AudioOutputMode): AudioOutputInfo {
        val capabilities = AudioCapabilities.getCapabilities(context)
        val encoding = when (mimeType) {
            MimeTypes.AUDIO_AC3 -> C.ENCODING_AC3
            MimeTypes.AUDIO_E_AC3 -> C.ENCODING_E_AC3
            MimeTypes.AUDIO_E_AC3_JOC -> C.ENCODING_E_AC3_JOC
            MimeTypes.AUDIO_DTS -> C.ENCODING_DTS
            MimeTypes.AUDIO_DTS_HD -> C.ENCODING_DTS_HD
            MimeTypes.AUDIO_TRUEHD -> C.ENCODING_DOLBY_TRUEHD
            else -> C.ENCODING_PCM_16BIT
        }
        val passthroughEligible = encoding != C.ENCODING_PCM_16BIT &&
            capabilities.supportsEncoding(encoding)
        val codec = mimeType?.substringAfterLast('/') ?: "unknown"
        val description = when (mode) {
            AudioOutputMode.PCM -> "$codec • requested PCM"
            AudioOutputMode.PASSTHROUGH -> if (passthroughEligible) {
                "$codec • passthrough eligible"
            } else {
                "$codec • PCM fallback"
            }
            AudioOutputMode.AUTO -> if (passthroughEligible) {
                "$codec • auto / passthrough eligible"
            } else {
                "$codec • auto / PCM"
            }
        }
        return AudioOutputInfo(mode, codec, passthroughEligible, description)
    }
}
