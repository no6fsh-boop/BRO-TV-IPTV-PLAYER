package com.brotv.player.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(recording: RecordingEntity)

    @Query("SELECT * FROM recordings ORDER BY CASE status WHEN 'RECORDING' THEN 0 WHEN 'WAITING_RESOURCE' THEN 1 WHEN 'SCHEDULED' THEN 2 ELSE 3 END, scheduledStartMs DESC, createdAt DESC")
    fun observeAll(): Flow<List<RecordingEntity>>

    @Query("SELECT * FROM recordings ORDER BY scheduledStartMs DESC, createdAt DESC")
    suspend fun getAll(): List<RecordingEntity>

    @Query("SELECT * FROM recordings WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): RecordingEntity?

    @Query("SELECT * FROM recordings WHERE channelId = :channelId AND status IN ('RECORDING','WAITING_RESOURCE') ORDER BY createdAt DESC LIMIT 1")
    suspend fun getActiveForChannel(channelId: String): RecordingEntity?

    @Query("SELECT * FROM recordings WHERE channelId = :channelId AND scheduledStartMs = :startMs AND scheduledEndMs = :endMs AND status IN ('SCHEDULED','WAITING_RESOURCE','RECORDING') ORDER BY createdAt DESC LIMIT 1")
    suspend fun getMatchingScheduled(channelId: String, startMs: Long, endMs: Long): RecordingEntity?

    @Query("SELECT * FROM recordings WHERE status = 'SCHEDULED' AND scheduledEndMs > :nowMs ORDER BY scheduledStartMs ASC")
    suspend fun getFutureScheduled(nowMs: Long): List<RecordingEntity>

    @Query("SELECT * FROM recordings WHERE status IN ('RECORDING','WAITING_RESOURCE','INTERRUPTED') AND (scheduledEndMs = 0 OR scheduledEndMs > :nowMs) ORDER BY createdAt ASC")
    suspend fun getRecoverable(nowMs: Long): List<RecordingEntity>

    @Query("UPDATE recordings SET status = :status, errorMessage = :errorMessage, actualStartMs = CASE WHEN :actualStartMs > 0 THEN :actualStartMs ELSE actualStartMs END, actualEndMs = CASE WHEN :actualEndMs > 0 THEN :actualEndMs ELSE actualEndMs END WHERE id = :id")
    suspend fun updateStatus(
        id: String,
        status: String,
        errorMessage: String = "",
        actualStartMs: Long = 0L,
        actualEndMs: Long = 0L
    )

    @Query("UPDATE recordings SET filePath = :filePath, mimeType = :mimeType, bytesWritten = :bytesWritten WHERE id = :id")
    suspend fun updateProgress(id: String, filePath: String, mimeType: String, bytesWritten: Long)

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteById(id: String)
}
