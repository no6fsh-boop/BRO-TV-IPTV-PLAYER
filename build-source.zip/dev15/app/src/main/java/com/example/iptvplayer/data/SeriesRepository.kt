package com.brotv.player.data

import android.content.Context
import com.brotv.player.model.Episode
import com.brotv.player.model.Series
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** يجمع مسلسلات كل حسابات Xtream المحفوظة مع بعض، ويعرف يرجع لنفس الحساب عند جلب الحلقات. */
class SeriesRepository(private val context: Context) {

    private val sourcesManager = SourcesManager(context)

    suspend fun getSeriesList(): List<Series> {
        val sources = sourcesManager.getXtreamSources()
        if (sources.isEmpty()) return emptyList()

        // Providers are independent. Loading them sequentially made the whole VOD screen wait
        // for every slow/dead provider. Keep concurrency deliberately small: many IPTV servers
        // rate-limit aggressive clients, and TV boxes have limited sockets/memory.
        val gate = Semaphore(3)
        return supervisorScope {
            sources.map { source ->
                async {
                    gate.withPermit {
                        runCatching {
                            val client = XtreamClient(source.xtreamServer, source.xtreamUsername, source.xtreamPassword)
                            client.getSeriesList(source.id)
                        }.getOrElse { emptyList() }
                    }
                }
            }.awaitAll().flatten() // awaitAll preserves configured provider order.
        }
    }

    /** seriesId بالصيغة series::sourceId::numericId، نستخدم sourceId عشان نرجع لنفس الحساب بالظبط. */
    suspend fun getEpisodes(seriesId: String): Map<Int, List<Episode>> {
        val parts = seriesId.split("::")
        if (parts.size < 3) return emptyMap()
        val sourceId = parts[1]

        val source = sourcesManager.getXtreamSources().firstOrNull { it.id == sourceId } ?: return emptyMap()
        val client = XtreamClient(source.xtreamServer, source.xtreamUsername, source.xtreamPassword)
        // Keep provider outages/malformed series payloads isolated to this series. The caller can
        // show an empty/retry state instead of losing the whole Activity or auto-next flow.
        return runCatching { client.getSeriesEpisodes(seriesId) }.getOrElse { emptyMap() }
    }

    suspend fun isSourceSupported(): Boolean = sourcesManager.getXtreamSources().isNotEmpty()
}
