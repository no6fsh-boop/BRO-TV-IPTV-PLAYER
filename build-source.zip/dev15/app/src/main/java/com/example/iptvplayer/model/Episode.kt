package com.brotv.player.model

import android.os.Parcel
import android.os.Parcelable

data class Episode(
    val id: String,
    val seriesId: String,
    val seriesName: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val plot: String,
    val durationLabel: String,
    val streamUrl: String,
    val imageUrl: String? = null,
    val watched: Boolean = false
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readInt(),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString(),
        parcel.readByte() != 0.toByte()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(seriesId)
        parcel.writeString(seriesName)
        parcel.writeInt(seasonNumber)
        parcel.writeInt(episodeNumber)
        parcel.writeString(title)
        parcel.writeString(plot)
        parcel.writeString(durationLabel)
        parcel.writeString(streamUrl)
        parcel.writeString(imageUrl)
        parcel.writeByte(if (watched) 1 else 0)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Episode> {
        override fun createFromParcel(parcel: Parcel): Episode = Episode(parcel)
        override fun newArray(size: Int): Array<Episode?> = arrayOfNulls(size)
    }
}
