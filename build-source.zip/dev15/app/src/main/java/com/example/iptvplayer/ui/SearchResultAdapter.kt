package com.brotv.player.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.model.SearchResultItem

class SearchResultAdapter(
    private val onClick: (SearchResultItem) -> Unit,
    private val onFirstItemUp: () -> Unit = {}
) : ListAdapter<SearchResultItem, SearchResultAdapter.ResultViewHolder>(DIFF) {

    class ResultViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.txtResultTitle)
        val subtitle: TextView = view.findViewById(R.id.txtResultSubtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_search_result, parent, false)
        return ResultViewHolder(view)
    }

    override fun onBindViewHolder(holder: ResultViewHolder, position: Int) {
        val item = getItem(position)
        holder.title.text = item.title
        holder.subtitle.text = item.subtitle
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnKeyListener { _, keyCode, event ->
            if (holder.bindingAdapterPosition == 0 && event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                onFirstItemUp()
                true
            } else false
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<SearchResultItem>() {
            override fun areItemsTheSame(oldItem: SearchResultItem, newItem: SearchResultItem): Boolean = when {
                oldItem.type != newItem.type -> false
                oldItem.channel != null || newItem.channel != null -> oldItem.channel?.id == newItem.channel?.id
                oldItem.movie != null || newItem.movie != null -> oldItem.movie?.id == newItem.movie?.id
                else -> oldItem.series?.id == newItem.series?.id
            }

            override fun areContentsTheSame(oldItem: SearchResultItem, newItem: SearchResultItem): Boolean = oldItem == newItem
        }
    }
}
