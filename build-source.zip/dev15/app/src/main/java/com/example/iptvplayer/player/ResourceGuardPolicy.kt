package com.brotv.player.player

/**
 * Pure policy/state machine behind [ResourceGuard]. It deliberately has no Android dependency so
 * provider-connection and decoder admission rules can be unit-tested on the JVM.
 *
 * A lease reserves one provider connection. Only leases with [SessionKind.usesVideoDecoder] also
 * count against the device decoder budget. Recording is modelled as a raw network workload, so it
 * consumes a provider connection without reserving a decoder.
 */
class ResourceBudget {

    enum class SessionKind(
        val priority: Int,
        val preemptible: Boolean,
        val usesVideoDecoder: Boolean
    ) {
        PRIMARY_PLAYBACK(priority = 100, preemptible = false, usesVideoDecoder = true),
        RECORDING(priority = 80, preemptible = true, usesVideoDecoder = false),
        MULTIVIEW_FOCUSED(priority = 60, preemptible = true, usesVideoDecoder = true),
        MULTIVIEW_BACKGROUND(priority = 40, preemptible = true, usesVideoDecoder = true),
        PREVIEW(priority = 20, preemptible = true, usesVideoDecoder = true)
    }

    enum class DenialReason {
        PROVIDER_CONNECTION_LIMIT,
        DEVICE_DECODER_LIMIT,
        DEVICE_MEMORY_PRESSURE
    }

    data class DeviceState(
        val lowRamDevice: Boolean,
        val memoryClassMb: Int,
        val sdkInt: Int,
        val availableMemoryMb: Long,
        val lowMemory: Boolean
    )

    data class ProviderState(
        val key: String,
        /** Null means the provider did not expose a reliable connection limit. */
        val maxConnections: Int? = null,
        /** Latest server-reported active_cons. Null when unavailable. */
        val reportedActiveConnections: Int? = null
    )

    data class Admission(
        val allowed: Boolean,
        val denialReason: DenialReason? = null,
        val preemptLeaseIds: List<Long> = emptyList(),
        val providerMaxConnections: Int? = null,
        val providerProjectedConnections: Int? = null,
        val deviceDecoderLimit: Int? = null
    )

    private data class LeaseRecord(
        val id: Long,
        val providerKey: String,
        var kind: SessionKind
    )

    private val leases = LinkedHashMap<Long, LeaseRecord>()

    /**
     * Conservative estimate of connections not owned by this process for each provider.
     * It never goes down while local leases exist, preventing active_cons timing jitter from
     * temporarily creating a fake free slot. Once all local leases are gone, the next acquire
     * establishes a fresh baseline.
     */
    private val externalConnectionFloor = mutableMapOf<String, Int>()

    fun acquire(
        leaseId: Long,
        kind: SessionKind,
        provider: ProviderState,
        device: DeviceState
    ): Admission {
        require(leaseId !in leases) { "Duplicate resource lease id: $leaseId" }

        val localForProvider = leases.values.count { it.providerKey == provider.key }
        updateExternalFloor(provider, localForProvider)

        val selectedForPreemption = LinkedHashSet<Long>()

        val maxConnections = provider.maxConnections?.takeIf { it > 0 }
        if (maxConnections != null) {
            val external = externalConnectionFloor[provider.key] ?: 0
            var projected = external + localForProvider + 1
            if (projected > maxConnections) {
                val providerCandidates = leases.values
                    .asSequence()
                    .filter { it.providerKey == provider.key }
                    .filter { it.kind.preemptible && it.kind.priority < kind.priority }
                    .sortedWith(compareBy<LeaseRecord> { it.kind.priority }.thenBy { it.id })
                    .toList()

                for (candidate in providerCandidates) {
                    if (projected <= maxConnections) break
                    selectedForPreemption += candidate.id
                    projected--
                }

                if (projected > maxConnections) {
                    return Admission(
                        allowed = false,
                        denialReason = DenialReason.PROVIDER_CONNECTION_LIMIT,
                        providerMaxConnections = maxConnections,
                        providerProjectedConnections = projected,
                        deviceDecoderLimit = decoderLimit(device)
                    )
                }
            }
        }

        if (kind.usesVideoDecoder) {
            val decoderLimit = decoderLimit(device)
            var projectedDecoders = leases.values.count {
                it.kind.usesVideoDecoder && it.id !in selectedForPreemption
            } + 1

            if (projectedDecoders > decoderLimit) {
                val decoderCandidates = leases.values
                    .asSequence()
                    .filter { it.id !in selectedForPreemption }
                    .filter { it.kind.usesVideoDecoder }
                    .filter { it.kind.preemptible && it.kind.priority < kind.priority }
                    .sortedWith(compareBy<LeaseRecord> { it.kind.priority }.thenBy { it.id })
                    .toList()

                for (candidate in decoderCandidates) {
                    if (projectedDecoders <= decoderLimit) break
                    selectedForPreemption += candidate.id
                    projectedDecoders--
                }

                if (projectedDecoders > decoderLimit) {
                    return Admission(
                        allowed = false,
                        denialReason = if (device.lowMemory || availableMemoryIsCritical(device)) {
                            DenialReason.DEVICE_MEMORY_PRESSURE
                        } else {
                            DenialReason.DEVICE_DECODER_LIMIT
                        },
                        providerMaxConnections = maxConnections,
                        providerProjectedConnections = maxConnections?.let {
                            (externalConnectionFloor[provider.key] ?: 0) + localForProvider + 1
                        },
                        deviceDecoderLimit = decoderLimit
                    )
                }
            }
        }

        // On actual Android low-memory pressure, secondary video sessions are not admitted even
        // if the nominal decoder count has room. PRIMARY can still enter by evicting lower work.
        if (kind.usesVideoDecoder && kind != SessionKind.PRIMARY_PLAYBACK &&
            (device.lowMemory || availableMemoryIsCritical(device))
        ) {
            return Admission(
                allowed = false,
                denialReason = DenialReason.DEVICE_MEMORY_PRESSURE,
                providerMaxConnections = maxConnections,
                deviceDecoderLimit = decoderLimit(device)
            )
        }

        val requestedProviderExternalFloor = externalConnectionFloor[provider.key]
        selectedForPreemption.forEach(::removeLeaseInternal)
        // If admission atomically replaces the last local lease of this same provider, keep the
        // external baseline. removeLeaseInternal normally clears it when a provider becomes empty.
        if (requestedProviderExternalFloor != null) {
            externalConnectionFloor[provider.key] = requestedProviderExternalFloor
        }
        leases[leaseId] = LeaseRecord(leaseId, provider.key, kind)

        val projectedProvider = maxConnections?.let {
            (externalConnectionFloor[provider.key] ?: 0) +
                leases.values.count { record -> record.providerKey == provider.key }
        }

        return Admission(
            allowed = true,
            preemptLeaseIds = selectedForPreemption.toList(),
            providerMaxConnections = maxConnections,
            providerProjectedConnections = projectedProvider,
            deviceDecoderLimit = decoderLimit(device)
        )
    }

    fun release(leaseId: Long) {
        removeLeaseInternal(leaseId)
    }

    fun updateKind(leaseId: Long, kind: SessionKind) {
        leases[leaseId]?.kind = kind
    }

    fun activeLeaseCount(): Int = leases.size

    fun activeDecoderCount(): Int = leases.values.count { it.kind.usesVideoDecoder }

    fun activeProviderConnectionCount(providerKey: String): Int =
        leases.values.count { it.providerKey == providerKey }

    fun estimatedProviderConnectionCount(providerKey: String): Int =
        (externalConnectionFloor[providerKey] ?: 0) + activeProviderConnectionCount(providerKey)

    private fun removeLeaseInternal(leaseId: Long) {
        val removed = leases.remove(leaseId) ?: return
        if (leases.values.none { it.providerKey == removed.providerKey }) {
            // Do not keep a stale external baseline forever. A future first acquire will sample
            // active_cons again before opening a stream.
            externalConnectionFloor.remove(removed.providerKey)
        }
    }

    private fun updateExternalFloor(provider: ProviderState, localForProvider: Int) {
        val reported = provider.reportedActiveConnections?.coerceAtLeast(0) ?: return
        if (localForProvider == 0) {
            externalConnectionFloor[provider.key] = reported
            return
        }

        // active_cons usually includes this app's current streams. Subtract known local leases so
        // they are not double-counted, while never lowering a previously established external floor.
        val inferredExternal = (reported - localForProvider).coerceAtLeast(0)
        val previous = externalConnectionFloor[provider.key] ?: 0
        externalConnectionFloor[provider.key] = maxOf(previous, inferredExternal)
    }

    private fun decoderLimit(device: DeviceState): Int {
        val base = when {
            device.lowRamDevice -> 2
            device.sdkInt < 23 -> 2
            device.memoryClassMb < 192 -> 2
            device.memoryClassMb < 256 -> 3
            else -> 4
        }
        return when {
            device.lowMemory -> 1
            device.availableMemoryMb in 0..127 -> 1
            device.availableMemoryMb in 128..191 -> minOf(base, 2)
            else -> base
        }
    }

    private fun availableMemoryIsCritical(device: DeviceState): Boolean =
        device.availableMemoryMb in 0..127
}
