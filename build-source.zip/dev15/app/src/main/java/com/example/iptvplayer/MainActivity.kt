package com.brotv.player

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import com.brotv.player.data.SourcesManager
import com.brotv.player.dvr.DvrScheduler
import com.brotv.player.ui.HomeActivity
import com.brotv.player.ui.LoginActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        lifecycleScope.launch {
            // AlarmManager entries can be lost after reboot/update; restore persisted DVR jobs on every app start.
            DvrScheduler.restore(this@MainActivity)
            val hasSource = SourcesManager(this@MainActivity).hasAnySource()
            delay(850L)
            val target = if (hasSource) {
                Intent(this@MainActivity, HomeActivity::class.java)
            } else {
                Intent(this@MainActivity, LoginActivity::class.java)
            }
            startActivity(target)
            finish()
        }
    }
}
