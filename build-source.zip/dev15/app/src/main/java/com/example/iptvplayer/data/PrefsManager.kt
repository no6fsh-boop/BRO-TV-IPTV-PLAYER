package com.brotv.player.data

import android.content.Context

/**
 * يخزّن إعدادات مصدر القنوات (M3U أو Xtream) في SharedPreferences
 * حتى لا يحتاج المستخدم لإدخالها كل مرة يفتح التطبيق.
 *
 * المفضلة مقسّمة لـ3 أقسام مستقلة تماماً (قنوات/أفلام/مسلسلات) بمخازن منفصلة،
 * ما فيه أي دمج أو مشاركة IDs بينهم.
 */
class PrefsManager(context: Context) {

    private val prefs = context.getSharedPreferences("iptv_prefs", Context.MODE_PRIVATE)
    private val profileId: String = ProfileManager(context).activeProfileId

    // 3 ملفات SharedPreferences منفصلة فعلياً (مو بس مفاتيح مختلفة بنفس الملف)،
    // كل نوع مفضلة له ملف تخزين مستقل تماماً على مستوى نظام أندرويد نفسه.
    private val channelFavoritesPrefs = context.getSharedPreferences("channel_favorites", Context.MODE_PRIVATE)
    private val movieFavoritesPrefs = context.getSharedPreferences("movie_favorites", Context.MODE_PRIVATE)
    private val seriesFavoritesPrefs = context.getSharedPreferences("series_favorites", Context.MODE_PRIVATE)

    /** يضيف معرّف البروفايل النشط كبادئة، عشان كل بروفايل يكون له مفضلة/سجل مشاهدة مستقل. */
    private fun profileScoped(key: String) = "${key}_$profileId"

    enum class SourceType { M3U, XTREAM, NONE }

    var sourceType: SourceType
        get() = SourceType.valueOf(prefs.getString(KEY_TYPE, SourceType.NONE.name)!!)
        set(value) = prefs.edit().putString(KEY_TYPE, value.name).apply()

    var m3uUrl: String
        get() = prefs.getString(KEY_M3U_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_M3U_URL, value).apply()

    var xtreamServer: String
        get() = prefs.getString(KEY_X_SERVER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_X_SERVER, value).apply()

    var xtreamUsername: String
        get() = prefs.getString(KEY_X_USER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_X_USER, value).apply()

    var xtreamPassword: String
        get() = prefs.getString(KEY_X_PASS, "") ?: ""
        set(value) = prefs.edit().putString(KEY_X_PASS, value).apply()

    /** يحفظ ترتيب القنوات كقائمة معرّفات مفصولة بفواصل. */
    var channelOrder: List<String>
        get() = prefs.getString(KEY_CHANNEL_ORDER, "")?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
        set(value) = prefs.edit().putString(KEY_CHANNEL_ORDER, value.joinToString(",")).apply()

    /** ترتيب مجلدات البث الحي كما رتّبها المستخدم من شاشة التنسيق. */
    var liveCategoryOrder: List<String>
        get() = prefs.getString(KEY_LIVE_CATEGORY_ORDER, "")?.split("\u001F")?.filter { it.isNotBlank() } ?: emptyList()
        set(value) = prefs.edit().putString(KEY_LIVE_CATEGORY_ORDER, value.joinToString("\u001F")).apply()

    // ---------- المفضلة: 3 أقسام مستقلة تماماً ----------

    var favoriteChannelIds: MutableSet<String>
        get() = HashSet(channelFavoritesPrefs.getStringSet(profileScoped(KEY_FAVORITE_CHANNELS), emptySet()) ?: emptySet())
        set(value) = channelFavoritesPrefs.edit().putStringSet(profileScoped(KEY_FAVORITE_CHANNELS), value).apply()

    var favoriteMovieIds: MutableSet<String>
        get() = HashSet(movieFavoritesPrefs.getStringSet(profileScoped(KEY_FAVORITE_MOVIES), emptySet()) ?: emptySet())
        set(value) = movieFavoritesPrefs.edit().putStringSet(profileScoped(KEY_FAVORITE_MOVIES), value).apply()

    var favoriteSeriesIds: MutableSet<String>
        get() = HashSet(seriesFavoritesPrefs.getStringSet(profileScoped(KEY_FAVORITE_SERIES), emptySet()) ?: emptySet())
        set(value) = seriesFavoritesPrefs.edit().putStringSet(profileScoped(KEY_FAVORITE_SERIES), value).apply()

    fun toggleChannelFavorite(channelId: String) {
        val current = favoriteChannelIds
        if (!current.remove(channelId)) current.add(channelId)
        favoriteChannelIds = current
    }

    fun toggleMovieFavorite(movieId: String) {
        val current = favoriteMovieIds
        if (!current.remove(movieId)) current.add(movieId)
        favoriteMovieIds = current
    }

    fun toggleSeriesFavorite(seriesId: String) {
        val current = favoriteSeriesIds
        if (!current.remove(seriesId)) current.add(seriesId)
        favoriteSeriesIds = current
    }

    // ---------- القنوات المخفية ----------

    var hiddenChannelIds: MutableSet<String>
        get() = HashSet(prefs.getStringSet(profileScoped(KEY_HIDDEN), emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(profileScoped(KEY_HIDDEN), value).apply()

    fun hideChannel(channelId: String) {
        val current = hiddenChannelIds
        current.add(channelId)
        hiddenChannelIds = current
    }

    // ---------- الحلقات المشاهدة ----------

    var watchedEpisodeIds: MutableSet<String>
        get() = HashSet(prefs.getStringSet(profileScoped(KEY_WATCHED_EPISODES), emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(profileScoped(KEY_WATCHED_EPISODES), value).apply()

    fun markEpisodeWatched(episodeId: String) {
        val current = watchedEpisodeIds
        current.add(episodeId)
        watchedEpisodeIds = current
    }

    fun hasSavedSource(): Boolean = sourceType != SourceType.NONE

    // ---------- إعدادات عامة (ما تتغير حسب البروفايل) ----------

    var use24HourTime: Boolean
        get() = prefs.getBoolean(KEY_TIME_FORMAT_24H, true)
        set(value) = prefs.edit().putBoolean(KEY_TIME_FORMAT_24H, value).apply()

    var compactChannelList: Boolean
        get() = prefs.getBoolean(KEY_COMPACT_LAYOUT, false)
        set(value) = prefs.edit().putBoolean(KEY_COMPACT_LAYOUT, value).apply()

    var showChannelNumbers: Boolean
        get() = prefs.getBoolean(KEY_SHOW_CHANNEL_NUMBERS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_CHANNEL_NUMBERS, value).apply()

    var hiddenLiveCategories: MutableSet<String>
        get() = HashSet(prefs.getStringSet(KEY_HIDDEN_LIVE_CATEGORIES, emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(KEY_HIDDEN_LIVE_CATEGORIES, value).apply()

    var hiddenVodCategories: MutableSet<String>
        get() = HashSet(prefs.getStringSet(KEY_HIDDEN_VOD_CATEGORIES, emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(KEY_HIDDEN_VOD_CATEGORIES, value).apply()

    var hiddenSeriesCategories: MutableSet<String>
        get() = HashSet(prefs.getStringSet(KEY_HIDDEN_SERIES_CATEGORIES, emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(KEY_HIDDEN_SERIES_CATEGORIES, value).apply()

    var lockedLiveCategories: MutableSet<String>
        get() = HashSet(prefs.getStringSet(KEY_LOCKED_LIVE_CATEGORIES, emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(KEY_LOCKED_LIVE_CATEGORIES, value).apply()

    var lockedVodCategories: MutableSet<String>
        get() = HashSet(prefs.getStringSet(KEY_LOCKED_VOD_CATEGORIES, emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(KEY_LOCKED_VOD_CATEGORIES, value).apply()

    var lockedSeriesCategories: MutableSet<String>
        get() = HashSet(prefs.getStringSet(KEY_LOCKED_SERIES_CATEGORIES, emptySet()) ?: emptySet())
        set(value) = prefs.edit().putStringSet(KEY_LOCKED_SERIES_CATEGORIES, value).apply()

    /** بروفايل الـBuffer: AUTO / LOW_LATENCY / BALANCED / STABLE (بند "Smart Buffer Engine"). */
    var bufferProfile: String
        get() = prefs.getString(KEY_BUFFER_PROFILE, "BALANCED") ?: "BALANCED"
        set(value) = prefs.edit().putString(KEY_BUFFER_PROFILE, value).apply()

    /** تفعيل تراكب معلومات التشغيل التقنية (Player Diagnostics) للمستخدم المتقدم. */
    var playerStatsOverlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_STATS_OVERLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_STATS_OVERLAY, value).apply()

    /** وضع الجودة: AUTO / SOURCE / UHD_4K / FHD_1080P / HD_720P (بند "Highest Quality"). */
    var qualityMode: String
        get() = prefs.getString(KEY_QUALITY_MODE, "SOURCE") ?: "SOURCE"
        set(value) = prefs.edit().putString(KEY_QUALITY_MODE, value).apply()

    /** مطابقة معدل الإطارات: OFF / AUTO / ALWAYS (بند "Match Frame Rate"). */
    var matchFrameRateMode: String
        get() = prefs.getString(KEY_MATCH_FRAME_RATE, "AUTO") ?: "AUTO"
        set(value) = prefs.edit().putString(KEY_MATCH_FRAME_RATE, value).apply()

    /** خرج الصوت: AUTO / PCM / PASSTHROUGH. */
    var audioOutputMode: String
        get() = prefs.getString(KEY_AUDIO_OUTPUT_MODE, "AUTO") ?: "AUTO"
        set(value) = prefs.edit().putString(KEY_AUDIO_OUTPUT_MODE, value).apply()

    /** حارس جودة ذكي يخفض سقف الفيديو مؤقتاً فقط عند ضغط فعلي ثم يعيد الجودة بعد الاستقرار. */
    var smartQualityGuardEnabled: Boolean
        get() = prefs.getBoolean(KEY_SMART_QUALITY_GUARD, true)
        set(value) = prefs.edit().putBoolean(KEY_SMART_QUALITY_GUARD, value).apply()

    fun clear() = prefs.edit().clear().apply()

    companion object {
        private const val KEY_TYPE = "source_type"
        private const val KEY_M3U_URL = "m3u_url"
        private const val KEY_X_SERVER = "xtream_server"
        private const val KEY_X_USER = "xtream_user"
        private const val KEY_X_PASS = "xtream_pass"
        private const val KEY_CHANNEL_ORDER = "channel_order"
        private const val KEY_LIVE_CATEGORY_ORDER = "live_category_order"
        private const val KEY_FAVORITE_CHANNELS = "favorite_channels"
        private const val KEY_FAVORITE_MOVIES = "favorite_movies"
        private const val KEY_FAVORITE_SERIES = "favorite_series"
        private const val KEY_HIDDEN = "hidden_channels"
        private const val KEY_WATCHED_EPISODES = "watched_episodes"
        private const val KEY_TIME_FORMAT_24H = "time_format_24h"
        private const val KEY_COMPACT_LAYOUT = "compact_layout"
        private const val KEY_SHOW_CHANNEL_NUMBERS = "show_channel_numbers"
        private const val KEY_HIDDEN_LIVE_CATEGORIES = "hidden_live_categories"
        private const val KEY_HIDDEN_VOD_CATEGORIES = "hidden_vod_categories"
        private const val KEY_HIDDEN_SERIES_CATEGORIES = "hidden_series_categories"
        private const val KEY_LOCKED_LIVE_CATEGORIES = "locked_live_categories"
        private const val KEY_LOCKED_VOD_CATEGORIES = "locked_vod_categories"
        private const val KEY_LOCKED_SERIES_CATEGORIES = "locked_series_categories"
        private const val KEY_BUFFER_PROFILE = "buffer_profile"
        private const val KEY_STATS_OVERLAY = "stats_overlay_enabled"
        private const val KEY_QUALITY_MODE = "quality_mode"
        private const val KEY_MATCH_FRAME_RATE = "match_frame_rate_mode"
        private const val KEY_AUDIO_OUTPUT_MODE = "audio_output_mode"
        private const val KEY_SMART_QUALITY_GUARD = "smart_quality_guard_enabled"

        /**
         * وصول مباشر لبيانات بروفايل معيّن (مو بس البروفايل النشط حالياً) — يُستخدم فقط
         * من BackupManager عشان يصدّر ويسترجع بيانات كل البروفايلات مو بس الحالي.
         * كل نوع مفضلة يُقرأ من ملف SharedPreferences المستقل الخاص فيه.
         */
        private fun rawPrefs(context: Context) = context.getSharedPreferences("iptv_prefs", Context.MODE_PRIVATE)
        private fun channelFavPrefs(context: Context) = context.getSharedPreferences("channel_favorites", Context.MODE_PRIVATE)
        private fun movieFavPrefs(context: Context) = context.getSharedPreferences("movie_favorites", Context.MODE_PRIVATE)
        private fun seriesFavPrefs(context: Context) = context.getSharedPreferences("series_favorites", Context.MODE_PRIVATE)

        fun getChannelFavoritesForProfile(context: Context, profileId: String): Set<String> =
            channelFavPrefs(context).getStringSet("${KEY_FAVORITE_CHANNELS}_$profileId", emptySet()) ?: emptySet()

        fun setChannelFavoritesForProfile(context: Context, profileId: String, values: Set<String>) =
            channelFavPrefs(context).edit().putStringSet("${KEY_FAVORITE_CHANNELS}_$profileId", values).apply()

        fun getMovieFavoritesForProfile(context: Context, profileId: String): Set<String> =
            movieFavPrefs(context).getStringSet("${KEY_FAVORITE_MOVIES}_$profileId", emptySet()) ?: emptySet()

        fun setMovieFavoritesForProfile(context: Context, profileId: String, values: Set<String>) =
            movieFavPrefs(context).edit().putStringSet("${KEY_FAVORITE_MOVIES}_$profileId", values).apply()

        fun getSeriesFavoritesForProfile(context: Context, profileId: String): Set<String> =
            seriesFavPrefs(context).getStringSet("${KEY_FAVORITE_SERIES}_$profileId", emptySet()) ?: emptySet()

        fun setSeriesFavoritesForProfile(context: Context, profileId: String, values: Set<String>) =
            seriesFavPrefs(context).edit().putStringSet("${KEY_FAVORITE_SERIES}_$profileId", values).apply()

        fun getHiddenForProfile(context: Context, profileId: String): Set<String> =
            rawPrefs(context).getStringSet("${KEY_HIDDEN}_$profileId", emptySet()) ?: emptySet()

        fun setHiddenForProfile(context: Context, profileId: String, values: Set<String>) =
            rawPrefs(context).edit().putStringSet("${KEY_HIDDEN}_$profileId", values).apply()

        fun getWatchedForProfile(context: Context, profileId: String): Set<String> =
            rawPrefs(context).getStringSet("${KEY_WATCHED_EPISODES}_$profileId", emptySet()) ?: emptySet()

        fun setWatchedForProfile(context: Context, profileId: String, values: Set<String>) =
            rawPrefs(context).edit().putStringSet("${KEY_WATCHED_EPISODES}_$profileId", values).apply()

        // ---------- إعدادات عامة (وصول ثابت، يُستخدم من BackupManager) ----------

        fun getGeneralSettingsSnapshot(context: Context): Map<String, Any> {
            val p = PrefsManager(context)
            return mapOf(
                "use24HourTime" to p.use24HourTime,
                "compactChannelList" to p.compactChannelList,
                "showChannelNumbers" to p.showChannelNumbers,
                "hiddenLiveCategories" to p.hiddenLiveCategories.joinToString(","),
                "hiddenVodCategories" to p.hiddenVodCategories.joinToString(","),
                "hiddenSeriesCategories" to p.hiddenSeriesCategories.joinToString(","),
                "smartQualityGuardEnabled" to p.smartQualityGuardEnabled
            )
        }
    }
}
