package com.brotv.player.data

import java.text.Normalizer
import java.util.Locale

/** Lightweight normalization shared by TV search surfaces. */
object SearchMatcher {
    fun normalize(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{M}+"), "")
            .replace("ـ", "")
            .replace(Regex("[أإآ]"), "ا")
            .replace("ى", "ي")
            .replace("ة", "ه")
            .replace("ؤ", "و")
            .replace("ئ", "ي")
            .lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * الأكواد التي يقدر المستخدم يكتبها للوصول للقناة مباشرة:
     * رقم القناة في القائمة + رقم stream في نهاية روابط Xtream إن وجد.
     */
    fun channelCodes(displayNumber: Int, sourceUrls: List<String>): Set<String> = buildSet {
        if (displayNumber > 0) add(displayNumber.toString())
        sourceUrls.forEach { url ->
            val withoutQuery = url.substringBefore('?').trimEnd('/')
            val tail = withoutQuery.substringAfterLast('/')
            val code = tail.substringBeforeLast('.', tail)
            if (code.isNotBlank() && code.all(Char::isDigit)) add(code)
        }
    }

    fun matchesChannelCode(normalizedQuery: String, codes: Set<String>): Boolean =
        normalizedQuery.isNotBlank() && normalizedQuery.all(Char::isDigit) && normalizedQuery in codes

    fun matches(value: String, query: String): Boolean {
        val q = normalize(query)
        return q.isNotEmpty() && normalize(value).contains(q)
    }
}
