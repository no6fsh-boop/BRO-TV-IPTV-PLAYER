package com.brotv.player.data

import kotlin.math.roundToInt

/** قياسات فعلية خاصة بمصدر بث واحد داخل الجلسة. */
data class StreamHealthSnapshot(
    val width: Int = 0,
    val height: Int = 0,
    val fps: Float = 0f,
    val bitrate: Long = 0L,
    val ttffMs: Long = -1L,
    val rebufferCount: Int = 0,
    val rebufferDurationMs: Long = 0L,
    val playbackErrors: Int = 0,
    val droppedFrames: Int = 0,
    val successfulStarts: Int = 0,
    val serverLatencyMs: Long = -1L
)

/**
 * Score من 0..100 ومجموع أوزانه = 100، لذلك مصدر ممتاز يستطيع فعلاً الوصول إلى 95-100.
 * الثبات له وزن أكبر من الدقة وحدها حتى لا يتغلب 4K متقطع على 1080p50 ثابت.
 */
object StreamHealthScorer {
    fun score(s: StreamHealthSnapshot): Int {
        val resolution = when {
            s.width >= 3840 && s.height >= 2160 -> 100
            s.width >= 1920 && s.height >= 1080 -> 95
            s.width >= 1280 && s.height >= 720 -> 80
            s.width > 0 -> 60
            else -> 50
        }
        val fps = when {
            s.fps >= 50f -> 100
            s.fps >= 29f -> 92
            s.fps >= 24f -> 85
            s.fps > 0f -> 70
            else -> 50
        }
        val bitrate = when {
            s.bitrate >= 12_000_000L -> 100
            s.bitrate >= 5_000_000L -> 92
            s.bitrate >= 2_000_000L -> 80
            s.bitrate > 0L -> 65
            else -> 50
        }
        val ttff = when {
            s.ttffMs in 0..1_500 -> 100
            s.ttffMs in 1_501..3_000 -> 88
            s.ttffMs in 3_001..6_000 -> 68
            s.ttffMs > 6_000 -> 40
            else -> 50
        }
        val rebuffer = when {
            s.rebufferCount == 0 -> 100
            s.rebufferCount == 1 && s.rebufferDurationMs < 2_500 -> 82
            s.rebufferCount <= 2 && s.rebufferDurationMs < 6_000 -> 65
            s.rebufferDurationMs < 15_000 -> 40
            else -> 15
        }
        val errors = when (s.playbackErrors) {
            0 -> 100
            1 -> 70
            2 -> 45
            else -> 15
        }
        val dropped = when {
            s.droppedFrames <= 2 -> 100
            s.droppedFrames <= 20 -> 85
            s.droppedFrames <= 75 -> 60
            else -> 30
        }
        val latency = when {
            s.serverLatencyMs < 0L -> 55
            s.serverLatencyMs < 350L -> 100
            s.serverLatencyMs < 800L -> 90
            s.serverLatencyMs < 1_500L -> 75
            s.serverLatencyMs < 3_000L -> 50
            else -> 25
        }
        val startSuccess = if (s.successfulStarts > 0) 100 else 45

        val weighted =
            resolution * 0.15 +
                fps * 0.10 +
                bitrate * 0.10 +
                ttff * 0.10 +
                rebuffer * 0.20 +
                errors * 0.15 +
                dropped * 0.05 +
                latency * 0.10 +
                startSuccess * 0.05
        return weighted.roundToInt().coerceIn(0, 100)
    }
}

object StreamHealthRegistry {
    private val records = LinkedHashMap<String, StreamHealthSnapshot>()

    @Synchronized
    fun recordStart(url: String) {
        records[url] = records[url] ?: StreamHealthSnapshot()
    }

    @Synchronized
    fun recordSuccess(url: String, snapshot: StreamHealthSnapshot) {
        val old = records[url]
        records[url] = snapshot.copy(
            playbackErrors = maxOf(old?.playbackErrors ?: 0, snapshot.playbackErrors),
            successfulStarts = (old?.successfulStarts ?: 0) + 1,
            serverLatencyMs = if (snapshot.serverLatencyMs >= 0) snapshot.serverLatencyMs
            else old?.serverLatencyMs ?: -1L
        )
    }

    @Synchronized
    fun recordError(url: String) {
        val old = records[url] ?: StreamHealthSnapshot()
        records[url] = old.copy(playbackErrors = old.playbackErrors + 1)
    }

    @Synchronized
    fun recordRebuffer(url: String, count: Int, durationMs: Long) {
        val old = records[url] ?: StreamHealthSnapshot()
        records[url] = old.copy(rebufferCount = count, rebufferDurationMs = durationMs)
    }

    @Synchronized
    fun recordLatency(url: String, latencyMs: Long) {
        if (latencyMs < 0) return
        val old = records[url] ?: StreamHealthSnapshot()
        records[url] = old.copy(serverLatencyMs = latencyMs)
    }

    @Synchronized
    fun snapshot(url: String): StreamHealthSnapshot? = records[url]

    @Synchronized
    fun score(url: String): Int? = records[url]?.let(StreamHealthScorer::score)
}
