package com.brotv.player.model

data class CatchupProgram(
    val title: String,
    val startUnix: Long,
    val endUnix: Long,
    val startLabel: String,
    val endLabel: String
) {
    val durationMinutes: Int
        get() = ((endUnix - startUnix) / 60).toInt().coerceAtLeast(1)
}
