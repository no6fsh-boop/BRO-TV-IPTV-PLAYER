package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.brotv.player.R
import com.brotv.player.data.ContinueWatchingManager
import com.brotv.player.data.MovieRepository
import com.brotv.player.data.PrefsManager
import com.brotv.player.model.ChannelCategory
import com.brotv.player.model.ContinueWatchingType
import com.brotv.player.model.Movie
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class MoviesActivity : AppCompatActivity() {

    private enum class QuickList { NONE, CONTINUE, FAVORITES, RED, FAMILY }
    private enum class SortMode { DEFAULT, NEWEST, OLDEST, AZ, ZA }

    private lateinit var prefs: PrefsManager
    private var allMovies: List<Movie> = emptyList()
    private var selectedMovie: Movie? = null
    private var currentCategoryId = "all"
    private var quickList = QuickList.NONE
    private var sortMode = SortMode.DEFAULT
    private lateinit var contentAdapter: MovieAdapter
    private var heroDetailsJob: Job? = null
    private var heroArtworkJob: Job? = null
    private var lastFocusedMovieId: String? = null
    private var restoreGridFocusOnResume = false
    private var pendingGridFocusRestore = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movies)
        prefs = PrefsManager(this)
        savedInstanceState?.let { state ->
            currentCategoryId = state.getString(STATE_CATEGORY_ID, currentCategoryId)
            quickList = state.getString(STATE_QUICK_LIST)?.let { runCatching { QuickList.valueOf(it) }.getOrNull() } ?: quickList
            sortMode = state.getString(STATE_SORT_MODE)?.let { runCatching { SortMode.valueOf(it) }.getOrNull() } ?: sortMode
            lastFocusedMovieId = state.getString(STATE_FOCUSED_MOVIE_ID)
        }

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.imgHeaderLogo).setOnClickListener { finish() }
        findViewById<ImageView>(R.id.btnHeaderSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.btnTopLive).setOnClickListener { switchSection(ChannelBrowseActivity::class.java) }
        findViewById<TextView>(R.id.btnTopMovies).setOnClickListener { focusCurrentGrid() }
        findViewById<TextView>(R.id.btnTopSeries).setOnClickListener { switchSection(SeriesActivity::class.java) }
        findViewById<ImageView>(R.id.btnSearchMovies).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java).apply {
                putExtra(SearchActivity.EXTRA_SCOPE, SearchActivity.Scope.MOVIES.name)
            })
        }
        findViewById<RecyclerView>(R.id.recyclerCategories).apply {
            layoutManager = LinearLayoutManager(this@MoviesActivity, LinearLayoutManager.HORIZONTAL, false)
            setHasFixedSize(true)
            setItemViewCacheSize(8)
            itemAnimator = null
        }
        findViewById<RecyclerView>(R.id.recyclerMovies).apply {
            layoutManager = GridLayoutManager(this@MoviesActivity, MEDIA_GRID_SPAN)
            setHasFixedSize(true)
            setItemViewCacheSize(MEDIA_GRID_SPAN)
            itemAnimator = null // TV grids feel faster and avoid focus glitches without change animations.
        }
        contentAdapter = MovieAdapter(
            movies = emptyList(),
            onFocus = { selectMovie(it) },
            onLeftEdge = { focusActiveSidebarItem() },
            onClick = { openPlayer(it) }
        )
        findViewById<RecyclerView>(R.id.recyclerMovies).adapter = contentAdapter

        findViewById<LinearLayout>(R.id.btnPlayHero).setOnClickListener { selectedMovie?.let(::openPlayer) }
        findViewById<LinearLayout>(R.id.btnFavoriteHero).setOnClickListener {
            selectedMovie?.let {
                prefs.toggleMovieFavorite(it.id)
                updateFavoriteHeroState()
                updateQuickCounts()
                if (quickList == QuickList.FAVORITES) applyFiltersAndShow()
            }
        }

        findViewById<LinearLayout>(R.id.btnContinueWatching).setOnClickListener { selectQuickList(QuickList.CONTINUE) }
        findViewById<LinearLayout>(R.id.btnFavoritesFilter).setOnClickListener { selectQuickList(QuickList.FAVORITES) }
        findViewById<LinearLayout>(R.id.btnRedList).setOnClickListener { selectQuickList(QuickList.RED) }
        findViewById<LinearLayout>(R.id.btnFamilyList).setOnClickListener { selectQuickList(QuickList.FAMILY) }
        setupSidebarDpad()

        setupSortButtons()
        loadMovies()
    }

    override fun onResume() {
        super.onResume()
        pendingGridFocusRestore = restoreGridFocusOnResume
        if (allMovies.isNotEmpty()) {
            updateQuickCounts()
            applyFiltersAndShow()
        }
    }

    override fun onPause() {
        val recycler = findViewById<RecyclerView>(R.id.recyclerMovies)
        restoreGridFocusOnResume = currentFocus?.let { recycler.findContainingItemView(it) != null } == true
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString(STATE_CATEGORY_ID, currentCategoryId)
        outState.putString(STATE_QUICK_LIST, quickList.name)
        outState.putString(STATE_SORT_MODE, sortMode.name)
        outState.putString(STATE_FOCUSED_MOVIE_ID, lastFocusedMovieId)
        super.onSaveInstanceState(outState)
    }

    private fun switchSection(target: Class<out AppCompatActivity>) {
        if (target == this::class.java) return
        startActivity(Intent(this, target))
        // Treat the top bar like TV tabs instead of stacking duplicate media screens.
        finish()
    }

    private fun focusCurrentGrid() {
        val recycler = findViewById<RecyclerView>(R.id.recyclerMovies)
        val preferred = lastFocusedMovieId
        val index = preferred?.let { id -> contentAdapter.currentList.indexOfFirst { it.id == id } } ?: -1
        val target = index.takeIf { it >= 0 } ?: 0
        recycler.scrollToPosition(target)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(target)?.itemView?.requestFocus() ?: recycler.requestFocus()
        }
    }

    private fun setupSidebarDpad() {
        listOf(
            R.id.btnContinueWatching,
            R.id.btnFavoritesFilter,
            R.id.btnRedList,
            R.id.btnFamilyList
        ).forEach { id ->
            findViewById<View>(id).setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    focusCurrentGrid()
                    true
                } else false
            }
        }
    }

    private fun focusActiveSidebarItem() {
        val quickTarget = when (quickList) {
            QuickList.CONTINUE -> R.id.btnContinueWatching
            QuickList.FAVORITES -> R.id.btnFavoritesFilter
            QuickList.RED -> R.id.btnRedList
            QuickList.FAMILY -> R.id.btnFamilyList
            QuickList.NONE -> View.NO_ID
        }
        if (quickTarget != View.NO_ID) {
            findViewById<View>(quickTarget).requestFocus()
            return
        }
        val recycler = findViewById<RecyclerView>(R.id.recyclerCategories)
        val position = (recycler.adapter as? CategoryAdapter)?.selectedAdapterPosition() ?: 0
        recycler.scrollToPosition(position)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus() ?: recycler.requestFocus()
        }
    }

    private fun loadMovies() {
        val repo = MovieRepository(this)
        setLoading(true)
        lifecycleScope.launch {
            if (!repo.isSourceSupported()) {
                showEmpty(getString(R.string.movies_xtream_only))
                return@launch
            }

            val hidden = prefs.hiddenVodCategories
            allMovies = repo.getMovies().filter {
                it.providerCategoryName !in hidden && it.genre !in hidden
            }
            setLoading(false)
            if (allMovies.isEmpty()) {
                showEmpty(getString(R.string.movies_none_source))
                return@launch
            }

            buildCategories()
            updateQuickCounts()
            applyFiltersAndShow()
        }
    }

    private fun buildCategories() {
        val sourceOrder = allMovies.mapNotNull { it.id.split("::").getOrNull(1) }.distinct()
        val sourceRank = sourceOrder.withIndex().associate { it.value to it.index }
        val categoryMovies = allMovies
            .filter { it.providerCategoryKey.isNotBlank() }
            .groupBy { it.providerCategoryKey }
        val orderedKeys = categoryMovies.keys.sortedWith(
            compareBy<String> { key -> sourceRank[key.substringBefore("::")] ?: Int.MAX_VALUE }
                .thenBy { key -> categoryMovies[key]?.firstOrNull()?.providerCategoryOrder ?: Int.MAX_VALUE }
        )

        val categories = mutableListOf(
            ChannelCategory("all", getString(R.string.all_movies), allMovies.size, R.drawable.ic_all_channels)
        )
        orderedKeys.forEach { key ->
            val items = categoryMovies[key].orEmpty()
            val name = items.firstOrNull()?.providerCategoryName.orEmpty().ifBlank { getString(R.string.uncategorized_label) }
            categories += ChannelCategory(key, name, items.size, R.drawable.ic_folder)
        }

        val categoryRecycler = findViewById<RecyclerView>(R.id.recyclerCategories)
        val categoryAdapter = CategoryAdapter(
            categories = categories,
            selectedCategoryId = currentCategoryId,
            onMoveRight = { focusCurrentGrid() },
            compact = true
        ) { category ->
            quickList = QuickList.NONE
            currentCategoryId = category.id
            updateQuickSelection()
            applyFiltersAndShow()
        }
        categoryRecycler.adapter = categoryAdapter

        // Android TV does not guarantee which newly-inflated focusable wins first focus.
        // Entering a media section must start on the selected category so RIGHT always
        // moves deterministically into the content grid.
        val selectedPosition = categoryAdapter.selectedAdapterPosition()
        categoryRecycler.scrollToPosition(selectedPosition)
        categoryRecycler.post {
            categoryRecycler.findViewHolderForAdapterPosition(selectedPosition)?.itemView?.requestFocus()
                ?: categoryRecycler.requestFocus()
        }
    }

    private fun selectQuickList(value: QuickList) {
        quickList = value
        updateQuickSelection()
        applyFiltersAndShow()
    }

    private fun updateQuickSelection() {
        findViewById<LinearLayout>(R.id.btnContinueWatching).isSelected = quickList == QuickList.CONTINUE
        findViewById<LinearLayout>(R.id.btnFavoritesFilter).isSelected = quickList == QuickList.FAVORITES
        findViewById<LinearLayout>(R.id.btnRedList).isSelected = quickList == QuickList.RED
        findViewById<LinearLayout>(R.id.btnFamilyList).isSelected = quickList == QuickList.FAMILY
    }

    private fun updateQuickCounts() {
        val continueIds = ContinueWatchingManager(this).getAll()
            .filter { it.type == ContinueWatchingType.MOVIE }
            .map { it.contentId }
            .toSet()
        findViewById<TextView>(R.id.txtContinueCount).text = allMovies.count { it.id in continueIds }.toString()
        findViewById<TextView>(R.id.txtFavoritesCount).text = allMovies.count { it.id in prefs.favoriteMovieIds }.toString()
        findViewById<TextView>(R.id.txtRedCount).text = allMovies.count(::isRedListMovie).toString()
        findViewById<TextView>(R.id.txtFamilyCount).text = allMovies.count(::isFamilyMovie).toString()
    }

    private fun isRedListMovie(movie: Movie): Boolean {
        val text = "${movie.providerCategoryName} ${movie.genre}".lowercase(Locale.ROOT)
        return listOf("حمراء", "أحمر", "red").any(text::contains)
    }

    private fun isFamilyMovie(movie: Movie): Boolean {
        val text = "${movie.providerCategoryName} ${movie.genre}".lowercase(Locale.ROOT)
        return listOf("عائل", "أطفال", "اطفال", "family", "kids", "children").any(text::contains)
    }

    private fun applyFiltersAndShow() {
        var list = when (quickList) {
            QuickList.CONTINUE -> {
                val ids = ContinueWatchingManager(this).getAll()
                    .filter { it.type == ContinueWatchingType.MOVIE }
                    .map { it.contentId }
                    .toSet()
                allMovies.filter { it.id in ids }
            }
            QuickList.FAVORITES -> allMovies.filter { it.id in prefs.favoriteMovieIds }
            QuickList.RED -> allMovies.filter(::isRedListMovie)
            QuickList.FAMILY -> allMovies.filter(::isFamilyMovie)
            QuickList.NONE -> if (currentCategoryId == "all") allMovies else allMovies.filter { it.providerCategoryKey == currentCategoryId }
        }

        list = when (sortMode) {
            SortMode.DEFAULT -> list
            SortMode.NEWEST -> list.sortedByDescending { it.year.toIntOrNull() ?: 0 }
            SortMode.OLDEST -> list.sortedBy { it.year.toIntOrNull() ?: Int.MAX_VALUE }
            SortMode.AZ -> list.sortedBy { it.name.lowercase(Locale.getDefault()) }
            SortMode.ZA -> list.sortedByDescending { it.name.lowercase(Locale.getDefault()) }
        }

        val title = when (quickList) {
            QuickList.CONTINUE -> getString(R.string.home_continue_watching)
            QuickList.FAVORITES -> getString(R.string.home_favorites)
            QuickList.RED -> getString(R.string.media_red_list)
            QuickList.FAMILY -> getString(R.string.media_family_list)
            QuickList.NONE -> if (currentCategoryId == "all") getString(R.string.all_movies)
                else allMovies.firstOrNull { it.providerCategoryKey == currentCategoryId }?.providerCategoryName.orEmpty()
        }
        findViewById<TextView>(R.id.txtSectionTitle).text = title
        showMovies(list)
    }

    private fun showMovies(list: List<Movie>) {
        val empty = findViewById<TextView>(R.id.txtEmpty)
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        if (list.isEmpty()) {
            empty.text = getString(R.string.media_list_empty)
            selectedMovie = null
            contentAdapter.submitList(emptyList())
            return
        }

        val preferred = list.firstOrNull { it.id == lastFocusedMovieId }
            ?: list.firstOrNull { it.id == selectedMovie?.id }
            ?: list.first()
        selectMovie(preferred)
        contentAdapter.submitList(list) {
            if (pendingGridFocusRestore) {
                pendingGridFocusRestore = false
                restoreMovieFocus(list, preferred.id)
            }
        }
    }

    private fun restoreMovieFocus(list: List<Movie>, movieId: String) {
        val index = list.indexOfFirst { it.id == movieId }
        if (index < 0) return
        val recycler = findViewById<RecyclerView>(R.id.recyclerMovies)
        recycler.scrollToPosition(index)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus()
                ?: recycler.requestFocus()
        }
    }

    private fun setupSortButtons() {
        val buttons = mapOf(
            R.id.btnSortDefault to SortMode.DEFAULT,
            R.id.btnSortNewest to SortMode.NEWEST,
            R.id.btnSortOldest to SortMode.OLDEST,
            R.id.btnSortAz to SortMode.AZ,
            R.id.btnSortZa to SortMode.ZA
        )
        buttons.forEach { (id, mode) ->
            findViewById<TextView>(id).setOnClickListener {
                sortMode = mode
                buttons.forEach { (buttonId, buttonMode) ->
                    findViewById<TextView>(buttonId).isSelected = buttonMode == sortMode
                }
                applyFiltersAndShow()
            }
        }
        buttons.keys.forEach { id ->
            findViewById<TextView>(id).setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    val recycler = findViewById<RecyclerView>(R.id.recyclerMovies)
                    recycler.scrollToPosition(0)
                    recycler.post {
                        recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                            ?: recycler.requestFocus()
                    }
                    true
                } else false
            }
        }
        buttons.forEach { (buttonId, buttonMode) ->
            findViewById<TextView>(buttonId).isSelected = buttonMode == sortMode
        }
    }

    private fun updateFavoriteHeroState() {
        val movie = selectedMovie ?: return
        findViewById<LinearLayout>(R.id.btnFavoriteHero).isSelected = movie.id in prefs.favoriteMovieIds
    }

    private fun selectMovie(movie: Movie) {
        selectedMovie = movie
        lastFocusedMovieId = movie.id
        findViewById<TextView>(R.id.txtHeroTitle).text = movie.name
        findViewById<TextView>(R.id.txtHeroMeta).text = listOfNotNull(
            movie.rating.takeIf { it.isNotBlank() }?.let { "IMDb $it" },
            movie.year.takeIf { it.isNotBlank() },
            movie.genre.takeIf { it.isNotBlank() },
            movie.providerCategoryName.takeIf { it.isNotBlank() }
        ).joinToString("   |   ")
        findViewById<TextView>(R.id.txtHeroPlot).text = movie.plot
        updateFavoriteHeroState()

        val hero = findViewById<ImageView>(R.id.imgHeroBackground)
        heroArtworkJob?.cancel()
        heroArtworkJob = lifecycleScope.launch {
            delay(HERO_ARTWORK_DEBOUNCE_MS)
            if (selectedMovie?.id != movie.id) return@launch
            if (movie.posterUrl.isNullOrBlank()) {
                hero.setImageResource(R.drawable.media_hero_fallback)
            } else {
                hero.load(movie.posterUrl) {
                    crossfade(false)
                    placeholder(R.drawable.media_hero_fallback)
                    error(R.drawable.media_hero_fallback)
                }
            }
        }

        // D-pad focus can move across many posters per second. Do not let every transient
        // focus start a provider details request: cancel the old one and only fetch after
        // focus settles briefly. This keeps navigation responsive on large IPTV libraries.
        heroDetailsJob?.cancel()
        heroDetailsJob = lifecycleScope.launch {
            delay(HERO_DETAILS_DEBOUNCE_MS)
            val plot = MovieRepository(this@MoviesActivity).getMovieDetails(movie)
            if (selectedMovie?.id == movie.id) findViewById<TextView>(R.id.txtHeroPlot).text = plot
        }
    }

    private fun openPlayer(movie: Movie) {
        startActivity(Intent(this, VodPlayerActivity::class.java).apply {
            putExtra(VodPlayerActivity.EXTRA_CONTENT_ID, movie.id)
            putExtra(VodPlayerActivity.EXTRA_TITLE, movie.name)
            putExtra(VodPlayerActivity.EXTRA_SUBTITLE, movie.providerCategoryName.ifBlank { movie.genre })
            putExtra(VodPlayerActivity.EXTRA_STREAM_URL, movie.streamUrl)
            putExtra(VodPlayerActivity.EXTRA_POSTER_URL, movie.posterUrl)
            putExtra(VodPlayerActivity.EXTRA_IS_MOVIE, true)
            putExtra(VodPlayerActivity.EXTRA_PARENTAL_CATEGORY, movie.providerCategoryName.ifBlank { movie.genre })
        })
    }

    private fun setLoading(loading: Boolean) {
        findViewById<ProgressBar>(R.id.progressBar).visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showEmpty(message: String) {
        setLoading(false)
        findViewById<TextView>(R.id.txtEmpty).apply {
            text = message
            visibility = View.VISIBLE
        }
    }

    override fun onDestroy() {
        heroDetailsJob?.cancel()
        heroDetailsJob = null
        heroArtworkJob?.cancel()
        heroArtworkJob = null
        super.onDestroy()
    }

    private companion object {
        const val HERO_DETAILS_DEBOUNCE_MS = 300L
        const val HERO_ARTWORK_DEBOUNCE_MS = 120L
        const val STATE_CATEGORY_ID = "movies_category_id"
        const val STATE_QUICK_LIST = "movies_quick_list"
        const val STATE_SORT_MODE = "movies_sort_mode"
        const val STATE_FOCUSED_MOVIE_ID = "movies_focused_id"
        const val MEDIA_GRID_SPAN = 4
    }

}
