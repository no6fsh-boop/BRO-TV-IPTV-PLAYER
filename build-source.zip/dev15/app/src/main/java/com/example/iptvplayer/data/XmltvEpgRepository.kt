package com.brotv.player.data

import android.content.Context
import androidx.room.withTransaction
import com.brotv.player.data.db.AppDatabase
import com.brotv.player.data.db.EpgProgramEntity
import com.brotv.player.model.EpgProgram
import com.brotv.player.model.MergedChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.GZIPInputStream

/** XMLTV متعدد المصادر مع Cache محلي. لا يجلب EPG عند كل حركة Focus. */
class XmltvEpgRepository(context: Context) {
    private val appContext = context.applicationContext
    private val database = AppDatabase.getInstance(appContext)
    private val dao = database.epgDao()
    private val sourcesManager = SourcesManager(appContext)

    data class SyncResult(val attempted: Int, val succeeded: Int, val programmes: Int)

    suspend fun refreshIfNeeded(force: Boolean = false): SyncResult = refreshMutex.withLock {
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val windowStart = now - CACHE_PAST_MS
            val windowEnd = now + CACHE_FUTURE_MS
            var attempted = 0
            var succeeded = 0
            var count = 0
            dao.deleteExpired(now - EXPIRED_GRACE_MS)

            for (source in sourcesManager.getEnabledSources()) {
                if (source.epgUrl.isBlank()) continue
                val latest = dao.latestUpdate(source.id) ?: 0L
                if (!force && now - latest < REFRESH_INTERVAL_MS) continue
                attempted++
                try {
                    val programmes = downloadAndParse(source.epgUrl, windowStart, windowEnd)
                    // لا نمسح Cache صالح بسبب رد فارغ/ملف تالف.
                    if (programmes.isEmpty()) continue
                    val updatedAt = System.currentTimeMillis()
                    val entities = programmes.map {
                        EpgProgramEntity(
                            sourceId = source.id,
                            channelId = it.channelId,
                            channelName = it.channelName,
                            normalizedChannelName = normalizeName(it.channelName),
                            title = it.title,
                            description = it.description,
                            startTimeMs = it.startTimeMs,
                            endTimeMs = it.endTimeMs,
                            updatedAt = updatedAt
                        )
                    }
                    database.withTransaction {
                        dao.deleteBySource(source.id)
                        entities.chunked(500).forEach { dao.insertAll(it) }
                    }
                    succeeded++
                    count += entities.size
                } catch (_: Exception) {
                    // مصدر EPG واحد لا يُسقط بقية المصادر ولا يمس Cache القديم.
                }
            }
            SyncResult(attempted, succeeded, count)
        }
    }

    /**
     * Fast cache-only lookup for scrolling lists. It deliberately never falls back to Xtream
     * network calls, otherwise every recycled guide row can trigger a provider request.
     */
    suspend fun currentCachedProgram(channel: MergedChannel): EpgProgram? = withContext(Dispatchers.IO) {
        currentCachedProgramInternal(channel, System.currentTimeMillis())
    }

    suspend fun currentProgram(channel: MergedChannel): EpgProgram? = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        currentCachedProgramInternal(channel, now)?.let { return@withContext it }

        // Single-channel fallback is still useful in the player chrome when XMLTV is absent.
        val url = channel.sourceUrls.firstOrNull() ?: return@withContext null
        val client = XtreamClient.fromLiveStreamUrl(url) ?: return@withContext null
        val streamId = client.extractStreamId(url) ?: return@withContext null
        client.getCurrentProgram(streamId)
    }

    private suspend fun currentCachedProgramInternal(channel: MergedChannel, now: Long): EpgProgram? {
        val sources = sourcesManager.getEnabledSources().filter { it.epgUrl.isNotBlank() }
        val normalized = normalizeName(channel.name)
        for (source in sources) {
            for (epgId in channel.epgIds) {
                dao.currentByChannelId(source.id, epgId, now)?.let { return it.toUi(now) }
            }
            if (normalized.isNotBlank()) {
                dao.currentByName(source.id, normalized, now)?.let { return it.toUi(now) }
            }
        }
        return null
    }


    /** Current + upcoming programmes used by DVR scheduling. */
    suspend fun programs(
        channel: MergedChannel,
        fromMs: Long = System.currentTimeMillis(),
        toMs: Long = fromMs + 24L * 60L * 60L * 1000L,
        limit: Int = 30
    ): List<EpgProgram> = withContext(Dispatchers.IO) {
        val sources = sourcesManager.getEnabledSources().filter { it.epgUrl.isNotBlank() }
        val normalized = normalizeName(channel.name)
        for (source in sources) {
            for (epgId in channel.epgIds) {
                val rows = dao.rangeByChannelId(source.id, epgId, fromMs, toMs, limit)
                if (rows.isNotEmpty()) return@withContext rows.map { it.toUi(System.currentTimeMillis()) }
            }
            if (normalized.isNotBlank()) {
                val rows = dao.rangeByName(source.id, normalized, fromMs, toMs, limit)
                if (rows.isNotEmpty()) return@withContext rows.map { it.toUi(System.currentTimeMillis()) }
            }
        }

        // Xtream fallback when no XMLTV URL is configured.
        val url = channel.sourceUrls.firstOrNull() ?: return@withContext emptyList()
        val client = XtreamClient.fromLiveStreamUrl(url) ?: return@withContext emptyList()
        val streamId = client.extractStreamId(url) ?: return@withContext emptyList()
        client.getUpcomingPrograms(streamId, limit).filter { it.endTimeMs > fromMs && it.startTimeMs < toMs }
    }

    private fun downloadAndParse(urlString: String, startMs: Long, endMs: Long): List<XmltvParser.Programme> {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 30_000
            requestMethod = "GET"
            setRequestProperty("Accept-Encoding", "gzip")
            setRequestProperty("User-Agent", "BRO-TV/2.0 XMLTV")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            val base = BufferedInputStream(connection.inputStream)
            val compressed = XmltvTransportPolicy.isGzip(connection.contentEncoding, urlString)
            val input = if (compressed) GZIPInputStream(base) else base
            input.use { return XmltvParser.parse(it, startMs, endMs) }
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private val refreshMutex = Mutex()
        private const val REFRESH_INTERVAL_MS = 6 * 60 * 60 * 1000L
        private const val CACHE_PAST_MS = 2 * 60 * 60 * 1000L
        private const val CACHE_FUTURE_MS = 72 * 60 * 60 * 1000L
        private const val EXPIRED_GRACE_MS = 6 * 60 * 60 * 1000L

        fun normalizeName(name: String): String = name
            .lowercase(Locale.ROOT)
            .replace(Regex("""\(.*?\)"""), "")
            .replace(Regex("""\b(hd|fhd|uhd|4k|sd)\b"""), "")
            .replace(Regex("""[^a-z0-9\u0600-\u06FF]+"""), " ")
            .trim()
    }
}

private fun EpgProgramEntity.toUi(nowMs: Long): EpgProgram {
    val format = SimpleDateFormat("HH:mm", Locale.getDefault())
    val duration = (endTimeMs - startTimeMs).coerceAtLeast(1L)
    val progress = (((nowMs - startTimeMs).coerceAtLeast(0L) * 100L) / duration).toInt().coerceIn(0, 100)
    return EpgProgram(
        title = title,
        startTime = format.format(Date(startTimeMs)),
        endTime = format.format(Date(endTimeMs)),
        progressPercent = progress,
        startTimeMs = startTimeMs,
        endTimeMs = endTimeMs,
        description = description
    )
}
