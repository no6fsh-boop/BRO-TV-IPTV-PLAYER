package com.brotv.player.ui

import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.brotv.player.R

/** يجعل عنصر الريموت الحالي واضحاً جداً داخل قوائم التلفزيون المنبثقة. */
fun AlertDialog.enableTvListFocus(preferredPosition: Int = 0): AlertDialog {
    listView?.apply {
        selector = ContextCompat.getDrawable(context, R.drawable.tv_dialog_list_selector)
        isFocusable = true
        isFocusableInTouchMode = true
        setSelection(preferredPosition.coerceAtLeast(0))
        requestFocus()
    }
    return this
}
