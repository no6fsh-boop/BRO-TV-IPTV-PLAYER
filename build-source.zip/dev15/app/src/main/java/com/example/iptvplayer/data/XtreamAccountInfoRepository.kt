package com.brotv.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Lightweight account metadata for the Home header. Credentials are used only in-memory for the API call. */
data class XtreamAccountInfo(
    val status: String,
    val expiresAtMs: Long?,
    val activeConnections: Int?,
    val maxConnections: Int?
) {
    val isExpired: Boolean
        get() = status.equals("Expired", true) || status.equals("Disabled", true) ||
            (expiresAtMs != null && expiresAtMs > 0L && expiresAtMs <= System.currentTimeMillis())
}

object XtreamAccountInfoRepository {
    private const val CACHE_TTL_MS = 60_000L
    private data class CacheEntry(val value: XtreamAccountInfo, val storedAtMs: Long)
    private val cache = java.util.concurrent.ConcurrentHashMap<String, CacheEntry>()

    /**
     * Account metadata is shown on Home and must never make returning to Home feel slow.
     * A short in-memory cache avoids a network round-trip on every onResume. Manual refresh
     * bypasses the cache via [forceRefresh]. Credentials are never persisted by this cache.
     */
    suspend fun load(source: SourceConfig, forceRefresh: Boolean = false): XtreamAccountInfo? = withContext(Dispatchers.IO) {
        val key = source.id
        if (!forceRefresh) {
            cache[key]?.let { entry ->
                if (System.currentTimeMillis() - entry.storedAtMs < CACHE_TTL_MS) return@withContext entry.value
                cache.remove(key, entry)
            }
        }
        if (source.type != PrefsManager.SourceType.XTREAM || source.xtreamServer.isBlank() || source.xtreamUsername.isBlank()) {
            return@withContext null
        }
        var connection: HttpURLConnection? = null
        try {
            val url = XtreamUrlCodec.playerApiUrl(source.xtreamServer, source.xtreamUsername, source.xtreamPassword)
            connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = 4_000
            connection.readTimeout = 4_000
            connection.useCaches = false
            connection.instanceFollowRedirects = true
            connection.requestMethod = "GET"
            connection.setRequestProperty("User-Agent", "BROTV/1.2")
            if (connection.responseCode !in 200..299) return@withContext null
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val userInfo = JSONObject(body).optJSONObject("user_info") ?: return@withContext null
            val auth = userInfo.optString("auth", "1").toIntOrNull() ?: userInfo.optInt("auth", 1)
            if (auth == 0) {
                return@withContext XtreamAccountInfo("Disabled", null, null, null)
            }
            val expiresSeconds = userInfo.optString("exp_date")
                .takeUnless { it.isNullOrBlank() || it.equals("null", true) }
                ?.toLongOrNull()
                ?.takeIf { it > 0L }
            XtreamAccountInfo(
                status = userInfo.optString("status", "Active"),
                expiresAtMs = expiresSeconds?.let { it * 1000L },
                activeConnections = userInfo.optString("active_cons").toIntOrNull()?.coerceAtLeast(0),
                maxConnections = userInfo.optString("max_connections").toIntOrNull()?.takeIf { it > 0 }
            ).also { cache[key] = CacheEntry(it, System.currentTimeMillis()) }
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }
}
