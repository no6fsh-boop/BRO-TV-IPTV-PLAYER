package com.brotv.player.data

data class SourceConfig(
    val id: String,
    val name: String,
    val type: PrefsManager.SourceType,
    val m3uUrl: String = "",
    val xtreamServer: String = "",
    val xtreamUsername: String = "",
    val xtreamPassword: String = "",
    val epgUrl: String = "",
    val enabled: Boolean = true
)
