package com.brotv.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/**
 * Central source-selection brain for BRO TV.
 *
 * It deliberately prefers observed playback history over synthetic probing. Unknown sources are
 * probed only when there is no trustworthy history, keeping channel zapping fast and avoiding
 * unnecessary provider connections.
 */
object AutoPilotEngine {
    data class RankedSource(
        val url: String,
        val score: Int,
        val observed: Boolean,
        val latencyMs: Long = -1L
    )

    private const val TRUSTED_HISTORY_MIN_STARTS = 1
    private const val FAILURE_PENALTY = 14
    private const val REBUFFER_PENALTY = 4
    private const val MAX_HISTORY_BONUS = 8

    suspend fun rank(
        urls: List<String>,
        excluded: Set<String> = emptySet(),
        probeUnknown: Boolean = true
    ): List<RankedSource> = coroutineScope {
        val candidates = urls.distinct().filterNot(excluded::contains)
        if (candidates.isEmpty()) return@coroutineScope emptyList()

        candidates.map { url ->
            async(Dispatchers.IO) {
                val snapshot = StreamHealthRegistry.snapshot(url)
                if (snapshot != null && snapshot.successfulStarts >= TRUSTED_HISTORY_MIN_STARTS) {
                    val base = StreamHealthScorer.score(snapshot)
                    val reliabilityBonus = snapshot.successfulStarts.coerceAtMost(MAX_HISTORY_BONUS)
                    val penalty = snapshot.playbackErrors * FAILURE_PENALTY +
                        snapshot.rebufferCount.coerceAtMost(5) * REBUFFER_PENALTY
                    RankedSource(
                        url = url,
                        score = (base + reliabilityBonus - penalty).coerceIn(0, 100),
                        observed = true,
                        latencyMs = snapshot.serverLatencyMs
                    )
                } else if (probeUnknown) {
                    val measurement = ConnectionQualityChecker.measure(url)
                    val score = when (measurement.quality) {
                        ConnectionQualityChecker.Quality.GOOD -> 75
                        ConnectionQualityChecker.Quality.MEDIUM -> 62
                        ConnectionQualityChecker.Quality.WEAK -> 48
                        ConnectionQualityChecker.Quality.UNREACHABLE -> 0
                    }
                    RankedSource(url, score, false, measurement.latencyMs)
                } else {
                    RankedSource(url, 55, false, snapshot?.serverLatencyMs ?: -1L)
                }
            }
        }.awaitAll().sortedWith(
            compareByDescending<RankedSource> { it.score }
                .thenByDescending { it.observed }
                .thenBy { it.latencyMs.takeIf { ms -> ms >= 0 } ?: Long.MAX_VALUE }
        )
    }

    suspend fun bestSource(
        urls: List<String>,
        excluded: Set<String> = emptySet(),
        probeUnknown: Boolean = true
    ): String? = rank(urls, excluded, probeUnknown).firstOrNull { it.score > 0 }?.url

    /**
     * Hot path used for startup/zapping. Never performs network I/O: waiting for a synthetic probe
     * before opening a channel makes a TV player feel slow. Unknown sources keep playlist order;
     * once real playback history exists, the healthiest observed source wins.
     */
    fun bestKnownSource(urls: List<String>, excluded: Set<String> = emptySet()): String? {
        val candidates = urls.distinct().filterNot(excluded::contains)
        if (candidates.isEmpty()) return null

        val rankedObserved = candidates.mapNotNull { url ->
            val snapshot = StreamHealthRegistry.snapshot(url) ?: return@mapNotNull null
            if (snapshot.successfulStarts < TRUSTED_HISTORY_MIN_STARTS) return@mapNotNull null
            val base = StreamHealthScorer.score(snapshot)
            val reliabilityBonus = snapshot.successfulStarts.coerceAtMost(MAX_HISTORY_BONUS)
            val penalty = snapshot.playbackErrors * FAILURE_PENALTY +
                snapshot.rebufferCount.coerceAtMost(5) * REBUFFER_PENALTY
            RankedSource(
                url = url,
                score = (base + reliabilityBonus - penalty).coerceIn(0, 100),
                observed = true,
                latencyMs = snapshot.serverLatencyMs
            )
        }.sortedWith(
            compareByDescending<RankedSource> { it.score }
                .thenBy { it.latencyMs.takeIf { ms -> ms >= 0 } ?: Long.MAX_VALUE }
        )

        return rankedObserved.firstOrNull { it.score >= 55 }?.url ?: candidates.first()
    }

    /** Startup must be instant. Real playback measures the chosen source in the background. */
    suspend fun bestSourceForStartup(urls: List<String>): String? = bestKnownSource(urls)
}
