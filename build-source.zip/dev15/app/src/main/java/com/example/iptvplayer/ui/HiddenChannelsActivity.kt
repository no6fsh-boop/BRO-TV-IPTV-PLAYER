package com.brotv.player.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.PrefsManager
import com.brotv.player.model.MergedChannel
import kotlinx.coroutines.launch

/** تعرض كل القنوات اللي أخفاها المستخدم من شاشة تصفح القنوات، وتقدر ترجعها بضغطة زر. */
class HiddenChannelsActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hidden_channels)
        prefs = PrefsManager(this)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<RecyclerView>(R.id.recyclerHidden).layoutManager = LinearLayoutManager(this)

        loadHiddenChannels()
    }

    private fun loadHiddenChannels() {
        findViewById<ProgressBar>(R.id.progressBar).visibility = View.VISIBLE
        lifecycleScope.launch {
            val hiddenIds = prefs.hiddenChannelIds
            val allChannels = MergedChannelRepository(this@HiddenChannelsActivity).loadMergedChannels()
            val hiddenChannels = allChannels.filter { it.id in hiddenIds }

            findViewById<ProgressBar>(R.id.progressBar).visibility = View.GONE
            findViewById<TextView>(R.id.txtEmpty).visibility = if (hiddenChannels.isEmpty()) View.VISIBLE else View.GONE
            renderList(hiddenChannels)
        }
    }

    private fun renderList(hiddenChannels: List<MergedChannel>) {
        findViewById<RecyclerView>(R.id.recyclerHidden).adapter = HiddenChannelAdapter(hiddenChannels) { channel ->
            val current = prefs.hiddenChannelIds
            current.remove(channel.id)
            prefs.hiddenChannelIds = current
            loadHiddenChannels() // نحدّث القائمة فوراً بعد الإظهار
        }
    }
}

private class HiddenChannelAdapter(
    private val channels: List<MergedChannel>,
    private val onUnhide: (MergedChannel) -> Unit
) : RecyclerView.Adapter<HiddenChannelAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.txtHiddenChannelName)
        val unhideBtn: LinearLayout = view.findViewById(R.id.btnUnhide)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_hidden_channel, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val channel = channels[position]
        holder.name.text = channel.name
        holder.unhideBtn.setOnClickListener { onUnhide(channel) }
    }

    override fun getItemCount(): Int = channels.size
}
