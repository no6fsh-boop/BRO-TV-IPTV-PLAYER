package com.brotv.player.ui

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.brotv.player.R
import com.brotv.player.model.Channel
import com.brotv.player.player.ResourceBudget
import com.brotv.player.player.ResourceGuard
import kotlinx.coroutines.launch

/**
 * مشغل القناة البسيط/القديم. حتى هذا المسار يمر عبر ResourceGuard حتى لا يوجد أي بث حي
 * يفتح اتصالاً خارج ميزانية المزود.
 */
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private var resourceLease: ResourceGuard.Lease? = null
    private var requestToken = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        val channel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_CHANNEL, Channel::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_CHANNEL)
        }

        if (channel == null) {
            finish()
            return
        }

        val playerView = findViewById<PlayerView>(R.id.playerView)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        progressBar.visibility = View.VISIBLE
        val token = ++requestToken

        lifecycleScope.launch {
            when (val result = ResourceGuard.acquire(
                context = this@PlayerActivity,
                streamUrl = channel.streamUrl,
                kind = ResourceBudget.SessionKind.PRIMARY_PLAYBACK
            )) {
                is ResourceGuard.AcquireResult.Granted -> {
                    if (token != requestToken || isFinishing || isDestroyed) {
                        result.lease.release()
                        return@launch
                    }
                    resourceLease = result.lease
                    val exoPlayer = ExoPlayer.Builder(this@PlayerActivity).build()
                    player = exoPlayer
                    playerView.player = exoPlayer

                    exoPlayer.addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) {
                            progressBar.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                        }
                    })

                    exoPlayer.setMediaItem(MediaItem.fromUri(channel.streamUrl))
                    exoPlayer.prepare()
                    exoPlayer.playWhenReady = true
                }
                is ResourceGuard.AcquireResult.Denied -> {
                    progressBar.visibility = View.GONE
                    val message = if (result.reason == ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT) {
                        getString(R.string.provider_connection_limit_reached)
                    } else {
                        getString(R.string.primary_resource_unavailable)
                    }
                    Toast.makeText(this@PlayerActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        requestToken++
        player?.release()
        player = null
        resourceLease?.release()
        resourceLease = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CHANNEL = "extra_channel"
    }
}
