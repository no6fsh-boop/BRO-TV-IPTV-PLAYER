package com.brotv.player.data

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * تسجيل أعطال محلي خفيف — بدون أي خدمة خارجية (Firebase Crashlytics وغيرها)، فما يحتاج
 * حساب/مشروع سحابي. الهدف: توفر أثر فعلي (Stack Trace + معلومات الجهاز) لأي تعطل حقيقي
 * بدل ما يختفي بدون أي أثر، عشان المطوّر يقدر يشخّص أعطال المستخدمين الحقيقيين.
 *
 * ملاحظة صريحة: هذا بديل محلي بسيط، مو بديل كامل عن خدمة تتبع أعطال سحابية حقيقية
 * (Firebase Crashlytics أو Sentry) اللي تجمع تقارير من كل أجهزة المستخدمين مركزياً.
 * لو احتجتوا هالمستوى لاحقاً، يحتاج ربط حساب Firebase حقيقي من طرفكم.
 */
object CrashLogger {
    private const val MAX_LOG_FILES = 25
    private const val DIR_NAME = "crash_logs"

    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val appContext = context.applicationContext
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching { writeCrashReport(appContext, thread, throwable) }
            // نمرر للمعالج الأصلي (نظام Android) عشان سلوك التعطل الطبيعي يستمر
            // (رسالة "توقف التطبيق"، إعادة التشغيل إن وجدت، إلخ) — ما نبلعه بصمت.
            previousHandler?.uncaughtException(thread, throwable)
                ?: run {
                    android.os.Process.killProcess(android.os.Process.myPid())
                    kotlin.system.exitProcess(10)
                }
        }
    }

    private fun writeCrashReport(context: Context, thread: Thread, throwable: Throwable) {
        val dir = crashDir(context)
        val timestamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val file = File(dir, "crash_$timestamp.txt")

        val stackTrace = StringWriter().also { sw ->
            throwable.printStackTrace(PrintWriter(sw))
        }.toString()

        val report = buildString {
            appendLine("=== BRO TV Crash Report ===")
            appendLine("Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            appendLine("App version: ${appVersionInfo(context)}")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
            appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine("Thread: ${thread.name}")
            appendLine()
            appendLine(stackTrace)
        }

        runCatching { file.writeText(report) }
        pruneOldReports(dir)
    }

    private fun appVersionInfo(context: Context): String = runCatching {
        val pkgInfo = context.packageManager.getPackageInfo(context.packageName, 0)
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pkgInfo.versionCode.toLong()
        }
        "${pkgInfo.versionName} ($versionCode)"
    }.getOrDefault("unknown")

    private fun pruneOldReports(dir: File) {
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        if (files.size <= MAX_LOG_FILES) return
        files.drop(MAX_LOG_FILES).forEach { runCatching { it.delete() } }
    }

    private fun crashDir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    /** لشاشة "مساعدة ودعم": قائمة تقارير الأعطال المحفوظة، الأحدث أولاً. */
    fun recentReports(context: Context): List<File> =
        crashDir(context.applicationContext).listFiles()
            ?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun clearReports(context: Context) {
        crashDir(context.applicationContext).listFiles()?.forEach { runCatching { it.delete() } }
    }

    /** يدمج كل التقارير بملف نصي وحد جاهز للمشاركة (مثلاً عبر Intent.ACTION_SEND). */
    fun buildCombinedReportText(context: Context): String {
        val reports = recentReports(context)
        if (reports.isEmpty()) return ""
        return reports.joinToString(separator = "\n\n${"-".repeat(40)}\n\n") { file ->
            runCatching { file.readText() }.getOrDefault("")
        }
    }
}
