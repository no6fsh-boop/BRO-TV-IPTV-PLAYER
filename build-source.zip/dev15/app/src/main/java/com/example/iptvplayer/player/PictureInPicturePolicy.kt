package com.brotv.player.player

import kotlin.math.abs

/** Pure PiP policy so Android-specific code stays tiny and testable. */
object PictureInPicturePolicy {
    private const val MIN_RATIO = 1.0 / 2.39
    private const val MAX_RATIO = 2.39

    data class Ratio(val width: Int, val height: Int)

    fun safeRatio(videoWidth: Int, videoHeight: Int): Ratio {
        if (videoWidth <= 0 || videoHeight <= 0) return Ratio(16, 9)
        val ratio = videoWidth.toDouble() / videoHeight.toDouble()
        if (ratio < MIN_RATIO || ratio > MAX_RATIO || !ratio.isFinite()) return Ratio(16, 9)
        val divisor = gcd(videoWidth, videoHeight).coerceAtLeast(1)
        val reduced = Ratio(videoWidth / divisor, videoHeight / divisor)
        // Avoid giant Rational values from unusual codec metadata.
        return if (reduced.width <= 10_000 && reduced.height <= 10_000) reduced else Ratio(16, 9)
    }

    private fun gcd(a: Int, b: Int): Int {
        var x = abs(a)
        var y = abs(b)
        while (y != 0) {
            val t = x % y
            x = y
            y = t
        }
        return x
    }
}
