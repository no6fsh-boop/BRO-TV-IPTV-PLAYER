package com.brotv.player.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.data.MergedChannelRepository
import com.brotv.player.data.PrefsManager
import com.brotv.player.model.SearchResultItem
import com.brotv.player.model.SearchResultType
import kotlinx.coroutines.launch

/**
 * زر "المفضلة" بالواجهة الرئيسية = قنوات فقط، بدون أي فيلم أو مسلسل.
 * مفضلة الأفلام تُعرض داخل قسم الأفلام، ومفضلة المسلسلات داخل قسم المسلسلات (كل وحدة لحالها).
 */
class FavoritesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<RecyclerView>(R.id.recyclerFavorites).layoutManager = LinearLayoutManager(this)

        loadFavoriteChannels()
    }

    private fun loadFavoriteChannels() {
        setLoading(true)
        lifecycleScope.launch {
            val prefs = PrefsManager(this@FavoritesActivity)
            val favoriteIds = prefs.favoriteChannelIds

            val results = if (favoriteIds.isEmpty()) {
                emptyList()
            } else {
                MergedChannelRepository(this@FavoritesActivity).loadMergedChannels()
                    .filter { it.id in favoriteIds }
                    .map { SearchResultItem(SearchResultType.CHANNEL, it.name, it.groupTitle, channel = it) }
            }

            setLoading(false)
            findViewById<TextView>(R.id.txtEmpty).visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
            val adapter = SearchResultAdapter(onClick = { item -> onItemClick(item) })
            findViewById<RecyclerView>(R.id.recyclerFavorites).adapter = adapter
            adapter.submitList(results)
        }
    }

    private fun onItemClick(item: SearchResultItem) {
        val channel = item.channel ?: return
        val intent = Intent(this, FullPlayerActivity::class.java)
        intent.putExtra(FullPlayerActivity.EXTRA_CHANNEL, channel)
        intent.putExtra(FullPlayerActivity.EXTRA_IS_LIVE, true)
        intent.putExtra(FullPlayerActivity.EXTRA_SURF_SCOPE, com.brotv.player.player.ChannelSurfScopePolicy.FAVORITES)
        startActivity(intent)
    }

    private fun setLoading(loading: Boolean) {
        findViewById<ProgressBar>(R.id.progressBar).visibility = if (loading) View.VISIBLE else View.GONE
    }
}
