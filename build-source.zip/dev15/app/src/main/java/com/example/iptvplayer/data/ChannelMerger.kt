package com.brotv.player.data

import com.brotv.player.model.Channel
import com.brotv.player.model.MergedChannel

/**
 * Conservative channel merger. A wrong merge is much worse than leaving a duplicate visible,
 * so BRO only combines channels when the normalized identity and metadata do not conflict.
 */
object ChannelMerger {
    fun merge(channels: List<Channel>): List<MergedChannel> {
        val buckets = LinkedHashMap<String, MutableList<MutableList<Channel>>>()
        channels.forEach { channel ->
            val key = normalizeName(channel.name)
            val candidates = buckets.getOrPut(key) { mutableListOf() }
            val compatible = candidates.firstOrNull { group -> group.all { canMerge(it, channel) } }
            if (compatible != null) compatible += channel else candidates += mutableListOf(channel)
        }

        return buckets.values.flatten().mapIndexed { index, group ->
            val first = group.first()
            MergedChannel(
                id = "merged_${stableId(normalizeName(first.name))}_$index",
                name = preferredDisplayName(group),
                groupTitle = preferredGroup(group),
                logoUrl = group.firstNotNullOfOrNull { it.logoUrl?.takeIf(String::isNotBlank) },
                sourceUrls = group.map { it.streamUrl }.filter(String::isNotBlank).distinct(),
                epgIds = group.mapNotNull { it.epgId?.takeIf(String::isNotBlank) }.distinct(),
                hasArchive = group.any { it.hasArchive },
                archiveDurationDays = group.maxOf { it.archiveDurationDays }
            )
        }
    }

    internal fun canMerge(a: Channel, b: Channel): Boolean {
        if (normalizeName(a.name) != normalizeName(b.name)) return false
        val aEpg = normalizeEpg(a.epgId)
        val bEpg = normalizeEpg(b.epgId)
        if (aEpg != null && bEpg != null && aEpg != bEpg) return false
        val ga = normalizeGroup(a.groupTitle)
        val gb = normalizeGroup(b.groupTitle)
        return ga.isBlank() || gb.isBlank() || ga == gb || genericGroup(ga) || genericGroup(gb)
    }

    internal fun normalizeName(name: String): String = name
        .lowercase()
        .replace(Regex("""\[[^]]*]"""), " ")
        .replace(Regex("""\([^)]*\)"""), " ")
        .replace(Regex("""\b(ar|arabic|ksa|sa|uhd|fhd|full\s*hd|hd|sd|4k|hevc|h265|h264)\b"""), " ")
        .replace(Regex("""\b(عربي|السعودية|سعودي)\b"""), " ")
        .replace(Regex("""[^a-z0-9\u0600-\u06FF]+"""), " ")
        .replace(Regex("""\s+"""), " ")
        .trim()

    private fun normalizeEpg(value: String?): String? = value?.trim()?.lowercase()?.takeIf(String::isNotBlank)
    private fun normalizeGroup(value: String): String = value.lowercase().replace(Regex("""[^a-z0-9\u0600-\u06FF]+"""), " ").trim()
    private fun genericGroup(v: String) = v in setOf("عام", "general", "live", "tv")
    private fun preferredGroup(group: List<Channel>) = group.map { it.groupTitle }.firstOrNull { !genericGroup(normalizeGroup(it)) } ?: group.first().groupTitle
    private fun preferredDisplayName(group: List<Channel>) = group.minByOrNull { displayNoise(it.name) }?.name ?: group.first().name
    private fun displayNoise(name: String) = name.count { it == '|' || it == '[' || it == ']' } + if (Regex("(?i)\\b(uhd|fhd|hd|sd|4k)\\b").containsMatchIn(name)) 1 else 0
    private fun stableId(value: String) = value.hashCode().toUInt().toString(16)
}
