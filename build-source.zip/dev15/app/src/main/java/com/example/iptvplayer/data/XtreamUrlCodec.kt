package com.brotv.player.data

import java.net.URLEncoder

/**
 * Single source of truth for Xtream URL construction.
 * Keeps credentials/query values encoded consistently across playback, health checks and quota probes.
 */
object XtreamUrlCodec {
    fun cleanServer(server: String): String = server.trim().trimEnd('/')

    fun encodeQuery(value: String): String =
        URLEncoder.encode(value, Charsets.UTF_8.name()).replace("+", "%20")

    fun encodePathSegment(value: String): String = encodeQuery(value)

    fun playerApiUrl(
        server: String,
        username: String,
        password: String,
        action: String? = null,
        extraQuery: Map<String, String> = emptyMap()
    ): String {
        val params = buildList {
            add("username=${encodeQuery(username)}")
            add("password=${encodeQuery(password)}")
            if (!action.isNullOrBlank()) add("action=${encodeQuery(action)}")
            extraQuery.forEach { (key, value) ->
                add("${encodeQuery(key)}=${encodeQuery(value)}")
            }
        }
        return "${cleanServer(server)}/player_api.php?${params.joinToString("&")}" 
    }
}
