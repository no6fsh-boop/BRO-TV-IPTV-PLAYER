package com.brotv.player.player

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Process-wide IPTV connection/resource guard.
 *
 * Every concurrent stream obtains a lease before opening its network connection. Xtream accounts
 * are probed through player_api.php for max_connections/active_cons; M3U/unknown providers still
 * get device RAM/decoder protection. Higher-priority work can preempt lower-priority local leases,
 * so the primary channel can never be sacrificed to Multiview or an active DVR job.
 */
object ResourceGuard {

    sealed class AcquireResult {
        data class Granted(val lease: Lease) : AcquireResult()
        data class Denied(
            val reason: ResourceBudget.DenialReason,
            val providerMaxConnections: Int? = null,
            val providerProjectedConnections: Int? = null,
            val deviceDecoderLimit: Int? = null
        ) : AcquireResult()
    }

    data class Status(
        val localConnections: Int,
        val activeVideoDecoders: Int,
        val providerEstimatedConnections: Int? = null,
        val providerMaxConnections: Int? = null
    )

    class Lease internal constructor(
        val id: Long,
        val providerKey: String,
        internal var kind: ResourceBudget.SessionKind
    ) {
        private val closed = AtomicBoolean(false)
        @Volatile internal var preempted: Boolean = false

        fun release() {
            if (!closed.compareAndSet(false, true)) return
            ResourceGuard.releaseInternal(this)
        }

        fun updateKind(newKind: ResourceBudget.SessionKind) {
            if (closed.get() || preempted || kind == newKind) return
            kind = newKind
            ResourceGuard.updateKindInternal(this, newKind)
        }

        internal fun markPreempted(): Boolean {
            preempted = true
            return closed.compareAndSet(false, true)
        }
    }

    private data class Probe(
        val providerKey: String,
        val maxConnections: Int?,
        val activeConnections: Int?
    )

    private data class RuntimeLease(
        val lease: Lease,
        val onPreempt: ((Long) -> Unit)?
    )

    private data class AdmissionOutcome(
        val result: AcquireResult,
        val preemptedCallbacks: List<Pair<Long, ((Long) -> Unit)?>> = emptyList()
    )

    private val lock = Any()
    private val budget = ResourceBudget()
    private val nextLeaseId = AtomicLong(1L)
    private val runtimeLeases = LinkedHashMap<Long, RuntimeLease>()
    private val providerMaxConnections = mutableMapOf<String, Int>()
    private val lastReleasedAtMs = mutableMapOf<String, Long>()
    private val RELEASE_SETTLE_RETRY_DELAYS_MS = longArrayOf(700L, 1_200L, 1_800L)
    private const val RECENT_RELEASE_WINDOW_MS = 6_000L

    suspend fun acquire(
        context: Context,
        streamUrl: String,
        kind: ResourceBudget.SessionKind,
        onPreempt: ((Long) -> Unit)? = null
    ): AcquireResult {
        val device = readDeviceState(context.applicationContext)
        val leaseId = nextLeaseId.getAndIncrement()
        var probe = probeProvider(streamUrl)
        var outcome = admit(leaseId, kind, probe, device, onPreempt)

        // Xtream active_cons often stays stale for a few seconds after this app closes a stream.
        // During a known local handoff, wait/re-probe a few bounded times before declaring the
        // provider slot full. We never subtract/guess server counters and we never loop forever.
        var denied = outcome.result as? AcquireResult.Denied
        if (denied?.reason == ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT &&
            wasRecentlyReleased(probe.providerKey)
        ) {
            for (settleDelayMs in RELEASE_SETTLE_RETRY_DELAYS_MS) {
                delay(settleDelayMs)
                probe = probeProvider(streamUrl)
                outcome = admit(leaseId, kind, probe, device, onPreempt)
                denied = outcome.result as? AcquireResult.Denied
                if (denied?.reason != ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT) break
            }
        }

        outcome.preemptedCallbacks.forEach { (id, callback) ->
            runCatching { callback?.invoke(id) }
        }
        return outcome.result
    }

    private fun admit(
        leaseId: Long,
        kind: ResourceBudget.SessionKind,
        probe: Probe,
        device: ResourceBudget.DeviceState,
        onPreempt: ((Long) -> Unit)?
    ): AdmissionOutcome = synchronized(lock) {
        if (probe.maxConnections != null) {
            providerMaxConnections[probe.providerKey] = probe.maxConnections
        }
        val effectiveProviderMax = probe.maxConnections ?: providerMaxConnections[probe.providerKey]
        val admission = budget.acquire(
            leaseId = leaseId,
            kind = kind,
            provider = ResourceBudget.ProviderState(
                key = probe.providerKey,
                maxConnections = effectiveProviderMax,
                reportedActiveConnections = probe.activeConnections
            ),
            device = device
        )

        if (!admission.allowed) {
            return@synchronized AdmissionOutcome(
                AcquireResult.Denied(
                    reason = admission.denialReason ?: ResourceBudget.DenialReason.DEVICE_DECODER_LIMIT,
                    providerMaxConnections = admission.providerMaxConnections,
                    providerProjectedConnections = admission.providerProjectedConnections,
                    deviceDecoderLimit = admission.deviceDecoderLimit
                )
            )
        }

        val callbacks = mutableListOf<Pair<Long, ((Long) -> Unit)?>>()
        admission.preemptLeaseIds.forEach { id ->
            val old = runtimeLeases.remove(id)
            if (old != null && old.lease.markPreempted()) {
                callbacks += id to old.onPreempt
            }
        }
        val lease = Lease(leaseId, probe.providerKey, kind)
        runtimeLeases[leaseId] = RuntimeLease(lease, onPreempt)
        lastReleasedAtMs.remove(probe.providerKey)
        AdmissionOutcome(AcquireResult.Granted(lease), callbacks)
    }

    private fun wasRecentlyReleased(providerKey: String): Boolean = synchronized(lock) {
        val releasedAt = lastReleasedAtMs[providerKey] ?: return@synchronized false
        System.currentTimeMillis() - releasedAt <= RECENT_RELEASE_WINDOW_MS
    }

    /** Stable provider identity that never exposes the username/password in logs or UI. */
    fun providerKeyFor(streamUrl: String): String = parseXtream(streamUrl)?.let { xtream ->
        "xtream:${sha256("${xtream.server}|${xtream.username}")}" 
    } ?: hostProviderKey(streamUrl)

    fun activeConnectionCount(): Int = synchronized(lock) { budget.activeLeaseCount() }

    fun status(providerKey: String? = null): Status = synchronized(lock) {
        Status(
            localConnections = budget.activeLeaseCount(),
            activeVideoDecoders = budget.activeDecoderCount(),
            providerEstimatedConnections = providerKey?.let(budget::estimatedProviderConnectionCount),
            providerMaxConnections = providerKey?.let(providerMaxConnections::get)
        )
    }

    private fun releaseInternal(lease: Lease) {
        synchronized(lock) {
            runtimeLeases.remove(lease.id)
            // A preempted lease has already been removed from the pure budget by the admitting call.
            if (!lease.preempted) {
                budget.release(lease.id)
                lastReleasedAtMs[lease.providerKey] = System.currentTimeMillis()
            }
        }
    }

    private fun updateKindInternal(lease: Lease, kind: ResourceBudget.SessionKind) {
        synchronized(lock) {
            if (runtimeLeases.containsKey(lease.id)) budget.updateKind(lease.id, kind)
        }
    }

    private fun readDeviceState(context: Context): ResourceBudget.DeviceState {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        return ResourceBudget.DeviceState(
            lowRamDevice = am.isLowRamDevice,
            memoryClassMb = am.memoryClass,
            sdkInt = Build.VERSION.SDK_INT,
            availableMemoryMb = memoryInfo.availMem / (1024L * 1024L),
            lowMemory = memoryInfo.lowMemory
        )
    }

    private suspend fun probeProvider(streamUrl: String): Probe = withContext(Dispatchers.IO) {
        val xtream = parseXtream(streamUrl)
        if (xtream == null) {
            return@withContext Probe(hostProviderKey(streamUrl), null, null)
        }

        val key = "xtream:${sha256("${xtream.server}|${xtream.username}")}" 
        try {
            val apiUrl = com.brotv.player.data.XtreamUrlCodec.playerApiUrl(
                xtream.server,
                xtream.username,
                xtream.password
            )
            val connection = URL(apiUrl).openConnection() as HttpURLConnection
            connection.connectTimeout = 2_000
            connection.readTimeout = 2_500
            connection.requestMethod = "GET"
            connection.useCaches = false
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "BROTV/1.2")
            val code = connection.responseCode
            if (code !in 200..299) {
                connection.disconnect()
                return@withContext Probe(key, null, null)
            }
            val body = try {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally {
                connection.disconnect()
            }
            val userInfo = JSONObject(body).optJSONObject("user_info")
            Probe(
                providerKey = key,
                maxConnections = userInfo?.optString("max_connections")?.toIntOrNull()?.takeIf { it > 0 },
                activeConnections = userInfo?.optString("active_cons")?.toIntOrNull()?.coerceAtLeast(0)
            )
        } catch (_: Exception) {
            // An unsupported/slow account-info endpoint must not break playback. Device protection
            // remains active and the provider quota is treated as unknown for this acquisition.
            Probe(key, null, null)
        }
    }

    private data class XtreamIdentity(
        val server: String,
        val username: String,
        val password: String
    )

    private fun parseXtream(streamUrl: String): XtreamIdentity? {
        return try {
            val uri = URI(streamUrl)
            val server = serverFromUri(uri) ?: return null
            val path = uri.rawPath.orEmpty()
            val parts = path.split('/').filter { it.isNotBlank() }

            // Standard Xtream stream shapes:
            // /live/user/pass/id.ext, /movie/user/pass/id.ext, /series/user/pass/id.ext
            val typeIndex = parts.indexOfFirst { it == "live" || it == "movie" || it == "series" }
            if (typeIndex >= 0 && parts.size > typeIndex + 3) {
                val username = URLDecoder.decode(parts[typeIndex + 1], Charsets.UTF_8.name())
                val password = URLDecoder.decode(parts[typeIndex + 2], Charsets.UTF_8.name())
                if (username.isNotBlank()) return XtreamIdentity(server, username, password)
            }

            // Catch-up/timeshift commonly carries credentials as query parameters instead.
            if (path.endsWith("/streaming/timeshift.php") || path.endsWith("/timeshift.php")) {
                val query = parseQuery(uri.rawQuery.orEmpty())
                val username = query["username"].orEmpty()
                val password = query["password"].orEmpty()
                if (username.isNotBlank()) return XtreamIdentity(server, username, password)
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun serverFromUri(uri: URI): String? {
        val scheme = uri.scheme?.takeIf { it.isNotBlank() } ?: return null
        val host = uri.host?.takeIf { it.isNotBlank() } ?: return null
        val port = if (uri.port >= 0) ":${uri.port}" else ""
        return "$scheme://$host$port"
    }

    private fun parseQuery(rawQuery: String): Map<String, String> {
        if (rawQuery.isBlank()) return emptyMap()
        return rawQuery.split('&').mapNotNull { pair ->
            val index = pair.indexOf('=')
            if (index <= 0) return@mapNotNull null
            val key = URLDecoder.decode(pair.substring(0, index), Charsets.UTF_8.name())
            val value = URLDecoder.decode(pair.substring(index + 1), Charsets.UTF_8.name())
            key to value
        }.toMap()
    }

    private fun hostProviderKey(streamUrl: String): String {
        return try {
            val uri = URI(streamUrl)
            val host = uri.host ?: return "stream:${sha256(streamUrl.substringBefore('?'))}"
            val port = if (uri.port >= 0) ":${uri.port}" else ""
            "host:${uri.scheme ?: "http"}://$host$port"
        } catch (_: Exception) {
            "stream:${sha256(streamUrl.substringBefore('?'))}"
        }
    }

    private fun sha256(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return digest.take(12).joinToString("") { "%02x".format(it) }
    }
}
