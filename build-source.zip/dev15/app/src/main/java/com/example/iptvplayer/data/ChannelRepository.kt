package com.brotv.player.data

import android.content.Context
import com.brotv.player.model.Channel

/**
 * يجمع قنوات كل المصادر المحفوظة (كل قوائم M3U + كل حسابات Xtream) مع بعض،
 * بدل ما يقرأ مصدر وحيد بس. النتيجة النهائية تُمرَّر بعدين لـ ChannelMerger
 * عشان يدمج القنوات المتكررة عبر كل هذي المصادر بقناة وحدة.
 */
class ChannelRepository(private val context: Context) {

    private val sourcesManager = SourcesManager(context)

    suspend fun loadChannels(): List<Channel> {
        val allChannels = mutableListOf<Channel>()

        sourcesManager.getEnabledSources().forEach { source ->
            try {
                val channels = when (source.type) {
                    PrefsManager.SourceType.M3U -> M3uParser.fetchAndParse(source.m3uUrl)
                    PrefsManager.SourceType.XTREAM -> XtreamClient(
                        source.xtreamServer, source.xtreamUsername, source.xtreamPassword
                    ).getLiveChannels()
                    PrefsManager.SourceType.NONE -> emptyList()
                }
                allChannels.addAll(channels)
            } catch (e: Exception) {
                // لو مصدر وحد فشل (سيرفر واقع مثلاً)، نكمل بالباقي بدل ما نوقف كل شي
            }
        }
        return allChannels
    }
}
