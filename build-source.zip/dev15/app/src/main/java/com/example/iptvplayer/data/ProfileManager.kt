package com.brotv.player.data

import android.content.Context
import com.brotv.player.R
import org.json.JSONArray
import org.json.JSONObject

data class Profile(val id: String, val name: String)

/**
 * يدير قائمة البروفايلات والبروفايل النشط حالياً. كل بروفايل له مفضلة واستكمال
 * مشاهدة وحلقات مشاهدة خاصة فيه، عن طريق إضافة معرّف البروفايل كبادئة لمفاتيح التخزين.
 */
class ProfileManager(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    private fun defaultProfile() = Profile(DEFAULT_PROFILE_ID, appContext.getString(R.string.default_profile_name))

    fun getProfiles(): List<Profile> {
        val raw = prefs.getString(KEY_PROFILES, null)
        if (raw == null) {
            // أول تشغيل: ننشئ بروفايل افتراضي وحيد
            val default = listOf(defaultProfile())
            saveProfiles(default)
            return default
        }
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map {
                val obj = array.getJSONObject(it)
                val id = obj.getString("id")
                Profile(id, if (id == DEFAULT_PROFILE_ID) defaultProfile().name else obj.getString("name"))
            }
        } catch (e: Exception) {
            listOf(defaultProfile())
        }
    }

    fun addProfile(name: String): Profile {
        val newProfile = Profile("profile_${System.currentTimeMillis()}", name)
        val updated = getProfiles() + newProfile
        saveProfiles(updated)
        return newProfile
    }

    /** يضيف بروفايل بمعرّف محدد مسبقاً — يُستخدم فقط عند استرجاع نسخة احتياطية عشان
     *  تبقى بيانات المفضلة/المشاهدة (المرتبطة بنفس المعرّف القديم) متطابقة صح. */
    fun addProfileWithId(id: String, name: String) {
        if (getProfiles().any { it.id == id }) return
        saveProfiles(getProfiles() + Profile(id, name))
    }

    fun deleteProfile(id: String) {
        if (id == DEFAULT_PROFILE_ID) return // البروفايل الرئيسي ما ينحذف
        saveProfiles(getProfiles().filter { it.id != id })
        if (activeProfileId == id) activeProfileId = DEFAULT_PROFILE_ID
    }

    /** يُستخدم في Restore الموثوق: يستبدل قائمة البروفايلات دفعة واحدة بعد التحقق من الحمولة. */
    fun replaceProfiles(profiles: List<Profile>) {
        val safe = profiles.distinctBy { it.id }.ifEmpty {
            listOf(defaultProfile())
        }
        saveProfiles(safe)
        if (safe.none { it.id == activeProfileId }) activeProfileId = safe.first().id
    }

    var activeProfileId: String
        get() = prefs.getString(KEY_ACTIVE, DEFAULT_PROFILE_ID) ?: DEFAULT_PROFILE_ID
        set(value) = prefs.edit().putString(KEY_ACTIVE, value).apply()

    fun getActiveProfile(): Profile =
        getProfiles().firstOrNull { it.id == activeProfileId } ?: getProfiles().first()

    private fun saveProfiles(profiles: List<Profile>) {
        val array = JSONArray()
        profiles.forEach { p ->
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("name", p.name)
            array.put(obj)
        }
        prefs.edit().putString(KEY_PROFILES, array.toString()).apply()
    }

    companion object {
        const val DEFAULT_PROFILE_ID = "default"
        private const val KEY_PROFILES = "profiles_list"
        private const val KEY_ACTIVE = "active_profile"
    }
}
