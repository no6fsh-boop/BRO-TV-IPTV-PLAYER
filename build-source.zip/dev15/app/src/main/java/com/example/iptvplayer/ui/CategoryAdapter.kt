package com.brotv.player.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.model.ChannelCategory

class CategoryAdapter(
    private val categories: List<ChannelCategory>,
    private val selectedCategoryId: String? = null,
    private val onMoveRight: (() -> Unit)? = null,
    private val compact: Boolean = false,
    private val onSelected: (ChannelCategory) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    private var selectedPosition = categories.indexOfFirst { it.id == selectedCategoryId }.takeIf { it >= 0 } ?: 0

    init {
        setHasStableIds(true)
    }

    class CategoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.imgCategoryIcon)
        val name: TextView = view.findViewById(R.id.txtCategoryName)
        val count: TextView = view.findViewById(R.id.txtCategoryCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val layout = if (compact) R.layout.item_category_chip else R.layout.item_category
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return CategoryViewHolder(view)
    }

    override fun getItemId(position: Int): Long = categories[position].id.hashCode().toLong()

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categories[position]
        holder.icon.setImageResource(category.iconRes)
        holder.name.text = category.name
        holder.count.text = category.count.toString()
        holder.itemView.isSelected = position == selectedPosition

        holder.itemView.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && onMoveRight != null) {
                onMoveRight.invoke()
                true
            } else {
                false
            }
        }
        holder.itemView.setOnClickListener {
            val newPosition = holder.bindingAdapterPosition
            if (newPosition == RecyclerView.NO_POSITION) return@setOnClickListener
            val previous = selectedPosition
            selectedPosition = newPosition
            if (previous in categories.indices) notifyItemChanged(previous)
            notifyItemChanged(selectedPosition)
            onSelected(categories[newPosition])
        }
    }

    fun selectedAdapterPosition(): Int = selectedPosition.coerceIn(0, (categories.size - 1).coerceAtLeast(0))

    override fun onViewRecycled(holder: CategoryViewHolder) {
        holder.itemView.setOnKeyListener(null)
        holder.itemView.setOnClickListener(null)
        super.onViewRecycled(holder)
    }

    override fun getItemCount(): Int = categories.size
}
