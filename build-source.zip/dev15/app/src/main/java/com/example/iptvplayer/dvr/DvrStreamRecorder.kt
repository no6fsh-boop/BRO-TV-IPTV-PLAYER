package com.brotv.player.dvr

import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.max

/**
 * Blocking stream recorder used from an IO coroutine. It supports raw TS/MP4 and common HLS:
 * master playlists, AES-128, EXT-X-MAP (fMP4), byte ranges and live playlist refresh.
 * SAMPLE-AES/DRM is intentionally rejected rather than producing a corrupt file.
 */
class DvrStreamRecorder {
    data class Result(
        val bytesWritten: Long,
        val mimeType: String,
        val endedNaturally: Boolean
    )

    private val currentConnection = AtomicReference<HttpURLConnection?>(null)
    private val aborted = AtomicBoolean(false)

    fun abortCurrentNetworkCall() {
        aborted.set(true)
        currentConnection.getAndSet(null)?.disconnect()
    }

    fun resetAbort() {
        aborted.set(false)
    }

    fun record(
        sourceUrl: String,
        destination: File,
        stopAtMs: Long,
        shouldStop: () -> Boolean,
        onProgress: (bytesWritten: Long, mimeType: String) -> Unit
    ): Result {
        resetAbort()
        destination.parentFile?.mkdirs()
        return if (looksLikeHls(sourceUrl)) {
            recordHls(sourceUrl, destination, stopAtMs, shouldStop, onProgress)
        } else {
            recordRaw(sourceUrl, destination, stopAtMs, shouldStop, onProgress)
        }
    }

    private fun recordRaw(
        sourceUrl: String,
        destination: File,
        stopAtMs: Long,
        shouldStop: () -> Boolean,
        onProgress: (Long, String) -> Unit
    ): Result {
        var connection: HttpURLConnection? = null
        var total = destination.takeIf(File::exists)?.length() ?: 0L
        val mime = when {
            sourceUrl.substringBefore('?').lowercase().endsWith(".mp4") -> "video/mp4"
            else -> "video/mp2t"
        }
        try {
            connection = open(sourceUrl)
            val code = connection.responseCode
            if (code !in 200..299) throw RecorderHttpException(code)
            val responseType = connection.contentType.orEmpty().lowercase()
            if (responseType.contains("mpegurl")) {
                connection.disconnect(); currentConnection.compareAndSet(connection, null)
                return recordHls(sourceUrl, destination, stopAtMs, shouldStop, onProgress)
            }
            val networkInput = connection.inputStream.buffered()
            networkInput.mark(HLS_SNIFF_BYTES)
            val prefix = ByteArray(HLS_SNIFF_BYTES)
            val prefixCount = networkInput.read(prefix)
            networkInput.reset()
            if (prefixCount > 0 && prefix.copyOf(prefixCount).toString(Charsets.US_ASCII).trimStart().startsWith("#EXTM3U")) {
                networkInput.close()
                connection.disconnect(); currentConnection.compareAndSet(connection, null)
                return recordHls(sourceUrl, destination, stopAtMs, shouldStop, onProgress)
            }
            FileOutputStream(destination, true).use { output ->
                networkInput.use { input ->
                    val buffer = ByteArray(DEFAULT_BUFFER_BYTES)
                    var lastProgress = 0L
                    while (!mustStop(stopAtMs, shouldStop)) {
                        if (aborted.get()) throw RecordingPreemptedException()
                        val read = input.read(buffer)
                        if (read < 0) return Result(total, mime, endedNaturally = true)
                        if (read == 0) continue
                        output.write(buffer, 0, read)
                        total += read
                        if (total - lastProgress >= PROGRESS_STEP_BYTES) {
                            lastProgress = total
                            onProgress(total, mime)
                        }
                    }
                    output.flush()
                }
            }
            onProgress(total, mime)
            return Result(total, mime, endedNaturally = false)
        } catch (e: Exception) {
            if (aborted.get() && e !is RecordingPreemptedException) throw RecordingPreemptedException()
            throw e
        } finally {
            connection?.disconnect()
            currentConnection.compareAndSet(connection, null)
        }
    }

    private fun recordHls(
        sourceUrl: String,
        destination: File,
        stopAtMs: Long,
        shouldStop: () -> Boolean,
        onProgress: (Long, String) -> Unit
    ): Result {
        var playlistUrl = sourceUrl
        var masterText = fetchText(playlistUrl)
        HlsRecorderParser.selectBestVariant(masterText, playlistUrl)?.let { best ->
            playlistUrl = best.uri
            masterText = fetchText(playlistUrl)
        }
        if (!HlsRecorderParser.isPlaylist(masterText)) {
            throw IllegalStateException("HLS playlist is invalid")
        }

        var total = destination.takeIf(File::exists)?.length() ?: 0L
        var mimeType = "video/mp2t"
        val checkpoint = Checkpoint(destination)
        val downloadedSegments = checkpoint.segmentIds.toHashSet()
        val writtenMaps = checkpoint.mapIds.toHashSet()
        val keyCache = HashMap<String, ByteArray>()
        val previousRangeEnd = HashMap<String, Long>()
        var firstPassText: String? = masterText
        var idleRounds = 0

        FileOutputStream(destination, true).use { output ->
            while (!mustStop(stopAtMs, shouldStop)) {
                if (aborted.get()) throw RecordingPreemptedException()
                val text = firstPassText ?: fetchText(playlistUrl)
                firstPassText = null
                val playlist = HlsRecorderParser.parseMedia(text, playlistUrl)
                if (playlist.isFmp4) mimeType = "video/mp4"
                var wroteThisRound = false

                for (segment in playlist.segments) {
                    if (mustStop(stopAtMs, shouldStop)) break
                    if (aborted.get()) throw RecordingPreemptedException()
                    // Resolve implicit byte-range offsets even for already-downloaded entries so a
                    // process restart can safely resume playlists that reuse the same URI.
                    val resolvedSegmentRange = resolveSegmentByteRange(segment, previousRangeEnd, checkpoint)
                    val identity = segmentIdentity(segment, resolvedSegmentRange)
                    if (identity in downloadedSegments) continue

                    segment.initMap?.let { initMap ->
                        val resolvedMapRange = resolveByteRange(initMap.uri, initMap.byteRange, previousRangeEnd)
                        val mapIdentity = mapIdentity(initMap, resolvedMapRange)
                        if (mapIdentity !in writtenMaps) {
                            val bytes = fetchBytes(initMap.uri, resolvedMapRange)
                            output.write(bytes)
                            output.flush()
                            total += bytes.size
                            wroteThisRound = true
                            writtenMaps += mapIdentity
                            checkpoint.appendMap(mapIdentity)
                            onProgress(total, mimeType)
                        }
                    }

                    var bytes = fetchBytes(segment.uri, resolvedSegmentRange)
                    val key = segment.key
                    if (key != null) {
                        when (key.method.uppercase()) {
                            "AES-128" -> {
                                val keyUri = key.uri ?: throw IllegalStateException("AES-128 key URI is missing")
                                val rawKey = keyCache.getOrPut(keyUri) { fetchBytes(keyUri, null) }
                                bytes = decryptAes128(bytes, rawKey, key.ivHex, segment.sequence)
                            }
                            "NONE" -> Unit
                            else -> throw UnsupportedOperationException("Unsupported HLS encryption: ${key.method}")
                        }
                    }
                    output.write(bytes)
                    // Persist the segment identity only after its bytes are flushed. A crash can at
                    // worst duplicate the last segment; it cannot mark unwritten media as complete.
                    output.flush()
                    total += bytes.size
                    wroteThisRound = true
                    downloadedSegments += identity
                    checkpoint.appendSegment(identity)
                    checkpoint.appendSegmentRange(
                        sequence = segment.sequence,
                        uriHash = sha256(segment.uri),
                        range = resolvedSegmentRange
                    )
                    onProgress(total, mimeType)
                }
                output.flush()

                if (playlist.endList) {
                    return Result(total, mimeType, endedNaturally = true)
                }
                idleRounds = if (wroteThisRound) 0 else idleRounds + 1
                val waitMs = max(900L, (playlist.targetDurationSeconds * 500L)).coerceAtMost(5_000L)
                sleepInterruptibly(if (idleRounds > 2) max(waitMs, 2_000L) else waitMs, stopAtMs, shouldStop)
            }
        }
        onProgress(total, mimeType)
        return Result(total, mimeType, endedNaturally = false)
    }

    private fun resolveSegmentByteRange(
        segment: HlsRecorderParser.Segment,
        previousRangeEnd: MutableMap<String, Long>,
        checkpoint: Checkpoint
    ): HlsRecorderParser.ByteRange? {
        val range = segment.byteRange ?: return null
        val uriHash = sha256(segment.uri)
        val checkpointRange = checkpoint.segmentRange(segment.sequence, uriHash)
        val offset = range.offset
            ?: checkpointRange?.offset
            ?: previousRangeEnd[segment.uri]
            ?: checkpoint.previousSequenceRangeEnd(segment.sequence, uriHash)
            ?: throw IllegalStateException("HLS implicit byte-range offset cannot be resolved safely")
        val end = safeRangeEnd(offset, range.length)
        previousRangeEnd[segment.uri] = end
        return HlsRecorderParser.ByteRange(range.length, offset)
    }

    private fun resolveByteRange(
        uri: String,
        range: HlsRecorderParser.ByteRange?,
        previousRangeEnd: MutableMap<String, Long>
    ): HlsRecorderParser.ByteRange? {
        if (range == null) return null
        val offset = range.offset
            ?: previousRangeEnd[uri]
            ?: throw IllegalStateException("HLS implicit byte-range offset cannot be resolved safely")
        previousRangeEnd[uri] = safeRangeEnd(offset, range.length)
        return HlsRecorderParser.ByteRange(range.length, offset)
    }

    private fun safeRangeEnd(offset: Long, length: Long): Long {
        require(offset >= 0L && length > 0L && offset <= Long.MAX_VALUE - length) {
            "Invalid HLS byte range"
        }
        return offset + length
    }

    private fun fetchText(url: String): String {
        val bytes = fetchBytes(url, null)
        return bytes.toString(Charsets.UTF_8)
    }

    private fun fetchBytes(url: String, range: HlsRecorderParser.ByteRange?): ByteArray {
        if (aborted.get()) throw RecordingPreemptedException()
        var connection: HttpURLConnection? = null
        try {
            connection = open(url, range)
            val code = connection.responseCode
            if (code !in 200..299) throw RecorderHttpException(code)
            val bytes = connection.inputStream.buffered().use { it.readBytes() }
            if (range == null || code == HttpURLConnection.HTTP_PARTIAL) return bytes

            // A surprising number of IPTV/CDN origins ignore Range and answer 200 with the full
            // object. Slice locally so EXT-X-BYTERANGE recordings remain byte-accurate instead
            // of silently appending the whole media object for every segment.
            val start = (range.offset ?: 0L)
            val endExclusive = start + range.length
            if (start < 0L || range.length <= 0L || endExclusive > bytes.size.toLong()) {
                throw IllegalStateException(
                    "Server ignored HTTP Range and returned ${bytes.size} bytes; " +
                        "requested $start-${endExclusive - 1}"
                )
            }
            return bytes.copyOfRange(start.toInt(), endExclusive.toInt())
        } catch (e: Exception) {
            if (aborted.get() && e !is RecordingPreemptedException) throw RecordingPreemptedException()
            throw e
        } finally {
            connection?.disconnect()
            currentConnection.compareAndSet(connection, null)
        }
    }

    private fun open(url: String, range: HlsRecorderParser.ByteRange? = null): HttpURLConnection {
        val connection = URI.create(url).toURL().openConnection() as HttpURLConnection
        connection.connectTimeout = CONNECT_TIMEOUT_MS
        connection.readTimeout = READ_TIMEOUT_MS
        connection.instanceFollowRedirects = true
        connection.useCaches = false
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", "BROTV/2 DVR")
        if (range != null) {
            val start = range.offset ?: 0L
            val end = start + range.length - 1
            connection.setRequestProperty("Range", "bytes=$start-$end")
        }
        currentConnection.set(connection)
        return connection
    }

    private fun decryptAes128(data: ByteArray, rawKey: ByteArray, ivHex: String?, sequence: Long): ByteArray {
        require(rawKey.size >= 16) { "Invalid AES-128 key" }
        val key = if (rawKey.size == 16) rawKey else rawKey.copyOf(16)
        val iv = ivHex?.let(::parseIv) ?: sequenceIv(sequence)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return cipher.doFinal(data)
    }

    private fun parseIv(value: String): ByteArray {
        var hex = value.removePrefix("0x").removePrefix("0X").filterNot(Char::isWhitespace)
        if (hex.length % 2 != 0) hex = "0$hex"
        val raw = ByteArray(hex.length / 2) { index ->
            hex.substring(index * 2, index * 2 + 2).toInt(16).toByte()
        }
        return if (raw.size >= 16) raw.takeLast(16).toByteArray() else ByteArray(16 - raw.size) + raw
    }

    private fun sequenceIv(sequence: Long): ByteArray {
        val iv = ByteArray(16)
        var value = sequence
        for (i in 15 downTo 8) {
            iv[i] = (value and 0xFF).toByte()
            value = value ushr 8
        }
        return iv
    }

    private fun segmentIdentity(
        segment: HlsRecorderParser.Segment,
        resolvedRange: HlsRecorderParser.ByteRange?
    ): String {
        val raw = "${segment.sequence}|${segment.uri}|$resolvedRange"
        return sha256(raw)
    }

    private fun mapIdentity(map: HlsRecorderParser.InitMap, resolvedRange: HlsRecorderParser.ByteRange?): String =
        sha256("${map.uri}|$resolvedRange")

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun sleepInterruptibly(ms: Long, stopAtMs: Long, shouldStop: () -> Boolean) {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (aborted.get()) throw RecordingPreemptedException()
            if (mustStop(stopAtMs, shouldStop)) return
            Thread.sleep(minOf(250L, end - System.currentTimeMillis()))
        }
    }

    private fun mustStop(stopAtMs: Long, shouldStop: () -> Boolean): Boolean =
        shouldStop() || (stopAtMs > 0L && System.currentTimeMillis() >= stopAtMs)

    private fun looksLikeHls(url: String): Boolean =
        url.substringBefore('?').lowercase().endsWith(".m3u8")

    /** Hash-only sidecar used to resume HLS after process/service restarts without storing stream URLs. */
    private class Checkpoint(destination: File) {
        private val file = checkpointFile(destination)
        val segmentIds = LinkedHashSet<String>()
        val mapIds = LinkedHashSet<String>()
        private val segmentRanges = LinkedHashMap<RangeKey, HlsRecorderParser.ByteRange>()

        init {
            if (file.exists()) {
                runCatching {
                    file.forEachLine { line ->
                        when {
                            line.startsWith("S:") -> line.substring(2).takeIf(::isHash)?.let(segmentIds::add)
                            line.startsWith("M:") -> line.substring(2).takeIf(::isHash)?.let(mapIds::add)
                            line.startsWith("R:") -> parseRangeState(line)?.let { (key, range) -> segmentRanges[key] = range }
                        }
                    }
                }
            }
        }


        fun segmentRange(sequence: Long, uriHash: String): HlsRecorderParser.ByteRange? =
            segmentRanges[RangeKey(sequence, uriHash)]

        fun previousSequenceRangeEnd(sequence: Long, uriHash: String): Long? {
            if (sequence == Long.MIN_VALUE) return null
            val range = segmentRanges[RangeKey(sequence - 1L, uriHash)] ?: return null
            val offset = range.offset ?: return null
            return if (offset <= Long.MAX_VALUE - range.length) offset + range.length else null
        }

        @Synchronized fun appendSegmentRange(
            sequence: Long,
            uriHash: String,
            range: HlsRecorderParser.ByteRange?
        ) {
            val resolved = range?.takeIf { it.offset != null } ?: return
            if (!isHash(uriHash)) return
            val key = RangeKey(sequence, uriHash)
            if (segmentRanges[key] == resolved) return
            segmentRanges[key] = resolved
            append("R:$sequence:$uriHash:${resolved.offset}:${resolved.length}")
        }

        private fun parseRangeState(line: String): Pair<RangeKey, HlsRecorderParser.ByteRange>? {
            val parts = line.split(':')
            if (parts.size != 5 || parts[0] != "R") return null
            val sequence = parts[1].toLongOrNull() ?: return null
            val uriHash = parts[2].takeIf(::isHash) ?: return null
            val offset = parts[3].toLongOrNull()?.takeIf { it >= 0L } ?: return null
            val length = parts[4].toLongOrNull()?.takeIf { it > 0L } ?: return null
            if (offset > Long.MAX_VALUE - length) return null
            return RangeKey(sequence, uriHash) to HlsRecorderParser.ByteRange(length, offset)
        }

        private data class RangeKey(val sequence: Long, val uriHash: String)

        @Synchronized fun appendSegment(id: String) {
            if (segmentIds.add(id)) append("S:$id")
        }

        @Synchronized fun appendMap(id: String) {
            if (mapIds.add(id)) append("M:$id")
        }

        private fun append(line: String) {
            file.parentFile?.mkdirs()
            file.appendText(line + "\n", Charsets.US_ASCII)
        }

        private fun isHash(value: String): Boolean = value.length == 64 && value.all { it in '0'..'9' || it in 'a'..'f' }
    }

    companion object {
        private fun checkpointFile(destination: File): File = File(destination.absolutePath + ".brotv.idx")

        fun cleanupCheckpoint(destination: File) {
            runCatching { checkpointFile(destination).delete() }
        }

        private const val CONNECT_TIMEOUT_MS = 10_000
        private const val READ_TIMEOUT_MS = 15_000
        private const val DEFAULT_BUFFER_BYTES = 128 * 1024
        private const val HLS_SNIFF_BYTES = 16
        private const val PROGRESS_STEP_BYTES = 1024 * 1024L
    }
}

class RecordingPreemptedException : Exception("Recording was preempted by a higher-priority session")
class RecorderHttpException(val statusCode: Int) : Exception("HTTP $statusCode")
