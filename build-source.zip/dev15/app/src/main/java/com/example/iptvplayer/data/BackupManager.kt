package com.brotv.player.data

import android.content.Context
import com.brotv.player.R
import com.brotv.player.security.CredentialCipher
import com.brotv.player.security.PortableBackupCipher
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * نسخ احتياطي كامل لحالة BRO TV.
 * - Device backup: مشفر بمفتاح Android Keystore الخاص بالجهاز.
 * - Portable backup: مشفر بكلمة مرور، ويمكن نقله إلى جهاز آخر.
 *
 * Restore يعمل بطريقة تعويضية: تُلتقط Snapshot للحالة الحالية قبل التطبيق، وإذا فشلت
 * مرحلة لاحقة نحاول استرجاع الـSnapshot بدل ترك التطبيق بنصف حالة جديدة ونصف قديمة.
 */
object BackupManager {

    @Volatile
    var lastErrorMessage: String? = null
        private set

    suspend fun exportToFile(context: Context): File {
        lastErrorMessage = null
        val file = getBackupFile(context)
        val encrypted = try {
            CredentialCipher.encryptOrThrow(context, buildPayload(context).toString(2))
        } catch (e: Exception) {
            lastErrorMessage = e.message ?: context.getString(R.string.backup_encrypt_device_failed)
            throw e
        }
        file.writeText(encrypted)
        return file
    }

    suspend fun exportPortableToFile(context: Context, password: CharArray): File {
        lastErrorMessage = null
        val file = getPortableBackupFile(context)
        val encrypted = try {
            PortableBackupCipher.encrypt(buildPayload(context).toString(2), password)
        } catch (e: Exception) {
            lastErrorMessage = e.message ?: context.getString(R.string.backup_encrypt_portable_failed)
            throw e
        }
        file.writeText(encrypted)
        return file
    }

    suspend fun importFromFile(context: Context, file: File): Boolean {
        lastErrorMessage = null
        val decrypted = try {
            CredentialCipher.decryptOrNull(context, file.readText())
        } catch (_: Exception) {
            null
        }
        if (decrypted.isNullOrEmpty()) {
            lastErrorMessage = context.getString(R.string.backup_decrypt_device_failed)
            return false
        }
        return importJsonWithRollback(context, decrypted)
    }

    suspend fun importPortableFromFile(context: Context, file: File, password: CharArray): Boolean {
        lastErrorMessage = null
        val decrypted = PortableBackupCipher.decrypt(file.readText(), password)
        if (decrypted.isNullOrEmpty()) {
            lastErrorMessage = context.getString(R.string.backup_portable_password_or_file_invalid)
            return false
        }
        return importJsonWithRollback(context, decrypted)
    }

    private suspend fun importJsonWithRollback(context: Context, rawJson: String): Boolean {
        val target = try {
            JSONObject(rawJson)
        } catch (_: Exception) {
            lastErrorMessage = context.getString(R.string.backup_invalid_file)
            return false
        }
        validateBackupPayload(context, target)?.let {
            lastErrorMessage = it
            return false
        }

        // Snapshot كاملة قبل لمس أي مخزن، لاستخدامها في rollback إذا فشلت مرحلة لاحقة.
        val before = try {
            buildPayload(context)
        } catch (e: Exception) {
            lastErrorMessage = context.getString(R.string.backup_snapshot_failed, e.message.orEmpty())
            return false
        }

        return try {
            applyPayload(context, target)
            true
        } catch (e: Exception) {
            val rollbackSucceeded = try {
                applyPayload(context, before)
                true
            } catch (_: Exception) {
                false
            }
            lastErrorMessage = if (rollbackSucceeded) {
                context.getString(R.string.backup_rollback_succeeded)
            } else {
                context.getString(R.string.backup_rollback_failed)
            }
            false
        }
    }

    /** يبني Payload واحدة تستخدم للـDevice والـPortable والـRollback حتى لا تختلف الحقول بينهم. */
    private suspend fun buildPayload(context: Context): JSONObject {
        val prefs = PrefsManager(context)
        val sourcesManager = SourcesManager(context)
        val profileManager = ProfileManager(context)
        val json = JSONObject()
        json.put("backupVersion", 2)

        val sources = sourcesManager.getSources()
        val defaultSourceId = sourcesManager.getDefaultSource()?.id.orEmpty()
        val sourcesArray = JSONArray()
        sources.forEach { s ->
            sourcesArray.put(JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("type", s.type.name)
                put("m3uUrl", s.m3uUrl)
                put("xtreamServer", s.xtreamServer)
                put("xtreamUsername", s.xtreamUsername)
                put("xtreamPassword", s.xtreamPassword)
                put("epgUrl", s.epgUrl)
                put("enabled", s.enabled)
            })
        }
        json.put("sources", sourcesArray)
        json.put("defaultSourceId", defaultSourceId)

        json.put("channelOrder", prefs.channelOrder.joinToString(","))
        json.put("use24HourTime", prefs.use24HourTime)
        json.put("compactChannelList", prefs.compactChannelList)
        json.put("showChannelNumbers", prefs.showChannelNumbers)
        json.put("hiddenLiveCategories", prefs.hiddenLiveCategories.joinToString(","))
        json.put("hiddenVodCategories", prefs.hiddenVodCategories.joinToString(","))
        json.put("hiddenSeriesCategories", prefs.hiddenSeriesCategories.joinToString(","))
        json.put("bufferProfile", prefs.bufferProfile)
        json.put("qualityMode", prefs.qualityMode)
        json.put("matchFrameRateMode", prefs.matchFrameRateMode)
        json.put("audioOutputMode", prefs.audioOutputMode)
        json.put("smartQualityGuardEnabled", prefs.smartQualityGuardEnabled)
        json.put("playerStatsOverlayEnabled", prefs.playerStatsOverlayEnabled)

        val profilesArray = JSONArray()
        profileManager.getProfiles().forEach { profile ->
            profilesArray.put(JSONObject().apply {
                put("id", profile.id)
                put("name", profile.name)
                put("favoriteChannels", PrefsManager.getChannelFavoritesForProfile(context, profile.id).joinToString(","))
                put("favoriteMovies", PrefsManager.getMovieFavoritesForProfile(context, profile.id).joinToString(","))
                put("favoriteSeries", PrefsManager.getSeriesFavoritesForProfile(context, profile.id).joinToString(","))
                put("hidden", PrefsManager.getHiddenForProfile(context, profile.id).joinToString(","))
                put("watchedEpisodes", PrefsManager.getWatchedForProfile(context, profile.id).joinToString(","))
                put("continueWatching", ContinueWatchingManager.getRawJsonForProfile(context, profile.id) ?: "[]")
            })
        }
        json.put("profiles", profilesArray)
        json.put("activeProfileId", profileManager.activeProfileId)
        return json
    }

    /**
     * يطبق الحمولة بعد التحقق منها. أي فشل يرمي Exception لطبقة rollback الخارجية.
     * المصادر تُستبدل داخل Room transaction واحدة، ثم بقية المخازن تُطبق من payload محققة مسبقاً.
     */
    private suspend fun applyPayload(context: Context, json: JSONObject) {
        validateBackupPayload(context, json)?.let { throw IllegalArgumentException(it) }
        val prefs = PrefsManager(context)
        val sourcesManager = SourcesManager(context)
        val profileManager = ProfileManager(context)

        val sourcesArray = json.optJSONArray("sources") ?: JSONArray()
        val configs = ArrayList<SourceConfig>(sourcesArray.length())
        for (i in 0 until sourcesArray.length()) {
            val obj = sourcesArray.getJSONObject(i)
            configs += SourceConfig(
                id = obj.getString("id"),
                name = obj.optString("name", ""),
                type = PrefsManager.SourceType.valueOf(obj.getString("type")),
                m3uUrl = obj.optString("m3uUrl", ""),
                xtreamServer = obj.optString("xtreamServer", ""),
                xtreamUsername = obj.optString("xtreamUsername", ""),
                xtreamPassword = obj.optString("xtreamPassword", ""),
                epgUrl = obj.optString("epgUrl", ""),
                enabled = obj.optBoolean("enabled", true)
            )
        }
        if (!sourcesManager.replaceSourcesAtomically(configs, json.optString("defaultSourceId", ""))) {
            throw IllegalStateException(context.getString(R.string.backup_replace_sources_failed))
        }

        prefs.channelOrder = splitCsv(json.optString("channelOrder", ""))
        prefs.use24HourTime = json.optBoolean("use24HourTime", true)
        prefs.compactChannelList = json.optBoolean("compactChannelList", false)
        prefs.showChannelNumbers = json.optBoolean("showChannelNumbers", true)
        prefs.hiddenLiveCategories = splitCsv(json.optString("hiddenLiveCategories", "")).toMutableSet()
        prefs.hiddenVodCategories = splitCsv(json.optString("hiddenVodCategories", "")).toMutableSet()
        prefs.hiddenSeriesCategories = splitCsv(json.optString("hiddenSeriesCategories", "")).toMutableSet()
        prefs.bufferProfile = json.optString("bufferProfile", "BALANCED")
        prefs.qualityMode = json.optString("qualityMode", "SOURCE")
        prefs.matchFrameRateMode = json.optString("matchFrameRateMode", "AUTO")
        prefs.audioOutputMode = json.optString("audioOutputMode", "AUTO")
        prefs.smartQualityGuardEnabled = json.optBoolean("smartQualityGuardEnabled", true)
        prefs.playerStatsOverlayEnabled = json.optBoolean("playerStatsOverlayEnabled", false)

        val profilesArray = json.optJSONArray("profiles") ?: JSONArray()
        val profiles = ArrayList<Profile>(profilesArray.length())
        for (i in 0 until profilesArray.length()) {
            val obj = profilesArray.getJSONObject(i)
            profiles += Profile(obj.getString("id"), obj.optString("name", context.getString(R.string.profile_generic_name)))
        }
        if (profiles.isNotEmpty()) profileManager.replaceProfiles(profiles)

        for (i in 0 until profilesArray.length()) {
            val obj = profilesArray.getJSONObject(i)
            val profileId = obj.getString("id")
            PrefsManager.setChannelFavoritesForProfile(context, profileId, splitCsv(obj.optString("favoriteChannels", "")).toSet())
            PrefsManager.setMovieFavoritesForProfile(context, profileId, splitCsv(obj.optString("favoriteMovies", "")).toSet())
            PrefsManager.setSeriesFavoritesForProfile(context, profileId, splitCsv(obj.optString("favoriteSeries", "")).toSet())
            PrefsManager.setHiddenForProfile(context, profileId, splitCsv(obj.optString("hidden", "")).toSet())
            PrefsManager.setWatchedForProfile(context, profileId, splitCsv(obj.optString("watchedEpisodes", "")).toSet())
            ContinueWatchingManager.setRawJsonForProfile(context, profileId, obj.optString("continueWatching", "[]"))
        }

        val activeId = json.optString("activeProfileId", "")
        if (activeId.isNotBlank() && profileManager.getProfiles().any { it.id == activeId }) {
            profileManager.activeProfileId = activeId
        }
    }

    private fun splitCsv(raw: String): List<String> = raw.split(',').filter { it.isNotBlank() }

    /** يتحقق من كامل الحمولة قبل لمس Room أو SharedPreferences. */
    private fun validateBackupPayload(context: Context, json: JSONObject): String? {
        val sources = json.optJSONArray("sources")
        if (sources != null) {
            val ids = HashSet<String>()
            for (i in 0 until sources.length()) {
                val source = sources.optJSONObject(i) ?: return context.getString(R.string.backup_invalid_source)
                val id = source.optString("id", "")
                if (id.isBlank() || !ids.add(id)) return context.getString(R.string.backup_duplicate_sources)
                try {
                    PrefsManager.SourceType.valueOf(source.getString("type"))
                } catch (_: Exception) {
                    return context.getString(R.string.backup_unknown_source_type)
                }
            }
        }

        val profiles = json.optJSONArray("profiles")
        if (profiles != null) {
            val ids = HashSet<String>()
            for (i in 0 until profiles.length()) {
                val profile = profiles.optJSONObject(i) ?: return context.getString(R.string.backup_invalid_profile)
                val id = profile.optString("id", "")
                if (id.isBlank() || !ids.add(id)) return context.getString(R.string.backup_duplicate_profiles)
                try {
                    JSONArray(profile.optString("continueWatching", "[]"))
                } catch (_: Exception) {
                    return context.getString(R.string.backup_invalid_continue_watching)
                }
            }
        }

        val buffer = json.optString("bufferProfile", "BALANCED")
        if (buffer !in setOf("AUTO", "LOW_LATENCY", "BALANCED", "STABLE")) return context.getString(R.string.backup_unknown_buffer)
        val quality = json.optString("qualityMode", "SOURCE")
        if (quality !in setOf("AUTO", "SOURCE", "UHD_4K", "FHD_1080P", "HD_720P")) return context.getString(R.string.backup_unknown_quality)
        val frame = json.optString("matchFrameRateMode", "AUTO")
        if (frame !in setOf("OFF", "AUTO", "ALWAYS")) return context.getString(R.string.backup_unknown_frame_rate)
        val audio = json.optString("audioOutputMode", "AUTO")
        if (audio !in setOf("AUTO", "PCM", "PASSTHROUGH")) return context.getString(R.string.backup_unknown_audio)
        return null
    }

    fun getBackupFile(context: Context): File = File(context.getExternalFilesDir(null), BACKUP_FILE_NAME)
    fun getPortableBackupFile(context: Context): File = File(context.getExternalFilesDir(null), PORTABLE_BACKUP_FILE_NAME)

    private const val BACKUP_FILE_NAME = "brotv_backup.json"
    private const val PORTABLE_BACKUP_FILE_NAME = "brotv_backup_portable.brotv"
}
