package com.brotv.player.data

import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject
import java.net.InetAddress
import java.security.MessageDigest

/**
 * Lightweight local-only HTTP bridge between the TV and a phone.
 * The page follows BRO TV's selected Arabic/English UI language.
 */
class LocalPairingServer(
    port: Int,
    private val mode: Mode,
    @Volatile private var currentToken: String,
    private val languageCode: String = LocaleManager.LANGUAGE_ARABIC,
    private val onDataReceived: (Map<String, String>) -> Unit
) : NanoHTTPD(port) {

    enum class Mode { LOGIN, SEARCH }

    private val english: Boolean
        get() = languageCode.equals(LocaleManager.LANGUAGE_ENGLISH, ignoreCase = true)

    private fun t(ar: String, en: String): String = if (english) en else ar

    private fun htmlEscape(value: String): String = value
        .replace("&", "&amp;")
        .replace("\"", "&quot;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")

    fun updateToken(newToken: String) {
        currentToken = newToken
    }

    override fun serve(session: IHTTPSession): Response {
        if (!isLocalClient(session.remoteIpAddress)) {
            return harden(newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain; charset=utf-8", "Forbidden"))
        }
        return when {
            session.method == Method.GET && session.uri == "/pair" -> serveForm(session)
            session.method == Method.POST && session.uri == "/pair" -> handleSubmit(session)
            else -> harden(newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain; charset=utf-8", "Not found"))
        }
    }


    private fun tokenMatches(candidate: String?): Boolean {
        if (candidate.isNullOrEmpty()) return false
        val expected = currentToken.toByteArray(Charsets.US_ASCII)
        val actual = candidate.toByteArray(Charsets.US_ASCII)
        return MessageDigest.isEqual(expected, actual)
    }

    private fun isLocalClient(remoteIp: String?): Boolean {
        if (remoteIp.isNullOrBlank()) return false
        return runCatching {
            val address = InetAddress.getByName(remoteIp)
            address.isSiteLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress
        }.getOrDefault(false)
    }

    private fun serveForm(session: IHTTPSession): Response {
        val token = session.parameters["token"]?.firstOrNull()
        if (!tokenMatches(token)) {
            val expired = htmlEscape(t(
                "انتهت صلاحية الكود، ارجع وامسحه من جديد.",
                "This code expired. Go back and scan the new code."
            ))
            return harden(newFixedLengthResponse(
                Response.Status.FORBIDDEN,
                "text/html; charset=utf-8",
                htmlPage("<p style='color:#d33'>$expired</p>")
            ))
        }

        val bodyHtml = if (mode == Mode.LOGIN) loginFormHtml() else searchFormHtml()
        return harden(newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", htmlPage(bodyHtml)))
    }

    private fun handleSubmit(session: IHTTPSession): Response {
        // Authenticate from the query string before NanoHTTPD buffers/parses the request body.
        // The JSON carries the token too (defence in depth), but unauthenticated clients never
        // get a chance to feed an arbitrarily large payload into parseBody().
        val queryToken = session.parameters["token"]?.firstOrNull()
        if (!tokenMatches(queryToken)) return jsonResponse(false, t("انتهت صلاحية الكود", "Code expired"))
        val contentLength = session.headers["content-length"]?.toLongOrNull()
        if (contentLength != null && contentLength > MAX_REQUEST_BODY_BYTES) {
            return jsonResponse(false, t("الطلب كبير جداً", "Request is too large"))
        }

        val files = HashMap<String, String>()
        session.parseBody(files)
        val body = files["postData"] ?: ""
        if (body.toByteArray(Charsets.UTF_8).size > MAX_REQUEST_BODY_BYTES) {
            return jsonResponse(false, t("الطلب كبير جداً", "Request is too large"))
        }

        return try {
            val json = JSONObject(body)
            val token = json.optString("token")
            if (!tokenMatches(token)) {
                return jsonResponse(false, t("انتهت صلاحية الكود", "Code expired"))
            }
            val data = mutableMapOf<String, String>()
            json.keys().forEach { key -> data[key] = json.optString(key) }
            onDataReceived(data)
            jsonResponse(true, t("تم", "Done"))
        } catch (_: Exception) {
            jsonResponse(false, t("تعذر معالجة الطلب", "Unable to process request"))
        }
    }

    private fun jsonResponse(ok: Boolean, message: String): Response {
        val json = JSONObject().put("ok", ok).put("message", message).toString()
        return harden(newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", json))
    }

    private fun harden(response: Response): Response = response.apply {
        addHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        addHeader("Pragma", "no-cache")
        addHeader("Referrer-Policy", "no-referrer")
        addHeader("X-Content-Type-Options", "nosniff")
        addHeader(
            "Content-Security-Policy",
            "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; form-action 'self'; base-uri 'none'"
        )
    }

    private fun htmlPage(bodyHtml: String): String = """
        <!DOCTYPE html>
        <html dir="${if (english) "ltr" else "rtl"}" lang="${if (english) "en" else "ar"}">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>BRO TV</title>
            <style>
                body { background:#0A0E14; color:#fff; font-family:sans-serif; padding:24px; margin:0; }
                h2 { color:#E5B93A; }
                input { width:100%; box-sizing:border-box; padding:12px; margin:8px 0; border-radius:8px;
                        border:1px solid #2A2F36; background:#1A2029; color:#fff; font-size:16px; }
                button { width:100%; padding:14px; margin-top:12px; border:none; border-radius:8px;
                         background:#E5B93A; color:#111; font-size:16px; font-weight:bold; }
                .msg { text-align:center; margin-top:20px; }
            </style>
        </head>
        <body>
            <h2>BRO TV</h2>
            $bodyHtml
        </body>
        </html>
    """.trimIndent()

    private fun loginFormHtml(): String {
        val m3uLabel = htmlEscape(t("رابط M3U", "M3U Link"))
        val playlistName = htmlEscape(t("اسم القائمة", "Playlist name"))
        val username = htmlEscape(t("اسم المستخدم", "Username"))
        val password = htmlEscape(t("كلمة السر", "Password"))
        val host = htmlEscape(t("Host (مثال: http://example.com:8080)", "Host (example: http://example.com:8080)"))
        val m3uHint = htmlEscape(t("رابط قائمة M3U/M3U8", "M3U/M3U8 playlist URL"))
        val send = htmlEscape(t("إرسال للتلفزيون", "Send to TV"))
        val sent = t("تم الإرسال، سجّل الدخول تلقائياً بالتلفزيون", "Sent. The TV will sign in automatically.")
        return """
        <div style="display:flex; gap:10px; margin-bottom:16px;">
            <button type="button" id="tabX" style="flex:1; background:#E5B93A; color:#111;">Xtream Codes</button>
            <button type="button" id="tabM" style="flex:1; background:#1A2029; color:#fff; border:1px solid #2A2F36;">$m3uLabel</button>
        </div>
        <form id="f">
            <input name="playlistName" placeholder="$playlistName" required>
            <div id="xtreamBox">
                <input name="username" placeholder="$username">
                <input name="password" placeholder="$password" type="password">
                <input name="host" placeholder="$host">
            </div>
            <div id="m3uBox" style="display:none;">
                <input name="m3uUrl" placeholder="$m3uHint">
            </div>
            <button type="submit">$send</button>
        </form>
        <p class="msg" id="msg"></p>
        <script>
        var currentType = 'xtream';
        document.getElementById('tabX').onclick = function() {
            currentType = 'xtream';
            document.getElementById('xtreamBox').style.display = 'block';
            document.getElementById('m3uBox').style.display = 'none';
            this.style.background = '#E5B93A'; this.style.color = '#111';
            document.getElementById('tabM').style.background = '#1A2029'; document.getElementById('tabM').style.color = '#fff';
        };
        document.getElementById('tabM').onclick = function() {
            currentType = 'm3u';
            document.getElementById('xtreamBox').style.display = 'none';
            document.getElementById('m3uBox').style.display = 'block';
            this.style.background = '#E5B93A'; this.style.color = '#111';
            document.getElementById('tabX').style.background = '#1A2029'; document.getElementById('tabX').style.color = '#fff';
        };
        document.getElementById('f').onsubmit = async function(e) {
            e.preventDefault();
            const data = {
                token: "$currentToken",
                type: currentType,
                playlistName: this.playlistName.value,
                username: this.username.value,
                password: this.password.value,
                host: this.host.value,
                m3uUrl: this.m3uUrl.value
            };
            const res = await fetch('/pair?token=$currentToken', { method: 'POST', body: JSON.stringify(data) });
            const json = await res.json();
            document.getElementById('msg').innerText = json.ok ? ${JSONObject.quote(sent)} : json.message;
        };
        </script>
        """.trimIndent()
    }

    private fun searchFormHtml(): String {
        val hint = htmlEscape(t("اكتب قناة أو فيلم أو مسلسل أو كود قناة...", "Type a channel, movie, series, or channel code..."))
        val live = htmlEscape(t("تظهر النتائج على التلفزيون أثناء الكتابة", "Results update on the TV while you type"))
        val submit = htmlEscape(t("بحث على التلفزيون", "Search on TV"))
        return """
        <form id="searchForm">
            <input id="q" placeholder="$hint" autofocus autocomplete="off">
            <button type="submit">$submit</button>
        </form>
        <p class="msg">$live</p>
        <script>
        const q = document.getElementById('q');
        let timer = null;
        async function sendQuery(commit) {
            await fetch('/pair?token=$currentToken', {
                method: 'POST',
                body: JSON.stringify({ token: "$currentToken", query: q.value, submit: commit ? "true" : "false" })
            });
        }
        q.oninput = function() {
            clearTimeout(timer);
            timer = setTimeout(function(){ sendQuery(false); }, 250);
        };
        document.getElementById('searchForm').onsubmit = function(e) {
            e.preventDefault();
            clearTimeout(timer);
            sendQuery(true);
        };
        </script>
        """.trimIndent()
    }

    companion object {
        private const val MAX_REQUEST_BODY_BYTES = 64L * 1024L
    }

}
