package com.brotv.player.player

import android.content.Context
import android.util.Log
import com.brotv.player.dvr.HlsRecorderParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.util.concurrent.CopyOnWriteArrayList

/**
 * MVP للبَفر المحلي لإعادة اللف على المباشر (StreamVault parity: "rewind حتى 30 دقيقة
 * حتى بدون دعم المزود لـ catch-up"). هذا مكوّن خفيف ومستقل تماماً عن خدمة DVR الحقيقية
 * (DvrRecordingService/DvrStreamRecorder) — لا يستخدم Foreground Service، لا يلمس قاعدة
 * بيانات التسجيلات، ولا يدخل بحسابات ResourceGuard لمساحة التخزين. يعيد استخدام
 * HlsRecorderParser فقط (كائن Kotlin صرف بدون أي اعتماديات Android) لقراءة الـplaylist.
 *
 * القيود المتعمدة بهذا الـMVP (بالمقارنة بخدمة DVR الكاملة):
 * - يدعم فقط شرائح MPEG-TS العادية غير المشفّرة (AES-128/fMP4 غير مدعومة الآن؛ يتم
 *   تعطيل الميزة بهدوء لتلك القنوات بدل محاولة تسجيل ملف تالف).
 * - يعيش فقط طول مدة تشغيل الشاشة الحالية (Activity-scoped) وليس Service، فلو المستخدم
 *   طلع من المشغل ينتهي البَفر ويُحذف — مو تسجيل دائم.
 * - يُخزَّن في cacheDir (يُنظَّف تلقائياً من النظام عند ضغط التخزين، وهذا مناسب لبَفر
 *   مؤقت وليس تسجيل يحتاج ضمان بقاء).
 */
class LiveRollingBufferRecorder(
    private val context: Context,
    private val channelId: String
) {
    data class BufferedSegment(
        val sequence: Long,
        val file: File,
        val durationSeconds: Double,
        val downloadedAtMs: Long
    )

    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)
    private var pollJob: Job? = null

    private val segments = CopyOnWriteArrayList<BufferedSegment>()
    private val seenSequences = HashSet<Long>()
    // معرّف القناة ممكن يجي من مصدر IPTV خارجي، فننظّفه قبل استخدامه كاسم مجلد حتى
    // لو احتوى محارف زي "/" أو "..".
    private val safeChannelId: String = sanitizeChannelId(channelId)
    private val bufferDir: File = File(context.cacheDir, "live_rewind/$safeChannelId").apply { mkdirs() }

    @Volatile var unsupported: Boolean = false
        private set

    @Volatile private var lastMediaPlaylistUrl: String? = null

    /** يبدأ الاستقطاب الخلفي لملف الـplaylist المباشر وتنزيل الشرائح الجديدة أولاً بأول. */
    fun start(liveUrl: String) {
        stop(deleteFiles = false)
        pollJob = scope.launch {
            runCatching { resolveMediaPlaylistUrl(liveUrl) }
                .getOrNull()
                ?.let { lastMediaPlaylistUrl = it }
                ?: run { lastMediaPlaylistUrl = liveUrl }

            while (true) {
                val playlistUrl = lastMediaPlaylistUrl ?: break
                val nextDelaySeconds = runCatching { pollOnce(playlistUrl) }
                    .onFailure { Log.w(TAG, "poll failed", it) }
                    .getOrDefault(DEFAULT_POLL_SECONDS)
                pruneOldSegments()
                delay(nextDelaySeconds.coerceIn(2, 10) * 1000L)
            }
        }
    }

    fun stop(deleteFiles: Boolean = true) {
        pollJob?.cancel()
        pollJob = null
        if (deleteFiles) {
            segments.forEach { runCatching { it.file.delete() } }
            segments.clear()
            seenSequences.clear()
            runCatching { bufferDir.deleteRecursively() }
        }
    }

    /** أقدم نقطة يقدر المستخدم يرجع لها بالبَفر المحلي حالياً (Elapsed ms منذ الآن). */
    fun maxRewindMs(): Long {
        val oldest = segments.firstOrNull() ?: return 0L
        return (System.currentTimeMillis() - oldest.downloadedAtMs).coerceAtLeast(0L)
    }

    /**
     * يبني ملف playlist محلي صالح من الشرائح المحفوظة حالياً، أو null لو ما فيه شرائح
     * كافية بعد (البَفر لسه يتكوّن) أو القناة مو مدعومة (مشفّرة).
     */
    suspend fun buildLocalPlaylistFile(): File? = withContext(Dispatchers.IO) {
        if (unsupported) return@withContext null
        val snapshot = segments.toList().sortedBy { it.sequence }
        if (snapshot.size < MIN_SEGMENTS_FOR_REWIND) return@withContext null

        val playlistFile = File(bufferDir, "rewind.m3u8")
        val existingEntries = snapshot
            .filter { it.file.exists() }
            .map { PlaylistEntry(it.sequence, it.durationSeconds, it.file.toURI().toString()) }
        val text = buildPlaylistText(existingEntries, snapshot.first().sequence)
        runCatching { playlistFile.writeText(text) }.getOrElse { return@withContext null }
        playlistFile
    }

    private suspend fun resolveMediaPlaylistUrl(liveUrl: String): String? = withContext(Dispatchers.IO) {
        val text = fetchText(liveUrl) ?: return@withContext null
        if (!HlsRecorderParser.isPlaylist(text)) return@withContext null
        val variant = HlsRecorderParser.selectBestVariant(text, liveUrl)
        // لو ما فيه Master variants، يعني liveUrl أصلاً media playlist مباشر.
        variant?.uri ?: liveUrl
    }

    private fun pollOnce(playlistUrl: String): Int {
        val text = fetchText(playlistUrl) ?: return DEFAULT_POLL_SECONDS
        val playlist = HlsRecorderParser.parseMedia(text, playlistUrl)
        if (playlist.isFmp4) {
            // fMP4 يحتاج EXT-X-MAP init segment لإعادة التشغيل بشكل صحيح؛ خارج نطاق الـMVP.
            unsupported = true
            return DEFAULT_POLL_SECONDS
        }
        for (seg in playlist.segments) {
            if (seg.key != null) {
                // شرائح مشفّرة (AES-128) — خارج نطاق الـMVP، نوقف الميزة بهدوء لهذي القناة.
                unsupported = true
                continue
            }
            if (!seenSequences.add(seg.sequence)) continue
            val bytes = runCatching { downloadBytes(seg.uri) }.getOrNull() ?: continue
            val file = File(bufferDir, "${seg.sequence}.ts")
            if (runCatching { file.writeBytes(bytes) }.isFailure) continue
            segments.add(
                BufferedSegment(
                    sequence = seg.sequence,
                    file = file,
                    durationSeconds = seg.durationSeconds,
                    downloadedAtMs = System.currentTimeMillis()
                )
            )
        }
        return playlist.targetDurationSeconds.takeIf { it > 0 } ?: DEFAULT_POLL_SECONDS
    }

    private fun pruneOldSegments() {
        val cutoff = System.currentTimeMillis() - ROLLING_WINDOW_MS
        var totalBytes = 0L
        val kept = ArrayList<BufferedSegment>(segments.size)
        // نحسب من الأحدث للأقدم عشان نطبّق حد الحجم الأقصى أيضاً (احتياط لبث عالي البتريت).
        for (seg in segments.sortedByDescending { it.sequence }) {
            val withinWindow = seg.downloadedAtMs >= cutoff
            val size = seg.file.length()
            val withinSizeCap = totalBytes + size <= MAX_TOTAL_BYTES
            if (withinWindow && withinSizeCap) {
                kept.add(seg)
                totalBytes += size
            } else {
                runCatching { seg.file.delete() }
                seenSequences.remove(seg.sequence)
            }
        }
        segments.clear()
        segments.addAll(kept.sortedBy { it.sequence })
    }

    private fun fetchText(url: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            connection = URI.create(url).toURL().openConnection() as HttpURLConnection
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            if (connection.responseCode !in 200..299) return null
            connection.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun downloadBytes(url: String): ByteArray? {
        var connection: HttpURLConnection? = null
        return try {
            connection = URI.create(url).toURL().openConnection() as HttpURLConnection
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            if (connection.responseCode !in 200..299) return null
            connection.inputStream.use { it.readBytes() }
        } catch (e: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    /** شريحة جاهزة لبناء نص الـplaylist — بدون أي اعتمادية على File/Android (قابلة للاختبار). */
    data class PlaylistEntry(val sequence: Long, val durationSeconds: Double, val uri: String)

    companion object {
        private const val TAG = "LiveRollingBuffer"
        private const val ROLLING_WINDOW_MS = 30 * 60 * 1000L // 30 دقيقة، يطابق StreamVault
        private const val MAX_TOTAL_BYTES = 700L * 1024 * 1024 // سقف حماية 700MB بغض النظر عن الوقت
        private const val MIN_SEGMENTS_FOR_REWIND = 3
        private const val DEFAULT_POLL_SECONDS = 4
        private const val CONNECT_TIMEOUT_MS = 8_000
        private const val READ_TIMEOUT_MS = 8_000

        /**
         * ينظّف معرّف قناة قادم من مصدر IPTV خارجي حتى يكون آمن كاسم مجلد/ملف: يستبدل أي
         * محرف غير حرف/رقم/شرطة بشرطة سفلية، يقصّه لطول معقول، ويرجّع اسم احتياطي لو صار فاضي.
         * دالة صرفة (بدون Android) لتسهيل الاختبار.
         */
        internal fun sanitizeChannelId(rawId: String): String =
            rawId.trim().replace(Regex("[^A-Za-z0-9_-]"), "_").take(120).ifBlank { "channel" }

        /**
         * يبني نص playlist محلي صالح (M3U8) من قائمة شرائح مُرتّبة مسبقاً حسب sequence.
         * دالة صرفة (بدون File/Android) لتسهيل الاختبار؛ تستخدم Locale.US إجبارياً لتنسيق
         * EXTINF حتى لا ينكسر التنسيق على أجهزة بلغة تستخدم فاصلة عشرية غير النقطة.
         */
        internal fun buildPlaylistText(entries: List<PlaylistEntry>, mediaSequenceStart: Long): String {
            val targetDuration = entries.maxOfOrNull { it.durationSeconds }
                ?.let { if (it < 1.0) 4 else it.toInt() + 1 } ?: 4
            val builder = StringBuilder()
            builder.appendLine("#EXTM3U")
            builder.appendLine("#EXT-X-VERSION:3")
            builder.appendLine("#EXT-X-TARGETDURATION:$targetDuration")
            builder.appendLine("#EXT-X-MEDIA-SEQUENCE:$mediaSequenceStart")
            entries.forEach { entry ->
                val duration = String.format(java.util.Locale.US, "%.3f", entry.durationSeconds)
                builder.appendLine("#EXTINF:$duration,")
                builder.appendLine(entry.uri)
            }
            builder.appendLine("#EXT-X-ENDLIST")
            return builder.toString()
        }
    }
}
