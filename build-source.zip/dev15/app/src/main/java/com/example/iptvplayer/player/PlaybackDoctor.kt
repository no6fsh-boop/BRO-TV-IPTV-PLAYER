package com.example.iptvplayer.player

/**
 * BRO Doctor: deterministic playback failure diagnosis used to choose recovery and user messaging.
 * Pure Kotlin on purpose: cheap, testable and safe to run on every failure without cloud/AI calls.
 */
object PlaybackDoctor {
    enum class Cause { AUTH, NOT_FOUND, RATE_LIMIT, SERVER, NETWORK, DECODER, FORMAT, UNKNOWN }
    enum class Remedy { SWITCH_SOURCE, RETRY_BACKOFF, RETRY_NETWORK, RECREATE_PLAYER, REQUIRE_MANUAL }

    data class Diagnosis(val cause: Cause, val remedy: Remedy, val retryable: Boolean)

    /** Short user-facing status. Kept local so playback diagnosis never needs a cloud call. */
    fun messageKey(diagnosis: Diagnosis): String = when (diagnosis.cause) {
        Cause.AUTH -> "auth"
        Cause.NOT_FOUND -> "not_found"
        Cause.RATE_LIMIT -> "rate_limit"
        Cause.SERVER -> "server"
        Cause.NETWORK -> "network"
        Cause.DECODER -> "decoder"
        Cause.FORMAT -> "format"
        Cause.UNKNOWN -> "unknown"
    }

    fun diagnose(httpCode: Int?, mediaErrorCode: Int, decodingFailedCode: Int,
                 unsupportedFormatCode: Int, malformedContainerCode: Int,
                 networkErrorCodes: Set<Int> = emptySet()): Diagnosis {
        if (httpCode == 401 || httpCode == 403) return Diagnosis(Cause.AUTH, Remedy.SWITCH_SOURCE, false)
        if (httpCode == 404 || httpCode == 410) return Diagnosis(Cause.NOT_FOUND, Remedy.SWITCH_SOURCE, false)
        if (httpCode == 429) return Diagnosis(Cause.RATE_LIMIT, Remedy.RETRY_BACKOFF, true)
        if (httpCode != null && httpCode >= 500) return Diagnosis(Cause.SERVER, Remedy.RETRY_BACKOFF, true)
        if (mediaErrorCode == decodingFailedCode) return Diagnosis(Cause.DECODER, Remedy.RECREATE_PLAYER, true)
        if (mediaErrorCode == unsupportedFormatCode || mediaErrorCode == malformedContainerCode) {
            return Diagnosis(Cause.FORMAT, Remedy.SWITCH_SOURCE, false)
        }
        if (mediaErrorCode in networkErrorCodes) return Diagnosis(Cause.NETWORK, Remedy.RETRY_NETWORK, true)
        return Diagnosis(Cause.UNKNOWN, Remedy.RETRY_BACKOFF, true)
    }
}
