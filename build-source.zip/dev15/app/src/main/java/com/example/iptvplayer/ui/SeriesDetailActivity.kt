package com.brotv.player.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.brotv.player.R
import com.brotv.player.data.ContinueWatchingManager
import com.brotv.player.data.PrefsManager
import com.brotv.player.data.SeriesRepository
import com.brotv.player.model.ContinueWatchingType
import com.brotv.player.model.Episode
import com.brotv.player.model.Series
import kotlinx.coroutines.launch

class SeriesDetailActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private var episodesBySeason: Map<Int, List<Episode>> = emptyMap()
    private var currentSeason = 1
    private var sortNewestFirst = true
    private lateinit var series: Series
    private lateinit var episodeAdapter: EpisodeAdapter
    private var lastFocusedEpisodeId: String? = null
    private var restoreEpisodeFocusOnResume = false
    private var pendingEpisodeFocusRestore = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series_detail)
        prefs = PrefsManager(this)
        series = getSeriesExtra() ?: return finish()
        savedInstanceState?.let { state ->
            currentSeason = state.getInt(STATE_SEASON, currentSeason)
            sortNewestFirst = state.getBoolean(STATE_SORT_NEWEST, sortNewestFirst)
            lastFocusedEpisodeId = state.getString(STATE_FOCUSED_EPISODE_ID)
        }

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.txtSeriesTitle).text = series.name
        findViewById<TextView>(R.id.txtSeriesMeta).text = listOfNotNull(
            series.rating.takeIf { it.isNotBlank() }?.let { "IMDb $it" },
            series.year.takeIf { it.isNotBlank() },
            series.genre.takeIf { it.isNotBlank() },
            series.providerCategoryName.takeIf { it.isNotBlank() }
        ).joinToString("   |   ")
        findViewById<TextView>(R.id.txtSeriesPlot).text = series.plot

        val posterView = findViewById<ImageView>(R.id.imgSeriesPoster)
        val backdropView = findViewById<ImageView>(R.id.imgSeriesBackdrop)
        if (!series.posterUrl.isNullOrBlank()) {
            posterView.load(series.posterUrl) {
                crossfade(false)
                listener(
                    onSuccess = { _, _ ->
                        posterView.alpha = 1f
                        posterView.setPadding(0, 0, 0, 0)
                        posterView.scaleType = ImageView.ScaleType.CENTER_CROP
                    },
                    onError = { _, _ -> applySeriesArtworkFallback(posterView, backdropView) }
                )
            }
            backdropView.load(series.posterUrl) {
                crossfade(false)
                error(R.drawable.media_hero_fallback)
            }
        } else {
            applySeriesArtworkFallback(posterView, backdropView)
        }

        findViewById<LinearLayout>(R.id.btnFavoriteSeries).setOnClickListener {
            prefs.toggleSeriesFavorite(series.id)
            updateFavoriteButtonState()
        }
        updateFavoriteButtonState()

        findViewById<LinearLayout>(R.id.btnSortEpisodes).setOnClickListener { showEpisodeSortDialog() }
        findViewById<TextView>(R.id.txtSortLabel).text = getString(if (sortNewestFirst) R.string.latest_label else R.string.oldest_label)
        findViewById<LinearLayout>(R.id.btnResumeSeries).setOnClickListener { resumeSeries() }

        findViewById<RecyclerView>(R.id.recyclerSeasons).apply {
            layoutManager = LinearLayoutManager(this@SeriesDetailActivity)
            setHasFixedSize(true)
            itemAnimator = null
        }
        episodeAdapter = EpisodeAdapter(
            onFocus = { episode -> lastFocusedEpisodeId = episode.id },
            onClick = { episode -> playEpisode(episode) }
        )
        findViewById<RecyclerView>(R.id.recyclerEpisodes).apply {
            layoutManager = LinearLayoutManager(this@SeriesDetailActivity)
            setHasFixedSize(true)
            itemAnimator = null
            // Keep only a small amount of off-screen episode UI alive. Large seasons can
            // otherwise retain artwork/row state and cause visible GC pauses on low-RAM TVs.
            setItemViewCacheSize(4)
            adapter = episodeAdapter
        }
        loadEpisodes()
    }

    override fun onResume() {
        super.onResume()
        pendingEpisodeFocusRestore = restoreEpisodeFocusOnResume
        if (episodesBySeason.isNotEmpty()) showEpisodesForCurrentSeason()
        updateResumeButton()
    }

    override fun onPause() {
        val recycler = findViewById<RecyclerView>(R.id.recyclerEpisodes)
        restoreEpisodeFocusOnResume = currentFocus?.let { recycler.findContainingItemView(it) != null } == true
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(STATE_SEASON, currentSeason)
        outState.putBoolean(STATE_SORT_NEWEST, sortNewestFirst)
        outState.putString(STATE_FOCUSED_EPISODE_ID, lastFocusedEpisodeId)
        super.onSaveInstanceState(outState)
    }


    private val Int.dp: Int
        get() = (this * resources.displayMetrics.density).toInt()

    private fun applySeriesArtworkFallback(posterView: ImageView, backdropView: ImageView) {
        posterView.alpha = 0.42f
        posterView.setImageResource(R.drawable.ic_series)
        posterView.setPadding(72.dp, 72.dp, 72.dp, 72.dp)
        posterView.scaleType = ImageView.ScaleType.CENTER_INSIDE
        backdropView.setImageResource(R.drawable.media_hero_fallback)
    }

    private fun updateFavoriteButtonState() {
        findViewById<LinearLayout>(R.id.btnFavoriteSeries).isSelected = series.id in prefs.favoriteSeriesIds
    }

    private fun getSeriesExtra(): Series? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        intent.getParcelableExtra(EXTRA_SERIES, Series::class.java)
    } else {
        @Suppress("DEPRECATION")
        intent.getParcelableExtra(EXTRA_SERIES)
    }

    private fun loadEpisodes() {
        findViewById<ProgressBar>(R.id.progressBar).visibility = View.VISIBLE
        lifecycleScope.launch {
            // Provider failures must never leave the details screen spinning forever or crash
            // the TV UI. Xtream servers commonly time out or return malformed JSON temporarily.
            episodesBySeason = runCatching {
                SeriesRepository(this@SeriesDetailActivity).getEpisodes(series.id)
            }.getOrElse { emptyMap() }
            findViewById<ProgressBar>(R.id.progressBar).visibility = View.GONE
            if (episodesBySeason.isEmpty()) {
                findViewById<TextView>(R.id.txtEpisodesCount).text = getString(R.string.episodes_none)
                return@launch
            }

            if (currentSeason !in episodesBySeason.keys) {
                currentSeason = episodesBySeason.keys.minOrNull() ?: 1
            }
            val seasons = episodesBySeason.entries.sortedBy { it.key }.map { it.key to it.value.size }
            findViewById<RecyclerView>(R.id.recyclerSeasons).adapter = SeasonAdapter(
                seasons = seasons,
                initialSelectedSeason = currentSeason
            ) { season ->
                currentSeason = season
                lastFocusedEpisodeId = null
                showEpisodesForCurrentSeason()
            }
            showEpisodesForCurrentSeason()
            updateResumeButton()
        }
    }

    private fun showEpisodesForCurrentSeason() {
        val episodes = episodesBySeason[currentSeason].orEmpty()
        val ordered = if (sortNewestFirst) episodes.sortedByDescending { it.episodeNumber }
        else episodes.sortedBy { it.episodeNumber }
        findViewById<TextView>(R.id.txtEpisodesCount).text = getString(R.string.episodes_count, ordered.size)
        episodeAdapter.submitEpisodes(ordered, prefs.watchedEpisodeIds) {
            if (pendingEpisodeFocusRestore) {
                pendingEpisodeFocusRestore = false
                restoreEpisodeFocus(ordered)
            }
        }
    }

    private fun restoreEpisodeFocus(episodes: List<Episode>) {
        val id = lastFocusedEpisodeId ?: return
        val index = episodes.indexOfFirst { it.id == id }
        if (index < 0) return
        val recycler = findViewById<RecyclerView>(R.id.recyclerEpisodes)
        recycler.scrollToPosition(index)
        recycler.post {
            recycler.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus()
                ?: recycler.requestFocus()
        }
    }

    private fun showEpisodeSortDialog() {
        val labels = arrayOf(getString(R.string.latest_label), getString(R.string.oldest_label))
        val current = if (sortNewestFirst) 0 else 1
        AlertDialog.Builder(this, R.style.BroTvDialog)
            .setTitle(R.string.sort_episodes)
            .setSingleChoiceItems(labels, current) { dialog, which ->
                sortNewestFirst = which == 0
                findViewById<TextView>(R.id.txtSortLabel).text = labels[which]
                lastFocusedEpisodeId = null
                showEpisodesForCurrentSeason()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
            .enableTvListFocus(current)
    }

    private fun updateResumeButton() {
        val item = ContinueWatchingManager(this).getAll().firstOrNull {
            it.type == ContinueWatchingType.EPISODE && it.seriesId == series.id
        }
        findViewById<LinearLayout>(R.id.btnResumeSeries).visibility = if (item != null) View.VISIBLE else View.GONE
    }

    private fun resumeSeries() {
        val item = ContinueWatchingManager(this).getAll().firstOrNull {
            it.type == ContinueWatchingType.EPISODE && it.seriesId == series.id
        } ?: run {
            episodesBySeason.toSortedMap().values.flatten().firstOrNull()?.let(::playEpisode)
            return
        }
        startActivity(Intent(this, VodPlayerActivity::class.java).apply {
            putExtra(VodPlayerActivity.EXTRA_CONTENT_ID, item.contentId)
            putExtra(VodPlayerActivity.EXTRA_TITLE, item.title)
            putExtra(VodPlayerActivity.EXTRA_SUBTITLE, item.subtitle)
            putExtra(VodPlayerActivity.EXTRA_STREAM_URL, item.streamUrl)
            putExtra(VodPlayerActivity.EXTRA_POSTER_URL, item.posterUrl ?: series.posterUrl)
            putExtra(VodPlayerActivity.EXTRA_IS_MOVIE, false)
            putExtra(VodPlayerActivity.EXTRA_SERIES_ID, series.id)
            putExtra(VodPlayerActivity.EXTRA_PARENTAL_CATEGORY, series.providerCategoryName.ifBlank { series.genre })
            putExtra(VodPlayerActivity.EXTRA_PARENTAL_SCOPE, VodPlayerActivity.PARENTAL_SCOPE_SERIES)
        })
    }

    private fun playEpisode(episode: Episode) {
        startActivity(Intent(this, VodPlayerActivity::class.java).apply {
            putExtra(VodPlayerActivity.EXTRA_CONTENT_ID, episode.id)
            putExtra(VodPlayerActivity.EXTRA_TITLE, getString(R.string.episode_content_title, series.name, episode.episodeNumber))
            putExtra(VodPlayerActivity.EXTRA_SUBTITLE, getString(R.string.season_episode, episode.seasonNumber, episode.episodeNumber))
            putExtra(VodPlayerActivity.EXTRA_STREAM_URL, episode.streamUrl)
            putExtra(VodPlayerActivity.EXTRA_POSTER_URL, episode.imageUrl ?: series.posterUrl)
            putExtra(VodPlayerActivity.EXTRA_IS_MOVIE, false)
            putExtra(VodPlayerActivity.EXTRA_SERIES_ID, series.id)
            putExtra(VodPlayerActivity.EXTRA_PARENTAL_CATEGORY, series.providerCategoryName.ifBlank { series.genre })
            putExtra(VodPlayerActivity.EXTRA_PARENTAL_SCOPE, VodPlayerActivity.PARENTAL_SCOPE_SERIES)
        })
    }

    companion object {
        const val EXTRA_SERIES = "extra_series"
        private const val STATE_SEASON = "series_detail_season"
        private const val STATE_SORT_NEWEST = "series_detail_sort_newest"
        private const val STATE_FOCUSED_EPISODE_ID = "series_detail_focused_episode"
    }
}
