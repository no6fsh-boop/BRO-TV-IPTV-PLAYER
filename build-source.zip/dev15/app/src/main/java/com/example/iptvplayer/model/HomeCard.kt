package com.brotv.player.model

data class HomeCard(
    val title: String,
    val backgroundRes: Int,
    val action: () -> Unit
)
