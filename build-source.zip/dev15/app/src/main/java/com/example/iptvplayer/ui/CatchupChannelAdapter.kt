package com.brotv.player.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.brotv.player.R
import com.brotv.player.model.MergedChannel

class CatchupChannelAdapter(
    private val channels: List<MergedChannel>,
    private val onClick: (MergedChannel) -> Unit
) : RecyclerView.Adapter<CatchupChannelAdapter.ViewHolder>() {

    private var selectedPosition = -1

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.txtResultTitle)
        val subtitle: TextView = view.findViewById(R.id.txtResultSubtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_search_result, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val channel = channels[position]
        holder.title.text = channel.name
        holder.subtitle.text = holder.itemView.context.getString(R.string.archive_days, channel.archiveDurationDays)
        holder.itemView.isSelected = position == selectedPosition
        holder.itemView.setOnClickListener {
            val previous = selectedPosition
            selectedPosition = holder.bindingAdapterPosition
            notifyItemChanged(previous)
            notifyItemChanged(selectedPosition)
            onClick(channel)
        }
    }

    override fun getItemCount(): Int = channels.size
}
