package com.brotv.player.model

import android.os.Parcel
import android.os.Parcelable

data class Series(
    val id: String,
    val name: String,
    val posterUrl: String?,
    val year: String,
    val rating: String,
    val genre: String,
    val plot: String,
    val seasonCount: Int,
    val providerCategoryKey: String = "",
    val providerCategoryName: String = "",
    val providerCategoryOrder: Int = Int.MAX_VALUE
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString(),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(name)
        parcel.writeString(posterUrl)
        parcel.writeString(year)
        parcel.writeString(rating)
        parcel.writeString(genre)
        parcel.writeString(plot)
        parcel.writeInt(seasonCount)
        parcel.writeString(providerCategoryKey)
        parcel.writeString(providerCategoryName)
        parcel.writeInt(providerCategoryOrder)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Series> {
        override fun createFromParcel(parcel: Parcel): Series = Series(parcel)
        override fun newArray(size: Int): Array<Series?> = arrayOfNulls(size)
    }
}
