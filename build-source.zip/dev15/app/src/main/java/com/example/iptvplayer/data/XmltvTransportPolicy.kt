package com.brotv.player.data

/** Pure transport decisions for XMLTV downloads, kept testable outside Android networking. */
object XmltvTransportPolicy {
    fun isGzip(contentEncoding: String?, url: String): Boolean {
        val encoded = contentEncoding.orEmpty()
            .split(',')
            .any { it.trim().equals("gzip", ignoreCase = true) }
        if (encoded) return true
        val path = url.substringBefore('?').substringBefore('#').lowercase()
        return path.endsWith(".gz")
    }
}
