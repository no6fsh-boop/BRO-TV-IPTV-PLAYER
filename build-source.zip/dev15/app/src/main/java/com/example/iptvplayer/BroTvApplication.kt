package com.brotv.player

import android.app.Application
import com.brotv.player.data.CrashLogger

/**
 * أول Application class حقيقية للمشروع — كانت غير موجودة سابقاً (لا android:name
 * بالـManifest)، فمعالج التعطلات الافتراضي لنظام Android هو الوحيد اللي كان يشتغل
 * بدون أي أثر محلي قابل للمراجعة.
 */
class BroTvApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
    }
}
