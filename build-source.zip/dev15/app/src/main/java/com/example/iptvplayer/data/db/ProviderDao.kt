package com.brotv.player.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProviderDao {

    @Query("SELECT * FROM providers ORDER BY sortOrder ASC, createdAt ASC")
    fun observeAll(): Flow<List<ProviderEntity>>

    @Query("SELECT * FROM providers ORDER BY sortOrder ASC, createdAt ASC")
    suspend fun getAll(): List<ProviderEntity>

    @Query("SELECT * FROM providers WHERE enabled = 1 ORDER BY sortOrder ASC, createdAt ASC")
    suspend fun getEnabled(): List<ProviderEntity>

    @Query("SELECT * FROM providers WHERE enabled = 1 AND type = :type ORDER BY sortOrder ASC")
    suspend fun getEnabledByType(type: ProviderType): List<ProviderEntity>

    @Query("SELECT * FROM providers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProviderEntity?

    @Query("SELECT * FROM providers WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefault(): ProviderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(provider: ProviderEntity)

    @Update
    suspend fun update(provider: ProviderEntity)

    @Delete
    suspend fun delete(provider: ProviderEntity)

    @Query("DELETE FROM providers WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM providers")
    suspend fun deleteAll()

    @Query("UPDATE providers SET enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean)

    @Query("UPDATE providers SET name = :name WHERE id = :id")
    suspend fun rename(id: String, name: String)

    @Query("UPDATE providers SET sortOrder = :order WHERE id = :id")
    suspend fun setSortOrder(id: String, order: Int)

    @Query("UPDATE providers SET isDefault = 0")
    suspend fun clearDefault()

    @Query("UPDATE providers SET isDefault = 1 WHERE id = :id")
    suspend fun setDefault(id: String)

    @Query("UPDATE providers SET status = :status, lastCheckedAt = :checkedAt WHERE id = :id")
    suspend fun updateStatus(id: String, status: ProviderStatus, checkedAt: Long)

    @Query("UPDATE providers SET lastSyncAt = :syncedAt WHERE id = :id")
    suspend fun updateLastSync(id: String, syncedAt: Long)

    @Query("SELECT COUNT(*) FROM providers")
    suspend fun count(): Int
}
