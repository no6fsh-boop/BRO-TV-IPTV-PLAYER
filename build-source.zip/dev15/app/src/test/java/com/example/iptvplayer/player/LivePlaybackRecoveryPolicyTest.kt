package com.brotv.player.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LivePlaybackRecoveryPolicyTest {
    @Test
    fun `five seconds after first video frame never triggers black screen recovery`() {
        assertFalse(
            LivePlaybackRecoveryPolicy.shouldRecoverMissingFirstFrame(
                hasExpectedVideoTrack = true,
                hasReceivedFirstVideoFrame = true,
                playbackAgeMs = 60_000L,
                audioStarted = true,
                positionMoving = true
            )
        )
    }

    @Test
    fun `startup recovery waits for fifteen seconds and evidence playback is progressing`() {
        assertFalse(
            LivePlaybackRecoveryPolicy.shouldRecoverMissingFirstFrame(
                true, false, 5_000L, true, true
            )
        )
        assertFalse(
            LivePlaybackRecoveryPolicy.shouldRecoverMissingFirstFrame(
                true, false, 15_000L, false, false
            )
        )
        assertTrue(
            LivePlaybackRecoveryPolicy.shouldRecoverMissingFirstFrame(
                true, false, 15_000L, true, false
            )
        )
    }

    @Test
    fun `freeze recovery is deliberately conservative`() {
        assertFalse(LivePlaybackRecoveryPolicy.shouldRecoverFreeze(true, true, 5_000L))
        assertFalse(LivePlaybackRecoveryPolicy.shouldRecoverFreeze(false, true, 20_000L))
        assertTrue(LivePlaybackRecoveryPolicy.shouldRecoverFreeze(true, true, 15_000L))
    }
}
