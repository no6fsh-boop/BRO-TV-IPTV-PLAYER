package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Test

class ConnectionQualityCheckerTest {
    @Test
    fun safeProbeUrl_extractsAndReencodesXtreamCredentials() {
        val stream = "https://iptv.example:8443/live/user%20name/p%2Ba%26ss/123.m3u8"

        assertEquals(
            "https://iptv.example:8443/player_api.php?username=user%20name&password=p%2Ba%26ss",
            ConnectionQualityChecker.safeProbeUrl(stream)
        )
    }

    @Test
    fun safeProbeUrl_handlesTimeshiftQueryCredentials() {
        val stream = "http://host:8080/streaming/timeshift.php?username=u%2Fser&password=p%20ass&stream=55"

        assertEquals(
            "http://host:8080/player_api.php?username=u%2Fser&password=p%20ass",
            ConnectionQualityChecker.safeProbeUrl(stream)
        )
    }
}
