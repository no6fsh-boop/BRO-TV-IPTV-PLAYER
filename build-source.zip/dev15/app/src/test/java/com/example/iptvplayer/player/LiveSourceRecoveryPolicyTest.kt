package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Test

class LiveSourceRecoveryPolicyTest {
    @Test
    fun `transient live error retries current source once before giving up`() {
        assertEquals(
            LiveSourceRecoveryPolicy.Action.RETRY_CURRENT_SOURCE,
            LiveSourceRecoveryPolicy.actionFor(
                retryAttempts = 0,
                permanentFailure = false,
                alternativeAvailable = true,
                automaticAlternativeAlreadyUsed = false
            )
        )
    }

    @Test
    fun `after retry budget live playback requires manual source even when alternative exists`() {
        assertEquals(
            LiveSourceRecoveryPolicy.Action.REQUIRE_MANUAL_SOURCE,
            LiveSourceRecoveryPolicy.actionFor(
                retryAttempts = 1,
                permanentFailure = false,
                alternativeAvailable = true,
                automaticAlternativeAlreadyUsed = false
            )
        )
        assertEquals(
            LiveSourceRecoveryPolicy.Action.REQUIRE_MANUAL_SOURCE,
            LiveSourceRecoveryPolicy.actionFor(
                retryAttempts = 1,
                permanentFailure = false,
                alternativeAvailable = true,
                automaticAlternativeAlreadyUsed = true
            )
        )
    }

    @Test
    fun `permanent error skips useless retry and requires manual source`() {
        assertEquals(
            LiveSourceRecoveryPolicy.Action.REQUIRE_MANUAL_SOURCE,
            LiveSourceRecoveryPolicy.actionFor(
                retryAttempts = 0,
                permanentFailure = true,
                alternativeAvailable = true,
                automaticAlternativeAlreadyUsed = false
            )
        )
    }

    @Test
    fun `no alternative requires manual source without cycling`() {
        assertEquals(
            LiveSourceRecoveryPolicy.Action.REQUIRE_MANUAL_SOURCE,
            LiveSourceRecoveryPolicy.actionFor(
                retryAttempts = 1,
                permanentFailure = false,
                alternativeAvailable = false,
                automaticAlternativeAlreadyUsed = false
            )
        )
    }

    @Test
    fun `automatic source switching is never returned regardless of inputs`() {
        val allActions = listOf(
            LiveSourceRecoveryPolicy.actionFor(0, false, true, false),
            LiveSourceRecoveryPolicy.actionFor(0, true, true, false),
            LiveSourceRecoveryPolicy.actionFor(1, false, true, true),
            LiveSourceRecoveryPolicy.actionFor(5, true, false, true)
        )
        assertEquals(
            emptyList<LiveSourceRecoveryPolicy.Action>(),
            allActions.filter { it == LiveSourceRecoveryPolicy.Action.TRY_ONE_ALTERNATIVE }
        )
    }
}
