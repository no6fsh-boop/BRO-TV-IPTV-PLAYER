package com.brotv.player.dvr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.nio.file.Files
import kotlin.concurrent.thread
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class DvrStreamRecorderTest {
    @Test
    fun `master byte ranges and checkpoint resume do not duplicate segments`() {
        MiniHttpServer().use { server ->
            val master = """
                #EXTM3U
                #EXT-X-STREAM-INF:BANDWIDTH=100
                low.m3u8
                #EXT-X-STREAM-INF:BANDWIDTH=900
                high.m3u8
            """.trimIndent().toByteArray()
            val high = """
                #EXTM3U
                #EXT-X-TARGETDURATION:1
                #EXT-X-MEDIA-SEQUENCE:50
                #EXTINF:1,
                #EXT-X-BYTERANGE:4@0
                media.bin
                #EXTINF:1,
                #EXT-X-BYTERANGE:4
                media.bin
                #EXT-X-ENDLIST
            """.trimIndent().toByteArray()
            server.routes["/master.m3u8"] = Response(master, "application/vnd.apple.mpegurl")
            server.routes["/low.m3u8"] = Response("#EXTM3U\n#EXT-X-ENDLIST\n".toByteArray(), "application/vnd.apple.mpegurl")
            server.routes["/high.m3u8"] = Response(high, "application/vnd.apple.mpegurl")
            server.routes["/media.bin"] = Response("AAAABBBBCCCC".toByteArray())
            server.start()

            val temp = Files.createTempDirectory("brotv-dvr-test").toFile()
            try {
                val output = temp.resolve("recording.ts")
                val url = server.url("/master.m3u8")
                val first = DvrStreamRecorder().record(url, output, 0L, { false }) { _, _ -> }
                assertTrue(first.endedNaturally)
                assertEquals("AAAABBBB", output.readText())
                val firstSize = output.length()

                val second = DvrStreamRecorder().record(url, output, 0L, { false }) { _, _ -> }
                assertTrue(second.endedNaturally)
                assertEquals(firstSize, output.length())
                assertEquals("AAAABBBB", output.readText())

                DvrStreamRecorder.cleanupCheckpoint(output)
                assertTrue(!temp.resolve("recording.ts.brotv.idx").exists())
            } finally {
                temp.deleteRecursively()
            }
        }
    }


    @Test
    fun `byte range recording stays correct when origin ignores Range header`() {
        MiniHttpServer().use { server ->
            val playlist = """
                #EXTM3U
                #EXT-X-TARGETDURATION:1
                #EXT-X-MEDIA-SEQUENCE:10
                #EXTINF:1,
                #EXT-X-BYTERANGE:4@4
                media.bin
                #EXTINF:1,
                #EXT-X-BYTERANGE:4
                media.bin
                #EXT-X-ENDLIST
            """.trimIndent().toByteArray()
            server.routes["/range.m3u8"] = Response(playlist, "application/vnd.apple.mpegurl")
            server.routes["/media.bin"] = Response("AAAABBBBCCCCDDDD".toByteArray(), ignoreRange = true)
            server.start()

            val temp = Files.createTempDirectory("brotv-dvr-range-ignore").toFile()
            try {
                val output = temp.resolve("recording.ts")
                val result = DvrStreamRecorder().record(server.url("/range.m3u8"), output, 0L, { false }) { _, _ -> }
                assertTrue(result.endedNaturally)
                assertEquals("BBBBCCCC", output.readText())
            } finally {
                temp.deleteRecursively()
            }
        }
    }

    @Test
    fun `aes128 hls segment is decrypted before writing`() {
        MiniHttpServer().use { server ->
            val key = "0123456789ABCDEF".toByteArray(Charsets.US_ASCII)
            val clear = "AES_RECORDING_OK".toByteArray(Charsets.UTF_8)
            val encrypted = encryptAes(clear, key, sequence = 1L)
            val playlist = """
                #EXTM3U
                #EXT-X-TARGETDURATION:1
                #EXT-X-MEDIA-SEQUENCE:1
                #EXT-X-KEY:METHOD=AES-128,URI="key.bin"
                #EXTINF:1,
                encrypted.ts
                #EXT-X-ENDLIST
            """.trimIndent().toByteArray()
            server.routes["/secure.m3u8"] = Response(playlist, "application/vnd.apple.mpegurl")
            server.routes["/key.bin"] = Response(key)
            server.routes["/encrypted.ts"] = Response(encrypted, "video/mp2t")
            server.start()

            val temp = Files.createTempDirectory("brotv-dvr-aes").toFile()
            try {
                val output = temp.resolve("recording.ts")
                val result = DvrStreamRecorder().record(server.url("/secure.m3u8"), output, 0L, { false }) { _, _ -> }
                assertTrue(result.endedNaturally)
                assertEquals("AES_RECORDING_OK", output.readText())
            } finally {
                temp.deleteRecursively()
            }
        }
    }

    @Test
    fun `playlist signature is detected even when url and content type do not say hls`() {
        MiniHttpServer().use { server ->
            val playlist = """
                #EXTM3U
                #EXT-X-TARGETDURATION:1
                #EXT-X-MEDIA-SEQUENCE:1
                #EXTINF:1,
                segment.ts
                #EXT-X-ENDLIST
            """.trimIndent().toByteArray()
            server.routes["/live"] = Response(playlist, "application/octet-stream")
            server.routes["/segment.ts"] = Response("SNIFF_OK".toByteArray(), "video/mp2t")
            server.start()

            val temp = Files.createTempDirectory("brotv-dvr-sniff").toFile()
            try {
                val output = temp.resolve("recording.ts")
                val result = DvrStreamRecorder().record(server.url("/live"), output, 0L, { false }) { _, _ -> }
                assertTrue(result.endedNaturally)
                assertEquals("SNIFF_OK", output.readText())
            } finally {
                temp.deleteRecursively()
            }
        }
    }

    @Test
    fun `checkpoint restores implicit byte range after live playlist window slides`() {
        MiniHttpServer().use { server ->
            val firstWindow = """
                #EXTM3U
                #EXT-X-TARGETDURATION:1
                #EXT-X-MEDIA-SEQUENCE:100
                #EXTINF:1,
                #EXT-X-BYTERANGE:4@0
                media.bin
                #EXTINF:1,
                #EXT-X-BYTERANGE:4
                media.bin
                #EXT-X-ENDLIST
            """.trimIndent().toByteArray()
            val secondWindow = """
                #EXTM3U
                #EXT-X-TARGETDURATION:1
                #EXT-X-MEDIA-SEQUENCE:102
                #EXTINF:1,
                #EXT-X-BYTERANGE:4
                media.bin
                #EXT-X-ENDLIST
            """.trimIndent().toByteArray()
            server.routes["/window.m3u8"] = Response(firstWindow, "application/vnd.apple.mpegurl")
            server.routes["/media.bin"] = Response("AAAABBBBCCCCDDDD".toByteArray())
            server.start()

            val temp = Files.createTempDirectory("brotv-dvr-sliding-range").toFile()
            try {
                val output = temp.resolve("recording.ts")
                val url = server.url("/window.m3u8")
                val first = DvrStreamRecorder().record(url, output, 0L, { false }) { _, _ -> }
                assertTrue(first.endedNaturally)
                assertEquals("AAAABBBB", output.readText())

                // Simulate a provider whose live window slid forward while the recorder process was down.
                // Sequence 102 keeps the provider's implicit BYTERANGE style even though sequence 101 is gone.
                server.routes["/window.m3u8"] = Response(secondWindow, "application/vnd.apple.mpegurl")
                val resumed = DvrStreamRecorder().record(url, output, 0L, { false }) { _, _ -> }

                assertTrue(resumed.endedNaturally)
                assertEquals("AAAABBBBCCCC", output.readText())
                val checkpoint = temp.resolve("recording.ts.brotv.idx").readText()
                assertTrue(checkpoint.lines().any { it.startsWith("R:101:") })
                assertTrue(checkpoint.lines().any { it.startsWith("R:102:") })
                assertTrue(!checkpoint.contains("media.bin"))
            } finally {
                temp.deleteRecursively()
            }
        }
    }

    private fun encryptAes(clear: ByteArray, key: ByteArray, sequence: Long): ByteArray {
        val iv = ByteArray(16)
        var value = sequence
        for (i in 15 downTo 8) {
            iv[i] = (value and 0xFF).toByte()
            value = value ushr 8
        }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return cipher.doFinal(clear)
    }

    private data class Response(
        val body: ByteArray,
        val contentType: String = "application/octet-stream",
        val ignoreRange: Boolean = false
    )

    private class MiniHttpServer : AutoCloseable {
        val routes = mutableMapOf<String, Response>()
        private val server = ServerSocket(0, 50, java.net.InetAddress.getByName("127.0.0.1"))
        private var worker: Thread? = null

        fun url(path: String): String = "http://127.0.0.1:${server.localPort}$path"

        fun start() {
            worker = thread(name = "brotv-test-http", isDaemon = true) {
                try {
                    while (!server.isClosed) handle(server.accept())
                } catch (_: SocketException) {
                    // Normal close.
                }
            }
        }

        private fun handle(socket: Socket) = socket.use { client ->
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.US_ASCII))
            val requestLine = reader.readLine().orEmpty()
            val path = requestLine.split(' ').getOrNull(1)?.substringBefore('?') ?: "/"
            var range: String? = null
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isBlank()) break
                if (line.startsWith("Range:", ignoreCase = true)) range = line.substringAfter(':').trim()
            }
            val route = routes[path]
            if (route == null) {
                writeResponse(client, 404, "text/plain", "not found".toByteArray(), null)
                return@use
            }
            val requested = if (route.ignoreRange) null else parseRange(range, route.body.size)
            if (requested == null) {
                writeResponse(client, 200, route.contentType, route.body, null)
            } else {
                val (start, end) = requested
                val body = route.body.copyOfRange(start, end + 1)
                writeResponse(client, 206, route.contentType, body, "bytes $start-$end/${route.body.size}")
            }
        }

        private fun parseRange(value: String?, size: Int): Pair<Int, Int>? {
            if (value.isNullOrBlank() || !value.startsWith("bytes=")) return null
            val parts = value.removePrefix("bytes=").split('-', limit = 2)
            val start = parts.getOrNull(0)?.toIntOrNull() ?: return null
            val end = parts.getOrNull(1)?.toIntOrNull()?.coerceAtMost(size - 1) ?: (size - 1)
            return start to end
        }

        private fun writeResponse(client: Socket, code: Int, contentType: String, body: ByteArray, contentRange: String?) {
            val reason = if (code == 206) "Partial Content" else if (code == 200) "OK" else "Not Found"
            val out = client.getOutputStream()
            val headers = buildString {
                append("HTTP/1.1 $code $reason\r\n")
                append("Content-Type: $contentType\r\n")
                append("Content-Length: ${body.size}\r\n")
                if (contentRange != null) append("Content-Range: $contentRange\r\n")
                append("Connection: close\r\n\r\n")
            }
            out.write(headers.toByteArray(Charsets.US_ASCII))
            out.write(body)
            out.flush()
        }

        override fun close() {
            runCatching { server.close() }
            worker?.join(1_000L)
        }
    }
}
