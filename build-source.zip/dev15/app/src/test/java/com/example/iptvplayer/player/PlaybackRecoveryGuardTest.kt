package com.brotv.player.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackRecoveryGuardTest {
    @Test
    fun cooldown_blocks_immediate_recovery() {
        val guard = PlaybackRecoveryGuard(cooldownMs = 2_000, windowMs = 60_000, maxRecoveriesInWindow = 4)
        assertTrue(guard.canRecover(10_000))
        guard.recordRecovery(10_000)
        assertFalse(guard.canRecover(11_000))
        assertTrue(guard.canRecover(12_001))
    }

    @Test
    fun window_limit_prevents_recovery_storm() {
        val guard = PlaybackRecoveryGuard(cooldownMs = 0, windowMs = 60_000, maxRecoveriesInWindow = 2)
        guard.recordRecovery(1_000)
        guard.recordRecovery(2_000)
        assertFalse(guard.canRecover(3_000))
        assertTrue(guard.canRecover(61_001))
    }

    @Test
    fun reset_starts_a_fresh_session() {
        val guard = PlaybackRecoveryGuard(cooldownMs = 10_000, windowMs = 60_000, maxRecoveriesInWindow = 1)
        guard.recordRecovery(1_000)
        assertFalse(guard.canRecover(2_000))
        guard.reset()
        assertTrue(guard.canRecover(2_000))
    }
}
