package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class XtreamUrlCodecTest {
    @Test
    fun playerApiUrl_encodesCredentialsAndActionConsistently() {
        val url = XtreamUrlCodec.playerApiUrl(
            server = " https://example.com:8080/ ",
            username = "user +@/",
            password = "p a&?#",
            action = "get_live_streams"
        )

        assertEquals(
            "https://example.com:8080/player_api.php?username=user%20%2B%40%2F&password=p%20a%26%3F%23&action=get_live_streams",
            url
        )
        assertFalse(url.contains("user +@/"))
        assertFalse(url.contains("p a&?#"))
    }

    @Test
    fun playerApiUrl_encodesExtraQueryKeysAndValues() {
        val url = XtreamUrlCodec.playerApiUrl(
            "http://host/",
            "u",
            "p",
            "get_short_epg",
            linkedMapOf("stream id" to "12/34", "limit" to "2")
        )

        assertTrue(url.endsWith("&stream%20id=12%2F34&limit=2"))
    }

    @Test
    fun cleanServer_removesWhitespaceAndTrailingSlash() {
        assertEquals("http://host:8080", XtreamUrlCodec.cleanServer("  http://host:8080///  "))
    }
}
