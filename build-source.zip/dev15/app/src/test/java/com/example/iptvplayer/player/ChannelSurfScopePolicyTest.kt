package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelSurfScopePolicyTest {
    @Test
    fun `explicit folder scope wins and fallback is current folder`() {
        assertEquals("Sports", ChannelSurfScopePolicy.resolve("Sports", "News"))
        assertEquals("News", ChannelSurfScopePolicy.resolve(null, "News"))
    }

    @Test
    fun `folder scope never accepts channels from another folder`() {
        assertTrue(ChannelSurfScopePolicy.accepts("Sports", "Sports", false))
        assertFalse(ChannelSurfScopePolicy.accepts("Sports", "News", true))
    }

    @Test
    fun `all and favorites scopes are explicit`() {
        assertTrue(ChannelSurfScopePolicy.accepts(ChannelSurfScopePolicy.ALL, "Anything", false))
        assertTrue(ChannelSurfScopePolicy.accepts(ChannelSurfScopePolicy.FAVORITES, "News", true))
        assertFalse(ChannelSurfScopePolicy.accepts(ChannelSurfScopePolicy.FAVORITES, "News", false))
    }
}
