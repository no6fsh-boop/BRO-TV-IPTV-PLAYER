package com.example.iptvplayer.player

import org.junit.Assert.*
import org.junit.Test

class PlaybackDoctorTest {
    private fun d(http: Int? = null, media: Int = 0) = PlaybackDoctor.diagnose(http, media, 10, 11, 12, setOf(20, 21))

    @Test fun authSwitchesWithoutRetry() { assertEquals(PlaybackDoctor.Cause.AUTH, d(403).cause); assertFalse(d(403).retryable) }
    @Test fun missingSwitchesWithoutRetry() { assertEquals(PlaybackDoctor.Remedy.SWITCH_SOURCE, d(404).remedy) }
    @Test fun rateLimitBacksOff() { assertEquals(PlaybackDoctor.Cause.RATE_LIMIT, d(429).cause); assertTrue(d(429).retryable) }
    @Test fun serverFailureBacksOff() { assertEquals(PlaybackDoctor.Cause.SERVER, d(503).cause) }
    @Test fun decoderRecreatesPlayer() { assertEquals(PlaybackDoctor.Remedy.RECREATE_PLAYER, d(media=10).remedy) }
    @Test fun badFormatSwitches() { assertEquals(PlaybackDoctor.Cause.FORMAT, d(media=11).cause) }
    @Test fun networkRetriesNetwork() { assertEquals(PlaybackDoctor.Cause.NETWORK, d(media=20).cause) }
    @Test fun diagnosisHasStableMessageKey() {
        assertEquals("decoder", PlaybackDoctor.messageKey(d(media=10)))
        assertEquals("network", PlaybackDoctor.messageKey(d(media=20)))
    }

}
