package com.brotv.player.data

import com.brotv.player.model.Channel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelMergerTest {
    private fun ch(name: String, url: String, epg: String? = null, group: String = "عام") =
        Channel(url, name, url, groupTitle = group, epgId = epg)

    @Test fun qualityAndRegionNoiseStillMerge() {
        val result = ChannelMerger.merge(listOf(ch("|AR| MBC 1 HD", "a"), ch("MBC 1 FHD KSA", "b")))
        assertEquals(1, result.size); assertEquals(2, result.single().sourceUrls.size)
    }

    @Test fun conflictingEpgIdsNeverMerge() {
        assertFalse(ChannelMerger.canMerge(ch("Sports 1 HD", "a", "sports1.sa"), ch("Sports 1", "b", "sports1.uk")))
    }

    @Test fun compatibleEpgIdsMerge() {
        assertTrue(ChannelMerger.canMerge(ch("News HD", "a", "NEWS.ONE"), ch("News", "b", "news.one")))
    }

    @Test fun clearlyDifferentGroupsStaySeparate() {
        val result = ChannelMerger.merge(listOf(ch("Channel 1 HD", "a", group="Kids"), ch("Channel 1", "b", group="Sports")))
        assertEquals(2, result.size)
    }
}
