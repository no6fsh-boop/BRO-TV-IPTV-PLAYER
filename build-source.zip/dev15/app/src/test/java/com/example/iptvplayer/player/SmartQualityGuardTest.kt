package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartQualityGuardTest {
    @Test
    fun `does not lower quality during startup warmup`() {
        val guard = SmartQualityGuard()
        val decision = guard.observe(
            nowMs = 5_000,
            playbackAgeMs = 5_000,
            baseMaxHeight = 2160,
            droppedFrames = 40,
            rebufferCount = 1,
            rebufferDurationMs = 2_000,
            estimatedBandwidth = 2_000_000,
            videoBitrate = 8_000_000,
            currentBufferMs = 200
        )
        assertFalse(decision.changed)
        assertEquals(SmartQualityGuard.Ceiling.USER_MAX, decision.ceiling)
    }

    @Test
    fun `rebuffer lowers 4k or source ceiling one step to 1080p`() {
        val guard = SmartQualityGuard()
        val decision = guard.observe(
            nowMs = 20_000,
            playbackAgeMs = 20_000,
            baseMaxHeight = 2160,
            droppedFrames = 0,
            rebufferCount = 1,
            rebufferDurationMs = 900,
            estimatedBandwidth = 20_000_000,
            videoBitrate = 8_000_000,
            currentBufferMs = 4_000
        )
        assertTrue(decision.changed)
        assertEquals(SmartQualityGuard.Ceiling.FHD_1080P, decision.ceiling)
    }

    @Test
    fun `cooldown prevents rapid repeated quality drops`() {
        val guard = SmartQualityGuard()
        guard.observe(20_000, 20_000, 2160, 0, 1, 900, 20_000_000, 8_000_000, 4_000)
        val second = guard.observe(25_000, 25_000, 2160, 40, 2, 2_500, 3_000_000, 8_000_000, 400)
        assertFalse(second.changed)
        assertEquals(SmartQualityGuard.Ceiling.FHD_1080P, second.ceiling)

        val afterCooldown = guard.observe(41_000, 41_000, 2160, 80, 3, 4_000, 3_000_000, 8_000_000, 400)
        assertTrue(afterCooldown.changed)
        assertEquals(SmartQualityGuard.Ceiling.HD_720P, afterCooldown.ceiling)
    }

    @Test
    fun `stable playback restores quality gradually`() {
        val guard = SmartQualityGuard(restoreStableMs = 60_000L)
        guard.observe(20_000, 20_000, 2160, 0, 1, 900, 20_000_000, 8_000_000, 4_000)
        assertEquals(SmartQualityGuard.Ceiling.FHD_1080P, guard.currentCeiling())

        guard.observe(41_000, 41_000, 2160, 0, 1, 900, 20_000_000, 8_000_000, 5_000)
        val restored = guard.observe(101_001, 101_001, 2160, 0, 1, 900, 20_000_000, 8_000_000, 5_000)
        assertTrue(restored.changed)
        assertEquals(SmartQualityGuard.Ceiling.USER_MAX, restored.ceiling)
    }

    @Test
    fun `720p user choice only falls to 540p under pressure`() {
        val guard = SmartQualityGuard()
        val decision = guard.observe(20_000, 20_000, 720, 35, 0, 0, 2_000_000, 7_000_000, 500)
        assertTrue(decision.changed)
        assertEquals(SmartQualityGuard.Ceiling.SD_540P, decision.ceiling)
    }
}
