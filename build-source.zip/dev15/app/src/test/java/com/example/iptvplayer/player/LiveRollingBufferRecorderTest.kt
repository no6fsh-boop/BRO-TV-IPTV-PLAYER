package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * يختبر فقط المنطق الصرف (بدون Android/File/شبكة) داخل LiveRollingBufferRecorder:
 * تنظيف معرّف القناة، وبناء نص الـplaylist المحلي. باقي المنطق (استقطاب الشبكة،
 * قراءة/كتابة الملفات) يحتاج بيئة Android حقيقية (Robolectric/جهاز) وخارج نطاق
 * اختبارات الوحدة هذه.
 */
class LiveRollingBufferRecorderTest {

    // --- sanitizeChannelId -------------------------------------------------

    @Test
    fun `sanitizeChannelId keeps already-safe ids unchanged`() {
        assertEquals(
            "channel_123",
            LiveRollingBufferRecorder.sanitizeChannelId("channel_123")
        )
    }

    @Test
    fun `sanitizeChannelId replaces path traversal and slashes`() {
        val result = LiveRollingBufferRecorder.sanitizeChannelId("../../etc/passwd")
        assertTrue("must not contain path separators", !result.contains("/"))
        assertTrue("must not contain '..'", !result.contains(".."))
    }

    @Test
    fun `sanitizeChannelId falls back to default for blank input`() {
        assertEquals("channel", LiveRollingBufferRecorder.sanitizeChannelId(""))
        assertEquals("channel", LiveRollingBufferRecorder.sanitizeChannelId("   "))
    }

    @Test
    fun `sanitizeChannelId truncates overly long ids to 120 chars`() {
        val longId = "a".repeat(500)
        val result = LiveRollingBufferRecorder.sanitizeChannelId(longId)
        assertEquals(120, result.length)
    }

    @Test
    fun `sanitizeChannelId strips unicode and special characters`() {
        val result = LiveRollingBufferRecorder.sanitizeChannelId("قناة تجربة #1 (HD)!")
        assertTrue("must only contain safe filesystem chars", result.matches(Regex("[A-Za-z0-9_-]+")))
    }

    // --- buildPlaylistText ---------------------------------------------------

    @Test
    fun `buildPlaylistText produces valid m3u8 header and footer`() {
        val entries = listOf(
            LiveRollingBufferRecorder.PlaylistEntry(1L, 4.0, "file:///tmp/1.ts"),
            LiveRollingBufferRecorder.PlaylistEntry(2L, 4.0, "file:///tmp/2.ts")
        )
        val text = LiveRollingBufferRecorder.buildPlaylistText(entries, mediaSequenceStart = 1L)

        assertTrue(text.startsWith("#EXTM3U"))
        assertTrue(text.contains("#EXT-X-VERSION:3"))
        assertTrue(text.contains("#EXT-X-MEDIA-SEQUENCE:1"))
        assertTrue(text.trim().endsWith("#EXT-X-ENDLIST"))
    }

    @Test
    fun `buildPlaylistText uses locale-US dot decimal separator for EXTINF`() {
        val defaultLocale = java.util.Locale.getDefault()
        try {
            // لغة تستخدم فاصلة "," كفاصل عشري افتراضياً (زي الفرنسية) — للتأكد إن الدالة
            // لا تتأثر بلغة الجهاز وتفرض نقطة "." دائماً حسب مواصفة HLS.
            java.util.Locale.setDefault(java.util.Locale.FRANCE)
            val entries = listOf(LiveRollingBufferRecorder.PlaylistEntry(1L, 4.5, "file:///tmp/1.ts"))
            val text = LiveRollingBufferRecorder.buildPlaylistText(entries, mediaSequenceStart = 1L)
            assertTrue("EXTINF must use '.' not ','", text.contains("#EXTINF:4.500,"))
            assertTrue(!text.contains("4,500"))
        } finally {
            java.util.Locale.setDefault(defaultLocale)
        }
    }

    @Test
    fun `buildPlaylistText includes every entry uri in order`() {
        val entries = listOf(
            LiveRollingBufferRecorder.PlaylistEntry(10L, 4.0, "file:///tmp/10.ts"),
            LiveRollingBufferRecorder.PlaylistEntry(11L, 4.0, "file:///tmp/11.ts"),
            LiveRollingBufferRecorder.PlaylistEntry(12L, 4.0, "file:///tmp/12.ts")
        )
        val text = LiveRollingBufferRecorder.buildPlaylistText(entries, mediaSequenceStart = 10L)

        val indexOf10 = text.indexOf("file:///tmp/10.ts")
        val indexOf11 = text.indexOf("file:///tmp/11.ts")
        val indexOf12 = text.indexOf("file:///tmp/12.ts")
        assertTrue(indexOf10 in 0 until indexOf11)
        assertTrue(indexOf11 in 0 until indexOf12)
    }

    @Test
    fun `buildPlaylistText falls back to default target duration when entries empty`() {
        val text = LiveRollingBufferRecorder.buildPlaylistText(emptyList(), mediaSequenceStart = 0L)
        assertTrue(text.contains("#EXT-X-TARGETDURATION:4"))
    }

    @Test
    fun `buildPlaylistText rounds target duration up from the longest segment`() {
        val entries = listOf(
            LiveRollingBufferRecorder.PlaylistEntry(1L, 2.0, "file:///tmp/1.ts"),
            LiveRollingBufferRecorder.PlaylistEntry(2L, 6.2, "file:///tmp/2.ts")
        )
        val text = LiveRollingBufferRecorder.buildPlaylistText(entries, mediaSequenceStart = 1L)
        // 6.2 -> toInt() == 6, +1 == 7
        assertTrue(text.contains("#EXT-X-TARGETDURATION:7"))
    }
}
