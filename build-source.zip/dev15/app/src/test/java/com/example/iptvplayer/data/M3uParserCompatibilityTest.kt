package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class M3uParserCompatibilityTest {
    @Test
    fun `metadata attributes are case insensitive and support unquoted values`() {
        val content = """
            #EXTM3U
            #extinf:-1 TVG-ID=channel.one TVG-LOGO='https://cdn.example/logo one.png' GROUP-TITLE=Sports,Channel One
            https://example.com/live/one.m3u8
        """.trimIndent()

        val channel = M3uParser.parse(content).single()
        assertEquals("Channel One", channel.name)
        assertEquals("channel.one", channel.epgId)
        assertEquals("https://cdn.example/logo one.png", channel.logoUrl)
        assertEquals("Sports", channel.groupTitle)
    }

    @Test
    fun `extgrp overrides default group for pending channel`() {
        val content = """
            #EXTM3U
            #EXTINF:-1 tvg-id="news.one",News One
            #EXTGRP:Arabic News
            https://example.com/news.ts
        """.trimIndent()

        val channel = M3uParser.parse(content).single()
        assertEquals("Arabic News", channel.groupTitle)
        assertEquals("news.one", channel.epgId)
    }

    @Test
    fun `utf8 bom before extm3u does not affect first channel`() {
        val content = "\uFEFF#EXTM3U\n#EXTINF:-1,One\nhttps://example.com/one\n"

        val channel = M3uParser.parse(content).single()
        assertEquals("One", channel.name)
        assertNull(channel.logoUrl)
    }
}
