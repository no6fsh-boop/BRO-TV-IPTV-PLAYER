package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveTimeshiftPolicyTest {

    @Test
    fun seekableLiveWindow_enablesNativeTimeshift() {
        val state = LiveTimeshiftPolicy.evaluate(
            isLive = true,
            isSeekable = true,
            durationMs = 120_000,
            positionMs = 90_000
        )
        assertTrue(state.supported)
        assertEquals(30_000, state.behindLiveMs)
        assertTrue(state.canRewind)
        assertTrue(state.canForward)
        assertFalse(state.atLiveEdge)
    }

    @Test
    fun nonSeekableLive_doesNotPretendTimeshiftExists() {
        val state = LiveTimeshiftPolicy.evaluate(
            isLive = true,
            isSeekable = false,
            durationMs = 120_000,
            positionMs = 90_000
        )
        assertFalse(state.supported)
        assertFalse(state.canRewind)
        assertFalse(state.canForward)
    }

    @Test
    fun nearLiveEdge_isReportedAsLive() {
        val state = LiveTimeshiftPolicy.evaluate(
            isLive = true,
            isSeekable = true,
            durationMs = 120_000,
            positionMs = 118_500
        )
        assertTrue(state.supported)
        assertTrue(state.atLiveEdge)
        assertFalse(state.canForward)
    }

    @Test
    fun seekIsAlwaysClampedInsidePublishedWindow() {
        assertEquals(0, LiveTimeshiftPolicy.clampSeek(-5_000, 60_000))
        assertEquals(60_000, LiveTimeshiftPolicy.clampSeek(70_000, 60_000))
        assertEquals(25_000, LiveTimeshiftPolicy.clampSeek(25_000, 60_000))
    }
}
