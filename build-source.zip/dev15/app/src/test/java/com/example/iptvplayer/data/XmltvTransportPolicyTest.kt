package com.brotv.player.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class XmltvTransportPolicyTest {
    @Test
    fun `gzip is detected from content encoding or url path before query`() {
        assertTrue(XmltvTransportPolicy.isGzip("gzip", "https://epg.example/guide.xml"))
        assertTrue(XmltvTransportPolicy.isGzip("GZip", "https://epg.example/guide.xml"))
        assertTrue(XmltvTransportPolicy.isGzip(null, "https://epg.example/guide.xml.gz?token=abc"))
        assertFalse(XmltvTransportPolicy.isGzip(null, "https://epg.example/guide.xml?format=gz"))
    }
}
