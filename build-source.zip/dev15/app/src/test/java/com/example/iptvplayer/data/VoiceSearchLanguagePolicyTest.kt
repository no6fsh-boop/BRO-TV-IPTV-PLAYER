package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Test

class VoiceSearchLanguagePolicyTest {
    @Test fun englishUiUsesEnglishRecognition() {
        assertEquals("en-US", VoiceSearchLanguagePolicy.languageTag("en"))
    }

    @Test fun arabicAndUnknownUiUseArabicRecognition() {
        assertEquals("ar-SA", VoiceSearchLanguagePolicy.languageTag("ar"))
        assertEquals("ar-SA", VoiceSearchLanguagePolicy.languageTag("xx"))
    }
}
