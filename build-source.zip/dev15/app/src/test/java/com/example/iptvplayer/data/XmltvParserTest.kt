package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class XmltvParserTest {
    @Test
    fun parsesProgrammeAndChannelName() {
        val xml = """
            <tv>
              <channel id="beinsports1"><display-name>beIN Sports 1 HD</display-name></channel>
              <programme start="20260914180000 +0300" stop="20260914190000 +0300" channel="beinsports1">
                <title>Live Match</title><desc>Test description</desc>
              </programme>
            </tv>
        """.trimIndent()
        val result = XmltvParser.parse(ByteArrayInputStream(xml.toByteArray()))
        assertEquals(1, result.size)
        assertEquals("beinsports1", result[0].channelId)
        assertEquals("beIN Sports 1 HD", result[0].channelName)
        assertEquals("Live Match", result[0].title)
    }

    @Test
    fun filtersOutsideRequestedWindow() {
        val xml = """
            <tv>
              <channel id="a"><display-name>A</display-name></channel>
              <programme start="20260914180000 +0300" stop="20260914190000 +0300" channel="a"><title>Inside</title></programme>
              <programme start="20260915180000 +0300" stop="20260915190000 +0300" channel="a"><title>Outside</title></programme>
            </tv>
        """.trimIndent()
        val parser = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US).apply { timeZone = TimeZone.getTimeZone("GMT+3") }
        val start = parser.parse("20260914170000 +0300")!!.time
        val end = parser.parse("20260914200000 +0300")!!.time
        val result = XmltvParser.parse(ByteArrayInputStream(xml.toByteArray()), start, end)
        assertEquals(listOf("Inside"), result.map { it.title })
    }

    @Test
    fun parsesTimezoneWithColon() {
        val parsed = XmltvParser.parseXmltvTime("20260914180000 +03:00")
        assertNotNull(parsed)
        assertTrue(parsed!! > 0)
    }
}
