package com.brotv.player.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelMappersTest {
    @Test
    fun toMergedChannel_preservesPlaybackMetadata() {
        val channel = Channel(
            id = "42",
            name = "Sports HD",
            streamUrl = "https://example.test/live/42.m3u8",
            logoUrl = "https://example.test/logo.png",
            groupTitle = "Sports",
            epgId = "sports.hd",
            hasArchive = true,
            archiveDurationDays = 7
        )

        val merged = channel.toMergedChannel()

        assertEquals(channel.id, merged.id)
        assertEquals(channel.name, merged.name)
        assertEquals(channel.groupTitle, merged.groupTitle)
        assertEquals(channel.logoUrl, merged.logoUrl)
        assertEquals(listOf(channel.streamUrl), merged.sourceUrls)
        assertEquals(listOf("sports.hd"), merged.epgIds)
        assertTrue(merged.hasArchive)
        assertEquals(7, merged.archiveDurationDays)
    }

    @Test
    fun toMergedChannel_dropsBlankEpgId() {
        val merged = Channel(
            id = "1",
            name = "News",
            streamUrl = "https://example.test/live/1.ts",
            epgId = "   "
        ).toMergedChannel()

        assertTrue(merged.epgIds.isEmpty())
        assertFalse(merged.hasArchive)
    }
}
