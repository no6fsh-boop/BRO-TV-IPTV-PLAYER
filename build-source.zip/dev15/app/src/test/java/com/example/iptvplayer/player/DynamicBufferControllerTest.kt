package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Test

class DynamicBufferControllerTest {
    @Test
    fun lowBufferEscalatesToStable() {
        val controller = DynamicBufferController()
        val profile = controller.observe(
            nowMs = 1_000,
            isLive = true,
            rebufferCount = 0,
            currentBufferMs = 500,
            estimatedBandwidth = 10_000_000,
            ttffMs = 1_000
        )
        assertEquals(PlayerEngine.BufferProfile.STABLE, profile)
    }

    @Test
    fun stableFastLiveCanMoveToLowLatencyAfterWarmup() {
        val controller = DynamicBufferController()
        controller.observe(1_000, true, 0, 5_000, 12_000_000, 1_000)
        val profile = controller.observe(17_000, true, 0, 5_000, 12_000_000, 1_000)
        assertEquals(PlayerEngine.BufferProfile.LOW_LATENCY, profile)
    }

    @Test
    fun resetReturnsBalanced() {
        val controller = DynamicBufferController()
        controller.observe(1_000, true, 0, 500, 1_000_000, 7_000)
        controller.reset()
        assertEquals(PlayerEngine.BufferProfile.BALANCED, controller.currentProfile)
    }
}
