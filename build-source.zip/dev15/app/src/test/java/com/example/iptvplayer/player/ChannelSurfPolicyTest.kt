package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelSurfPolicyTest {
    @Test
    fun channelUp_wrapsFromLastToFirst() {
        assertEquals(0, ChannelSurfPolicy.targetIndex(4, 5, 1))
    }

    @Test
    fun channelDown_wrapsFromFirstToLast() {
        assertEquals(4, ChannelSurfPolicy.targetIndex(0, 5, -1))
    }

    @Test
    fun emptyList_hasNoTarget() {
        assertEquals(-1, ChannelSurfPolicy.targetIndex(0, 0, 1))
    }
}
