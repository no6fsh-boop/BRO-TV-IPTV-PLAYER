package com.brotv.player.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PairingTokenGeneratorTest {
    @Test
    fun `pairing token uses qr friendly format`() {
        repeat(32) {
            assertTrue(PairingTokenGenerator.isValidFormat(PairingTokenGenerator.generate()))
        }
    }

    @Test
    fun `format rejects ambiguous or malformed tokens`() {
        assertFalse(PairingTokenGenerator.isValidFormat("O0I1ABCDEFGH"))
        assertFalse(PairingTokenGenerator.isValidFormat("ABC"))
    }
}
