package com.brotv.player.dvr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HlsRecorderParserTest {
    @Test
    fun `selectBestVariant resolves relative url and highest bandwidth`() {
        val master = """
            #EXTM3U
            #EXT-X-STREAM-INF:BANDWIDTH=800000
            low/index.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=4200000
            /hi/index.m3u8
        """.trimIndent()

        val best = HlsRecorderParser.selectBestVariant(master, "https://tv.example/live/master.m3u8")
        assertNotNull(best)
        assertEquals(4_200_000L, best!!.bandwidth)
        assertEquals("https://tv.example/hi/index.m3u8", best.uri)
    }

    @Test
    fun `parseMedia carries sequence aes key map and byte ranges`() {
        val media = """
            #EXTM3U
            #EXT-X-TARGETDURATION:6
            #EXT-X-MEDIA-SEQUENCE:42
            #EXT-X-KEY:METHOD=AES-128,URI="keys/key.bin",IV=0x0000000000000000000000000000002A
            #EXT-X-MAP:URI="init.mp4",BYTERANGE="200@0"
            #EXTINF:6.0,
            #EXT-X-BYTERANGE:1000@200
            media.mp4
            #EXTINF:6.0,
            #EXT-X-BYTERANGE:1000
            media.mp4
            #EXT-X-ENDLIST
        """.trimIndent()

        val parsed = HlsRecorderParser.parseMedia(media, "https://tv.example/path/live.m3u8")
        assertTrue(parsed.endList)
        assertTrue(parsed.isFmp4)
        assertEquals(6, parsed.targetDurationSeconds)
        assertEquals(2, parsed.segments.size)

        val first = parsed.segments[0]
        assertEquals(42L, first.sequence)
        assertEquals("https://tv.example/path/media.mp4", first.uri)
        assertEquals(HlsRecorderParser.ByteRange(1000, 200), first.byteRange)
        assertEquals("AES-128", first.key?.method)
        assertEquals("https://tv.example/path/keys/key.bin", first.key?.uri)
        assertEquals(HlsRecorderParser.ByteRange(200, 0), first.initMap?.byteRange)

        val second = parsed.segments[1]
        assertEquals(43L, second.sequence)
        assertEquals(HlsRecorderParser.ByteRange(1000, null), second.byteRange)
    }

    @Test
    fun `key NONE clears encryption and live list remains open`() {
        val media = """
            #EXTM3U
            #EXT-X-MEDIA-SEQUENCE:7
            #EXT-X-KEY:METHOD=AES-128,URI="key"
            #EXTINF:4,
            a.ts
            #EXT-X-KEY:METHOD=NONE
            #EXTINF:4,
            b.ts
        """.trimIndent()

        val parsed = HlsRecorderParser.parseMedia(media, "https://tv.example/live.m3u8")
        assertFalse(parsed.endList)
        assertNotNull(parsed.segments[0].key)
        assertNull(parsed.segments[1].key)
    }
    @Test
    fun `master prefers average bandwidth when provider supplies it`() {
        val master = """
            #EXTM3U
            #EXT-X-STREAM-INF:BANDWIDTH=5000000,AVERAGE-BANDWIDTH=1800000
            efficient/index.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=2500000,AVERAGE-BANDWIDTH=2200000
            stable/index.m3u8
        """.trimIndent()

        val best = HlsRecorderParser.selectBestVariant(master, "https://tv.example/master.m3u8")
        assertNotNull(best)
        assertEquals(2_200_000L, best!!.bandwidth)
        assertEquals("https://tv.example/stable/index.m3u8", best.uri)
    }

    @Test
    fun `playlist detection accepts utf8 bom and mixed case marker`() {
        assertTrue(HlsRecorderParser.isPlaylist("\uFEFF   #extm3u\n#EXT-X-ENDLIST"))
    }

    @Test
    fun `invalid byte ranges are rejected safely`() {
        assertNull(HlsRecorderParser.parseByteRange("0@0"))
        assertNull(HlsRecorderParser.parseByteRange("-4@0"))
        assertNull(HlsRecorderParser.parseByteRange("4@-1"))
        assertNull(HlsRecorderParser.parseByteRange("4@not-a-number"))
        assertNull(HlsRecorderParser.parseByteRange("9223372036854775807@1"))
    }

}
