package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Test

class AutoPilotEngineTest {
    @Test
    fun unknownSources_preservePlaylistOrder_withoutNetworkProbe() {
        val urls = listOf("http://one.example/live", "http://two.example/live")
        assertEquals(urls.first(), AutoPilotEngine.bestKnownSource(urls))
    }

    @Test
    fun excludedSource_isNeverSelected() {
        val urls = listOf("http://one.example/live", "http://two.example/live")
        assertEquals(urls[1], AutoPilotEngine.bestKnownSource(urls, setOf(urls[0])))
    }

    @Test
    fun healthierObservedSource_winsHotPath() {
        val slow = "http://slow.example/live"
        val healthy = "http://healthy.example/live"
        StreamHealthRegistry.recordSuccess(slow, StreamHealthSnapshot(ttffMs = 7000, rebufferCount = 4, playbackErrors = 2))
        StreamHealthRegistry.recordSuccess(healthy, StreamHealthSnapshot(ttffMs = 700, rebufferCount = 0, playbackErrors = 0))
        assertEquals(healthy, AutoPilotEngine.bestKnownSource(listOf(slow, healthy)))
    }
}
