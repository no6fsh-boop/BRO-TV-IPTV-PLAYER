package com.brotv.player.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ParentalControlManagerTest {
    @Test
    fun pinValidation_acceptsOnlyFourToEightDigits() {
        assertTrue(ParentalControlManager.isValidPin("1234"))
        assertTrue(ParentalControlManager.isValidPin("12345678"))
        assertFalse(ParentalControlManager.isValidPin("123"))
        assertFalse(ParentalControlManager.isValidPin("123456789"))
        assertFalse(ParentalControlManager.isValidPin("12a4"))
    }

    @Test
    fun constantTimeEquals_matchesEqualByteArrays() {
        assertTrue(ParentalControlManager.constantTimeEquals(byteArrayOf(1, 2, 3), byteArrayOf(1, 2, 3)))
        assertFalse(ParentalControlManager.constantTimeEquals(byteArrayOf(1, 2, 3), byteArrayOf(1, 2, 4)))
        assertFalse(ParentalControlManager.constantTimeEquals(byteArrayOf(1, 2), byteArrayOf(1, 2, 3)))
    }
    @Test
    fun algorithmChoiceIsStableAcrossApiLevels() {
        assertTrue(ParentalControlManager.preferredAlgorithm(25).endsWith("SHA1"))
        assertTrue(ParentalControlManager.preferredAlgorithm(26).endsWith("SHA256"))
    }
}
