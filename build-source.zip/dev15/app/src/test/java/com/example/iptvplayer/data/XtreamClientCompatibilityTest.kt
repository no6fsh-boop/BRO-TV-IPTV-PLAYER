package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class XtreamClientCompatibilityTest {

    @Test
    fun `query and path credentials are percent encoded`() {
        assertEquals("user%2Bname%40mail.com", XtreamClient.encodeQuery("user+name@mail.com"))
        assertEquals("p%40ss%2Fword%20%26%20more", XtreamClient.encodePathSegment("p@ss/word & more"))
    }

    @Test
    fun `encoded live url is parsed back to original credentials`() {
        val parsed = XtreamClient.parseLiveStreamUrl(
            "https://iptv.example:8443/live/user%2Bname/p%40ss%2Fword/12345.m3u8"
        )
        requireNotNull(parsed)
        assertEquals("https://iptv.example:8443", parsed.server)
        assertEquals("user+name", parsed.username)
        assertEquals("p@ss/word", parsed.password)
        assertEquals("12345", parsed.streamId)
    }

    @Test
    fun `invalid live url is rejected safely`() {
        assertNull(XtreamClient.parseLiveStreamUrl("file:///live/u/p/123.m3u8"))
        assertNull(XtreamClient.parseLiveStreamUrl("https://iptv.example/movie/u/p/123.mp4"))
        assertNull(XtreamClient.parseLiveStreamUrl("https://iptv.example/live/u/p/not-a-number.m3u8"))
    }

    @Test
    fun `unsafe container extension falls back to mp4`() {
        assertEquals("mkv", XtreamClient.sanitizeExtension(".mkv"))
        assertEquals("mp4", XtreamClient.sanitizeExtension("mp4?token=bad"))
        assertEquals("mp4", XtreamClient.sanitizeExtension("../../ts"))
    }

    @Test
    fun `catchup url protects credentials and clamps duration`() {
        val client = XtreamClient("https://iptv.example/", "user+name", "p@ss/word")
        val url = client.buildCatchupUrl("123", 1_700_000_000L, 0)
        assertTrue(url.contains("username=user%2Bname"))
        assertTrue(url.contains("password=p%40ss%2Fword"))
        assertTrue(url.contains("stream=123"))
        assertTrue(url.contains("duration=1"))
        assertTrue(!url.contains("p@ss/word"))
    }
}
