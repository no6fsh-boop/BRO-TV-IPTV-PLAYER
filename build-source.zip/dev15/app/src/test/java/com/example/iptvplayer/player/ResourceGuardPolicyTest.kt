package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourceGuardPolicyTest {

    private val healthyDevice = ResourceBudget.DeviceState(
        lowRamDevice = false,
        memoryClassMb = 512,
        sdkInt = 34,
        availableMemoryMb = 1024,
        lowMemory = false
    )

    @Test
    fun providerLimit_blocksExtraLocalConnection() {
        val budget = ResourceBudget()
        val provider = ResourceBudget.ProviderState("p", maxConnections = 2, reportedActiveConnections = 0)

        assertTrue(budget.acquire(1, ResourceBudget.SessionKind.MULTIVIEW_FOCUSED, provider, healthyDevice).allowed)
        // active_cons=1 now includes our first local stream; it must not be double-counted.
        assertTrue(
            budget.acquire(
                2,
                ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND,
                provider.copy(reportedActiveConnections = 1),
                healthyDevice
            ).allowed
        )
        val third = budget.acquire(
            3,
            ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND,
            provider.copy(reportedActiveConnections = 2),
            healthyDevice
        )
        assertFalse(third.allowed)
        assertEquals(ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT, third.denialReason)
    }

    @Test
    fun providerLimit_countsExternalConnections() {
        val budget = ResourceBudget()
        val provider = ResourceBudget.ProviderState("p", maxConnections = 2, reportedActiveConnections = 1)

        assertTrue(budget.acquire(1, ResourceBudget.SessionKind.MULTIVIEW_FOCUSED, provider, healthyDevice).allowed)
        val second = budget.acquire(
            2,
            ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND,
            provider.copy(reportedActiveConnections = 2),
            healthyDevice
        )
        assertFalse(second.allowed)
        assertEquals(ResourceBudget.DenialReason.PROVIDER_CONNECTION_LIMIT, second.denialReason)
    }

    @Test
    fun primaryPlayback_preemptsLowerPriorityLeaseAtProviderLimit() {
        val budget = ResourceBudget()
        val provider = ResourceBudget.ProviderState("p", maxConnections = 1, reportedActiveConnections = 0)

        assertTrue(budget.acquire(10, ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND, provider, healthyDevice).allowed)
        val primary = budget.acquire(
            11,
            ResourceBudget.SessionKind.PRIMARY_PLAYBACK,
            provider.copy(reportedActiveConnections = 1),
            healthyDevice
        )

        assertTrue(primary.allowed)
        assertEquals(listOf(10L), primary.preemptLeaseIds)
        assertEquals(1, budget.activeLeaseCount())
    }

    @Test
    fun primaryPlayback_preemptsRecordingBeforeExceedingProviderLimit() {
        val budget = ResourceBudget()
        val provider = ResourceBudget.ProviderState("p", maxConnections = 1, reportedActiveConnections = 0)

        assertTrue(budget.acquire(20, ResourceBudget.SessionKind.RECORDING, provider, healthyDevice).allowed)
        val primary = budget.acquire(
            21,
            ResourceBudget.SessionKind.PRIMARY_PLAYBACK,
            provider.copy(reportedActiveConnections = 1),
            healthyDevice
        )

        assertTrue(primary.allowed)
        assertEquals(listOf(20L), primary.preemptLeaseIds)
    }

    @Test
    fun lowMemory_rejectsSecondaryVideoButKeepsPrimaryPossible() {
        val budget = ResourceBudget()
        val lowMemoryDevice = healthyDevice.copy(availableMemoryMb = 100, lowMemory = true)
        val provider = ResourceBudget.ProviderState("m3u")

        val secondary = budget.acquire(
            1,
            ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND,
            provider,
            lowMemoryDevice
        )
        assertFalse(secondary.allowed)
        assertEquals(ResourceBudget.DenialReason.DEVICE_MEMORY_PRESSURE, secondary.denialReason)

        val primary = budget.acquire(
            2,
            ResourceBudget.SessionKind.PRIMARY_PLAYBACK,
            provider,
            lowMemoryDevice
        )
        assertTrue(primary.allowed)
    }

    @Test
    fun release_freesProviderSlot() {
        val budget = ResourceBudget()
        val provider = ResourceBudget.ProviderState("p", maxConnections = 1, reportedActiveConnections = 0)
        assertTrue(budget.acquire(1, ResourceBudget.SessionKind.MULTIVIEW_FOCUSED, provider, healthyDevice).allowed)
        budget.release(1)
        assertTrue(budget.acquire(2, ResourceBudget.SessionKind.MULTIVIEW_FOCUSED, provider, healthyDevice).allowed)
    }
    @Test
    fun providerPreemption_preservesExternalConnectionBaseline() {
        val budget = ResourceBudget()
        val provider = ResourceBudget.ProviderState("p", maxConnections = 2, reportedActiveConnections = 1)

        assertTrue(budget.acquire(30, ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND, provider, healthyDevice).allowed)
        val primary = budget.acquire(
            31,
            ResourceBudget.SessionKind.PRIMARY_PLAYBACK,
            provider.copy(reportedActiveConnections = 2),
            healthyDevice
        )

        assertTrue(primary.allowed)
        assertEquals(listOf(30L), primary.preemptLeaseIds)
        assertEquals(2, budget.estimatedProviderConnectionCount("p"))
    }

    @Test
    fun primaryPlayback_preemptsBackgroundDecoderWhenDeviceCapIsFull() {
        val budget = ResourceBudget()
        val smallDevice = healthyDevice.copy(memoryClassMb = 160) // two video decoders
        val provider = ResourceBudget.ProviderState("m3u")

        assertTrue(budget.acquire(40, ResourceBudget.SessionKind.MULTIVIEW_FOCUSED, provider, smallDevice).allowed)
        assertTrue(budget.acquire(41, ResourceBudget.SessionKind.MULTIVIEW_BACKGROUND, provider, smallDevice).allowed)
        val primary = budget.acquire(42, ResourceBudget.SessionKind.PRIMARY_PLAYBACK, provider, smallDevice)

        assertTrue(primary.allowed)
        assertEquals(listOf(41L), primary.preemptLeaseIds)
        assertEquals(2, budget.activeDecoderCount())
    }

    @Test
    fun recording_reservesConnectionWithoutConsumingVideoDecoder() {
        val budget = ResourceBudget()
        val provider = ResourceBudget.ProviderState("p", maxConnections = 2, reportedActiveConnections = 0)

        assertTrue(budget.acquire(50, ResourceBudget.SessionKind.PRIMARY_PLAYBACK, provider, healthyDevice).allowed)
        assertTrue(budget.acquire(51, ResourceBudget.SessionKind.RECORDING, provider.copy(reportedActiveConnections = 1), healthyDevice).allowed)
        assertEquals(2, budget.activeLeaseCount())
        assertEquals(1, budget.activeDecoderCount())
    }

}
