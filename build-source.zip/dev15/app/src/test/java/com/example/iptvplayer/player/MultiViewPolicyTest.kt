package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Test

class MultiViewPolicyTest {

    @Test
    fun lowRamDevice_isCappedAtTwoPanes() {
        assertEquals(2, MultiViewPolicy.maxPanes(MultiViewPolicy.DeviceProfile(true, 512, 34)))
    }

    @Test
    fun modernDeviceWithEnoughMemory_canUseFourPanes() {
        assertEquals(4, MultiViewPolicy.maxPanes(MultiViewPolicy.DeviceProfile(false, 384, 34)))
    }

    @Test
    fun focusedPane_keepsHigherQualityWhenFourStreamsAreActive() {
        assertEquals(
            SmartQualityGuard.Ceiling.FHD_1080P,
            MultiViewPolicy.ceiling(activePanes = 4, focused = true)
        )
        assertEquals(
            SmartQualityGuard.Ceiling.HD_720P,
            MultiViewPolicy.ceiling(activePanes = 4, focused = false)
        )
    }

    @Test
    fun twoPaneMode_preservesUserMaxOnFocusedPane() {
        assertEquals(
            SmartQualityGuard.Ceiling.USER_MAX,
            MultiViewPolicy.ceiling(activePanes = 2, focused = true)
        )
        assertEquals(
            SmartQualityGuard.Ceiling.FHD_1080P,
            MultiViewPolicy.ceiling(activePanes = 2, focused = false)
        )
    }
}
