package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * يختبر فقط منطق اختيار وضع العرض الصرف (`bestMatchingModeId`) — بدون أي اعتمادية
 * Android (`Display`/`Window`), والتي تحتاج جهاز حقيقي أو Robolectric.
 */
class DisplayModeSwitcherTest {

    private val commonModes = listOf(
        DisplayModeSwitcher.ModeInfo(modeId = 1, width = 1920, height = 1080, refreshRate = 60f),
        DisplayModeSwitcher.ModeInfo(modeId = 2, width = 1920, height = 1080, refreshRate = 50f),
        DisplayModeSwitcher.ModeInfo(modeId = 3, width = 3840, height = 2160, refreshRate = 60f),
        DisplayModeSwitcher.ModeInfo(modeId = 4, width = 3840, height = 2160, refreshRate = 50f),
        DisplayModeSwitcher.ModeInfo(modeId = 5, width = 3840, height = 2160, refreshRate = 24f)
    )

    @Test
    fun `picks the 4K mode for 4K content`() {
        val id = DisplayModeSwitcher.bestMatchingModeId(commonModes, 3840, 2160, 60f)
        assertEquals(3, id)
    }

    @Test
    fun `picks the 1080p mode for 1080p content instead of unnecessarily switching to 4K`() {
        val id = DisplayModeSwitcher.bestMatchingModeId(commonModes, 1920, 1080, 60f)
        assertEquals(1, id)
    }

    @Test
    fun `prefers a refresh rate that is an exact multiple of the content frame rate to avoid judder`() {
        // محتوى سينمائي 24fps: نفضّل وضع 24Hz الحقيقي على 60Hz رغم إنه أعلى.
        val id = DisplayModeSwitcher.bestMatchingModeId(commonModes, 3840, 2160, 24f)
        assertEquals(5, id)
    }

    @Test
    fun `falls back to highest available resolution when nothing matches or exceeds content`() {
        val onlyHdModes = listOf(
            DisplayModeSwitcher.ModeInfo(modeId = 1, width = 1280, height = 720, refreshRate = 60f),
            DisplayModeSwitcher.ModeInfo(modeId = 2, width = 1920, height = 1080, refreshRate = 60f)
        )
        // التلفزيون ما يدعم 4K أصلاً — لازم نختار أقرب/أعلى دقة متاحة بدل ما نرجع null.
        val id = DisplayModeSwitcher.bestMatchingModeId(onlyHdModes, 3840, 2160, 60f)
        assertEquals(2, id)
    }

    @Test
    fun `returns null for empty mode list or invalid content dimensions`() {
        assertNull(DisplayModeSwitcher.bestMatchingModeId(emptyList(), 3840, 2160, 60f))
        assertNull(DisplayModeSwitcher.bestMatchingModeId(commonModes, 0, 2160, 60f))
        assertNull(DisplayModeSwitcher.bestMatchingModeId(commonModes, 3840, -1, 60f))
    }

    @Test
    fun `zero or unknown frame rate still resolves a resolution match deterministically`() {
        val id = DisplayModeSwitcher.bestMatchingModeId(commonModes, 3840, 2160, 0f)
        // بدون معدل فيديو معروف، نختار أصغر modeId ضمن أقرب دقة كسلوك ثابت/متوقع.
        assertEquals(3, id)
    }

    @Test
    fun `does not downscale below content resolution when a larger mode is available`() {
        val modes = listOf(
            DisplayModeSwitcher.ModeInfo(modeId = 1, width = 1920, height = 1080, refreshRate = 60f),
            DisplayModeSwitcher.ModeInfo(modeId = 2, width = 3840, height = 2160, refreshRate = 60f)
        )
        val id = DisplayModeSwitcher.bestMatchingModeId(modes, 3840, 2160, 60f)
        assertEquals(2, id)
    }
}
