package com.brotv.player.player

import org.junit.Assert.assertEquals
import org.junit.Test

class PictureInPicturePolicyTest {
    @Test
    fun standard16by9_isReducedAndPreserved() {
        assertEquals(PictureInPicturePolicy.Ratio(16, 9), PictureInPicturePolicy.safeRatio(3840, 2160))
    }

    @Test
    fun invalidOrExtremeMetadata_fallsBackSafely() {
        assertEquals(PictureInPicturePolicy.Ratio(16, 9), PictureInPicturePolicy.safeRatio(0, 0))
        assertEquals(PictureInPicturePolicy.Ratio(16, 9), PictureInPicturePolicy.safeRatio(10_000, 100))
    }
}
