package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Test

class M3uEpgMetadataTest {
    @Test
    fun tvgIdIsPreservedForXmltvMatching() {
        val content = """
            #EXTM3U
            #EXTINF:-1 tvg-id="beinsports1" tvg-logo="https://x/logo.png" group-title="Sports",beIN Sports 1 HD
            https://example.com/live/1.m3u8
        """.trimIndent()
        val channel = M3uParser.parse(content).single()
        assertEquals("beinsports1", channel.epgId)
        assertEquals("Sports", channel.groupTitle)
    }
}
