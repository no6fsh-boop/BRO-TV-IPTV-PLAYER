package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Test

class XmltvNameNormalizationTest {
    @Test
    fun qualitySuffixesDoNotBreakNameMatching() {
        assertEquals(
            XmltvEpgRepository.normalizeName("beIN Sports 1"),
            XmltvEpgRepository.normalizeName("BEIN Sports 1 FHD")
        )
    }
}
