package com.brotv.player.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchMatcherTest {
    @Test
    fun normalizesArabicAlefAndDiacritics() {
        assertTrue(SearchMatcher.matches("قَنَاة الأخبار", "قناه الاخبار"))
        assertTrue(SearchMatcher.matches("أفلام عربية", "افلام"))
    }

    @Test
    fun matchesIsCaseInsensitiveAndWhitespaceTolerant() {
        assertTrue(SearchMatcher.matches("Sports   HD", "sports hd"))
        assertTrue(SearchMatcher.matches("BBC NEWS", "bbc news"))
    }

    @Test
    fun blankQueryDoesNotMatchEverything() {
        assertFalse(SearchMatcher.matches("Sports", "   "))
    }
    @Test
    fun channelCodesIncludeDisplayNumberAndXtreamStreamId() {
        val codes = SearchMatcher.channelCodes(13, listOf(
            "https://provider.test/live/user/pass/98765.ts",
            "https://provider.test/live/user/pass/222.m3u8?token=x"
        ))
        assertTrue("13" in codes)
        assertTrue("98765" in codes)
        assertTrue("222" in codes)
        assertTrue(SearchMatcher.matchesChannelCode("98765", codes))
        assertFalse(SearchMatcher.matchesChannelCode("98", codes))
    }

}
