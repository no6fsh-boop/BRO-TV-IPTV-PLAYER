package com.brotv.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamHealthScorerTest {
    @Test
    fun excellentStream_reaches100() {
        val score = StreamHealthScorer.score(
            StreamHealthSnapshot(
                width = 3840,
                height = 2160,
                fps = 60f,
                bitrate = 15_000_000,
                ttffMs = 700,
                rebufferCount = 0,
                playbackErrors = 0,
                droppedFrames = 0,
                successfulStarts = 1,
                serverLatencyMs = 100
            )
        )
        assertEquals(100, score)
    }

    @Test
    fun stable1080p50_beatsUnstable4k() {
        val stable1080 = StreamHealthScorer.score(
            StreamHealthSnapshot(
                width = 1920,
                height = 1080,
                fps = 50f,
                bitrate = 8_000_000,
                ttffMs = 1_200,
                rebufferCount = 0,
                playbackErrors = 0,
                droppedFrames = 1,
                successfulStarts = 1,
                serverLatencyMs = 250
            )
        )
        val unstable4k = StreamHealthScorer.score(
            StreamHealthSnapshot(
                width = 3840,
                height = 2160,
                fps = 60f,
                bitrate = 15_000_000,
                ttffMs = 7_500,
                rebufferCount = 4,
                rebufferDurationMs = 20_000,
                playbackErrors = 3,
                droppedFrames = 120,
                successfulStarts = 1,
                serverLatencyMs = 4_000
            )
        )
        assertTrue(stable1080 > unstable4k)
    }

    @Test
    fun scoreAlwaysWithinRange() {
        val score = StreamHealthScorer.score(
            StreamHealthSnapshot(
                width = Int.MAX_VALUE,
                height = Int.MAX_VALUE,
                fps = Float.MAX_VALUE,
                bitrate = Long.MAX_VALUE,
                successfulStarts = 1,
                serverLatencyMs = 0
            )
        )
        assertTrue(score in 0..100)
    }
}
