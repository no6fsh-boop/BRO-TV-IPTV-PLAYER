# BRO TV Dev15 — Live focus continuation

Base: `BRO-TV-3.0-dev15-LATEST-CLOUD-REFERENCE-DESIGN-v8-source.zip` from the attached handoff. App identity stays `com.brotv.player`, `3.0.0-dev15` (38).

## Blocking failure from the previous run

Targeted Live QA run `35713282188` timed out asserting focus inside `recyclerChannels` after the channel grid appeared. `ChannelBrowseActivity.showChannels()` called `ListAdapter.submitList()` and immediately posted a focus request. The asynchronous diff could leave no channel card attached when that request ran. Its fallback called `RecyclerView.requestFocus()`, which does not ensure that a focusable card receives focus.

## Change made

- Focus the selected channel only after the list commit. Wait for the target card to attach if its layout is pending. Retry the pending request when the browse window regains focus after the player closes.
- Preserve the manual Live source selector and the disabled automatic Live source switching. Playback handling was not changed.
- On a failed focus assertion, `ci/adb_ui.py` now reports the actual focused UI node for diagnosis.

## Verification state

- Passed locally: Python syntax for QA utilities, shell syntax for both QA scripts, parsing of all 134 Android resource XML files.
- Not run for this change: Android compilation, emulator targeted QA, a subsequent full QA, and real television/IPTV playback. This workspace has no Android SDK, `adb`, or emulator, and Gradle cannot download its distribution here.
- Previous screenshots and build artifacts in the original attachment cover the earlier version only; they do not validate this change or establish a match to the visual reference.

## Resume sequence on an Android CI runner

1. Build this source (`./gradlew testDebugUnitTest lintDebug assembleDebug assembleRelease`).
2. Run only `BROTV_QA_APK=app/build/outputs/apk/debug/app-debug.apk bash ci/android_tv_qa_live_tail.sh` on Android TV API 34 with the emulator and local mock service available. Keep the captured list/player/return screenshots and focus diagnostics.
3. If a blocking failure appears, fix only that blocker and resume Live from the failed step. Record other findings until the targeted pass completes.
4. Retest only failed cases after fixes, then run `ci/android_tv_qa.sh` for one final Full QA. Verify the interface against the user's actual reference images and test streams on a physical TV with the real provider before any field acceptance claim.

The remote `dev13-test` workflow currently fetches a separately hosted v17 source and a prebuilt v15 APK. A run of that workflow cannot validate the attached v8 based source or this fix without changing its source and APK inputs.

## Reference design pass in v10

- Added a brief black/gold startup screen with the BRO TV mark, bilingual feature labels, and a gold horizon arc before the existing source check routes to Login or Home.
- Made Live channel tiles dark navy, removed the competing section tabs from the in-screen header, and retained search plus remote BACK behavior.
- Changed Movies and Series to four poster columns, compact gold focusable category chips, a logo/search/settings header, and return-to-home behavior through the brand mark.
- Moved Search and Settings headings to the left under the logo, added settings-row arrows, and branded the player's top bar with the logo.
- The Home screen already had the hero/card-row composition; its initial focus now matches the top navigation and Watch Now opens Movies.
- Validation in this workspace: 139 resource XML files parsed, no missing `R.id` declarations, QA Python syntax and shell syntax passed. `assembleDebug` could not start because Gradle 8.6 is unavailable and network access is blocked. No screenshot from the redesigned build is available, so visual matching still needs Android TV emulator/device review. Provider poster/video content depends on the IPTV source.
