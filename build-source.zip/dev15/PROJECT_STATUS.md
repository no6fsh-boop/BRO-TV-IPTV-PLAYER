# BRO TV — Project Status

Current source version: **2.0.0 Commercial (versionCode 20)**.

## Confirmed in source

- LTR application layout (`supportsRtl=false`).
- Xtream/M3U live TV, VOD/Series, EPG, profiles, favorites, search, catch-up and Multiview.
- Media3 subtitle track selection.
- Connection / Resource Guard with provider quota, RAM/decoder protection and primary-playback priority.
- DVR direct recording, current-program recording and EPG scheduled recording.
- Foreground recording service, boot/update schedule restoration, exact-alarm fallback and wake lock.
- DVR failover, free-space protection, encrypted source URLs and local recording player.
- HLS DVR support for master variants, AES-128, fMP4 init maps, byte ranges and live polling.
- HLS hash-only checkpoint resume across process/service restarts.
- HLS byte-range fallback when an IPTV/CDN origin ignores the HTTP `Range` header, preventing silent recording corruption.
- Device and portable encrypted backup/restore.
- Home header now displays real Xtream account/connection information when available; fake fixed weather/location values were removed.
- M3U parser accepts mixed-case metadata keys, `#EXTGRP`, single-quoted/unquoted attributes and UTF-8 BOM input for broader provider compatibility.

## Verification completed in this workspace

- XML parse: 0 errors.
- Android resource-reference scan: 0 missing refs.
- Arabic/English string key parity verified.
- M3U compatibility tests added for mixed-case metadata, `#EXTGRP`, quoting variants and BOM input; full Gradle execution is delegated to CI when the package is published.
- ResourceGuard policy suite executed on the JVM and passed.
- HLS parser compilation/tests passed.
- DVR integration smoke tests passed for master variant selection, implicit byte ranges, AES-128, generic HLS signature sniffing and checkpoint resume without segment duplication.

## Environment limitation

Full Android Gradle verification is executed on GitHub Actions because the local workspace has no Android SDK. Integrated CI has validated unit tests, Debug APK, Release build and AAB generation before commercial signing.


## 1.2.1 Xtream network hardening
- Reserved characters in Xtream credentials and API parameters are encoded safely.
- Live/VOD/Series/Catch-up URL construction is hardened against malformed path/query components.
- Xtream HTTP calls now validate 2xx status, follow redirects and disconnect reliably.
- Added `XtreamClientCompatibilityTest` for the new compatibility/safety behavior.

## Commercial RC2 hardening

- Removed unused direct microphone permission/feature; voice search delegates to the system recognizer and follows the selected Arabic/English app language.
- Localized major user-facing search/live/VOD/series/catch-up/profile/subtitle/backup flows and the phone-pairing page.
- HLS DVR parser now accepts BOM/mixed-case playlists, prefers AVERAGE-BANDWIDTH, and rejects invalid/overflowing byte ranges.
- Boot receiver is non-exported to third-party apps while retaining system boot/package-replaced delivery.
- Pure JVM smoke checks for HLS hardening and voice-language policy pass locally; full Android unit/lint/release gates run in CI.

## Commercial RC4 final hardening

- RC3 passed unit tests, Android Release Lint, Release APK build and AAB build in GitHub Actions.
- Added hash-only sliding-window HLS BYTERANGE resume regression coverage.
- Pairing server now uses SecureRandom 12-character tokens, constant-time token checks, LAN-only access, pre-body authentication, 64 KiB request limits and no-store/CSP/referrer hardening.
- Self-Healing decoder recovery now forces player recreation and retry callbacks are generation-gated/isolated from seek UI timers.
- XMLTV gzip transport handles signed/query-string `.gz` URLs.
## Final commercial polish
- RC4 passed unit tests, release lint and Release APK/AAB build.
- Final polish adds bounded/renewed DVR WakeLock handling, localized search hint/input metadata, resource-formatted EPG/source text, and removes Lint cut/paste view lookup warnings.
- Final candidate must re-pass unit tests, release lint and Release APK/AAB before signing.


## 2.0.2 field hotfix
- Live playback recovery made conservative after real-TV testing exposed false 5-second restarts.
- Live AUTO buffer adaptation no longer recreates ExoPlayer mid-channel.
- Standard TV DPAD Up/Down changes channels from full-screen live playback.
- Physical-TV acceptance is required before calling this release final.
## 2.0.5 field fixes
- Real-TV feedback: live failover loops caused repeated source switching and UI/device slowdown. Live auto-failover is now disabled in favor of bounded same-source retry plus manual source selection.
- Green diagnostics overlay removed from normal playback.
- Live info bar, server refresh, series safe sizing and Movies/Series sort focus navigation updated from field feedback.



## Dev2 status
Fast-zapping source selection implemented. Compilation remains externally blocked by unavailable Gradle 8.6 distribution; no compile success is claimed.


Dev10: Home responsiveness pass completed; full Gradle build still environment-blocked before compilation.

## Dev11: StreamVault parity pass 1 — FFmpeg audio fallback
- Added `org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+2` (Maven Central, prebuilt AAR
  matching our exact media3 1.3.1) so unsupported audio codecs (AC-3/E-AC-3/DTS/MP2/TrueHD)
  fall back to software decoding instead of failing playback on devices without a hardware
  decoder. No media3 version bump and no PlayerEngine.kt changes needed: `EXTENSION_RENDERER_MODE_ON`
  was already set, so `DefaultRenderersFactory` discovers `FfmpegAudioRenderer` automatically
  once it's on the classpath.
- Not yet compiled locally (no Android SDK in this workspace, per README). Needs a real
  Gradle sync + `assembleDebug` + device test with an AC-3/DTS stream before shipping,
  same as every other unverified entry in this log.

## Dev12: StreamVault parity pass 2 — local rolling live-rewind buffer (MVP)
- New `player/LiveRollingBufferRecorder.kt`: deliberately independent of the real DVR
  Foreground Service (`DvrRecordingService`/`DvrStreamRecorder`) per explicit product
  decision — Activity-scoped, no notification/WakeLock, cacheDir-only storage, reuses only
  the dependency-free `HlsRecorderParser` object (no DB/ResourceGuard coupling).
  - Polls the live media playlist, downloads new unencrypted MPEG-TS segments, keeps a
    rolling 30-minute / 700MB-capped window, and can build a local `.m3u8` pointing at the
    still-cached segments.
  - Explicit MVP limits: no AES-128 or fMP4 support yet (`unsupported` flag set, feature
    silently no-ops for those channels rather than producing a broken recording); buffer is
    lost when the player screen closes (not a persistent recording).
  - Wired into `FullPlayerActivity` lifecycle (`updateRollingBufferForChannel` /
    `stopRollingBuffer`, called from `startPlaybackWithGrantedResource` / `onDestroy`) so it
    actually accumulates segments while a live channel plays.
  - Rewind UI/seek-control wiring landed in Dev13 (see below); this entry originally shipped
    the buffering engine only.
- Not yet compiled or device-tested, same caveat as Dev11.
- Home-screen and live-channel-grid layout redesign (matching current reference mockup)
  landed in the same pass: `activity_home.xml`, `item_home_card` flow unchanged,
  `item_merged_channel.xml` rebuilt as a logo tile, `MergedChannelAdapter` now loads real
  channel logos via Coil and fixed D-pad left-edge navigation for the new grid.

## Dev13: rewind UI wiring, CI, crash logging, test fixes
- **Local rewind buffer now wired to the live seek control in `FullPlayerActivity`**:
  `seekBy(deltaMs)` falls back to `tryEnterLocalRewindMode()` when the provider's native
  timeshift window is exhausted and a negative (backward) seek is requested, instead of
  just showing "timeshift unavailable". While playing from the local buffer
  (`isPlayingFromLocalBuffer`), seeking forward auto-catches-up to live once within
  `LOCAL_BUFFER_CATCHUP_THRESHOLD_MS` (3s) of the live edge, and the existing "Go Live"
  button (`btnGoLive`) now also exits local-rewind mode. `checkForFreeze()` and the
  player's `onPlayerError` callback both skip/short-circuit the normal live-failure
  recovery state machine while `isPlayingFromLocalBuffer` is true, so a local-buffer
  playback error can't be misread as a live-source failure and trigger the (now-disabled)
  auto source-switch path.
- **`LiveSourceRecoveryPolicy` unit tests fixed** — `LiveSourceRecoveryPolicyTest.kt` was
  still asserting the old `TRY_ONE_ALTERNATIVE` behavior that Dev-earlier's policy change
  removed; tests now assert `REQUIRE_MANUAL_SOURCE` after retry/permanent failure and add
  an explicit regression test asserting `TRY_ONE_ALTERNATIVE` is never returned for any
  input combination.
- **New unit tests for `LiveRollingBufferRecorder`** (`LiveRollingBufferRecorderTest.kt`):
  extracted its two pure/File-free pieces — channel-id sanitization and local-playlist-text
  building — into testable functions (`sanitizeChannelId`, `buildPlaylistText` +
  `PlaylistEntry`) with no behavior change, and added coverage for path-traversal
  sanitization, blank/overlong ids, Locale.US-forced EXTINF decimal formatting (regression
  guard for the earlier locale bug), entry ordering and target-duration rounding. The
  network/File-I/O parts of the recorder still need Robolectric or on-device testing.
- **New GitHub Actions CI** (`.github/workflows/android-ci.yml`): `build-and-test` job runs
  on every push/PR to main/master/dev (JDK 17, Gradle cache, `testDebugUnitTest`,
  `lintDebug`, `assembleDebug`, uploads APK + reports); `release-build` job runs only on
  `v*` tags, decodes a base64 keystore secret into a temp file and runs
  `assembleRelease bundleRelease` with the existing `BROTV_KEYSTORE`/`BROTV_STORE_PASSWORD`/
  `BROTV_KEY_ALIAS`/`BROTV_KEY_PASSWORD` signing env vars from `app/build.gradle.kts` — no
  new secrets scheme invented, matches the real single-`release`-buildType config (no
  product flavors).
- **Local-only crash logging** (no third-party service): new `CrashLogger` object installs
  a `Thread.setDefaultUncaughtExceptionHandler` wrapper in the new `BroTvApplication` class
  (`AndroidManifest.xml` now points `android:name` at it), writes timestamped crash reports
  to app-private storage (capped at 25 files, oldest pruned), and chains to any previous
  default handler. Settings now has a "crash reports" entry (data-only addition, no layout
  change) that lets the user view/share/clear recent reports via `ACTION_SEND`.
- Still not compiled or device-tested (no Android SDK/emulator in this workspace); CI is
  the first place these changes will actually build.

## Dev14: true 4K delivery + real HDMI 4K signal (StreamVault-parity)
- **Root cause found for "quality never reaches full/4K"**: `DefaultTrackSelector.Parameters.Builder(context)`
  in Media3 silently constrains adaptive (HLS/DASH) track selection to the device's *current*
  physical HDMI output resolution at the moment the player is built (its `viewport` default).
  If the box happens to be outputting 1080p (very common before the first 4K channel ever
  switches the TV), every 4K rendition in the master playlist is filtered out — regardless of
  `QualityMode.SOURCE`/`AUTO` or `setForceHighestSupportedBitrate(true)`. This was never a
  decoder or bandwidth limitation; it was an implicit, undocumented viewport cap.
  `PlayerEngine.buildQualityParameters` now explicitly clears that cap
  (`setViewportSize(Int.MAX_VALUE, Int.MAX_VALUE, true)`) for every quality mode, so the real
  ceiling is only ever the explicit `setMaxVideoSize` the user picked (or unlimited for
  AUTO/SOURCE).
- **New `player/DisplayModeSwitcher.kt`**: seamlessly switches the Activity window's actual
  HDMI output resolution/refresh rate (`Window.attributes.preferredDisplayModeId`, API 23+)
  to match the currently-playing content's real resolution, instead of always outputting at
  whatever mode the box booted into and upscaling internally. This is what makes a real 4K TV
  (e.g. LG) show its own genuine "4K" input-signal badge, because that badge reflects the
  actual HDMI signal, not anything the app claims. Mode selection logic
  (`bestMatchingModeId`) is pure/testable: prefers an exact resolution match (never
  needlessly upscales the physical signal for sub-4K content), and among same-resolution
  modes prefers a refresh rate that's an exact multiple of the content's frame rate (avoids
  judder on 24fps movies), falling back to the closest available resolution on TVs that don't
  support 4K at all. Wired into `FullPlayerActivity.onVideoInputFormatChanged` (reuses the
  existing "Match Frame Rate" preference — OFF disables both), reset to system default in
  `onDestroy`.
- `DisplayModeSwitcherTest.kt` added (7 pure-logic tests, no Android/Robolectric dependency).
- Not yet compiled or device-tested, same caveat as Dev11–13. A real 4K test stream and an
  actual 4K TV are needed to confirm the on-screen HDMI "4K" badge appears; the logic here is
  the same seamless-switching approach commercial Android TV apps use, but only a real device
  can confirm the specific TV firmware reports it.
- **In-app confirmation added per explicit request**: both `FullPlayerActivity` (live) and
  `VodPlayerActivity` (movies/series, previously had zero `DisplayModeSwitcher`/resolution
  wiring at all) now show a short Toast (`uhd_4k_activated` string, both locales) the moment
  content is verified ≥3840×2160 **and** `DisplayModeSwitcher.applyBestDisplayMode` confirms
  the actual applied HDMI mode is also ≥3840×2160 — i.e. only when the real output signal is
  4K, not just the source file. `applyBestDisplayMode` now returns the applied `ModeInfo?` (was
  `Unit`) so callers can verify this instead of assuming success. No layout/XML touched — the
  Toast needs no view changes. `VodPlayerActivity` also now calls `DisplayModeSwitcher.resetDisplayMode`
  in `onDestroy`, matching `FullPlayerActivity`.
